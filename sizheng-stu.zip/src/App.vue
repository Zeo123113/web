<template>
  <div id="app">
    <router-view v-if="isRouterAlive" />
    <Login></Login>
  </div>
</template>

<script>
import store from './store'
import Login from './views/login/index'
export default {
  name: 'App',
  components: {
    Login
  },
  provide() {
    return {
      reload: this.reload
    }
  },
  data() {
    return {
      isRouterAlive: true,
      screenWidth: document.body.clientWidth
    }
  },
  mounted: function() {
    // 监听浏览器窗口变化
    window.onresize = () => {
      this.screenWidth = document.body.clientWidth
      store.dispatch('app/setScreenWidth', this.screenWidth)
      if (this.screenWidth < 768) {
        //  当屏幕小于768时，设置Vuex里的数据为true
        store.dispatch('app/toggleDevice', 'modile')
      } else {
        //  反之，设置Vuex里的数据为false
        store.dispatch('app/toggleDevice', 'desktop')
      }
      // console.log(this.screenWidth)
    }
  },
  methods: {
    reload() {
      this.isRouterAlive = false
      this.$nextTick(function() {
        this.isRouterAlive = true
      })
    }
  }
}
</script>
<style lang="scss">
.icon {
  width: 1em;
  height: 1em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
.el-loading-mask {
  z-index: 1000 !important;
}
@media screen and (max-width: 768px) {
  #app {
    background-color: none;
  }
}
@media screen and (min-width: 768px) {
  #app {
    background-color: #f8f8f8;
  }
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  // text-align: center;
  color: #2c3e50;
  // background-color: #F8F8F8;
}
.v-modal {
  z-index: 200 !important;
}
.el-upload__input {
  display: none !important;
}
ul ol {
  list-style: none;
}
.el-pagination {
  text-align: center;
}
.el-dialog__wrapper {
  z-index: 1300 !important;
}
</style>
