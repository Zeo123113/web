/**
 * @description 分类分组管理
 * @author cuipengyuan
 */
import request from '@/utils/request'

export default {
  // 分类一级列表展示
  getCateNameList() {
    return request({
      url: '/course/category/getCateNameList',
      method: 'post'
    })
  },
  // 分类非一级列表展示
  getCateNameOthersList() {
    return request({
      url: '/course/category/getCateNameOthersList',
      method: 'post'
    })
  },
  // 分类列表展示
  getCategoryList(body) {
    return request({
      url: '/course/category/list',
      method: 'post',
      data: body
    })
  },
  // 分类组列表查询
  getCategoryGroupList(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/category-group/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 查询所有的分类组
  getAll() {
    return request({
      url: '/course/category-group/getAll',
      method: 'get'
    })
  },
  // 查询分类树形
  getTree() {
    return request({
      url: '/course/category/getTree',
      method: 'get'
    })
  },
  // 添加分组类
  addCategoryGroup(body) {
    return request({
      url: '/course/category-group/add',
      method: 'post',
      data: body
    })
  },
  // 添加类别
  addCategory(body) {
    return request({
      url: '/course/category/add',
      method: 'post',
      data: body
    })
  },
  // 修改分类组
  editCategoryGroup(body) {
    return request({
      url: '/course/category-group/edit',
      method: 'put',
      data: body
    })
  },
  // 修改类别
  editCategory(body) {
    return request({
      url: '/course/category/update',
      method: 'put',
      data: body
    })
  },
  // 删除分类
  deleteCategory(Id) {
    return request({
      url: '/course/category/delete/' + Id,
      method: 'delete'
    })
  },
  // 删除分类组
  deleteCategoryGroup(cgId) {
    return request({
      url: '/course/category-group/delete/' + cgId,
      method: 'delete'
    })
  },
  // 批量删除分类组
  deleteBatchCategoryGroup(data) {
    return request({
      url: '/course/category-group/deletebatch',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 验证分类编码
  validateCateCode(data) {
    const params = new URLSearchParams()
    params.append('validateCateCode', data)
    return request({
      url: '/course/category/validateCateCode',
      method: 'post',
      params: params
    })
  },
  // 验证分类名称
  validateCateName(data, parentId) {
    const params = new URLSearchParams()
    params.append('validateCateName', data)
    params.append('parentId', parentId)
    return request({
      url: '/course/category/validateCateName',
      method: 'post',
      params: params
    })
  },
  // 验证分类分组编码
  validateCgCode(data) {
    const params = new URLSearchParams()
    params.append('validateCgCode', data)
    return request({
      url: '/course/category-group/validateCgCode',
      method: 'post',
      params: params
    })
  },
  // 验证分类分组名称
  validateCgName(data) {
    const params = new URLSearchParams()
    params.append('validateCgName', data)
    return request({
      url: '/course/category-group/validateCgName',
      method: 'post',
      params: params
    })
  }
}
