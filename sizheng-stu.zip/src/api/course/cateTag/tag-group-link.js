/**
 * @description 标签分组纽带管理
 * @author chengguangyuan
 */

import request from '@/utils/request'

export default {
  getTagGroupLink(data) {
    return request({
      url: '/course/tag-group-link/getById',
      method: 'post',
      data
    })
  },
  addtagGroupLink(data) {
    return request({
      url: '/course/tag-group-link/add',
      method: 'post',
      data
    })
  },
  updatetagGroupLink(data) {
    return request({
      url: '/course/tag-group-link/update',
      method: 'put',
      data
    })
  },
  gettagGroupLinkList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/tag-group-link/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  deltagGroupLink(data) {
    return request({
      url: '/course/tag-group-link/delete',
      method: 'delete',
      params: { ids: data }
    })
  }
}
