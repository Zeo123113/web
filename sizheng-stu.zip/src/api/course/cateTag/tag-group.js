/**
 * @description 标签分组管理
 * @author chengguangyuan
 */

import request from '@/utils/request'

export default {
  addtagGroup(data) {
    return request({
      url: '/course/tag-group/add',
      method: 'post',
      data
    })
  },
  updatetagGroup(data) {
    return request({
      url: '/course/tag-group/update',
      method: 'put',
      data
    })
  },
  gettagGroupList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/tag-group/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  deltagGroup(data) {
    return request({
      url: '/course/tag-group/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getTagGroup(id) {
    return request({
      url: '/course/tag-group/getById/' + id,
      method: 'get'
    })
  }
}
