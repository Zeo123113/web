/**
 * @description 标签管理
 * @author chengguangyuan
 */

import request from '@/utils/request'

export default {
  addTag(data) {
    return request({
      url: '/course/tag/add',
      method: 'post',
      data
    })
  },
  updateTag(data) {
    return request({
      url: '/course/tag/update',
      method: 'put',
      data
    })
  },
  getTagList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/tag/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  deltag(data) {
    return request({
      url: '/course/tag/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getTag(id) {
    return request({
      url: '/course/tag/getById/' + id,
      method: 'get'
    })
  }
}
