/**
 * @description 课程照片管理接口
 * @author LHZ
 */
import request from '@/utils/request'

export default {
  // 列表展示
  listClassPhoto(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/class-photo/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加学员
  addEntry(data) {
    return request({
      url: '/course/class-photo/add',
      method: 'post',
      data
    })
  },
  // 修改学员
  updateEntry(data) {
    return request({
      url: '/course/class-photo/update',
      method: 'put',
      data
    })
  },
  // 批量删除学员
  batchDelete(data) {
    return request({
      url: '/course/class-photo/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除学员分组
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/class-photo/batchDelete',
      method: 'post',
      data: criteria
    })
  }
}
