import request from '@/utils/request'

export default {
  // 查询助教列表
  listCourseAssistant(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/courseAssistant/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 新增助教
  addCourseAssistant(data) {
    return request({
      url: '/course/courseAssistant/add',
      method: 'post',
      data: data
    })
  },
  // 修改助教
  updateCourseAssistant(data) {
    return request({
      url: '/course/courseAssistant/edit',
      method: 'put',
      data: data
    })
  },
  // 单条删除助教
  delCourseAssistant(taId) {
    return request({
      url: `/course/courseAssistant/${taId}`,
      method: 'delete'
    })
  },
  // 批量删除助教
  batchDelete(data) {
    return request({
      url: '/course/courseAssistant/batchDeleteByIds',
      method: 'delete',
      data: data
    })
  },
  // 按筛选条件删除助教
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/courseAssistant/realDelete',
      method: 'post',
      data: criteria
    })
  }

}
