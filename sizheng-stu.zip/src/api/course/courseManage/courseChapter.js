/**
 * @description 课程章节管理接口
 * @author zhouhuan
 */

import request from '@/utils/request'

export default {
  /**
  * 根据课程章节schemeId，获取其下面的单元courseChapter
  * @author:chengguangyuan
  */
  getFrontlist(schemeId) {
    return request({
      url: `/course/course-chapter/getFrontlist/${schemeId}`,
      method: 'get'
    })
  },
  /**
  * 根据课程章节schemeId，获取其下面的单元courseChapter
  * @author:chengguangyuan
  */
  getCourseChapterTreeBySchemeId(schemeId) {
    return request({
      url: `/course/course-chapter/getCourseChapterTreeBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  /**
  * 根据课程章节schemeId，获取其下面的单元courseChapter
  * @author:chengguangyuan
  */
  getCourseChapterBySchemeId(schemeId) {
    return request({
      url: `/course/course-chapter/getCourseChapterBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  // 查询课程章节列表
  listcourseChapter(query) {
    return request({
      url: '/course/course-chapter/list',
      method: 'post',
      data: query
    })
  },
  // 根据课程章节ID查询课程章节详细信息
  getCourseChapter(chapterId) {
    return request({
      url: '/course/course-chapter/selectCourseChapterById/' + chapterId,
      method: 'get'
    })
  },
  // 查询课程章节下拉树结构
  treeselect() {
    return request({
      url: '/course/course-chapter/tree',
      method: 'get'
    })
  },
  // 新增课程章节
  addChapter(data) {
    return request({
      url: '/course/course-chapter/addChapter',
      method: 'post',
      data: data
    })
  },
  // 新增课程章节
  addCourseChapter(data) {
    return request({
      url: '/course/course-chapter/add',
      method: 'post',
      data: data
    })
  },
  // 修改课程章节
  updateCourseChapter(data) {
    return request({
      url: '/course/course-chapter/update',
      method: 'put',
      data: data
    })
  },
  // 前端删除课程章节
  deleteFront(chapterId) {
    return request({
      url: '/course/course-chapter/deleteFront/' + chapterId,
      method: 'delete'
    })
  },
  // 删除课程章节
  delCourseChapter(chapterId) {
    return request({
      url: '/course/course-chapter/delete/' + chapterId,
      method: 'delete'
    })
  },
  // 发布课程章节
  releaseCourseChapter(chapterId) {
    return request({
      url: '/course/course-chapter/release/' + chapterId,
      method: 'get'
    })
  }
}
