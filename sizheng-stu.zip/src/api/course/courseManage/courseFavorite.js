/**
 * @description 课程收藏管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getCourseFavoriteList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-favorite/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加课程收藏
  add(data) {
    return request({
      url: '/course/course-favorite/add',
      method: 'post',
      data
    })
  },
  // 修改课程收藏
  update(data) {
    return request({
      url: '/course/course-favorite/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除课程收藏
  delete(data) {
    return request({
      url: '/course/course-favorite/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除
  deleteByConditions(data) {
    return request({
      url: '/course/course-favorite/deleteByConditions',
      method: 'delete',
      data
    })
  },
  // 根据 csId ctId schemeId userId courseType 查询课程收藏
  getCourseFavList(body) {
    return request({
      url: `/course/course-favorite/selectCourseFavoriteList`,
      method: 'post',
      data: body
    })
  }

}
