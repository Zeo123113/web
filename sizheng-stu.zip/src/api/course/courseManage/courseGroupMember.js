/**
 * @description 课程分组学员管理接口
 * @author LHZ
 */
import request from '@/utils/request'

export default {
  // 列表展示
  listCourseGroupMember(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-member/list',
      method: 'post',
      data: body,
      params: params
    })
  }
}
