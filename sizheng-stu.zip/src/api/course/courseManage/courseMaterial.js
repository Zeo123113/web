/**
 * @description 课程资源文件管理接口
 * @author zhouhuan
 */

import request from '@/utils/request'

export default {
  // 查询课程资料列表
  getcourseMaterialBySchemeId(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/courseMaterial/getcourseMaterialBySchemeId',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 查询课程资料列表
  listCourseMaterial(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/courseMaterial/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 新增课程资料
  addCourseMaterial(data) {
    return request({
      url: '/course/courseMaterial/add',
      method: 'post',
      data: data
    })
  },
  // 修改课程资料
  updateCourseMaterial(data) {
    return request({
      url: '/course/courseMaterial/update',
      method: 'put',
      data: data
    })
  },
  // 单条删除课程资料
  delCourseMaterial(materialId) {
    return request({
      url: `/course/courseMaterial/delete/${materialId}`,
      method: 'delete'
    })
  },
  // 批量删除课程资料
  batchDelete(data) {
    return request({
      url: '/course/courseMaterial/batchDeleteByIds',
      method: 'delete',
      data: data
    })
  },
  // 按筛选条件删除课程资料
  batchDeleteByCriteria(data) {
    return request({
      url: '/course/courseMaterial/realDelete',
      method: 'post',
      data: data
    })
  },
  // 根据课程资料Id查询课程资料
  getById(materialId) {
    return request({
      url: `/course/courseMaterial/getById/${materialId}`,
      method: 'get'
    })
  }
}
