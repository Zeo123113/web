/**
 * @description 课程分组学员管理接口
 * @author LHZ
 */
import request from '@/utils/request'

export default {
  // 列表展示
  listCourseMember(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-member/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加学员
  addEntry(data) {
    return request({
      url: '/course/course-member/add',
      method: 'post',
      data
    })
  },
  // 判断该用户是否加入了该课程计划
  isJoinCourseScheme(data) {
    return request({
      url: '/course/course-member/isJoinCourseScheme',
      method: 'post',
      data
    })
  },
  // 根据userId,stuId,realName,schemeId,添加到默认分组里
  joinCourseMember(data) {
    return request({
      url: '/course/course-member/joinCourseMember',
      method: 'post',
      data
    })
  },
  // 修改学员
  updateEntry(data) {
    return request({
      url: '/course/course-member/update',
      method: 'put',
      data
    })
  },
  // 批量删除学员
  batchDelete(data) {
    return request({
      url: '/course/course-member/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除学员分组
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-member/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  /**
   *根据学员分组ID查找学员列表
   * @author:yangxiao
   */
  getCourseMemberListByMgId(mgId) {
    return request({
      url: `/course/course-member/getCourseMemberListByMgId/${mgId}`,
      method: 'get'
    })
  },
  /**
  *根据用户id查找授课计划列表
  * @author:cgy
  */
  getCourseSchemesByUserId(userId) {
    return request({
      url: `/course/course-member/getCourseSchemesByUserId/${userId}`,
      method: 'get'
    })
  },
  // 添加学员,在用户表中添加
  addStuUser(data) {
    return request({
      url: '/course/course-member/addStudentUser',
      method: 'post',
      data
    })
  },
  // 移动学员
  move(data, mgId) {
    return request({
      url: `/course/course-member/move/${mgId}`,
      method: 'post',
      params: { ids: data }
    })
  },
  /**
   *根据学员分组ID查找学员列表,本分组学员及以下学员
   * @author:yangxiao
   */
  getCourseMembersByMgId(mgId) {
    return request({
      url: `/course/course-member/getCourseMembersByMgId/${mgId}`,
      method: 'get'
    })
  }
}
