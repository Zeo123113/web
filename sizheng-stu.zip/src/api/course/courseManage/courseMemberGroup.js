/**
 * @description 学员分组管理接口
 * @author LHZ
 */
import request from '@/utils/request'

export default {
  // 列表展示
  listCourseMemberGroup(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-member-group/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  /**
   * 根据根据父节点编号查询学员分组
   */
  getCourseMemberGroupListByParentId(parentId, delFlag) {
    return request({
      url: `/course/course-member-group/getCourseMemberGroupListByParentId/${parentId}/${delFlag}`,
      method: 'get'
    })
  },
  /**
   * 根据授课方案编号查询学员分组列表，包括课程分组和考试分组
   */
  getGroupBySchemeId(schemeId) {
    return request({
      url: `/course/course-member-group/getGroupBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  /**
   * 根据授课方案编号查询课程学员分组列表
   */
  getCourseMemberGroupBySchemeId(schemeId) {
    return request({
      url: `/course/course-member-group/getCourseMemberGroupBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  /**
   * 根据授课方案编号查询考试学员分组列表
   */
  getExamMemberGroupBySchemeId(schemeId) {
    return request({
      url: `/course/course-member-group/getExamMemberGroupBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  // 添加学员分组
  addEntry(data) {
    return request({
      url: '/course/course-member-group/add',
      method: 'post',
      data
    })
  },
  // 修改学员分组
  updateEntry(data) {
    return request({
      url: '/course/course-member-group/update',
      method: 'put',
      data
    })
  },
  // 批量删除学员分组
  batchDelete(data) {
    return request({
      url: '/course/course-member-group/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除学员分组
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-member-group/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  // 物理删除已被删除的记录
  realDelete(data) {
    return request({
      url: '/course/course-member-group/realDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件物理删除已被删除的记录
  realDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-member-group/realDelete',
      method: 'post',
      data: criteria
    })
  },
  // 批量还原学员分组
  batchRecall(data) {
    return request({
      url: '/course/course-member-group/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件批量还原学员分组
  batchRecallByCriteria(criteria) {
    return request({
      url: '/course/course-member-group/batchRecall',
      method: 'post',
      data: criteria
    })
  },
  // 复制移动分组操作
  copyMoveGroup(params) {
    return request({
      url: '/course/course-member-group/copyMoveGroup',
      method: 'post',
      data: params
    })
  },
  /**
   * 根据课程学期编号查询考试学员分组列表
   */
  getExamMemberGroupByCtId(ctId) {
    return request({
      url: `/course/course-member-group/getExamMemberGroupByCtId/${ctId}`,
      method: 'get'
    })
  },

  /**
   * 根据课程学期编号查询课程学员分组列表
   */
  getCourseMemberGroupByCtId(ctId) {
    return request({
      url: `/course/course-member-group/getCourseMemberGroupByCtId/${ctId}`,
      method: 'get'
    })
  },
  // 列表展示,用于教师端管理树形结构展示
  getList(body) {
    return request({
      url: '/course/course-member-group/getList',
      method: 'post',
      data: body
    })
  },
  /**
   * 获取最热小组
   * @author: cpy
   */
  getHotGroup() {
    return request({
      url: `/course/course-member-group/getHotGroup`,
      method: 'get'
    })
  },
  /**
   * 根据Id查询分组
   */
  getGroupById(mgId) {
    return request({
      url: `/course/course-member-group/getGroupById/${mgId}`,
      method: 'get'
    })
  },
  // 检查分组学员数量是否合法
  checkGroupMemberCountLegal(data) {
    return request({
      url: '/course/course-member-group/checkGroupMemberCountLegal',
      method: 'post',
      data: data
    })
  },
  /**
   * 根据课程学期编号查询学期编号为0的考试学员分组列表
   */
  getExamMemberGroupByCtIdAndSchemeId(ctId) {
    return request({
      url: `/course/course-member-group/getExamMemberGroupByCtIdAndSchemeId/${ctId}`,
      method: 'get'
    })
  }
}
