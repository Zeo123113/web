import request from '@/utils/request'

export default {
  // 新增课程笔记
  addCourseNote(data) {
    return request({
      url: '/course/course-note/add',
      method: 'post',
      data: data
    })
  },
  // 批量和单条删除
  delete(data) {
    return request({
      url: '/course/course-note/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除
  deleteByConditions(data) {
    return request({
      url: '/course/course-note/deleteByConditions',
      method: 'delete',
      data
    })
  },
  // 列表展示
  listCourseNote(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-note/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 更新
  updateCourseNote(data) {
    return request({
      url: '/course/course-note/update',
      method: 'put',
      data
    })
  },
  // 根据用户编号获取用户笔记 带有编号
  selectCourseNoteAndCourseByUserId(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-note/selectCourseNoteAndCourseByUserId',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据课程获取用户笔记
  selectCourseNoteByCourse(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-note/selectCourseNoteByCourse',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 点赞笔记
  giveLike(data) {
    return request({
      url: '/course/course-note/giveLike',
      method: 'put',
      data
    })
  },
  // 修改课程笔记内容
  updateNoteContent(data) {
    return request({
      url: '/course/course-note/updateNoteContent',
      method: 'put',
      data
    })
  },
  // 根据笔记编号获取笔记详情
  getByNoteId(nodeId) {
    return request({
      url: `/course/course-note/getById/` + nodeId,
      method: 'get'
    })
  },
  // 可以传入 csId ctId schemeId userId noteStatus 参数查询笔记
  getCourseNoteList(body) {
    return request({
      url: '/course/course-note/list/getCourseNoteList',
      method: 'post',
      data: body
    })
  }

}
