/**
 * @description 课程公告管理
 * @author chengguangyuan
 */

import request from '@/utils/request'

export default {
  addcourseNotice(data) {
    return request({
      url: '/course/course-notice/add',
      method: 'post',
      data
    })
  },
  updatecourseNotice(data) {
    return request({
      url: '/course/course-notice/update',
      method: 'put',
      data
    })
  },
  getcourseNoticeList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-notice/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  delcourseNotice(data) {
    return request({
      url: '/course/course-notice/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getCourseNoticeList(body) {
    return request({
      url: 'course/course-notice/getCourseNoticeList',
      method: 'post',
      data: body
    })
  }
}
