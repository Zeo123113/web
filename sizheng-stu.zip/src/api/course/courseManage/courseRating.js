/**
 * @description 课程评分管理接口
 * @author zhouhuan
 */
import request from '@/utils/request'

export default {
  /**
  * 根据授课方案编号查询课程评分列表
  * @author:chengguagnyuan
  */
  getCourseRatingBySchemeId(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-rating/getCourseRatingBySchemeId',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据查询条件查询课程评分分页数据列表
  getCourseRatingByCondition(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-rating/list',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 根据课程评分ID查询课程评分详细信息
  getCourseRating(crId) {
    return request({
      url: '/course/course-rating/selectCourseRatingById/' + crId,
      method: 'get'
    })
  },
  // 新增课程评分
  addCourseRating(data) {
    return request({
      url: '/course/course-rating/add',
      method: 'post',
      data: data
    })
  },
  // 修改课程评分
  updateCourseRating(data) {
    return request({
      url: '/course/course-rating/update',
      method: 'put',
      data: data
    })
  },
  // 删除课程评分
  delCourseRating(crId) {
    return request({
      url: '/course/course-rating/delete/' + crId,
      method: 'delete'
    })
  },
  // 批量删除课程评分
  delTypeList(data) {
    return request({
      url: '/course/course-rating/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据课程Id查询三条评分最高的评分,首页展示
  selectCourseRatingByCourseId(csId) {
    return request({
      url: '/course/course-rating/selectCourseRatingByCourseId/' + csId,
      method: 'get'
    })
  }
}
