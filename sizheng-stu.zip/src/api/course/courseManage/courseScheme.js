/**
 * @description 授课计划管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 验证加入课程的密码
  validateJoinPassword(data) {
    return request({
      url: '/course/course-scheme/validateJoinPassword',
      method: 'post',
      data
    })
  },
  // 验证开课学期是否唯一
  validateSchemeTitle(data) {
    return request({
      url: '/course/course-scheme/validateSchemeTitle',
      method: 'post',
      data
    })
  },
  // 列表展示
  getCoursesByTeacherUserId(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-scheme/getCoursesByTeacherUserId',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据主键查询实体信息
  getOneById(id) {
    return request({
      url: '/course/course-scheme/getById/' + id,
      method: 'get'
    })
  },
  // 根据主键查询实体信息
  getCourseSetById(id) {
    return request({
      url: '/course/course-scheme/getCourseSetById/' + id,
      method: 'get'
    })
  },
  /**
   * 根据课程学期Id查找其下教学方案
   * @author:chengguangyuan
   */
  getCourseSchemeByCourseTermId(courseTermId) {
    return request({
      url: `/course/course-scheme/getCourseSchemeByCourseTermId/${courseTermId}`,
      method: 'get'
    })
  },
  // 列表展示
  getCourseSchemeList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-scheme/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 首页列表展示
  getCourseSchemeFrontList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-scheme/frontList',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加授课计划
  add(data) {
    return request({
      url: '/course/course-scheme/add',
      method: 'post',
      data
    })
  },
  // 复制授课计划
  copyBySchemeId(data) {
    return request({
      url: '/course/course-scheme/copyBySchemeId',
      method: 'post',
      data
    })
  },
  // 修改授课计划
  update(data) {
    return request({
      url: '/course/course-scheme/update',
      method: 'put',
      data
    })
  },
  // 批量删除授课计划(逻辑删除)
  batchDelete(data) {
    return request({
      url: '/course/course-scheme/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量还原授课计划
  batchRecall(data) {
    return request({
      url: '/course/course-scheme/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量删除授课计划（真删除）
  realDelete(data) {
    return request({
      url: '/course/course-scheme/realDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件清空授课计划
  realDeleteByCondtions(data) {
    return request({
      url: '/course/course-scheme/realDeleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 根据条件删除授课计划
  deleteByCondtions(data) {
    return request({
      url: '/course/course-scheme/deleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 根据条件恢复授课计划
  recallByCondtions(data) {
    return request({
      url: '/course/course-scheme/recallByCondtions',
      method: 'delete',
      data
    })
  },
  // 根据课程学期获取授课方案
  getCourseSchemePageByCtId(ctId, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: `/course/course-scheme/getCourseSchemePageByCtId/${ctId}`,
      method: 'get',
      params: params
    })
  },
  // 根据课程设置获取授课方案
  getCourseSchemeByCsId(csId, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: `/course/course-scheme/getCourseSchemeByCsId/${csId}`,
      method: 'get',
      params: params
    })
  }
}
