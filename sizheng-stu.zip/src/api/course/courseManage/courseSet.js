/**
 * @description 课程设置管理接口
 * @author LiGuanJing
 */
import request from '@/utils/request'

export default {
  // 根据主键查询默认的计划
  getDefaultCourseSchemeById(id) {
    return request({
      url: '/course/course-set/getDefaultCourseSchemeById/' + id,
      method: 'get'
    })
  },
  // 根据主键查询实体信息
  getOneById(id) {
    return request({
      url: '/course/course-set/getById/' + id,
      method: 'get'
    })
  },
  // 根据教师id查找课程详情
  getCourseSetByTeaUserId(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-set/getCourseSetByTeaUserId',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 首页列表展示
  getCourseSetFrontList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-set/frontList',
      method: 'post',
      data: body,
      params: params
    })
  },
  /** 根据机构编号获取课程信息列表
   * @author: lhz
  */
  getCourseListByOrgId(orgId) {
    return request({
      url: `/course/course-set/getCourseListByOrgId/${orgId}`,
      method: 'get'
    })
  },
  /** 根据查询条件获取列表
   * @author: liguanjing
  */
  getCourseSetList(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-set/listCourseSet',
      method: 'post',
      data: body,
      params: params
    })
  },
  /** 新增课程
  * @author: liguanjing
 */
  addCourseSet(courseSet) {
    return request({
      url: '/course/course-set/add',
      method: 'post',
      data: courseSet
    })
  },
  /** 批量删除
  * @author: liguanjing
 */
  batchDelete(data) {
    return request({
      url: '/course/course-set/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件批量删除课程
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-set/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  // 物理删除已被删除的记录
  realDelete(data) {
    return request({
      url: '/course/course-set/realDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件物理删除已被删除的记录
  realDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-set/realDelete',
      method: 'post',
      data: criteria
    })
  },
  // 批量还原学期
  batchRecall(data) {
    return request({
      url: '/course/course-set/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件批量还原学期
  batchRecallByCriteria(criteria) {
    return request({
      url: '/course/course-set/batchRecall',
      method: 'post',
      data: criteria
    })
  },
  // 修改课程信息
  updateCourseSet(data) {
    return request({
      url: '/course/course-set/update',
      method: 'put',
      data
    })
  },
  /**
   *根据学员分组ID查找学员列表
   * @author:cpy
   */
  getCourseSetByUserId(data, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: `/course/course-set/getCourseSetByUserId`,
      method: 'post',
      params: params,
      data: data
    })
  },
  /**
   *根据学员分组ID查找学员列表
   * @author:cpy
   */
  selectCourseFavorite(data, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: `/course/course-set/selectCourseFavorite`,
      method: 'post',
      params: params,
      data: data
    })
  },
  /**
   * 通过评分查询三门课程用于首页展示
   */
  getThreeCourseByRating() {
    return request({
      url: `/course/course-set/getThreeCourseByRating`,
      method: 'get'
    })
  },
  /**
   * 不分页查询教师课程
   */
  getCourseByTeacher(body) {
    return request({
      url: `/course/course-set/getCourseByTeacher`,
      method: 'post',
      data: body
    })
  }
}
