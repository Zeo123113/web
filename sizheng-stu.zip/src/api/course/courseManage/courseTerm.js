/**
 * @description 课程学期管理接口
 * @author LHZ
 */
import request from '@/utils/request'

export default {
  // 列表展示
  listCourseTerms(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-term/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  /**
   * 根据课程Id查找学期列表
   * @author:yangxiao
   */
  getTermPageByCId(courseSetId, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: `/course/course-term/getTermPageByCId/${courseSetId}`,
      method: 'get',
      params: params
    })
  },
  /**
   * 根据课程Id查找学期列表
   * @author:yangxiao
   */
  getCourseTermByCourseSetId(courseSetId) {
    return request({
      url: `/course/course-term/getCourseTermByCourseSetId/${courseSetId}`,
      method: 'get'
    })
  },
  /**
   * 根据计划Id查找学期
   * @author:yangxiao
   */
  getCourseTermBySchemeId(schemeId) {
    return request({
      url: `/course/course-term/getCourseTermBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  /**
   * 根据学期Id查找学期
   * @author:yangxiao
   */
  getCourseTermById(courseTermId) {
    return request({
      url: `/course/course-term/getCourseTermById/${courseTermId}`,
      method: 'get'
    })
  },
  // 验证开课学期是否唯一
  validateCourseTerm(data) {
    return request({
      url: '/course/course-term/validateCourseTerm',
      method: 'post',
      data
    })
  },
  // 添加学期
  addEntry(data) {
    return request({
      url: '/course/course-term/add',
      method: 'post',
      data
    })
  },
  // 修改学期
  updateEntry(data) {
    return request({
      url: '/course/course-term/update',
      method: 'put',
      data
    })
  },
  // 批量删除学期
  batchDelete(data) {
    return request({
      url: '/course/course-term/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除学期
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-term/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  // 物理删除已被删除的记录
  realDelete(data) {
    return request({
      url: '/course/course-term/realDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件物理删除已被删除的记录
  realDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-term/realDelete',
      method: 'post',
      data: criteria
    })
  },
  // 批量还原学期
  batchRecall(data) {
    return request({
      url: '/course/course-term/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件批量还原学期
  batchRecallByCriteria(criteria) {
    return request({
      url: '/course/course-term/batchRecall',
      method: 'post',
      data: criteria
    })
  }
}
