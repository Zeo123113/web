/**
 * @description 授权单元管理
 * @author chengguangyuan
 */

import request from '@/utils/request'

export default {
  /**
   * 没有章节时候，从教学方案中获得课程单元
   * @author:chengguangyuan
   */
  getRefUnitBySchemeId(schemeId) {
    return request({
      url: `/course/course-unit/getRefUnitBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  /**
  * 根据课程章节chapterId，获取其下面的单元courseUnit
  * @author:chengguangyuan
  */
  getUnitsByChapterId(chapterId) {
    return request({
      url: `/course/course-unit/getUnitsByChapterId/${chapterId}`,
      method: 'get'
    })
  },
  addcourseUnit(data) {
    return request({
      url: '/course/course-unit/add',
      method: 'post',
      data
    })
  },
  addFrontByChapterId(data) {
    return request({
      url: '/course/course-unit/addFrontByChapterId',
      method: 'post',
      data
    })
  },
  updatecourseUnit(data) {
    return request({
      url: '/course/course-unit/update',
      method: 'put',
      data
    })
  },
  getcourseUnitList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-unit/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 批量删除授课计划(逻辑删除)
  batchDelete(data) {
    return request({
      url: '/course/course-unit/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量还原授课计划
  batchRecall(data) {
    return request({
      url: '/course/course-unit/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量删除授课计划（真删除）
  realDelete(data) {
    return request({
      url: '/course/course-unit/realDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件清空授课计划
  realDeleteByCondtions(data) {
    return request({
      url: '/course/course-unit/realDeleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 根据条件删除授课计划
  deleteByCondtions(data) {
    return request({
      url: '/course/course-unit/deleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 根据条件恢复授课计划
  recallByCondtions(data) {
    return request({
      url: '/course/course-unit/recallByCondtions',
      method: 'delete',
      data
    })
  }
}
