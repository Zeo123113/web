/**
 * @description 考试分组学员管理接口
 * @author LHZ
 */
import request from '@/utils/request'

export default {
  // 列表展示
  listExamGroupMember(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/exam-group-member/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加学员
  addEntry(data) {
    return request({
      url: '/course/exam-group-member/add',
      method: 'post',
      data
    })
  },
  // 修改学员
  updateEntry(data) {
    return request({
      url: '/course/exam-group-member/update',
      method: 'put',
      data
    })
  },
  // 批量删除学员
  batchDelete(data) {
    return request({
      url: '/course/exam-group-member/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除学员分组
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/exam-group-member/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  // 根据考试分组Id获取考试分组学员个数
  getMemberCountByExamGroup(id) {
    return request({
      url: `/course/exam-group-member/getMemberCountByExamGroup/${id}`,
      method: 'get'
    })
  },
  // 移动学员
  move(data, mgId) {
    return request({
      url: `/course/exam-group-member/move/${mgId}`,
      method: 'post',
      params: { ids: data }
    })
  }
}
