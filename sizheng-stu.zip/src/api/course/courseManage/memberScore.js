/**
 * @description 学员成绩管理
 * @author cuipengyuan
 */

import request from '@/utils/request'

export default {
  // 查询学员成绩列表
  listMemberScore(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-member-score/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加学员成绩列表
  add(data) {
    return request({
      url: '/course/course-member-score/add',
      method: 'post',
      data
    })
  },
  // 修改学员成绩列表
  edit(data) {
    return request({
      url: '/course/course-member-score/edit',
      method: 'put',
      data
    })
  },
  // 单条删除学员成绩列表
  delete(msId) {
    return request({
      url: `/course/course-member-score/delete/` + msId,
      method: 'delete'
    })
  },
  // 批量删除学员成绩列表
  deleteBatch(data) {
    return request({
      url: `/course/course-member-score/deletebatch`,
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量恢复学员成绩列表
  recallBatch(data) {
    return request({
      url: `/course/course-member-score/recallbatch`,
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除学员成绩列表
  deleteByCondtions(data) {
    return request({
      url: '/course/course-member-score/deleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 按条件恢复学员成绩列表
  recallByCondtions(data) {
    return request({
      url: '/course/course-member-score/recallByCondtions',
      method: 'delete',
      data
    })
  },
  // 按条件清空
  realDeleteByCondtions(data) {
    return request({
      url: '/course/course-member-score/realDeleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 按id清空
  realDeleteByIds(data) {
    return request({
      url: '/course/course-member-score/realDeleteByIds',
      method: 'delete',
      params: { ids: data }
    })
  }
}
