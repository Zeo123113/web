import request from '@/utils/request'

export default {
  // 某人给某笔记点赞
  addNoteLike(data) {
    return request({
      url: '/course/note-like/addNoteLike',
      method: 'post',
      data: data
    })
  },
  // 判断用户是否点过赞
  isLikeByUserId(data) {
    return request({
      url: '/course/note-like/isLikeByUserId',
      method: 'post',
      data: data
    })
  }
}
