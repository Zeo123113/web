/**
 * @description 学员成绩管理
 * @author cuipengyuan
 */

import request from '@/utils/request'

export default {
  /**
   * 根据教学方案Id查找其下课程成绩设置
   * @author:chengguangyuan
   */
  getScoreSettingBySchemeId(schemeId) {
    return request({
      url: `/course/course-score-setting/getScoreSettingBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  // 查询课程成绩设置列表
  listScoreSetting(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-score-setting/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加课程成绩设置列表
  add(data) {
    return request({
      url: '/course/course-score-setting/add',
      method: 'post',
      data
    })
  },
  // 修改课程成绩设置列表
  edit(data) {
    return request({
      url: '/course/course-score-setting/edit',
      method: 'put',
      data
    })
  },
  // 单条删除课程成绩设置列表
  delete(cssId) {
    return request({
      url: `/course/course-score-setting/delete/` + cssId,
      method: 'delete'
    })
  },
  // 批量删除课程成绩设置列表
  deleteBatch(data) {
    return request({
      url: `/course/course-score-setting/deletebatch`,
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量恢复课程成绩设置列表
  recallBatch(data) {
    return request({
      url: `/course/course-score-setting/recallbatch`,
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除课程成绩设置列表
  deleteByCondtions(data) {
    return request({
      url: '/course/course-score-setting/deleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 按条件恢复课程成绩设置列表
  recallByCondtions(data) {
    return request({
      url: '/course/course-score-setting/recallByCondtions',
      method: 'delete',
      data
    })
  },
  // 按条件清空
  realDeleteByCondtions(data) {
    return request({
      url: '/course/course-score-setting/realDeleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 按id清空
  realDeleteByIds(data) {
    return request({
      url: '/course/course-score-setting/realDeleteByIds',
      method: 'delete',
      params: { ids: data }
    })
  }
}
