import request from '@/utils/request'

export default {
  /**
   * 获取前topCount名的教师信息
   * @author:chengguangyuan
   */
  getBySeqDesByTopCount(topCount) {
    return request({
      url: `/course/teacherTeam/getBySeqDes/${topCount}`,
      method: 'get'
    })
  },
  // 查询教师团队列表
  listTeacherTeam(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/teacherTeam/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 新增教师团队
  addTeacherTeam(data) {
    return request({
      url: '/course/teacherTeam/add',
      method: 'post',
      data: data
    })
  },
  // 修改教师团队
  updateTeacherTeam(data) {
    return request({
      url: '/course/teacherTeam/edit',
      method: 'put',
      data: data
    })
  },
  // 单条删除教师
  delTeacherTeam(teacherId) {
    return request({
      url: `/course/teacherTeam/${teacherId}`,
      method: 'delete'
    })
  },
  // 批量删除教师
  batchDelete(data) {
    return request({
      url: '/course/teacherTeam/batchDeleteByIds',
      method: 'delete',
      data: data
    })
  },
  // 根据用户Id列表查询用户登录名,头像列表
  getTeaUserIdsByIds(data) {
    return request({
      url: '/course/teacherTeam/getTeaUserIdsByIds',
      method: 'post',
      params: { teacherIds: data }
    })
  },
  // 按筛选条件删除教师
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/teacherTeam/realDelete',
      method: 'post',
      data: criteria
    })
  },
  // 通过orgId获得部门及一下的教师
  getUserListByOrgId(orgId) {
    return request({
      url: `course/teacherTeam/getUserListByOrgId/${orgId}`,
      method: 'get'
    })
  },
  /**
   * 根据课程Id和学期Id查找教师团队列表
   * @author:yangxiao
   */
  getTeacherTeamByCourseSetIdAndCourseTermId(courseSetId, courseTermId) {
    return request({
      url: `/course/teacherTeam/getTeacherTeamByCourseSetIdAndCourseTermId/${courseSetId}/${courseTermId}`,
      method: 'get'
    })
  },
  // 获得教师团队列表为助教管理提供接口
  getTeacherTeam() {
    return request({
      url: '/course/teacherTeam/getTeacherTeam',
      method: 'get'
    })
  }
}
