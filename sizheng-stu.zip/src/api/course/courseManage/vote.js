/**
 * @description 投票管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getVoteList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/vote/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加投票
  add(data) {
    return request({
      url: '/course/vote/add',
      method: 'post',
      data
    })
  },
  // 修改投票
  update(data) {
    return request({
      url: '/course/vote/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除投票
  delete(data) {
    return request({
      url: '/course/vote/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除
  deleteByConditions(data) {
    return request({
      url: '/course/vote/deleteByConditions',
      method: 'delete',
      data
    })
  },
  /**
   * 根据学员分组编号获取投票列表
   * cpy
   */
  getVoteByMgId(mgId) {
    return request({
      url: `/course/vote/getVoteByMgId/${mgId}`,
      method: 'get'
    })
  }
}
