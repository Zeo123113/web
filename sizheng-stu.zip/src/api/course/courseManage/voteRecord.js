/**
 * @description 投票记录管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getVoteRecordList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/vote-record/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加投票记录
  add(data) {
    return request({
      url: '/course/vote-record/add',
      method: 'post',
      data
    })
  },
  // 修改投票记录
  update(data) {
    return request({
      url: '/course/vote-record/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除投票记录
  delete(data) {
    return request({
      url: '/course/vote-record/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除
  deleteByConditions(data) {
    return request({
      url: '/course/vote-record/deleteByConditions',
      method: 'delete',
      data
    })
  }

}
