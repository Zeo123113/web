/**
 * @description 实验报告管理
 * @author chengguangyuan
 */

import request from '@/utils/request'

export default {
  addexperimentReport(data) {
    return request({
      url: '/course/experiment-report/add',
      method: 'post',
      data
    })
  },
  updateexperimentReport(data) {
    return request({
      url: '/course/experiment-report/update',
      method: 'put',
      data
    })
  },
  getexperimentReportList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/experiment-report/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  delexperimentReport(data) {
    return request({
      url: '/course/experiment-report/delete',
      method: 'delete',
      params: { ids: data }
    })
  }
}
