/**
 * @description 实验任务管理
 * @author chengguangyuan
 */

import request from '@/utils/request'

export default {
  /**
  * 根据授权单元编号查询实验任务列表
  * @author:chengguangyuan
  */
  getExperimentTasksByUnitId(unitId) {
    return request({
      url: `/course/experiment-task/getExperimentTasksByUnitId/${unitId}`,
      method: 'get'
    })
  },
  addexperimentTask(data) {
    return request({
      url: '/course/experiment-task/add',
      method: 'post',
      data
    })
  },
  updateexperimentTask(data) {
    return request({
      url: '/course/experiment-task/update',
      method: 'put',
      data
    })
  },
  getexperimentTaskList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/experiment-task/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  delexperimentTask(data) {
    return request({
      url: '/course/experiment-task/delete',
      method: 'delete',
      params: { ids: data }
    })
  }
}
