/**
 * @description 作业管理接口
 * @author LHZ
 */
import request from '@/utils/request'

export default {
  // 根据计划Id查找未开始的考试
  getHomeworkTasksBySchemeId(schemeId, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: `/course/homework-task/getHomeworkTasksBySchemeId/${schemeId}`,
      method: 'get',
      params: params
    })
  },
  // 列表展示
  listHomeworkTask(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/homework-task/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据教学方案编号查询学生互评作业任务
  gethomeworkTaskBySchemeId(schemeId) {
    return request({
      url: `/course/homework-task/gethomeworkTaskBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  getRecordByHwtId(hwtId) {
    return request({
      url: `/course/homework-task/getRecordByHwtId/${hwtId}`,
      method: 'get'
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/course/homework-task/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/course/homework-task/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/course/homework-task/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/homework-task/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  getHomeworkByUnitId(unitId) {
    return request({
      url: '/course/homework-task/getHomeworkByUnitId/' + unitId,
      method: 'get'
    })
  }
}
