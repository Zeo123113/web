import request from '@/utils/request'

export default {
  // 查询预习/学习任务列表
  listPrepareStudyTask(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/prepare-study-task/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据schemeId获取下载资料
  getRefMaterialBySchemeId(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/prepare-study-task/getRefMaterialBySchemeId',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 前端新增预习/学习任务
  addFrontStudyTask(data) {
    return request({
      url: '/course/prepare-study-task/addFrontStudyTask',
      method: 'post',
      data: data
    })
  },
  // 前端修改预习/学习任务
  updateFrontStudyTask(data) {
    return request({
      url: '/course/prepare-study-task/updateFrontStudyTask',
      method: 'post',
      data: data
    })
  },
  // 新增预习/学习任务
  addPrepareStudyTask(data) {
    return request({
      url: '/course/prepare-study-task/add',
      method: 'post',
      data: data
    })
  },
  // 修改预习/学习任务
  updatePrepareStudyTask(data) {
    return request({
      url: '/course/prepare-study-task/edit',
      method: 'put',
      data: data
    })
  },
  // 单条删除预习/学习任务
  delPrepareStudyTask(pstId) {
    return request({
      url: `/course/prepare-study-task/${pstId}`,
      method: 'delete'
    })
  },
  // 批量删除预习/学习任务
  batchDelete(data) {
    return request({
      url: '/course/prepare-study-task/batchDeleteByIds',
      method: 'delete',
      data: data
    })
  },
  // 按筛选条件删除预习/学习任务
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/prepare-study-task/realDelete',
      method: 'post',
      data: criteria
    })
  },
  // 根据unitId查询预学习任务列表
  getPrepareStudyTaskByUnitId(unitId) {
    return request({
      url: `/course/prepare-study-task/${unitId}`,
      method: 'get'
    })
  },
  // 根据unitId和studyTaskType获取任务
  getPerpareStudyByUnitId(data) {
    return request({
      url: `/course/prepare-study-task/getPerpareStudyByUnitId`,
      method: 'post',
      data: data
    })
  }
}
