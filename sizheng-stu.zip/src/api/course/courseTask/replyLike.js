/**
 * @description 回复点赞接口
 * @author chengguangyuan
 */
import request from '@/utils/request'

export default {
  // 列表展示
  listreplyLike(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/reply-like/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/course/reply-like/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/course/reply-like/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/course/reply-like/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/reply-like/batchDelete',
      method: 'post',
      data: criteria
    })
  }
}
