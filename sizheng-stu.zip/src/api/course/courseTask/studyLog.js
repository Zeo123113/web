import request from '@/utils/request'

export default {
  // 查询学习记录列表
  listStudyLog(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-study-log/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 新增学习记录
  addStudyLog(data) {
    return request({
      url: '/course/course-study-log/add',
      method: 'post',
      data: data
    })
  },
  // 修改学习记录
  updateStudyLog(data) {
    return request({
      url: '/course/course-study-log/edit',
      method: 'put',
      data: data
    })
  },
  // 单条删除学习记录
  delStudyLog(studyLogId) {
    return request({
      url: `/course/course-study-log/${studyLogId}`,
      method: 'delete'
    })
  },
  // 批量删除学习记录
  batchDelete(data) {
    return request({
      url: '/course/course-study-log/batchDeleteByIds',
      method: 'delete',
      data: data
    })
  },
  // 按筛选条件删除学习记录
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-study-log/realDelete',
      method: 'post',
      data: criteria
    })
  },
  // 学生端新增学习记录
  StudentAddStudyLog(data) {
    return request({
      url: '/course/course-study-log/addStudyLog',
      method: 'post',
      data: data
    })
  },
  /**
   * @description 学生端没有学习记录时，新增默认学习记录（默认第一个学习任务）
   * @param {courseStudyLog} 学习记录courseStudyLog
   * @returns {courseStudyLog} 返回新增的学习记录
   */
  addDefaultStudyLog(data) {
    return request({
      url: '/course/course-study-log/addDefaultStudyLog',
      method: 'post',
      data: data
    })
  },
  /**
   * @description 根据预学习任务Id,学习资料id,用户Id查找用户的学习记录
   * @param {courseStudyLog} 学习记录courseStudyLog
   * @returns {courseStudyLog} 返回新增的学习记录
   */
  getStudyLog(data) {
    return request({
      url: '/course/course-study-log/getStudyLog',
      method: 'post',
      data: data
    })
  },
  /**
   * @description 根据csId,ctId,schemeId,用户Id,update_time倒排取出最大的查找学习记录
   * @param {courseStudyLog} 学习记录courseStudyLog
   * @returns {courseStudyLog} 返回新增的学习记录
   */
  getStudyLogBySchemeIdUserId(data) {
    return request({
      url: '/course/course-study-log/getStudyLogBySchemeIdUserId',
      method: 'post',
      data: data
    })
  },
  // 根据Id查找学生学习记录
  getStudyLogById(id) {
    return request({
      url: `/course/course-study-log/getById/${id}`,
      method: 'get'
    })
  }
}
