/**
 * @description 教案管理接口
 * @author liguanjing
 */
import request from '@/utils/request'

export default {
  // 列表展示
  listTeachingScheme(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/teaching-scheme/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加教案
  addEntity(data) {
    return request({
      url: '/course/teaching-scheme/add',
      method: 'post',
      data
    })
  },
  // 目录下添加教案
  addTeachingScheme(data) {
    return request({
      url: '/course/teaching-scheme/addTeachingScheme',
      method: 'post',
      data
    })
  },
  // 修改教案
  updateEntity(data) {
    return request({
      url: '/course/teaching-scheme/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除
  delete(data) {
    return request({
      url: '/course/teaching-scheme/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除
  deleteByConditions(data) {
    return request({
      url: '/course/teaching-scheme/deleteByConditions',
      method: 'delete',
      data
    })
  },
  // 复制操作
  copyMoveGroup(params) {
    return request({
      url: '/course/teaching-scheme/copyMoveGroup',
      method: 'post',
      data: params
    })
  }
}
