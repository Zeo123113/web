/**
 * @description 测验管理
 * @author liguanjing
 */

import request from '@/utils/request'

export default {
  // 查询列表
  list(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/test-task/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  examArrangeList(courseId, termId) {
    const params = new URLSearchParams()
    params.append('courseId', courseId)
    params.append('termId', termId)
    return request({
      url: '/course/test-task/examArrangeList',
      method: 'get',
      params: params
    })
  },
  // 添加
  add(data) {
    return request({
      url: '/course/test-task/add',
      method: 'post',
      data
    })
  },
  // 修改
  update(data) {
    return request({
      url: '/course/test-task/update',
      method: 'put',
      data
    })
  },
  // 批量删除学员分组
  deleteBatch(data) {
    return request({
      url: '/course/test-task/deletebatch',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除学员分组
  deleteByCondtions(body) {
    return request({
      url: '/course/test-task/deleteByCondtions',
      method: 'delete',
      data: body
    })
  },
  delete(ttaskId) {
    return request({
      url: '/course/test-task/delete/' + ttaskId,
      method: 'delete'
    })
  },
  // 根据用户Id和学期Id查找未开始的考试
  getTestTaskListByUserId(userId, pageIndex, pageSize, data) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: `/course/test-task/getTestTaskListByUserId/${userId}`,
      method: 'post',
      params: params,
      data
    })
  },
  // 根据计划Id查找未开始的考试
  getTestTasksBySchemeId(schemeId, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: `/course/test-task/getTestTasksBySchemeId/${schemeId}`,
      method: 'get',
      params: params
    })
  },
  // 前端新增测验任务
  addTestTask(data) {
    return request({
      url: '/course/test-task/addTestTask',
      method: 'post',
      data: data
    })
  },
  // 前端修改测验任务
  updateTestTask(data) {
    return request({
      url: '/course/test-task/updateTestTask',
      method: 'post',
      data: data
    })
  }
}
