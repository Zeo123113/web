/**
 * @description 话题接口
 * @author chengguangyuan
 */
import request from '@/utils/request'

export default {
  /**
  * 根据授课方案编号查询话题列表
  * @author:chengguangyuan
  */
  getCourseTopicBySchemeId(schemeId) {
    return request({
      url: `/course/course-topic/getCourseTopicBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  // 列表展示
  listtopic(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-topic/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/course/course-topic/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/course/course-topic/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/course/course-topic/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-topic/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  /**
  * 根据授课方案编号查询话题列表
  * @author:yangxiao
  */
  getTopicBySchemeId(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-topic/getTopicBySchemeId',
      method: 'post',
      data: body,
      params: params
    })
  },
  /**
  * 根据授课方案编号查询话题列表
  * @author:yangxiao
  */
  getTopicByCsIds(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-topic/getTopicByCsIds',
      method: 'post',
      data: body,
      params: params
    })
  },
  /**
  * 根据话题发布人用户ID查询话题列表(讨论或问题)
  * @author: cgy
  */
  getTopicByTopicUserId(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-topic/getTopicByTopicUserId',
      method: 'post',
      data: body,
      params: params
    })
  },
  /**
  * 根据Id查询话题
  * @author:yangxiao
  */
  getById(Id) {
    return request({
      url: `/course/course-topic/getById/${Id}`,
      method: 'get'
    })
  },
  /**
  * 可以根据 csId ctId schemeId topicType topicUserId 查询对应的课程话题列表
  * @author:zhaoshibin
  */
  getCourseTopicList(body) {
    return request({
      url: '/course/course-topic/getCourseTopicList',
      method: 'post',
      data: body
    })
  },
  // 根据unitId和studyTaskType获取任务
  getCourseTopicByUnitId(data) {
    return request({
      url: `/course/course-topic/getCourseTopicByUnitId`,
      method: 'post',
      data: data
    })
  }
}
