/**
 * @description 话题回复接口
 * @author chengguangyuan
 */
import request from '@/utils/request'

export default {
  /**
  * 根据主键查询实体信息
  * @author:chengguangyuan
  */
  getById(id) {
    return request({
      url: `/course/topic-reply/getById/${id}`,
      method: 'get'
    })
  },
  // 列表展示
  listtopicReply(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/topic-reply/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/course/topic-reply/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/course/topic-reply/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/course/topic-reply/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/topic-reply/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  // 根据课程问题编号cqId查询话题回复列表
  getReplayListBytTopicId(Id) {
    return request({
      url: `/course/topic-reply/getBytTopicId/${Id}`,
      method: 'get'
    })
  },
  // 回复点赞
  replyLike(Id) {
    return request({
      url: `/course/topic-reply/replyLike/${Id}`,
      method: 'get'
    })
  }
}
