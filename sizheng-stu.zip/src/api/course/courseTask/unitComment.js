/**
 * @description 随堂评分管理
 * @author cuipengyuan
 */

import request from '@/utils/request'

export default {
  // 查询考试列表
  list(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/unit-comment/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加学员分组
  add(data) {
    return request({
      url: '/course/unit-comment/add',
      method: 'post',
      data
    })
  },
  // 修改学员分组
  update(data) {
    return request({
      url: '/course/unit-comment/edit',
      method: 'put',
      data
    })
  },
  // 批量删除学员分组
  deleteBatch(data) {
    return request({
      url: '/course/unit-comment/deletebatch',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除学员分组
  deleteByCondtions(body) {
    return request({
      url: '/course/unit-comment/deleteByCondtions',
      method: 'delete',
      data: body
    })
  },
  // 添加评论点赞
  addLike(data) {
    return request({
      url: '/course/comment-like/addLike',
      method: 'post',
      data
    })
  },
  // 根据评论编号获取评论点赞列表
  getCommentLikeByCommmentId(commentId) {
    return request({
      url: '/course/comment-like/getCommentLikeByCommmentId/' + commentId,
      method: 'get'
    })
  }
}
