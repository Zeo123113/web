/**
 * @description 下载文件记录管理接口
 * @author zhouhuan
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/download-file-record/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加下载文件记录
  add(data) {
    return request({
      url: '/course/download-file-record/add',
      method: 'post',
      data
    })
  },
  // 修改下载文件记录
  update(data) {
    return request({
      url: '/course/download-file-record/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除下载文件记录
  delete(data) {
    return request({
      url: '/course/download-file-record/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除下载文件记录
  deleteByConditions(data) {
    return request({
      url: '/course/download-file-record/batchDelete',
      method: 'post',
      data
    })
  },
  // 导出下载文件记录
  export() {
    return request({
      url: '/course/download-file-record/export',
      method: 'get',
      responseType: 'blob'
    })
  }

}
