/**
 * @description 视频弹题答题管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/popup-answer/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加视频弹题答题
  add(data) {
    return request({
      url: '/course/popup-answer/add',
      method: 'post',
      data
    })
  },
  // 修改视频弹题答题
  update(data) {
    return request({
      url: '/course/popup-answer/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除视频弹题答题
  delete(data) {
    return request({
      url: '/course/popup-answer/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除视频弹题答题
  deleteByConditions(data) {
    return request({
      url: '/course/popup-answer/batchDelete',
      method: 'post',
      data
    })
  }

}
