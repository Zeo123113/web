/**
 * @description 视频弹题管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/popup-question/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加视频弹题
  add(data) {
    return request({
      url: '/course/popup-question/add',
      method: 'post',
      data
    })
  },
  // 修改视频弹题
  update(data) {
    return request({
      url: '/course/popup-question/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除视频弹题
  delete(data) {
    return request({
      url: '/course/popup-question/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除视频弹题
  deleteByConditions(data) {
    return request({
      url: '/course/popup-question/batchDelete',
      method: 'post',
      data
    })
  },
  // 根据条件查找弹题列表，学生看视频时的查找接口
  getListByCondition(data) {
    return request({
      url: '/course/popup-question/getListByCondition',
      method: 'post',
      data
    })
  }

}
