/**
 * @description 调查问卷接口
 * @author chengguangyuan
 */
import request from '@/utils/request'

export default {
  /**
  * 根据学员分组编号，获取调查问卷列表
  * @author:chengguangyuan
  */
  getQuestionnairesByMgId(mgId) {
    return request({
      url: `/course/questionnaire/getQuestionnairesByMgId/${mgId}`,
      method: 'get'
    })
  },
  /**
 * 根据主键查询实体信息
 * @author:chengguangyuan
 */
  getById(id) {
    return request({
      url: `/course/questionnaire/getById/${id}`,
      method: 'get'
    })
  },
  // 列表展示
  listquestionnaire(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/questionnaire/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/course/questionnaire/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/course/questionnaire/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/course/questionnaire/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/questionnaire/batchDelete',
      method: 'post',
      data: criteria
    })
  }
}
