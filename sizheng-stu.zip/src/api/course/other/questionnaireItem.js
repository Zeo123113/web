/**
 * @description 调查问卷接口
 * @author chengguangyuan
 */
import request from '@/utils/request'

export default {
  /**
  * 根据学员分组编号，获取调查问卷试题列表
  * @author:chengguangyuan
  */
  getQuestionnaireItemsByMgId(mgId) {
    return request({
      url: `/course/questionnaire-item/getQuestionnaireItemsByMgId/${mgId}`,
      method: 'get'
    })
  },
  /**
 * 根据主键查询实体信息
 * @author:chengguangyuan
 */
  getById(id) {
    return request({
      url: `/course/questionnaire-item/getById/${id}`,
      method: 'get'
    })
  },
  // 列表展示
  listquestionnaireItem(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/questionnaire-item/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/course/questionnaire-item/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/course/questionnaire-item/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/course/questionnaire-item/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/questionnaire-item/batchDelete',
      method: 'post',
      data: criteria
    })
  }
}
