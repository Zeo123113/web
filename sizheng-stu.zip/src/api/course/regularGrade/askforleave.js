/**
 * @description 请假审批管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/askforleave/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加请假审批
  add(data) {
    return request({
      url: '/course/askforleave/add',
      method: 'post',
      data
    })
  },
  // 修改请假审批
  update(data) {
    return request({
      url: '/course/askforleave/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除请假审批
  delete(data) {
    return request({
      url: '/course/askforleave/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除请假审批
  deleteByConditions(data) {
    return request({
      url: '/course/askforleave/batchDelete',
      method: 'post',
      data
    })
  },
  // 处理审批操作
  approve(data) {
    return request({
      url: '/course/askforleave/approve',
      method: 'put',
      data
    })
  }

}
