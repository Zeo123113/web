/**
 * @description 学生签到管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/checking-in/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加学生签到
  add(data) {
    return request({
      url: '/course/checking-in/add',
      method: 'post',
      data
    })
  },
  // 修改学生签到
  update(data) {
    return request({
      url: '/course/checking-in/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除学生签到
  delete(data) {
    return request({
      url: '/course/checking-in/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除学生签到
  deleteByConditions(data) {
    return request({
      url: '/course/checking-in/batchDelete',
      method: 'post',
      data
    })
  },
  // 根据学员分组Id获取签到列表
  getCheckinByMgId(mgId) {
    return request({
      url: `/course/checking-in/getCheckinByMgId/${mgId}`,
      method: 'get'
    })
  }

}
