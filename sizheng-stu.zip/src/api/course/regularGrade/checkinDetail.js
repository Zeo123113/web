/**
 * @description 签到详情管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/checking-in-detail/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加签到详情
  add(data) {
    return request({
      url: '/course/checking-in-detail/add',
      method: 'post',
      data
    })
  },
  // 修改签到详情
  update(data) {
    return request({
      url: '/course/checking-in-detail/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除签到详情
  delete(data) {
    return request({
      url: '/course/checking-in-detail/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除签到详情
  deleteByConditions(data) {
    return request({
      url: '/course/checking-in-detail/batchDelete',
      method: 'post',
      data
    })
  }

}
