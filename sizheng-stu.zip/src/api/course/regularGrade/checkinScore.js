/**
 * @description 考勤成绩管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/checkin-score/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加考勤成绩
  add(data) {
    return request({
      url: '/course/checkin-score/add',
      method: 'post',
      data
    })
  },
  // 修改考勤成绩
  update(data) {
    return request({
      url: '/course/checkin-score/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除考勤成绩
  delete(data) {
    return request({
      url: '/course/checkin-score/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除考勤成绩
  deleteByConditions(data) {
    return request({
      url: '/course/checkin-score/batchDelete',
      method: 'post',
      data
    })
  },
  // 根据学号和教学方案查询考勤成绩
  getCheckinScoreByStuIdAndSchemeId(stuId, schemeId) {
    return request({
      url: `/course/checkin-score/getCheckinScoreByStuIdAndSchemeId/${stuId}/${schemeId}`,
      method: 'get'
    })
  },
  // 下载导入模板
  downloadTemplete() {
    return request({
      url: '/course/checkin-score/templete',
      method: 'get'
    })
  }

}
