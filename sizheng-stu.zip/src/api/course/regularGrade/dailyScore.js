/**
 * @description 平时成绩管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/daily-score/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加平时成绩
  add(data) {
    return request({
      url: '/course/daily-score/add',
      method: 'post',
      data
    })
  },
  // 修改平时成绩
  update(data) {
    return request({
      url: '/course/daily-score/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除平时成绩
  delete(data) {
    return request({
      url: '/course/daily-score/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除平时成绩
  deleteByConditions(data) {
    return request({
      url: '/course/daily-score/batchDelete',
      method: 'post',
      data
    })
  },
  // 下载导入模板
  downloadTemplete() {
    return request({
      url: '/course/daily-score/templete',
      method: 'get'
    })
  }

}
