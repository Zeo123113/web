/**
 * @description 作业成绩管理
 * @author cuipengyuan
 */

import request from '@/utils/request'

export default {
  // 查询考试列表
  list(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/homework-score/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加作业成绩
  add(data) {
    return request({
      url: '/course/homework-score/add',
      method: 'post',
      data
    })
  },
  // 修改作业成绩
  update(data) {
    return request({
      url: '/course/homework-score/update',
      method: 'put',
      data
    })
  },
  // 批量删除作业成绩
  deleteBatch(data) {
    return request({
      url: '/course/homework-score/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除作业成绩
  deleteByCondtions(body) {
    return request({
      url: '/course/homework-score/deleteByCondtions',
      method: 'delete',
      data: body
    })
  },
  // 下载excel导入模板
  downloadTemplate() {
    return request({
      url: '/course/homework-score/templete',
      method: 'get'
    })
  },
  /**
 * 根据学号和教学方案查询作业成绩
 * @author:yangxiao
 */
  getHwScoreByStuIdAndSchemeId(stuId, schemeId) {
    return request({
      url: `/course/homework-score/getHwScoreByStuIdAndSchemeId/${stuId}/${schemeId}`,
      method: 'get'
    })
  }
}
