import request from '@/utils/request'

export default {
  // 新增
  addEntity(data) {
    return request({
      url: '/course/respond-record/add',
      method: 'post',
      data: data
    })
  },
  // 批量和单条删除
  delete(data) {
    return request({
      url: '/course/respond-record/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除
  deleteByConditions(data) {
    return request({
      url: '/course/respond-record/deleteByConditions',
      method: 'delete',
      data
    })
  },
  // 列表展示
  listEntity(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/respond-record/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 更新
  updateEntity(data) {
    return request({
      url: '/course/respond-record/update',
      method: 'put',
      data
    })
  },
  /**
   * 根据学员分组查询抢答记录
   */
  getRespondRecordByMgId(mgId) {
    return request({
      url: `/course/respond-record/getRespondRecordByMgId/${mgId}`,
      method: 'get'
    })
  }
}
