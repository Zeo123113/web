import request from '@/utils/request'

export default {
  // 新增课程笔记
  addEntity(data) {
    return request({
      url: '/course/responder-answer/add',
      method: 'post',
      data: data
    })
  },
  // 批量和单条删除
  delete(data) {
    return request({
      url: '/course/responder-answer/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除
  deleteByConditions(data) {
    return request({
      url: '/course/responder-answer/deleteByConditions',
      method: 'delete',
      data
    })
  },
  // 列表展示
  listEntity(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/responder-answer/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 更新
  updateEntity(data) {
    return request({
      url: '/course/responder-answer/update',
      method: 'put',
      data
    })
  }
}
