import request from '@/utils/request'

export default {
  // 新增课程笔记
  addEntity(data) {
    return request({
      url: '/course/responser-score/add',
      method: 'post',
      data: data
    })
  },
  // 批量和单条删除
  delete(data) {
    return request({
      url: '/course/responser-score/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除
  deleteByConditions(data) {
    return request({
      url: '/course/responser-score/deleteByConditions',
      method: 'delete',
      data
    })
  },
  // 列表展示
  listEntity(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/responser-score/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 更新
  updateEntity(data) {
    return request({
      url: '/course/responser-score/update',
      method: 'put',
      data
    })
  },
  // 根据学号和教学方案查询抢答成绩
  getResponserScoreByStuIdAndSchemeId(stuId, schemeId) {
    return request({
      url: `/course/responser-score/getResponserScoreByStuIdAndSchemeId/${stuId}/${schemeId}`,
      method: 'get'
    })
  }
}
