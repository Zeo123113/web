/**
 * @description 课程小组接口
 * @author chengguangyuan
 */
import request from '@/utils/request'

export default {
  /**
   * 根据学员分组编号，获取课程小组任务列表
   * @author:chengguangyuan
   */
  getCourseGroupsByMgId(mgId) {
    return request({
      url: `/course/course-group/getCourseGroupsByMgId/${mgId}`,
      method: 'get'
    })
  },
  /**
   * 根据教学方案编号，获取课程小组列表
   * @author:chengguangyuan
   */
  getCourseGroupsBySchemeId(schemeId) {
    return request({
      url: `/course/course-group/getCourseGroupsBySchemeId/${schemeId}`,
      method: 'get'
    })
  },
  /**
 * 根据主键查询实体信息
 * @author:chengguangyuan
 */
  getById(id) {
    return request({
      url: `/course/course-group/getById/${id}`,
      method: 'get'
    })
  },
  // 列表展示
  listcourseGroup(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/course-group/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/course/course-group/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/course/course-group/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/course/course-group/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/course-group/batchDelete',
      method: 'post',
      data: criteria
    })
  }
}
