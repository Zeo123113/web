/**
 * @description 任务小组成绩接口
 * @author chengguangyuan
 */
import request from '@/utils/request'

export default {
  /**
 * 根据主键查询实体信息
 * @author:chengguangyuan
 */
  getById(id) {
    return request({
      url: `/course/task-group-score/getById/${id}`,
      method: 'get'
    })
  },
  // 列表展示
  listTaskGroupScore(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/task-group-score/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/course/task-group-score/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/course/task-group-score/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/course/task-group-score/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/course/task-group-score/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  /**
 * 根据学号和教学方案查询任务小组成绩
 * @author:yangxiao
 */
  getTaskGroupScoreByStuIdAndSchemeId(stuId, schemeId) {
    return request({
      url: `/course/task-group-score/getTaskGroupScoreByStuIdAndSchemeId/${stuId}/${schemeId}`,
      method: 'get'
    })
  }
}
