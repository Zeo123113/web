/**
 * @description 测试成绩管理接口
 * @author 杨霄
 */

import request from '@/utils/request'

export default {
  // 列表展示
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/course/test-score/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加测试成绩
  add(data) {
    return request({
      url: '/course/test-score/add',
      method: 'post',
      data
    })
  },
  // 修改测试成绩
  update(data) {
    return request({
      url: '/course/test-score/update',
      method: 'put',
      data
    })
  },
  // 批量和单条删除测试成绩
  delete(data) {
    return request({
      url: '/course/test-score/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件删除测试成绩
  deleteByConditions(data) {
    return request({
      url: '/course/test-score/batchDelete',
      method: 'post',
      data
    })
  },
  // 根据学号和教学方案查询测验成绩
  getTestScoreByStuIdAndSchemeId(stuId, schemeId) {
    return request({
      url: `/course/test-score/getTestScoreByStuIdAndSchemeId/${stuId}/${schemeId}`,
      method: 'get'
    })
  },
  // 下载导入模板
  downloadTemplete() {
    return request({
      url: '/course/test-score/templete',
      method: 'get'
    })
  }

}
