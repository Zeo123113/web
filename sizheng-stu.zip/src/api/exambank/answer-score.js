import request from '@/utils/request'

export default {
  // 列表展示
  getAnswerScoreList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/answer-score/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 增加
  add(data) {
    return request({
      url: '/exambank/answer-score/add',
      method: 'post',
      data
    })
  }
}
