/**
 * @description 考试及题库管理接口
 * @author LHZ
 */
import request from '@/utils/request'

export default {

  /** 获取课程信息列表，目前测试用，以后改成从课程服务获取 */
  getCourseList() {
    return request({
      url: '/exambank/question-bank/getCourseList',
      method: 'get'
    })
  },
  // 列表展示
  listQuestions(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/question-bank/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 不分页随机抽取列表展示
  randomlist(body) {
    return request({
      url: '/exambank/question-bank/randomlist',
      method: 'post',
      data: body
    })
  },
  // 添加试题
  addEntry(data) {
    return request({
      url: '/exambank/question-bank/add',
      method: 'post',
      data
    })
  },
  // 批量删除考试记录(逻辑删除)
  batchDelete(data) {
    return request({
      url: '/exambank/question-bank/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量还原考试记录
  batchRecall(data) {
    return request({
      url: '/exambank/question-bank/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量删除考试记录（真删除）
  realDelete(data) {
    return request({
      url: '/exambank/question-bank/realDelete',
      method: 'delete',
      data
    })
  },
  // 修改试题
  updateEntry(data) {
    return request({
      url: '/exambank/question-bank/update',
      method: 'put',
      data
    })
  },
  // 根据Id查找编程题
  getPbById(id) {
    return request({
      url: `/exambank/question-bank/getPbById/${id}`,
      method: 'get'
    })
  },
  // 根据Id查找程序填空题题
  getPfbById(id) {
    return request({
      url: `/exambank/question-bank/getPfbById/${id}`,
      method: 'get'
    })
  },
  // 根据Id查找接口编程题
  getIbById(id) {
    return request({
      url: `/exambank/question-bank/getIbById/${id}`,
      method: 'get'
    })
  },
  // 根据Id查找编程题
  getUbById(id) {
    return request({
      url: `/exambank/question-bank/getUbById/${id}`,
      method: 'get'
    })
  },
  // 根据Id查找材料小题列表
  getMbById(id) {
    return request({
      url: `/exambank/question-bank/getMbListById/${id}`,
      method: 'get'
    })
  },
  // 根据ID删除材料小题
  deleteMbById(id) {
    return request({
      url: `/exambank/question-bank/deleteMbById/${id}`,
      method: 'delete'
    })
  },
  // 根据Id查找基本(单选，多选，判断，填空，问答)题
  getQbById(id) {
    return request({
      url: `/exambank/question-bank/getQbById/${id}`,
      method: 'get'
    })
  },
  templete(downloadUrlType) {
    return request({
      url: `/exambank/question-bank/templete/` + downloadUrlType,
      method: 'get'
    })
  },
  /**
   * 根据课程id获取试题列表
   * author: cpy
   */
  getlistBycsIds(csIds, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    params.append('csIds', csIds)
    return request({
      url: '/exambank/question-bank/getlistBycsIds',
      method: 'get',
      params: params
    })
  }
}
