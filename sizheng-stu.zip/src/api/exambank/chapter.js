import request from '@/utils/request'

export default {
  /** 获取课程信息列表，目前测试用，以后改成从课程服务获取 */
  getCourseList() {
    return request({
      url: '/exambank/chapter/getCourseList',
      method: 'get'
    })
  },
  /**
   * @description 根据课程编号查询章节信息
   * @author LHZ
   */
  getChapterTreeByCourseId(courseId) {
    return request({
      url: `/exambank/chapter/getChapterTreeByCourseId/${courseId}`,
      method: 'get'
    })
  },
  // 查询章节列表
  listChapter(body) {
    return request({
      url: '/exambank/chapter/listChapter',
      method: 'post',
      data: body
    })
  },
  // 创建树形结构
  getChapterTree() {
    return request({
      url: '/exambank/chapter/tree',
      method: 'get'
    })
  },
  /**
   * @description 保存知识点
   * @author LHZ
   */
  addChapter(chapter) {
    return request({
      url: '/exambank/chapter/add',
      method: 'post',
      data: chapter
    })
  },
  /**
   * @description 保存知识点，返回知识点id
   * @author cpy
   */
  addEntity(chapter) {
    return request({
      url: '/exambank/chapter/addEntity',
      method: 'post',
      data: chapter
    })
  },
  /**
   * 根据父级id获取子级列表
   * @param {} chapterId
   * @param {*} courseId
   * @author cpy
   */
  getChapterTreeByParentId(data) {
    return request({
      url: '/exambank/chapter/getChapterTreeByParentId',
      method: 'post',
      data
    })
  },
  /**
   * 根据子级获取同级章节列表
   * @param {}} chapter
   * @author cpy
   */
  GetByChapter(data) {
    return request({
      url: '/exambank/chapter/GetByChapter',
      method: 'post',
      data
    })
  },
  /**
   * @description 调整位置
   * @author:cpy
   */
  settingPosition(data, isTop) {
    return request({
      url: '/exambank/chapter/settingPosition',
      method: 'post',
      data,
      params: { isTop: isTop }
    })
  },
  // 单条删除章节
  delChapter(chapterId, courseId) {
    return request({
      url: '/exambank/chapter/delete',
      params: { ids: chapterId, courseId: courseId },
      method: 'delete'
    })
  },
  // 批量删除章节
  batchDelete(data) {
    return request({
      url: '/exambank/chapter/batchDeleteByIds',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 更新章节
  update(data) {
    return request({
      url: '/exambank/chapter/update',
      method: 'put',
      data
    })
  },
  /**
   * 根据课程编号获取章节列表
   * @param {} courseId
   */
  getChapterListByCourseId(courseId) {
    return request({
      url: '/exambank/chapter/getChapterListByCourseId/' + courseId,
      method: 'get'
    })
  }
}
