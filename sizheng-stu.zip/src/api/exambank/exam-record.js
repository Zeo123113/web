import request from '@/utils/request'

export default {
  // 批量删除考试记录(逻辑删除)
  batchDelete(data) {
    return request({
      url: '/exambank/exam-log/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量还原考试记录
  batchRecall(data) {
    return request({
      url: '/exambank/exam-log/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量删除考试记录（真删除）
  realDelete(data) {
    return request({
      url: '/exambank/exam-log/realDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 考试记录列表展示
  listExamLog(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/exam-log/list',
      method: 'post',
      data: data,
      params: params
    })
  },
  getByExamLogByUserId(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/exam-log/getByExamLogByUserId',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 根据考试记录ID获取考试记录详细信息
  getByExamLogById(examRecId) {
    return request({
      url: '/exambank/exam-log/getByExamLogById/' + examRecId,
      method: 'get'
    })
  },
  // 导出考试记录
  export(data) {
    return request({
      url: '/exambank/exam-log/export',
      method: 'post',
      data: data,
      responseType: 'blob'
    })
  },
  // 增加考试记录
  add(data) {
    return request({
      url: '/exambank/exam-log/add',
      method: 'post',
      data: data
    })
  },
  // 获取考试记录
  getExamLogsByRoundIdAndExamtype(data) {
    return request({
      url: '/exambank/exam-log/getExamLogsByRoundIdAndExamtype',
      method: 'post',
      data: data
    })
  },
  // 获取考试记录包括分数分页
  getExamLogAndScoreByPage(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/exam-log/getExamLogAndScoreByPage',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 获取考试记录包括分数
  getExamLogAndScore(data) {
    return request({
      url: '/exambank/exam-log/getExamLogAndScore',
      method: 'post',
      data: data
    })
  },
  // 获取考试记录包括分数
  getOneExamLogAndScore(data) {
    return request({
      url: '/exambank/exam-log/getOneExamLogAndScore',
      method: 'post',
      data: data
    })
  },
  // 根据考试安排编号和考试类型查找考试记录个数
  getExamLogCountByExamArrangeId(data) {
    return request({
      url: '/exambank/exam-log/getExamLogCountByExamArrangeId',
      method: 'post',
      data: data
    })
  },
  // 新增考试记录,教师点击开始考试为每个学员创建考试记录
  addExamLog(data) {
    return request({
      url: '/exambank/exam-log/addExamLog',
      method: 'post',
      data
    })
  },
  // 更新考试记录
  update(data) {
    return request({
      url: '/exambank/exam-log/update',
      method: 'post',
      data
    })
  },
  // 学生考试时进行更新剩余考试时间
  updateRemainTime(data) {
    return request({
      url: '/exambank/exam-log/updateRemainTime',
      method: 'post',
      data
    })
  }

}
