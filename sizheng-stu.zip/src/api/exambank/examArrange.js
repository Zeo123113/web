import request from '@/utils/request'

export default {
  // 新增考试安排
  addExamArrange(data) {
    return request({
      url: '/exambank/examArrange/add',
      method: 'post',
      data: data
    })
  },
  // 根据id逻辑删除考试安排
  delExamArrange(roundId) {
    return request({
      url: `/exambank/examArrange/delete/${roundId}`,
      method: 'delete'
    })
  },
  // 批量逻辑删除考试信息
  batchDelete(data) {
    return request({
      url: `/exambank/examArrange/batchDelete`,
      method: 'delete',
      data: data
    })
  },
  // 清空已删除的考试安排,物理删除
  cleanRecycleBinByIds(data) {
    return request({
      url: '/exambank/examArrange/cleanRecycleBinByIds',
      method: 'delete',
      data: data
    })
  },
  // 还原考试安排
  recallExamArrange(roundId) {
    return request({
      url: `/exambank/examArrange/recall/${roundId}`,
      method: 'post'
    })
  },
  // 批量还原考试安排
  batchRecall(data) {
    return request({
      url: '/exambank/examArrange/batchRecall',
      method: 'post',
      data: data
    })
  },
  // 修改考试安排
  updateExamArrange(data) {
    return request({
      url: '/exambank/examArrange/edit',
      method: 'put',
      data: data
    })
  },
  // 查询考试安排列表
  listExamArrange(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/examArrange/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 通过id查询考试安排
  getExamArrange(roundId) {
    return request({
      url: `/exambank/examArrange/list/${roundId}`,
      method: 'get'
    })
  },
  // 根据考试安排id获取对应考试分组Id
  getExamGroupIdByExamArrangeId(data) {
    return request({
      url: '/exambank/examArrange/getExamGroupIdByExamArrangeId',
      method: 'post',
      data: data
    })
  },
  // 考试/测试统计
  statistics(data) {
    return request({
      url: '/exambank/examArrange/statistics',
      method: 'post',
      data: data
    })
  },
  // 查询考试安排列表,用于教师端展示
  getExamArrangeList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/examArrange/getList',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据条件查找考试安排,用于前端测试选择考试安排
  getExamArrangeByCondition(data) {
    return request({
      url: '/exambank/examArrange/getExamArrangeByCondition',
      method: 'post',
      data: data
    })
  }
}
