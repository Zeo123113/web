import request from '@/utils/request'

export default {
  // 通过roundId查询对应的paperId
  getPaperIdByRoundId(roundId) {
    return request({
      url: `/exambank/exam-paper/getPaperIdByRoundId/${roundId}`,
      method: 'get'
    })
  },
  // 通过roundId查询对应的paperId列表
  getPaperListByRoundId(roundId) {
    return request({
      url: `/exambank/exam-paper/getPaperListByRoundId/${roundId}`,
      method: 'get'
    })
  }
}
