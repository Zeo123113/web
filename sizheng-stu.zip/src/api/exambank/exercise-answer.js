import request from '@/utils/request'
export default {

  // 根据练习记录试题列表
  selectInfoByErId(exerId) {
    return request({
      url: '/exambank/exercise-answer/selectInfoByErId/' + exerId,
      method: 'get'
    })
  },
  // 根据练习记录编号，获取练习详情
  selectAnswerByErId(exerId) {
    return request({
      url: '/exambank/exercise-answer/selectAnswerByErId/' + exerId,
      method: 'get'
    })
  }
}
