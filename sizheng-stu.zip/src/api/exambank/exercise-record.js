import request from '@/utils/request'
export default {

  // 增加练习记录
  add(data) {
    return request({
      url: '/exambank/exercise-record/add',
      method: 'post',
      data
    })
  },
  // 删除/批量删除练习记录
  delete(data) {
    return request({
      url: '/exambank/exercise-record/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 更新练习记录
  update(data) {
    return request({
      url: '/exambank/exercise-record/update',
      method: 'put',
      data
    })
  },
  // 根据条件查找试题类型
  getListByCondition(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/exercise-record/list',
      method: 'post',
      data,
      params: params
    })
  },
  // 根据id获取详情
  // @author:cpy
  getById(id) {
    return request({
      url: '/exambank/exercise-record/getById/' + id,
      method: 'get'
    })
  },
  // 练习提交
  // @author:cpy
  updateStudentAnswer(data) {
    return request({
      url: '/exambank/exercise-record/updateStudentAnswer',
      method: 'put',
      data
    })
  }
}
