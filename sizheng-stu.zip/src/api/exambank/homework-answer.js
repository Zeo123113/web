import request from '@/utils/request'

export default {
  // 根据id获取学生作业
  getEntityById(id) {
    return request({
      url: '/exambank/homework-answer/getById/' + id,
      method: 'get'
    })
  },
  // 添加学生作业答题
  addHomeworkAnswer(data) {
    return request({
      url: '/exambank/homework-answer/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getHomeworkAnswerList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-answer/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 编辑学生作业答题
  updateHomeworkAnswer(data) {
    return request({
      url: '/exambank/homework-answer/update',
      method: 'put',
      data
    })
  },
  delHomeworkAnswer(data) {
    return request({
      url: '/exambank/homework-answer/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 自动评分和保存
  automaticJudgment(entity) {
    return request({
      url: '/exambank/homework-answer/automaticJudgment',
      method: 'put',
      data: entity
    })
  },
  // 提交作业
  homeworkSubmit(entity) {
    return request({
      url: '/exambank/homework-answer/homeworkSubmit',
      method: 'put',
      data: entity
    })
  }
}
