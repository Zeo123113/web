import request from '@/utils/request'
export default {
  // 列表展示
  listAssign(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-arrange/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加布置作业
  addAssign(body) {
    return request({
      url: '/exambank/homework-arrange/add',
      method: 'post',
      data: body
    })
  },
  // 添加试题列表
  addQuestionList(body) {
    return request({
      url: '/exambank/homework-item-list/add',
      method: 'post',
      data: body
    })
  },
  // 添加材料题试题列表
  addMaterial(body) {
    return request({
      url: '/exambank/homework-item-list/addMaterial',
      method: 'post',
      data: body
    })
  },
  // 更新保存试题列表
  update(body) {
    return request({
      url: '/exambank/homework-item-list/update',
      method: 'put',
      data: body
    })
  },
  // 题库列表
  listQuestions(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-item-list/listQuestions',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 题库列表
  list(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-item-list/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据试卷编号查询详细试题列表
  getQuestionByAssignId(hwId) {
    return request({
      url: '/exambank/homework-item-list/getQuestionByAssignId/' + hwId,
      method: 'get'
    })
  },
  /**
   * 根据作业编号获取作业列表和正确率，提交人数
   */
  getQuestionByAssignIdForStatistic(hwId) {
    return request({
      url: '/exambank/homework-item-list/getQuestionByAssignIdForStatistic/' + hwId,
      method: 'get'
    })
  },
  // 学生端根据试卷编号查询详细试题列表以及用户答案
  studentGetQuestionByAssignId(hwId) {
    return request({
      url: '/exambank/homework-item-list/studentGetQuestionByAssignId/' + hwId,
      method: 'get'
    })
  },
  // 学生端根据试卷编号查询学生答卷详情、分数、解析
  studentRecordGetQuestionByAssignId(hwId) {
    return request({
      url: '/exambank/homework-item-list/studentRecordGetQuestionByAssignId/' + hwId,
      method: 'get'
    })
  },
  selectListBeforeCorrect(hwId, stuUserId) {
    return request({
      url: '/exambank/homework-item-list/selectListBeforeCorrect/' + hwId + '-' + stuUserId,
      method: 'get'
    })
  },
  // 更新布置作业信息
  updateAssign(body) {
    return request({
      url: '/exambank/homework-arrange/edit',
      method: 'put',
      data: body
    })
  },
  // 删除/恢复布置作业
  delete(hwId) {
    return request({
      url: '/exambank/homework-arrange/delete/' + hwId,
      method: 'delete'
    })
  },
  // 批量删除/恢复布置作业
  deleteBatch(ids) {
    return request({
      url: '/exambank/homework-arrange/deleteBatch',
      method: 'delete',
      params: { ids: ids }
    })
  },
  // 清空布置作业
  delectEmpty(body) {
    return request({
      url: '/exambank/homework-arrange/delectEmpty',
      method: 'delete',
      data: body
    })
  },

  /**
   * 根据作业编号获取作业布置信息
   * @Author:lhz
   */
  getHomeworkArrangeById(hwId) {
    return request({
      url: '/exambank/homework-arrange/getHomeworkArrangeById/' + hwId,
      method: 'get'
    })
  },
  /**
   * 根据用户编号获取未开始的作业布置信息
  */
  selectHomeworkArrangeNotStartListByMgId(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-arrange/selectHomeworkArrangeNotStartListByMgId',
      method: 'post',
      params: params,
      data: body
    })
  },
  /**
   * 根据用户编号获取已结束的作业布置信息
  */
  selectHomeworkArrangeEndListByMgId(data, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-arrange/selectHomeworkArrangeEndListByMgId',
      method: 'post',
      params: params,
      data
    })
  },
  /**
   * 根据用户编号获取进行中的作业布置信息
  */
  selectHomeworkArrangeDurationListByMgId(data, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-arrange/selectHomeworkArrangeDurationListByMgId',
      method: 'post',
      params: params,
      data
    })
  },
  /**
   * 根据用户编号获取可批阅的学生作业列表
   */
  selectHomeworkArrangeEndList(homeworkArrange, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-arrange/selectHomeworkArrangeEndList',
      method: 'post',
      data: homeworkArrange,
      params: params
    })
  },
  studentRecordCorrectByAssignId(hwId, userId) {
    const params = new URLSearchParams()
    params.append('hwId', hwId)
    params.append('userId', userId)
    return request({
      url: '/exambank/homework-arrange/studentRecordCorrectByAssignId',
      method: 'get',
      params: params
    })
  },
  // 保存教师批阅结果
  saveCorrect(body, hwrId) {
    return request({
      url: '/exambank/homework-item-list/saveCorrect/' + hwrId,
      method: 'put',
      data: body
    })
  },
  statisticsHomework(courseSchemaId, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-arrange/statisticsHomework/' + courseSchemaId,
      method: 'get',
      params: params
    })
  },
  statistics(courseSchemaId) {
    return request({
      url: '/exambank/homework-arrange/statistics/' + courseSchemaId,
      method: 'get'
    })
  }
}
