import request from '@/utils/request'

export default {
  // 自动评分和保存
  automaticJudgment(entity) {
    return request({
      url: '/exambank/homework-material-detail/automaticJudgment',
      method: 'put',
      data: entity
    })
  }
}
