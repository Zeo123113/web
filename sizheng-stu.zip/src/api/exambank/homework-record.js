import request from '@/utils/request'

export default {
  // 添加学生作业记录
  addHomeworkRecord(data) {
    return request({
      url: '/exambank/homework-record/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getHomeworkRecordList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/homework-record/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 编辑学生作业记录
  updateHomeworkRecord(data) {
    return request({
      url: '/exambank/homework-record/update',
      method: 'put',
      data
    })
  },
  // 真删除
  delHomeworkRecord(data) {
    return request({
      url: '/exambank/homework-record/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 逻辑删除
  fakedelHomeworkRecord(data) {
    return request({
      url: '/exambank/homework-record/fakedelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量删除授课计划(逻辑删除)
  batchDelete(data) {
    return request({
      url: '/exambank/homework-record/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量还原授课计划
  batchRecall(data) {
    return request({
      url: '/exambank/homework-record/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量删除授课计划（真删除）
  realDelete(data) {
    return request({
      url: '/exambank/homework-record/realDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据条件清空授课计划
  realDeleteByCondtions(data) {
    return request({
      url: '/exambank/homework-record/realDeleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 根据条件删除授课计划
  deleteByCondtions(data) {
    return request({
      url: '/exambank/homework-record/deleteByCondtions',
      method: 'delete',
      data
    })
  },
  // 根据条件恢复授课计划
  recallByCondtions(data) {
    return request({
      url: '/exambank/homework-record/recallByCondtions',
      method: 'delete',
      data
    })
  },
  // 根据id获取所哟信息
  getAllById(hwrId) {
    return request({
      url: '/exambank/homework-record/getAllById/ ' + hwrId,
      method: 'get'
    })
  },
  // 根据用户id获取作业记录
  selectHomeworkRecordListByUserId(data) {
    return request({
      url: '/exambank/homework-record/selectHomeworkRecordListByUserId',
      method: 'post',
      data
    })
  },
  getRecordByHwId(hwId) {
    return request({
      url: '/exambank/homework-record/getRecordByHwId/' + hwId,
      method: 'get'
    })
  },
  /**
   * @description 根据考试安排获取学生的每次作业成绩和总成绩
   */
  statisticsInfo(statisticsItemList) {
    return request({
      url: '/exambank/homework-record/statisticsInfo',
      method: 'post',
      data: statisticsItemList
    })
  }
}
