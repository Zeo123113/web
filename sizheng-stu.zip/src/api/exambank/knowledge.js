import request from '@/utils/request'

export default {

  // 查询知识点列表
  listKnowledge(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/knowledge/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 新增知识点
  addKnowledge(data) {
    return request({
      url: '/exambank/knowledge/add',
      method: 'post',
      data: data
    })
  },
  // 修改知识点
  updateKnowledge(data) {
    return request({
      url: '/exambank/knowledge/edit',
      method: 'put',
      data: data
    })
  },
  // 单条删除知识点
  delKnowledge(KnowledgeId) {
    return request({
      url: `/exambank/knowledge/${KnowledgeId}`,
      method: 'delete'
    })
  },
  // 批量删除知识点
  batchDelete(data) {
    return request({
      url: `/exambank/knowledge/batchDeleteByIds`,
      method: 'delete',
      data: data
    })
  },
  /**
  * @description 根据课程编号和章节编号查询知识点信息
  * @author LHZ
  */
  getKnownledgeListByCourseId(courseId) {
    return request({
      url: `/exambank/knowledge/getKnowledgeListByCourseIdAndChapterId/${courseId}`,
      method: 'get'
    })
  },
  /**
  * @description 保存知识点
  * @author LHZ
  * @update cpy
  */
  addKnownledge(knownledge) {
    return request({
      url: '/exambank/knowledge/addEntity',
      method: 'post',
      data: knownledge
    })
  }
}
