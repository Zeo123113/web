import request from '@/utils/request'

export default {
  // 自动评分和保存
  automaticJudgment(entity) {
    return request({
      url: '/exambank/material-answer/automaticJudgment',
      method: 'put',
      data: entity
    })
  },
  // 处理学生阅卷
  dealMaterialAnswerMarking(data) {
    return request({
      url: '/exambank/material-answer/dealMaterialAnswerMarking',
      method: 'post',
      data
    })
  }
}
