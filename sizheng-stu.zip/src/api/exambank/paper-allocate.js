import request from '@/utils/request'

export default {
  // 编辑阅卷设置
  updateSettings(data) {
    return request({
      url: '/exambank/paper-allocate/updateSettings',
      method: 'put',
      data
    })
  },
  // 根据课程-学期-试卷paperIds，题型typeIds，查询出所有要分配的试题ids,从试题分配表
  getIdsByTypeIds(data) {
    return request({
      url: '/exambank/paper-allocate/getIdsByTypeIds',
      method: 'post',
      data
    })
  },
  // 展示所有已添加的阅卷设置
  getSettings() {
    return request({
      url: '/exambank/paper-allocate/getSettings',
      method: 'get'
    })
  },
  // 根据answerId，查询阅卷试题分配信息
  getListByAllocateId(allocateId) {
    return request({
      url: '/exambank/paper-allocate/getList/' + allocateId,
      method: 'get'
    })
  },
  // 添加学生阅卷试题分配
  addPaperAllocate(data) {
    return request({
      url: '/exambank/paper-allocate/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getPaperAllocateList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/paper-allocate/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 编辑学生阅卷试题分配
  updatePaperAllocate(data) {
    return request({
      url: '/exambank/paper-allocate/update',
      method: 'put',
      data
    })
  },
  delPaperAllocate(data) {
    return request({
      url: '/exambank/paper-allocate/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据阅卷教师Id获取分配的试题列表
  getPaperAllocateListByTeacherId(data) {
    return request({
      url: '/exambank/paper-allocate/getPaperAllocateListByTeacherId',
      method: 'post',
      data
    })
  },
  // 根据Id修改阅卷状态
  updateStatusById(allocateId) {
    return request({
      url: `/exambank/paper-allocate/updateStatusById/${allocateId}`,
      method: 'put'
    })
  },
  // 处理集体阅卷完成阅卷
  dealSubmitAllocate(data) {
    return request({
      url: `/exambank/paper-allocate/dealSubmitAllocate`,
      method: 'post',
      data
    })
  }
}
