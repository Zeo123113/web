import request from '@/utils/request'

export default {
  // 根据课程和学期编号，来获取试卷
  getPapersByCourseAndTerm(courseId, termId) {
    const params = new URLSearchParams()
    params.append('courseId', courseId)
    params.append('termId', termId)
    return request({
      url: '/exambank/paper/getPaper',
      method: 'post',
      params: params
    })
  },
  // 添加试卷
  addPaper(body) {
    return request({
      url: '/exambank/paper/add',
      method: 'post',
      data: body
    })
  },
  // 添加试题列表
  addQuestionList(body, listMethod) {
    return request({
      url: '/exambank/question-list/add',
      method: 'post',
      params: { listMethod: listMethod },
      data: body
    })
  },
  // 添加材料题试题列表
  addMaterial(body) {
    return request({
      url: '/exambank/question-list/addMaterial',
      method: 'post',
      data: body
    })
  },
  // 根据材料题Id获取材料子题
  getMasterialItemByTqId(tqId) {
    return request({
      url: '/exambank/question-list/getMasterialItemByTqId/' + tqId,
      method: 'get'
    })
  },
  // 修改试卷
  editPaper(body) {
    return request({
      url: '/exambank/paper/edit',
      method: 'put',
      data: body
    })
  },
  // 列表展示
  listPaper(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/paper/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 题库列表
  listQuestions(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/question-list/listQuestions',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 题库列表
  list(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/question-list/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据试卷编号查询试题列表
  getListByPaperId(paperId) {
    return request({
      url: '/exambank/question-list/getListByPaperId/' + paperId,
      method: 'get'
    })
  },
  // 根据试卷编号查询详细试题列表
  getQuestionByPaperId(paperId) {
    return request({
      url: '/exambank/question-list/getQuestionByPaperId/' + paperId,
      method: 'get'
    })
  },
  // 预览保存试题列表
  update(body) {
    return request({
      url: '/exambank/question-list/update',
      method: 'put',
      data: body
    })
  },
  // 删除试卷
  deletePaper(paperId) {
    return request({
      url: '/exambank/paper/delete/' + paperId,
      method: 'delete'
    })
  },
  deletebatch(ids) {
    return request({
      url: '/exambank/paper/deletebatch',
      method: 'delete',
      params: { ids: ids }
    })
  },
  // 清空试卷
  delectEmpty(paper) {
    return request({
      url: '/exambank/paper/delectEmpty',
      method: 'delete',
      data: paper
    })
  },
  /**
   * 根据id获取试卷
   */
  getPaperById(id) {
    return request({
      url: `/exambank/paper/getPaperById/${id}`,
      method: 'get'
    })
  },
  /**
   * 根据试卷ID,答卷ID获取试题列表
   */
  getPaperQuestionListByPaperIdAndAnswerId(paperId, answerId) {
    return request({
      url: `/exambank/question-list/getPaperQuestionListByPaperIdAndAnswerId/${paperId}/${answerId}`,
      method: 'get'
    })
  },
  /**
   *  根据考试安排Id获取试卷Id
   */
  getPaperIdByExamArrangeId(examArrangeId) {
    return request({
      url: `/exambank/paper/getPaperIdByExamArrangeId/${examArrangeId}`,
      method: 'get'
    })
  },
  /**
   *  根据考试安排Id获取试卷列表
   */
  getPaperListByExamArrangeId(examArrangeId) {
    return request({
      url: `/exambank/paper/getPaperListByExamArrangeId/${examArrangeId}`,
      method: 'get'
    })
  }
}
