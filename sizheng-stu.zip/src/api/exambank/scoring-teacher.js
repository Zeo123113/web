import request from '@/utils/request'

export default {
  // 根据课程，学期编号，来获取阅卷老师
  listByTerm(body) {
    return request({
      url: '/exambank/scoring-teacher/listByTerm',
      method: 'post',
      data: body
    })
  },
  // 添加学生阅卷教师
  addScoringTeacher(data) {
    return request({
      url: '/exambank/scoring-teacher/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getScoringTeacherList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/scoring-teacher/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 编辑学生阅卷教师
  updateScoringTeacher(data) {
    return request({
      url: '/exambank/scoring-teacher/update',
      method: 'put',
      data
    })
  },
  delScoringTeacher(data) {
    return request({
      url: '/exambank/scoring-teacher/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 处理阅卷教师登录
  scoreTeacherLogin(data) {
    return request({
      url: '/exambank/scoring-teacher/scoreTeacherLogin',
      method: 'post',
      data
    })
  }
}
