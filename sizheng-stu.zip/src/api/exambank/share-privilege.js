import request from '@/utils/request'
export default {

  // 增加共享权限
  add(data) {
    return request({
      url: '/exambank/share-privilege/add',
      method: 'post',
      data
    })
  },
  // 删除共享权限
  delete(id) {
    return request({
      url: `/exambank/share-privilege/delete/${id}`,
      method: 'delete'
    })
  },
  // 批量删除共享权限
  deleteByIds(data) {
    return request({
      url: '/exambank/share-privilege/batchDelete',
      method: 'delete',
      data
    })
  },
  // 更新共享权限
  update(data) {
    return request({
      url: '/exambank/share-privilege/update',
      method: 'put',
      data
    })
  },
  // 根据条件查找共享权限
  getListByCondition(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/share-privilege/getListByCondition',
      method: 'post',
      data,
      params: params
    })
  },
  // 检查当前用户是否具有修改该试题，试卷或考试安排的权限
  check(data) {
    return request({
      url: '/exambank/share-privilege/check',
      method: 'post',
      data
    })
  },
  // 根据ID查询共享权限纪录
  getShareById(id) {
    return request({
      url: `/exambank/share-privilege/getShareById/${id}`,
      method: 'get'
    })
  }

}
