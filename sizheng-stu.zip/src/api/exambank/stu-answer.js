import request from '@/utils/request'

export default {
  // 添加学生答卷
  addStuAnswer(data) {
    return request({
      url: '/exambank/student-answer/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getStuAnswerList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/student-answer/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 编辑学生答卷
  updateStuAnswer(data) {
    return request({
      url: '/exambank/student-answer/update',
      method: 'put',
      data
    })
  },
  // 删除学生答卷
  delStuAnswer(data) {
    return request({
      url: '/exambank/student-answer/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 导出学生答卷，根据条件查询
  export(params) {
    return request({
      url: '/exambank/student-answer/export',
      method: 'get',
      params,
      responseType: 'blob'
    })
  },
  // 根据学生编号和试卷编号查询学生答卷
  getStuAnswerByPaperIdAndUserId(data) {
    return request({
      url: '/exambank/student-answer/getStuAnswerByPaperIdAndUserId',
      method: 'post',
      data: data
    })
  },
  // 添加学生答卷
  addStuAnswerByPaperIdAndUserId(data) {
    return request({
      url: '/exambank/student-answer/addStuAnswerByPaperIdAndUserId',
      method: 'post',
      data
    })
  },
  // 处理学生交卷
  submitStuAnswer(answerId, examRecId) {
    return request({
      url: `/exambank/student-answer/submitStuAnswer/${answerId}/${examRecId}`,
      method: 'get'
    })
  },
  // 处理教师完成阅卷
  finishMarke(answerId, isGrading) {
    const params = new URLSearchParams()
    params.append('isGrading', isGrading)
    return request({
      url: `/exambank/student-answer/finishMarke/${answerId}`,
      method: 'get',
      params: params
    })
  },
  // 根据试卷编号场次编号考试类型查找学生答卷列表
  getStuAnswerListByRoundIdANDPaperId(data) {
    return request({
      url: '/exambank/student-answer/getStuAnswerListByRoundIdANDPaperId',
      method: 'post',
      data
    })
  },
  // 分页条件查询学生答卷,用于教师端考试统计
  getList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/student-answer/getList',
      method: 'post',
      data: body,
      params: params
    })
  },
  /**
   * @author: cpy
   * @param {*} statisticsItemList
   * @description 根据考试安排获取学生的每次考试/测验成绩和总成绩
   */
  statisticsInfo(statisticsItemList) {
    return request({
      url: '/exambank/student-answer/statisticsInfo',
      method: 'post',
      data: statisticsItemList
    })
  }
}
