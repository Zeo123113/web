import request from '@/utils/request'

export default {
  // 根据课程-学期-试卷paperIds，题型typeIds，查询出所有要分配的试题ids,从答卷详情试题表
  getIdsByQuestionType(data) {
    return request({
      url: '/exambank/stu-paper-detail/getIdsByQuestionType',
      method: 'post',
      data
    })
  },
  // 根据answerId，查询答卷详情信息
  getListByAnswerId(answerId) {
    return request({
      url: '/exambank/stu-paper-detail/getList/' + answerId,
      method: 'get'
    })
  },
  // 添加学生答卷详情
  addStuPaperDetail(data) {
    return request({
      url: '/exambank/stu-paper-detail/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getStuPaperDetailList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/exambank/stu-paper-detail/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 编辑学生答卷详情
  updateStuPaperDetail(data) {
    return request({
      url: '/exambank/stu-paper-detail/update',
      method: 'put',
      data
    })
  },
  delStuPaperDetail(data) {
    return request({
      url: '/exambank/stu-paper-detail/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据学生答卷获取答卷详情
  getStuPaperDetailByPaperId(paperId, answerId) {
    return request({
      url: `/exambank/stu-paper-detail/getStuPaperDetailByPaperId/${paperId}/${answerId}`,
      method: 'get'
    })
  },
  // 提交答卷详情能评分的自动评分，不能的直接保存详情
  automaticJudgment(data) {
    return request({
      url: '/exambank/stu-paper-detail/automaticJudgment',
      method: 'put',
      data
    })
  },
  // 教师阅卷获取详情
  getMarkeStuPaperDetail(data) {
    return request({
      url: '/exambank/stu-paper-detail/getMarkeStuPaperDetail',
      method: 'post',
      data
    })
  },
  // 处理教师阅卷
  dealMarking(data) {
    return request({
      url: '/exambank/stu-paper-detail/dealMarking',
      method: 'post',
      data
    })
  },
  // 根据Id查找
  getEntityById(id) {
    return request({
      url: `/exambank/stu-paper-detail/getById/${id}`,
      method: 'get'
    })
  }
}
