import request from '@/utils/request'

export default {
  // 根据查询条件查询音频文件分页数据列表
  getaudioFileList(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/file/audio-files/list',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 修改音频文件名
  updateaudioFile(data) {
    return request({
      url: '/file/audio-files/update',
      method: 'put',
      data
    })
  },
  delaudioFile(data) {
    return request({
      url: '/file/audio-files/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getaudioFile(id) {
    return request({
      url: '/file/audio-files/getById/' + id,
      method: 'get'
    })
  },
  // 上传文件
  uploadFile(data, fileTag, fileOriginalName, duration) {
    const params = new URLSearchParams()
    params.append('fileTag', fileTag)
    params.append('fileOriginalName', fileOriginalName)
    params.append('duration', duration)
    return request({
      url: '/file/audio-files/upload',
      method: 'post',
      data: data,
      params: params
    })
  }
}
