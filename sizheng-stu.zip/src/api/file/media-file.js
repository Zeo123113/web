import request from '@/utils/request'

export default {

  // 获取视频文件列表
  getMediaFileList(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/file/video-files/list',
      method: 'post',
      data,
      params: params
    })
  },
  // 根据MD5获取视频文件信息
  getMediaFile(md5) {
    return request({
      url: '/file/video-files/getByMd5/' + md5,
      method: 'get'
    })
  },
  // 删除视频文件
  delete(data) {
    return request({
      url: '/file/video-files/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 更新视频文件
  updateMediaFile(data) {
    return request({
      url: '/file/video-files/update',
      method: 'put',
      data
    })
  },
  // 文件上传
  beforeSendFile(fileMd5, fileOriginalName, fileSize, mimeType, fileExt) {
    return request({
      url: '/file/video-files/checkfile',
      method: 'post',
      data: {
        // 文件唯一表示
        fileMd5: fileMd5,
        fileOriginalName: fileOriginalName,
        fileSize: fileSize,
        mimeType: mimeType,
        fileExt: fileExt
      }
    })
  },
  beforeSend(fileMd5, chunk, chunkSize) {
    return request({
      url: '/file/video-files/checkchunk',
      method: 'post',
      data: {
        fileMd5: fileMd5,
        chunk: chunk,
        chunkSize: chunkSize
      }
    })
  },

  afterSendFile(fileMd5, fileOriginalName, fileSize, mimeType, fileExt, fileTag) {
    return request({
      url: '/file/video-files/mergechunks',
      method: 'post',
      data: {
        // 文件唯一表示
        fileMd5: fileMd5,
        fileOriginalName: fileOriginalName,
        fileSize: fileSize,
        mimeType: mimeType,
        fileExt: fileExt,
        fileTag: fileTag
      }
    })
  }

}
