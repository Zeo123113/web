import request from '@/utils/request'

export default {
  // 根据查询条件查询活动文件分页数据列表
  getstudentFileList(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/file/student-files/list',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 修改文件名
  updatestudentFile(data) {
    return request({
      url: '/file/student-files/update',
      method: 'put',
      data: data
    })
  },
  delstudentFile(data) {
    return request({
      url: '/file/student-files/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getstudentFile(id) {
    return request({
      url: '/file/student-files/getById/' + id,
      method: 'get'
    })
  },
  beforeSend(fileMd5, chunk, chunkSize) {
    return request({
      url: '/file/student-files/checkchunk',
      method: 'post',
      data: {
        fileMd5: fileMd5,
        chunk: chunk,
        chunkSize: chunkSize
      }
    })
  },
  afterSendFile(fileMd5, fileName, fileSize, mimeType, fileExt) {
    return request({
      url: '/file/student-files/mergechunks',
      method: 'post',
      data: {
        // 文件唯一表示
        fileMd5: fileMd5,
        fileName: fileName,
        fileSize: fileSize,
        mimeType: mimeType,
        fileExt: fileExt
      }
    })
  }
}
