import request from '@/utils/request'

export default {
  // 根据查询条件查询活动文件分页数据列表
  getsystemFileList(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/file/system-files/list',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 修改活动文件名
  updatesystemFile(data) {
    return request({
      url: '/file/system-files/update',
      method: 'put',
      data
    })
  },
  delsystemFile(data) {
    return request({
      url: '/file/system-files/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getsystemFile(id) {
    return request({
      url: '/file/system-files/getById/' + id,
      method: 'get'
    })
  },
  // 上传文件
  uploadFile(data, fileTag, fileOriginalName) {
    const params = new URLSearchParams()
    params.append('fileTag', fileTag)
    params.append('fileOriginalName', fileOriginalName)
    return request({
      url: '/file/system-files/upload',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 富文本图片上传
  tinyMceUpload(fmData) {
    return request({
      url: '/file/system-files/tinyMceUpload',
      method: 'post',
      data: fmData
    })
  },
  // 资料库的文件转换为pdf接口
  changeToPdf(data) {
    return request({
      url: '/file/system-files/changeToPdf',
      method: 'post',
      data: data
    })
  }
}
