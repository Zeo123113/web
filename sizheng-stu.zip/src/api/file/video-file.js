/**
 * @file 视频文件管理模块
 * @author lhz
 * @copyright 思政平台项目组
 * @createDate 2020-04-03 07:26:11
 */

import request from '@/utils/request'

export default {
  /**
   * @description 在文件被发送前先检查文件是否存在
   * @method
   * @param {string} fileMd5 文件的MD值，取文件的前5M的MD5
   * @param {string} fileOriginalName 文件原始文件名
   * @param {string} fileExt 文件扩展名
   * @param {number} fileSize 文件大小
   * @returns {object} 返回json对象，返值见file-const.js文件
   */
  checkFileExistBeforeSend(fileMd5, fileOriginalName, fileExt, fileSize) {
    return request({
      url: '/file/video-files/checkFileExistBeforeSend',
      method: 'post',
      data: {
        fileMd5: fileMd5,
        fileOriginalName: fileOriginalName,
        fileExt: fileExt,
        fileSize: fileSize
      }
    })
  },
  /**
   * @description 每次上传分块前校验分块，如果已存在分块则不再上传
   * @param {string} fileMd5 文件的MD5
   * @param {number} chunk 分块编号
   * @param {number} chunkSize 分块大小
   * @returns {object} 返回json对象，返值见file-const.js文件
   */
  beforeSend(fileMd5, chunk, chunkSize) {
    return request({
      url: '/file/video-files/checkchunk',
      method: 'post',
      data: {
        fileMd5: fileMd5,
        chunk: chunk,
        chunkSize: chunkSize
      }
    })
  },

  /**
   * @description 所有分块上传完毕后，合并文件分块
   * @param {string} fileMd5 文件的MD5
   * @param {string} fileOriginalName 文件的原始名称
   * @param {number} fileSize 文件大小
   * @param {string} fileExt 文件扩展名
   * @returns {object} 返回json对象，返值见file-const.js文件
   */
  afterSendFile(fileMd5, fileOriginalName, fileSize, fileExt) {
    return request({
      url: '/file/video-files/mergechunks',
      method: 'post',
      data: {
        // 文件唯一表示
        fileMd5: fileMd5,
        fileOriginalName: fileOriginalName,
        fileSize: fileSize,
        fileExt: fileExt
      }
    })
  },

  /**
   * @description 把文件上传到FastDFS
   * @param {string} fileMd5 文件的MD5
   * @param {string} fileOriginalName 文件的原始名称
   * @param {number} fileSize 文件大小
   * @param {string} fileExt 文件扩展名
   * @param {string} fileTag 文件标签
   * @returns {object} 返回json对象，返值见file-const.js文件
   */
  uploadFileToFastDFS(fileMd5, fileOriginalName, fileSize, fileExt, fileTag) {
    return request({
      url: '/file/video-files/uploadToFastDFS',
      method: 'post',
      data: {
        fileMd5: fileMd5,
        fileOriginalName: fileOriginalName,
        fileSize: fileSize,
        fileExt: fileExt,
        fileTag: fileTag
      }
    })
  },

  /**
   * @description 查询文件上传到fastdfs的进度
   * @param {string} fileMd5 文件的MD5
   * @returns {number} 0-100表示的上传进度
   */
  uploadProgress(fileMd5) {
    return request({
      url: '/file/video-files/uploadProgress/' + fileMd5,
      method: 'get'
    })
  },
  /**
   * @description 发送文件转码消息
   * @param {string} fileMd5 文件的MD5
   * @param {boolean} isSlicing 文件转码后是否切片
   * @returns {number} data为0代表成功，不为0失败
   */
  sendFileConvertMsg(fileMd5, isSlicing) {
    return request({
      url: '/file/video-files/sendFileConvertMsg/' + fileMd5 + '/' + isSlicing,
      method: 'get'
    })
  },
  /**
   * @description 根据文件md5查询文件状态
   * @param {string} fileMd5 文件的MD5
   * @returns {string} 返回文件当前状态，具体含义参见file-const.js
   */
  getFileStatusByMd5(fileMd5) {
    return request({
      url: '/file/video-files/getFileStatusByMd5/' + fileMd5,
      method: 'get'
    })
  }
}
