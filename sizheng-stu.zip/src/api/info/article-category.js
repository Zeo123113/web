import request from '@/utils/request'

export default {
  // 查询类别列表
  listArticleCategory(data) {
    return request({
      url: '/news/article-category/list',
      method: 'post',
      data
    })
  },
  addArticleCategory(data) {
    return request({
      url: '/news/article-category/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getArticleCategoryTree() {
    return request({
      url: '/news/article-category/tree',
      method: 'get'
    })
  },
  updateArticleCategory(data) {
    return request({
      url: '/news/article-category/update',
      method: 'put',
      data
    })
  },
  delArticleCategory(data) {
    return request({
      url: '/news/article-category/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getArticleCategoryById(id) {
    return request({
      url: '/news/article-category/getById/' + id,
      method: 'get'
    })
  }
}
