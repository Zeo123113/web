import request from '@/utils/request'

export default {
  // 添加文章评论
  addArticleComment(data) {
    return request({
      url: '/news/article-comment/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getarticleCommentList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/news/article-comment/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  updatearticleComment(data) {
    return request({
      url: '/news/article-comment/update',
      method: 'put',
      data
    })
  },
  delarticleComment(data) {
    return request({
      url: '/news/article-comment/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getActivityById(id) {
    return request({
      url: '/news/article-comment/getById/' + id,
      method: 'get'
    })
  }
}
