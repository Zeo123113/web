import request from '@/utils/request'

export default {
  // 添加文章
  addArticle(data) {
    return request({
      url: '/news/article/add',
      method: 'post',
      data
    })
  },
  // 列表展示
  getArticleList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/news/article/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 编辑文章
  updateArticle(data) {
    return request({
      url: '/news/article/update',
      method: 'put',
      data
    })
  },
  // 审核文章
  checkArticle(data) {
    return request({
      url: '/news/article/check',
      method: 'put',
      data
    })
  },
  delArticle(data) {
    return request({
      url: '/news/article/delete',
      method: 'delete',
      params: { ids: data }
    })
  }
}
