import request from '@/utils/request'

export default {
  // 增加消息
  add(data) {
    return request({
      url: '/news/message/add',
      method: 'post',
      data
    })
  },
  // // 根据Id删除消息
  // deleteMessageById(id) {
  //   return request({
  //     url: `/news/message/delete/${id}`,
  //     method: 'delete'
  //   })
  // },
  // 批量删除
  deleteMessageByIds(data) {
    return request({
      url: '/news/message/delete',
      method: 'delete',
      params: { messageIds: data }
    })
  },
  // 修改消息
  update(msgId) {
    return request({
      url: '/news/message/update',
      method: 'put',
      params: { msgId: msgId }
    })
  },
  // 列表展示消息
  getMessageList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/news/message/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据用户获取信息列表
  getMessageListByUser(userId, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: `/news/message/getMessageByUser/${userId}`,
      method: 'get',
      params: params
    })
  },
  // 根据用户获取未读消息个数
  getMessageCountByUser(userId) {
    return request({
      url: `/news/message/getMessageCountByUser/${userId}`,
      method: 'get'
    })
  },
  // 标记全部消息为已读
  readAllMessage() {
    return request({
      url: '/news/message/readAllMessage',
      method: 'post'
    })
  }
}
