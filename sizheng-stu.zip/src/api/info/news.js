import request from '@/utils/request'

export default {
  // 查询新闻列表
  listNews(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/news/news/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据newsId预览新闻内容
  getNews(NewsId) {
    return request({
      url: `/news/news/list/${NewsId}`,
      method: 'get'
    })
  },
  // 新增新闻
  addNews(data) {
    return request({
      url: '/news/news/add',
      method: 'post',
      data: data
    })
  },
  // 修改新闻
  updateNews(data) {
    return request({
      url: '/news/news/edit',
      method: 'put',
      data: data
    })
  },
  // 单条删除新闻
  delNews(NewsId) {
    return request({
      url: `/news/news/${NewsId}`,
      method: 'delete'
    })
  },
  // 批量删除新闻
  batchDelete(data) {
    return request({
      url: `/news/news/batchDeleteByIds`,
      method: 'delete',
      data: data
    })
  },
  // 根据二级栏目id查询所有新闻
  selectNewsListByNewsCateId(newsCateid) {
    return request({
      url: `/news/news/list/selectNewsListByNewsCateId/${newsCateid}`,
      method: 'get'
    })
  },
  // 根据一级栏目id查询栏目下的所有新闻
  getNewsListByParentId(parentId) {
    return request({
      url: `/news/news/list/getNewsListByParentId/${parentId}`,
      method: 'get'
    })
  },
  // 获取新闻列表用于前端首页展示
  selectNewsList(orgId, newsAmount) {
    return request({
      url: `/news/news/selectNewsList/${orgId}/${newsAmount}`,
      method: 'get'
    })
  }
}
