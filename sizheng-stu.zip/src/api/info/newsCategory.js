import request from '@/utils/request'

export default {
  // 新增新闻栏目
  addNewsCategory(data) {
    return request({
      url: '/news/newCategory/add',
      method: 'post',
      data: data
    })
  },
  // 根据NewCategoryId单条删除记录
  deleteNewsCategoryById(NewCategoryId) {
    return request({
      url: `/news/newCategory/delete/${NewCategoryId}`,
      method: 'delete'
    })
  },
  // 修改NewCategory
  updateNewsCategory(data) {
    return request({
      url: '/news/newCategory/edit',
      method: 'put',
      data: data
    })
  },
  // 带分页，查询条件的查询
  listNewsCategory(queryParams) {
    return request({
      url: '/news/newCategory/list',
      method: 'post',
      data: queryParams
    })
  },
  // 根据key查询配置项
  getNewsCategoryValueByKey(key) {
    return request({
      url: '/news/newCategory/getNewCategoryValueByKey',
      method: 'post',
      data: key
    })
  },
  // 根据key列表查询配置项,keylist为逗号分隔的key列表项
  getNewsCategoryListByKeyList(keylist) {
    return request({
      url: '/news/newCategory/getNewCategoryListByKeyList',
      method: 'post',
      data: keylist
    })
  },
  // 查询栏目下拉树结构
  treeselect() {
    return request({
      url: '/news/newCategory/treeSelect',
      method: 'get'
    })
  },
  // 根据一级栏目id查询二级栏目信息
  getChildrenByParentId(parentId) {
    return request({
      url: `/news/newCategory/list/${parentId}`,
      method: 'get'
    })
  },
  // 根据新闻栏目id查询栏目信息
  getNewCategoryByNewsCateId(newsCateId) {
    return request({
      url: `/news/newCategory/list/newsCateId/${newsCateId}`,
      method: 'get'
    })
  }

}
