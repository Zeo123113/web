import request from '@/utils/request'

export default {
  // 查询新闻评论点赞列表
  listNewsCommentLike(body) {
    return request({
      url: '/news/news-comment-like/listNewsCommentLike',
      method: 'post',
      data: body
    })
  },
  // 新增新闻评论点赞
  addNewsCommentLike(data) {
    return request({
      url: '/news/news-comment-like/add',
      method: 'post',
      data: data
    })
  }
}
