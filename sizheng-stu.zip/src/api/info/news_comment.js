import request from '@/utils/request'

export default {
  // 添加文章评论
  addNewsComment(data) {
    return request({
      url: '/news/news-comment/add',
      method: 'post',
      data
    })
  },
  // 根据ncId预览回复内容
  getReply(ncId) {
    return request({
      url: `/news/news-comment/list/getByNcId/${ncId}`,
      method: 'get'
    })
  },
  // 列表展示
  listNewsComment(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/news/news-comment/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据newsId预览新闻评论
  getNewsComment(NewsId) {
    return request({
      url: `/news/news-comment/list/${NewsId}`,
      method: 'get'
    })
  },
  // 批量删除
  deleteBatch(data) {
    return request({
      url: '/news/news-comment/deletebatch',
      method: 'delete',
      params: { ids: data }
    })
  },
  deleteNewsComment(ncId) {
    return request({
      url: '/news/news-comment/delete/' + ncId,
      method: 'delete'
    })
  },
  updateNewsComment(data) {
    return request({
      url: '/news/news-comment/update',
      method: 'put',
      data
    })
  }
}
