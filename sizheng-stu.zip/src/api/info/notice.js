import request from '@/utils/request'

export default {
  // 列表展示
  listNotice(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/news/notice/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据noticeId预览新闻内容
  getNotice(noticeId) {
    return request({
      url: `/news/notice/list/${noticeId}`,
      method: 'get'
    })
  },
  // 添加公告
  addNotice(body) {
    return request({
      url: '/news/notice/add',
      method: 'post',
      data: body
    })
  },
  // 删除公告
  deleteNotice(noticeId) {
    return request({
      url: '/news/notice/delete/' + noticeId,
      method: 'delete'
    })
  },
  // 批量删除公告
  deleteBatch(data) {
    return request({
      url: '/news/notice/deletebatch',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 修改公告
  editNotice(body) {
    return request({
      url: '/news/notice/edit',
      method: 'put',
      data: body
    })
  },
  // 审核公告
  auditNotice(body) {
    return request({
      url: '/news/notice/audit',
      method: 'put',
      data: body
    })
  },
  // 获取公告列表用于前端首页展示
  selectNoticeList(orgId, newsAmount) {
    return request({
      url: `/news/notice/selectNoticeList/${orgId}/${newsAmount}`,
      method: 'get'
    })
  }
}
