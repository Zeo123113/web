import request from '@/utils/request'

export default {
  // 根据查询条件查询敏感词分页数据列表
  getWordFilterByCondition(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/news/word-filter/list',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 根据id查询敏感词
  getWordFilterById(filterId) {
    return request({
      url: '/news/word-filter/selectWordFilterById/' + filterId,
      method: 'get'
    })
  },
  // 新增敏感词
  addWordFilter(data) {
    return request({
      url: '/news/word-filter/add',
      method: 'post',
      data: data
    })
  },
  // 修改敏感词
  updateWordFilter(data) {
    return request({
      url: '/news/word-filter/update',
      method: 'put',
      data: data
    })
  },
  // 删除/批量删除敏感词
  delWordFilterList(data) {
    return request({
      url: '/news/word-filter/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 下载导入模板
  downloadTemplete() {
    return request({
      url: '/news/word-filter/template',
      method: 'get'
    })
  },
  // 导出字典类型信息
  export() {
    return request({
      url: '/news/word-filter/export',
      method: 'get',
      responseType: 'blob'
    })
  }
}
