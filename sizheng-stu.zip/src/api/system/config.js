import request from '@/utils/request'

export default {
  // 新增配置参数
  addConfig(data) {
    return request({
      url: '/system/config/add',
      method: 'post',
      data: data
    })
  },
  // 根据configId单条删除记录
  deleteConfigById(configId) {
    return request({
      url: `/system/config/delete/${configId}`,
      method: 'delete'
    })
  },
  // 修改config
  updateConfig(data) {
    return request({
      url: '/system/config/edit',
      method: 'put',
      data: data
    })
  },
  // 带分页，查询条件的查询
  listConfig(queryParams, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/system/config/list',
      method: 'post',
      data: queryParams,
      params: params
    })
  },
  // 根据key查询配置项
  getConfigValueByKey(key) {
    return request({
      url: '/system/config/getConfigValueByKey',
      method: 'post',
      data: key
    })
  },
  // 根据key列表查询配置项,keylist为逗号分隔的key列表项
  getConfigListByKeyList(keylist) {
    return request({
      url: '/system/config/getConfigListByKeyList',
      method: 'post',
      data: keylist
    })
  },
  // 导出配置参数信息
  export(params) {
    return request({
      url: '/system/config/export',
      method: 'get',
      params: params,
      responseType: 'blob'
    })
  }
}
