import request from '@/utils/request'

export default {
  // 根据查询条件查询字典数据分页数据列表
  getDictDataByCondition(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/system/dict-data/list',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 根据id查询字典数据
  getDataById(dictId) {
    return request({
      url: '/system/dict-data/selectDictDataById/' + dictId,
      method: 'get'
    })
  },
  // 根据字典类型查询字典数据
  getDataByType(dictType) {
    return request({
      url: '/system/dict-data/selectDictDataByType/' + dictType,
      method: 'get'
    })
  },
  // 新增字典数据
  addData(data) {
    return request({
      url: '/system/dict-data/add',
      method: 'post',
      data: data
    })
  },
  // 修改字典数据
  updateData(data) {
    return request({
      url: '/system/dict-data/update',
      method: 'put',
      data: data
    })
  },
  // 删除字典数据
  delData(dictId) {
    return request({
      url: '/system/dict-data/delete/' + dictId,
      method: 'delete'
    })
  },
  // 批量删除字典数据
  delDataList(data) {
    return request({
      url: '/system/dict-data/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  }
}
