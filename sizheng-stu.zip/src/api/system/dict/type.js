import request from '@/utils/request'

export default {
  // 根据查询条件查询字典类型分页数据列表
  getDictTypeByCondition(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/system/dict-type/pagList',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 查询字典类型数据列表
  listType() {
    return request({
      url: '/system/dict-type/list',
      method: 'get'
    })
  },
  // 根据id查询字典类型
  getType(dictId) {
    return request({
      url: '/system/dict-type/selectDictTypeById/' + dictId,
      method: 'get'
    })
  },
  // 新增字典类型
  addType(data) {
    return request({
      url: '/system/dict-type/add',
      method: 'post',
      data: data
    })
  },
  // 修改字典类型
  updateType(data) {
    return request({
      url: '/system/dict-type/update',
      method: 'put',
      data: data
    })
  },
  // 删除字典类型
  delType(dictId) {
    return request({
      url: '/system/dict-type/delete/' + dictId,
      method: 'delete'
    })
  },
  // 批量删除字典类型
  delTypeList(data) {
    return request({
      url: '/system/dict-type/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 导出字典类型信息
  export() {
    return request({
      url: '/system/dict-type/export',
      method: 'get',
      responseType: 'blob'
    })
  }
}
