import request from '@/utils/request'

export default {
  // 增加行政区域
  add(data) {
    return request({
      url: '/system/districts/add',
      method: 'post',
      data
    })
  },
  // 根据Id删除行政区域
  delete(id) {
    return request({
      url: `/system/districts/delete/${id}`,
      method: 'delete'
    })
  },
  // 修改行政区域
  update(data) {
    return request({
      url: '/system/districts/update',
      method: 'put',
      data
    })
  },
  // 根据条件查询行政区域
  getListByConditions(data) {
    return request({
      url: '/system/districts/getListByConditions',
      method: 'post',
      data
    })
  },
  // 根据父Id查询子地区列表
  getListByPid(pid) {
    return request({
      url: `/system/districts/getListByPid/${pid}`,
      method: 'get'
    })
  },
  // 根据Id查询地区
  getById(did) {
    return request({
      url: `/system/districts/getById/${did}`,
      method: 'get'
    })
  },
  // 导出行政区域信息
  export(params) {
    return request({
      url: '/system/districts/export',
      method: 'get',
      params,
      responseType: 'blob'
    })
  },
  // 下载导入模板
  downloadTemplete() {
    return request({
      url: '/system/districts/templete',
      method: 'get'
    })
  }
}
