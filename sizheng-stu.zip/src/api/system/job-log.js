/**
 * @description 任务日志调度
 * @author cpy
 */
import request from '@/utils/request'

export default {
  // 列表展示
  list(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/system/job-log/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/system/job-log/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/system/job-log/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/system/job-log/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/system/job-log/batchDelete',
      method: 'post',
      data: criteria
    })
  },
  // 导出任务日志
  export(params) {
    return request({
      url: '/system/job-log/export',
      method: 'get',
      params,
      responseType: 'blob'
    })
  }
}
