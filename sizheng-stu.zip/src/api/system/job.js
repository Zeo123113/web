/**
 * @description 定时任务调度
 * @author cpy
 */
import request from '@/utils/request'

export default {
  // 列表展示
  list() {
    return request({
      url: '/system/job/list',
      method: 'post'
    })
  },
  // 添加
  addEntry(data) {
    return request({
      url: '/system/job/add',
      method: 'post',
      data
    })
  },
  // 修改
  updateEntry(data) {
    return request({
      url: '/system/job/update',
      method: 'put',
      data
    })
  },
  // 批量删除
  batchDelete(data) {
    return request({
      url: '/system/job/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 按条件删除
  batchDeleteByCriteria(criteria) {
    return request({
      url: '/system/job/batchDelete',
      method: 'post',
      data: criteria
    })
  }
}
