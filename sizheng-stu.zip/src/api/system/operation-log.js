import request from '@/utils/request'

export default {
  // 批量删除cleanLoginLogByIds
  batchDelete(data) {
    return request({
      url: '/system/operation-log/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 清空记录
  delectEmpty(body) {
    return request({
      url: '/system/operation-log/delectEmpty',
      method: 'delete',
      data: body
    })
  },
  // 列表展示
  listLoginLog(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/system/operation-log/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 导出用户信息
  export(params) {
    return request({
      url: '/system/operation-log/export',
      method: 'get',
      params,
      responseType: 'blob'
    })
  }
}
