import request from '@/utils/request'

export default {
  addFavorite(data) {
    return request({
      url: '/user/favorite/add',
      method: 'post',
      data
    })
  },
  updateFavorite(data) {
    return request({
      url: '/user/favorite/update',
      method: 'put',
      data
    })
  },
  getFavoriteList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/user/favorite/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  delFavorite(data) {
    return request({
      url: '/user/favorite/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getFavorite(favId) {
    return request({
      url: '/user/favorite/getByFavId/' + favId,
      method: 'get'
    })
  }
}
