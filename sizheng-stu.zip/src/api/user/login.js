import request from '@/utils/request'

export default {
  imgcode() {
    return request({
      url: '/code',
      method: 'get',
      responseType: 'blob'
    })
  },
  getSmsCaptcha(data) {
    return request({
      url: '/getSmsCaptcha',
      method: 'post',
      // params: { aa: '112233444' },
      data
    })
  },
  getAppQRCode() {
    return request({
      url: '/appQRCode',
      method: 'get',
      responseType: 'blob'
    })
  }
}
