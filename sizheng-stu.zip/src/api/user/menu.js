import request from '@/utils/request'

export default {
  // 查询菜单列表
  listMenu(query) {
    return request({
      url: '/user/menu/list',
      method: 'post',
      data: query
    })
  },

  // 根据菜单ID查询菜单详细信息
  getMenu(menuId) {
    return request({
      url: '/user/menu/selectMenuById/' + menuId,
      method: 'get'
    })
  },

  // 查询菜单下拉树结构
  treeselect() {
    return request({
      url: '/user/menu/tree',
      method: 'get'
    })
  },

  // 根据角色ID查询角色所具有的权限
  selectMenuIdsByRoleId(roleId) {
    return request({
      url: '/user/menu/selectMenuIdsByRoleId/' + roleId,
      method: 'get'
    })
  },

  // 根据角色ID查询菜单树
  getMenuTreeByRoleId(roleId) {
    return request({
      url: '/user/menu/getMenuTreeByRoleId/' + roleId,
      method: 'get'
    })
  },

  // 新增菜单
  addMenu(data) {
    return request({
      url: '/user/menu/add',
      method: 'post',
      data: data
    })
  },

  // 修改菜单
  updateMenu(data) {
    return request({
      url: '/user/menu/update',
      method: 'put',
      data: data
    })
  },

  // 删除菜单
  delMenu(menuId) {
    return request({
      url: '/user/menu/delete/' + menuId,
      method: 'delete'
    })
  },
  // 下载导入模板
  downloadTemplete() {
    return request({
      url: '/user/menu/template',
      method: 'get'
    })
  },
  // 导出菜单信息
  export() {
    return request({
      url: '/user/menu/export',
      method: 'get',
      responseType: 'blob'
    })
  }
}
