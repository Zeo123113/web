import request from '@/utils/request'

export default {
  // 新增一个部门
  addOrg(data) {
    return request({
      url: '/user/org/add',
      method: 'post',
      data
    })
  },
  // 更新一个部门
  updateOrg(data) {
    return request({
      url: '/user/org/update',
      method: 'put',
      data
    })
  },
  // 删除一个部门
  delOrg(orgId) {
    return request({
      url: `/user/org/delete/${orgId}`,
      method: 'delete'
    })
  },
  // 恢复一个部门
  recallOrg(orgId) {
    return request({
      url: `/user/org/recall/${orgId}`,
      method: 'delete'
    })
  },
  // 清除一个部门
  cleanRecycleBinOrg(orgId) {
    return request({
      url: `/user/org/cleanRecycleBinById/${orgId}`,
      method: 'delete'
    })
  },
  // 批量恢复部门
  recallAllOrg(data) {
    return request({
      url: '/user/org/batchRecall',
      method: 'delete',
      data
    })
  },
  // 批量清除部门
  cleanRecycleBinAll(data) {
    return request({
      url: '/user/org/batchCleanRecycleBin',
      method: 'delete',
      data
    })
  },
  // 获得部门树形结构
  getTree(data) {
    return request({
      url: '/user/org/getListTree',
      method: 'post',
      data
    })
  },
  // 获得部门下拉树形结构
  getTreeSelect() {
    return request({
      url: '/user/org/getSelectTree',
      method: 'get'
    })
  },
  // 根据角色ID查询组织机构树结构
  roleOrgTreeselect(roleId) {
    return request({
      url: `/user/org/roleOrgTreeselect/${roleId}`,
      method: 'get'
    })
  },
  // 获取当前用户组织机构信息
  getOrgByUser() {
    return request({
      url: '/user/org/getOrgByUser',
      method: 'get'
    })
  },
  // 根据父Id获取子组织列表
  getListByParentId(id) {
    return request({
      url: `/user/org/getListByParentId/${id}`,
      method: 'get'
    })
  },
  // 用于组织机构修改和增加展示
  getTreeSelectByOrg() {
    return request({
      url: '/user/org/getSelectTreeByOrg',
      method: 'get'
    })
  },
  // 根据组织机构Id获取用户列表及子机构
  getOrgAndUserByParentId(orgId) {
    return request({
      url: `/user/org/getOrgAndUserByParentId/${orgId}`,
      method: 'get'
    })
  },
  /**
   * 查询当前用户所能管理的组织机构树
   * @author: lhz
   */
  getOrgTreeByCurrentUser() {
    return request({
      url: '/user/org/getOrgTreeByCurrentUser',
      method: 'get'
    })
  },
  /**
   * 查询当前用户所能管理的组织机构列表
   * @author: chengguangyuan
   */
  getNextOrgList() {
    return request({
      url: '/user/org/getNextOrgList',
      method: 'get'
    })
  },
  /**
   * 查询orgId的组织机构树
   * @author: lhz
   */
  getOrgTreeByOrgId(orgId) {
    return request({
      url: `/user/org/getOrgTreeByOrgId/${orgId}`,
      method: 'get'
    })
  }
}
