import request from '@/utils/request'

export default {
  // 增加一个岗位
  addPost(data) {
    return request({
      url: '/user/post/add',
      method: 'post',
      data
    })
  },
  // 更新一个岗位
  updatePost(data) {
    return request({
      url: '/user/post/update',
      method: 'put',
      data
    })
  },

  // 根据条件查询岗位
  getPostByCondition(data, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/user/post/list',
      method: 'post',
      data: data,
      params: params
    })
  },
  // 删除一个岗位
  delPost(postId) {
    return request({
      url: `/user/post/delete/${postId}`,
      method: 'delete'
    })
  },
  // 批量删除岗位
  delPostList(data) {
    return request({
      url: '/user/post/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 查询所有岗位，用于添加用户
  getPostList(data) {
    return request({
      url: '/user/post/getPostList',
      method: 'post',
      data
    })
  },
  // 查询当前用户所能管理的岗位信息集合
  getPostListByCurrentUser() {
    return request({
      url: '/user/post/getPostListByCurrentUser',
      method: 'post'
    })
  },
  // 查询用户所在机构的所有岗位
  getPostsByCurrentUser() {
    return request({
      url: '/user/post/getPostsByCurrentUser',
      method: 'get'
    })
  },
  // 根据userId查询岗位列表
  getPostIdsByUserId(userId) {
    return request({
      url: `/user/post/getPostIdsByUserId/${userId}`,
      method: 'get'
    })
  }
}
