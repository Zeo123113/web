import request from '@/utils/request'

export default {
  // 查询角色列表
  listRole(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/user/role/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 查询所有角色，用于添加用户
  getRoleList(data) {
    return request({
      url: '/user/role/getRoleList',
      method: 'post',
      data
    })
  },
  // 查询当前用户所能管理的角色信息集合
  getRoleListByCurrentUser() {
    return request({
      url: '/user/role/getRoleListByCurrentUser',
      method: 'post'
    })
  },
  // 查询角色详细
  getRole(roleId) {
    return request({
      url: `/user/role/list/${roleId}`,
      method: 'get'
    })
  },
  // 新增角色
  addRole(data) {
    return request({
      url: '/user/role/add',
      method: 'post',
      data: data
    })
  },
  // 修改角色
  updateRole(data) {
    return request({
      url: '/user/role/edit',
      method: 'put',
      data: data
    })
  },
  // 逻辑删除角色
  delRole(roleId) {
    return request({
      url: `/user/role/delete/${roleId}`,
      method: 'delete'
    })
  },
  // 还原角色
  recallRole(roleId) {
    return request({
      url: `/user/role/recall/${roleId}`,
      method: 'delete'
    })
  },
  // 批量删除角色
  batchDelete(data) {
    return request({
      url: `/user/role/batchDelete`,
      method: 'delete',
      params: { ids: data }
    })
  },
  // 批量还原角色
  batchRecall(data) {
    return request({
      url: '/user/role/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 清空已删除的角色,物理删除
  cleanRecycleBinByIds(data) {
    return request({
      url: '/user/role/cleanRecycleBinByIds',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 角色状态改变
  changeRoleStatus(roleId, roleStatus) {
    const data = {
      roleId,
      roleStatus
    }
    return request({
      url: '/user/role/edit/changeStatus',
      method: 'put',
      data: data
    })
  },
  // 数据权限
  dataScope(data) {
    return request({
      url: '/user/role/edit/dataScope',
      method: 'put',
      data: data
    })
  },
  // 查询用户所在机构的所有角色
  getRolesByCurrentUser() {
    return request({
      url: '/user/role/getRolesByCurrentUser',
      method: 'get'
    })
  },
  // 根据userId查询角色ID列表
  getRoleIdsByUserId(userId) {
    return request({
      url: `/user/role/getRoleIdsByUserId/${userId}`,
      method: 'get'
    })
  }
}
