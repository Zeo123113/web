import request from '@/utils/request'

export default {
  addSecurityQuestion(data) {
    return request({
      url: '/user/security/add',
      method: 'post',
      data
    })
  },
  updateSecurityQuestion(data) {
    return request({
      url: '/user/security/update',
      method: 'put',
      data
    })
  },
  getSecurityQuestionList(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/user/security/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  delSecurityQuestion(data) {
    return request({
      url: '/user/security/delete',
      method: 'delete',
      params: { ids: data }
    })
  },
  getSecurityQuestion(qid) {
    return request({
      url: '/user/security/getByQId/' + qid,
      method: 'get'
    })
  }
}
