import request from '@/utils/request'

export default {
  // 列表展示
  listUserOnline(body, pageIndex, pageSize) {
    const params = new URLSearchParams()
    params.append('pageIndex', pageIndex)
    params.append('pageSize', pageSize)
    return request({
      url: '/user/user-online/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 在线用户强退
  strongBack(sessionId, userId) {
    return request({
      url: '/user/user-online/strongBack',
      method: 'put',
      params: { sessionId: sessionId, userId: userId }
    })
  },
  // 批量在线用户强退
  strongBackList(sessionIds, userIds) {
    return request({
      url: '/user/user-online/strongBackList',
      method: 'put',
      params: { sessionIds: sessionIds, userIds: userIds }
    })
  },
  // 列表清空
  deleteEmpty(body) {
    return request({
      url: '/user/user-online/deleteEmpty',
      method: 'delete',
      data: body
    })
  }
}
