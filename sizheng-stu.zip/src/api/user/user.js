import request from '@/utils/request'

export default {
  login(data) {
    return request({
      url: '/user/user/login',
      method: 'post',
      data
    })
  },
  logout() {
    return request({
      url: '/user/user/logout',
      method: 'post'
    })
  },
  getInfo() {
    return request({
      url: '/user/user/info',
      method: 'get'
      // params: { token }
    })
  },
  getByUserId() {
    return request({
      url: '/user/user/getByUserId',
      method: 'get'
    })
  },
  // 查询用户详细
  getUser(userId) {
    return request({
      url: '/user/user/getUserInfo/' + userId,
      method: 'get'
    })
  },
  // 列表展示
  listUser(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/user/user/list',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 检测用户名是否唯一
  checkLoginName(data) {
    return request({
      url: '/user/user/checkLoginName',
      method: 'post',
      data: data
    })
  },
  // 检测手机号是否唯一
  checkMobile(data) {
    return request({
      url: '/user/user/checkMobile',
      method: 'post',
      data: data
    })
  },
  // 检测邮箱是否唯一
  checkEmail(data) {
    return request({
      url: '/user/user/checkEmail',
      method: 'post',
      data: data
    })
  },
  // 获取手机验证码
  getMobileSmsCaptcha(data) {
    return request({
      url: '/user/user/getMobileSmsCaptcha',
      method: 'post',
      data: data
    })
  },
  // 新增用户
  addUser(data) {
    return request({
      url: '/user/user/add',
      method: 'post',
      data: data
    })
  },
  // 更新用户信息
  updateUser(data) {
    return request({
      url: '/user/user/update',
      method: 'put',
      data
    })
  },

  // 修改代码
  updatePassword(data) {
    return request({
      url: '/user/user/updatePassword',
      method: 'put',
      data: data
    })
  },
  // 修改用户
  updateUserRolePost(data) {
    return request({
      url: '/user/user/updateUserRolePost',
      method: 'put',
      data: data
    })
  },

  // 用户状态修改
  changeUserStatus(userId, status) {
    const data = {
      userId,
      status
    }
    return request({
      url: '/user/user/changeStatus',
      method: 'put',
      params: data
    })
  },
  // 用户密码重置
  resetUserPwd(userId, password) {
    const data = {
      userId,
      password
    }
    return request({
      url: '/user/user/resetPwd',
      method: 'put',
      params: data
    })
  },
  // 删除用户
  delUser(userId) {
    return request({
      url: '/user/user/delete/' + userId,
      method: 'delete'
    })
  },
  // 批量删除用户
  batchDelete(data) {
    return request({
      url: '/user/user/batchDelete',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 根据查询条件(用户)查询教师列表
  getTeachersByUser(body, pageNum, pageSize) {
    const params = new URLSearchParams()
    params.append('pageNum', pageNum)
    params.append('pageSize', pageSize)
    return request({
      url: '/user/user/getTeachersByUser',
      method: 'post',
      data: body,
      params: params
    })
  },
  // 根据用户Id列表查询用户登录名,头像列表
  getUsersByIds(data) {
    return request({
      url: '/user/user/getUsersByIds',
      method: 'post',
      params: { ids: data }
    })
  },
  // 物理删除已被删除的记录
  cleanRecycleBinByIds(data) {
    return request({
      url: '/user/user/cleanRecycleBinByIds',
      method: 'delete',
      params: { ids: data }
    })
  },
  // 还原用户
  recallUser(userId) {
    return request({
      url: '/user/user/recall/' + userId,
      method: 'delete'
    })
  },
  // 批量还原用户
  batchRecall(data) {
    return request({
      url: '/user/user/batchRecall',
      method: 'delete',
      params: { ids: data }
    })
  },

  // 绑定手机
  bindingMobile(data) {
    return request({
      url: '/user/user/bindingMobile',
      method: 'post',
      data: data
    })
  },
  // 获取邮箱验证码
  getEmailCaptcha(data) {
    return request({
      url: '/user/user/getEmailCaptcha',
      method: 'post',
      data: data
    })
  },
  // 绑定邮箱
  bindingEmail(data) {
    return request({
      url: '/user/user/bindingEmail',
      method: 'post',
      data: data
    })
  },
  // 导出用户信息
  export(params) {
    return request({
      url: '/user/user/export',
      method: 'get',
      params,
      responseType: 'blob'
    })
  },
  // // 下载导入模板
  // downloadFile(filename) {
  //   return request({
  //     url: '/user/user/download/' + filename,
  //     method: 'get',
  //     responseType: 'blob'
  //   })
  // },
  // 下载excel导入模板
  downloadTemplate() {
    return request({
      url: '/user/user/templete',
      method: 'get'
    })
  },
  // 根据用户名查找用户
  checkUserByLoginName(loginName) {
    return request({
      url: '/user/user/checkUserByLoginName',
      method: 'get',
      params: loginName
    })
  },
  // 根据用户名查找用户
  checkUserByLoginName1(loginName) {
    return request({
      url: '/user/user/checkUserByLoginName',
      method: 'get',
      params: { loginName: loginName }
    })
  },
  // 根据机构编号获取该机构下（包含子机构）所有用户列表
  getUserListByOrgId(orgId) {
    return request({
      url: '/user/user/getUserListByOrgId/' + orgId,
      method: 'get'
    })
  },
  /**
   * 根据学号获取用户id,姓名等信息
   */
  getByStudentNumber(studentNumber) {
    return request({
      url: '/user/user/getByStudentNumber/' + studentNumber,
      method: 'get'
    })
  },
  /**
   * 根据用户编号查询用户头像
   * @author:yangxiao
   */
  getAvatarByUserId(id) {
    return request({
      url: '/user/user/getAvatarByUserId/' + id,
      method: 'get'
    })
  },
  // 通过当前用户的orgId查询此orgId所在二级组织机构下的所有教师用户
  getUserListByCurrentUserOrgId(orgId) {
    return request({
      url: `/user/user/selectUserListByOrgIds/${orgId}`,
      method: 'get'
    })
  },
  // 根据机构编号查找用户列表20条，或者根据用户真实姓名查找
  getUserListByOrgIdAndRealName(data) {
    return request({
      url: '/user/user/getUserListByOrgIdAndRealName',
      method: 'post',
      data
    })
  }

}
