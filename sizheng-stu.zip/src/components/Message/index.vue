<template>
  <div>
    <svg
      class="icon svg-icon"
      :class="isHasMessages?'has-message':'no-message'"
      aria-hidden="true"
      @click.stop="click"
    >
      <use xlink:href="#iconxiaoxizhongxin" />
    </svg>&emsp;
  </div>
</template>

<script>
export default {
  data: function() {
    return {
      isHasMessages: false
    }
  },
  methods: {
    click() {
      this.$router.push({ path: '/user/message' })
    }
  }
}
</script>
<style lang="scss" scoped>
.has-message {
  cursor: pointer;
  font-size: 18px;
  vertical-align: middle;
  color: red;
}
.no-message {
  cursor: pointer;
  font-size: 18px;
  vertical-align: middle;
}
</style>
