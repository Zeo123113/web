<template>
  <div id="footer">
    <div class="pt45 pb40 bg2">
      <div class="mar_auto">
        <div class="cf">
          <center>
            <div class="cf">
              <a href="#" class="mt20 qq_btn_sty" style="display:inline-block;">
                <i class="ico_qq_sty"></i>
                <span class="ml10 vm">qq联系</span>
              </a>
              <a href="#" class="mt15 join_btn_sty" style="display:inline-block;margin-left:10px;">
                <i class="ico_join_sty"></i>
                <span class="ml10 vm">加入我们</span>
              </a>
              <!-- <div class="ml40 fl">
                <img src="images/ico_code_1.png" class="img12" alt />
              </div>-->
            </div>
          </center>
          <div class="ov">
            <div class="mt20">
              <center>
                <ul class="fl_dib">
                  <li class>
                    <a href="#" class="dib fz18 lh24 cor_fff">关于我们</a>
                  </li>
                  <li class="ml65">
                    <a href="#" class="dib fz18 lh24 cor_fff">平台动态</a>
                  </li>
                  <li class="ml65">
                    <a href="#" class="dib fz18 lh24 cor_fff">帮助中心</a>
                  </li>
                  <li class="ml65">
                    <a href="#" class="dib fz18 lh24 cor_fff">意见反馈</a>
                  </li>
                </ul>
              </center>
            </div>
            <center>
              <div class="mt30 pt10">
                <i class="ico_phone_sty"></i>
                <span class="ml15 fz18 cor_2 vm">联系电话</span>
                <span class="ml15 fz18 cor_2 vm">400-800-9952</span>
              </div>
              <div class="mt10">
                <i class="ico_mail_sty"></i>
                <span class="ml15 fz18 cor_2 vm">电子邮件</span>
                <span class="ml15 fz18 cor_2 vm">1112233444@163.com</span>
              </div>
            </center>
          </div>
        </div>
      </div>
      <!--w1200-->
    </div>
    <p class="bt1 lh54 fz12 cor_8a8 tac bg2"><center>COPYRIGHT (©) 2018 版权所有：河北省大学生思政教育平台</center></p>
  </div>
</template>
<script>
export default {
  name: 'Footer'
}
</script>
<style lang="scss" scoped>
@media screen and (max-width: 576px) {
  .ml65 {
    margin-left: 5%;
  }
}
</style>
