<template>
  <div id="header">
    <div class="container-fluid">
      <div class="row header-row">
        <div class="logo fl">
          <img src="@/assets/images/logo_1.png" style="width: 100%; height: auto;" alt="logo丢了" />
        </div>
        <div class="nav fr">
          <div class="fr hidden-xs">
            <!-- 搜索 -->
            <div class="dib vm">
              <div class="cf">
                <div class="fr">
                  <a href="javascript:void(0);" class="search_btn_sty">搜索</a>
                </div>
                <div class="re ov hidden-sm">
                  <input type="text" class="search_ipt_sty" placeholder="搜索感兴趣的课程" />
                  <i class="ico_search_sty"></i>
                </div>
                <div class="re ov visible-sm inputdata">
                  <input type="text" class="search_ipt_sty" placeholder="搜索感兴趣的课程" />
                  <i class="ico_search_sty"></i>
                </div>
              </div>
            </div>
            <!-- 个人设置 -->
            <div class="dib ml15 vm" @mouseenter="showUserInfo" @mouseleave="hiddenUserInfo">
              <div v-if="$store.getters.token">
                <router-link to="/personalcenter">
                  <img
                    v-if="$store.getters.user.avatar !== null && $store.getters.user.avatar != ''"
                    :src="$store.getters.user.avatar"
                    class="img2 vm"
                    alt
                  />
                  <img v-else class="img2 vm" src="@/assets/images/avatar.png" />
                  <span class="dib fz18 fwb ml15 vm">{{ $store.getters.user.realName }}</span>
                </router-link>
                <div
                  v-if="$store.getters.token"
                  :style="{'display': showInfo? 'block':'none' }"
                  class="personal_column_pos hidden-xs people-info"
                >
                  <div class="cf">
                    <div class="fl mr25">
                      <img
                        v-if="$store.getters.user.avatar !== null && $store.getters.user.avatar !== ''"
                        :src="$store.getters.user.avatar"
                        class="img4"
                        alt
                      />
                      <img v-else src="@/assets/images/avatar.png" class="img4" />
                    </div>
                    <div class="ov">
                      <p class="pt15 fz22 fwb cor_2">{{ $store.getters.user.loginName }}</p>
                      <p class="mt10">
                        <el-button type="text">个人设置</el-button>
                        <el-button type="text" @click="gotoMessage">消息</el-button>
                        <el-button type="text" @click="logout()">退出</el-button>
                      </p>
                    </div>
                  </div>
                  <ul class="personal_fuc_list fl_dib tac">
                    <li
                      :class="isTeach? 'personal_fuc_list-active-li':''"
                      @click="isTeach = true"
                    >我的教学</li>
                    <li
                      :class="isTeach? '':'personal_fuc_list-active-li'"
                      @click="isTeach = false"
                    >我的学习</li>
                    <!-- <li @click="gotoPersonal('Mycourses')">课程</li>
                    <li @click="gotoMessage">消息</li>-->
                  </ul>
                  <div class="mt35 pt10">
                    <!--教学-->
                    <ul v-if="isTeach" class="curriculum_list_area fl_dib">
                      <li class @click="gotoCourseManger('onlineCourse')">
                        <i class="ico_study_1"></i>
                        <p class>课程</p>
                      </li>
                      <li class @click="gotoCourseManger('correcting')">
                        <i class="ico_study_2"></i>
                        <p class>作业</p>
                      </li>
                      <!-- <li class @click="gotoPersonal('MyNote')">
                        <i class="ico_study_3"></i>
                        <p class>考试</p>
                      </li> -->
                      <li class @click="gotoCourseManger('question')">
                        <i class="ico_study_4"></i>
                        <p class>问答</p>
                      </li>
                    </ul>
                    <!--学习-->
                    <ul v-else class="curriculum_list_area fl_dib">
                      <li class @click="gotoPersonal('Mycourses')">
                        <i class="ico_study_1"></i>
                        <p class>课程</p>
                      </li>
                      <li class @click="gotoPersonal('Mytests')">
                        <i class="ico_study_2"></i>
                        <p class>考试</p>
                      </li>
                      <li class @click="gotoPersonal('MyNote')">
                        <i class="ico_study_3"></i>
                        <p class>笔记</p>
                      </li>
                      <li class @click="gotoPersonal('MyQuestions')">
                        <i class="ico_study_4"></i>
                        <p class>问答</p>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div v-else>
                <el-button type="primary" @click="gotoLogin()">登录</el-button>
              </div>
            </div>
          </div>
          <el-dropdown class="visible-xs">
            <div class="ico">
              <img src="@/assets/images/appico_01.png" style alt />
            </div>
            <el-dropdown-menu slot="dropdown">
              <center>
                <el-dropdown-item>
                  <a href="javascript:void(0);" @click="gotoLogin()">登录</a>
                </el-dropdown-item>
                <el-dropdown-item>
                  <router-link to="/">首页</router-link>
                </el-dropdown-item>
                <el-dropdown-item>
                  <router-link to="/InfoHome">资讯平台</router-link>
                </el-dropdown-item>
                <el-dropdown-item>
                  <router-link to="/CourseHome">思政课程平台</router-link>
                </el-dropdown-item>
                <el-dropdown-item>
                  <router-link to="/FAQ">常见问题</router-link>
                </el-dropdown-item>
                <el-dropdown-item>
                  <router-link to="/aboutUs">关于我们</router-link>
                </el-dropdown-item>
              </center>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    </div>

    <!-- 登陆弹窗
    <Login :is-login-dialog-visiable.sync="isLoginDialogVisiable" /> -->
  </div>
</template>
<script>
// import Login from '@/views/login/index'
import photo from '@/assets/images/header.png'
import USER_CONST from '@/constant/user-const.js'
export default {
  name: 'Header',
  // components: {
  //   Login
  // },
  data() {
    return {
      qnSelected: true,
      // isLoginDialogVisiable: false,
      photos: photo,
      user: {},
      showInfo: false,
      // 头像前缀
      avatarHttp: USER_CONST.AVATARHTTP,
      teacher: USER_CONST.TEACHER,
      unSelectedHTML: require('@/assets/images/teach.png'),
      selectedHTML: require('@/assets/images/teached.png'),
      // 当前显示学习内容
      isTeach: false
    }
  },
  watch: {
    token(value) {
      if (value) {
        this.user = this.$store.getters.user
        console.log('user = ', this.user)
      }
    }
  },
  methods: {
    // 我的教学按钮样式绑定
    inArray() {
      this.qnSelected = false
    },
    outArray() {
      this.qnSelected = true
    },
    showUserInfo() {
      this.showInfo = true
    },
    hiddenUserInfo() {
      // this.showInfo = true
      this.showInfo = false
    },
    async logout() {
      this.$router.push(`/`)
      await this.$store.dispatch('user/logout')
    },
    // 打开消息模块
    gotoMessage() {
      this.$router.push({ name: `message` })
    },
    // 打开课程管理后台
    gotoCourseManger(val) {
      this.$router.push({
        name: `courseManger`,
        params: {
          activeName: val
        }
      })
    },
    // 打开课程
    gotoPersonal(state) {
      if (this.$router.history.current.name !== 'personalcenter') {
        this.$router.push({
          name: `personalcenter`,
          params: {
            state: state
          }
        })
      }
    },
    gotoLogin() {
      this.$store.commit('app/SET_LOGIN', true)
      console.log(this.$store.getters.openlogin)
    }
  }
}
</script>
<style lang="scss" scoped>
// @media screen and (max-width: 576px) {
//   .logo {
//     width: 60%;
//     padding-left: 3.5%;
//   }
//   .ico img {
//     width: 60%;
//     height: auto;
//   }
//   .nav {
//     margin: 2% 0;
//   }
// }
// @media screen and (min-width: 576px) and (max-width: 768px) {
//   .nav {
//     margin: 2% 0;
//   }
// }
// @media screen and (min-width: 768px) {
//   // .logo{width: 70%;}
//   .nav {
//     margin: 1% 0;
//   }
// }
#header {
  vertical-align: center;
  background: url('../assets/images/banner_00.jpg') no-repeat;
  background-size: 100% 100%;
  #demo li {
    border-bottom: 1px solid #f75e5e;
  }
  .header-row {
    position: relative;
    padding: 10px 10px;
    .login_btn_sty {
      display: inline-block;
      width: 65px;
      height: 40px;
      line-height: 40px;
      text-align: center;
      font-size: 16px;
      color: #fff;
      background: #e30013;
      border-radius: 3px;
      text-decoration: none;
    }
    .inputdata {
      width: 130px;
      float: right;
    }
    .vpright {
      float: right;
      margin-right: 2%;
    }
  }
}
.fl_dib {
  li {
    cursor: pointer;
  }
}
.el-dropdown-menu__item {
  color: #e00312;
  font-weight: bold;
}
.people-info {
  // margin-left:0;
  // padding: 31px 52px 0;
  width: 400px;
  height: 346px;
}
.personal_column_pos {
  display: block;
  position: absolute;
  top: 60px;
  right: 0px;
  left: auto;
  margin: 0px;
}
.nav {
  margin-top: 12px !important;
}
// .personal_fuc_list {
//   li:hover {
//     border: none;
//     background: #c0c4cc;
//     color: #323232;
//   }
// }
.personal_fuc_list-active-li {
  border: 1px solid #e50112;
  color: #e50112;
  border-radius: 3px;
}
.curriculum_list_area {
  li {
    a {
      color: #969696 !important;
    }
  }
}
.course-manger-style {
  font-size: 16px;
  color: #e00312;
  font-weight: bold;
  font-family: 微软雅黑, 'Microsoft YaHei';
  float: right;
  margin-left: 1rem;
  margin-top: 3px;
  // margin-right: 4rem;
}
a {
  cursor: pointer;
}
.myteachin {
  display: inline-block;
  border: 1px solid #e50112;
  border-radius: 5px;
  width: 33px;
  height: 33px;
}
.myteachout {
  display: inline-block;
  border: 1px solid #c0c4cc;
  border-radius: 5px;
  width: 33px;
  height: 33px;
}
.myteach:focus {
  background: aqua;
}
.search_btn_sty:hover{
  color:#fff;
}
.search_btn_sty{
  color:#fff;
  text-decoration: none;
}
</style>
