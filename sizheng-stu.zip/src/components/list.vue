<template>
  <div class="list">这里是列表</div>
</template>

<script>
export default {
  name: 'List'
}
</script>

<style lang="scss" scoped>
</style>
