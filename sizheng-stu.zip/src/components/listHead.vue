
<template>
  <div class="list-head">这里是列表</div>
</template>

<script>
export default {
  name: 'ListHead'
}
</script>

<style lang="scss" scoped>
</style>
