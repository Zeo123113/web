<template>
  <div id="nav" class="">
    <div class="nav_area_bg hidden-xs">
      <div style="padding-left: 10%; padding-right: 10%;">
        <router-link to="/index" class="list_nav">
          <span class="nav_item">首页</span>
        </router-link>
        <router-link to="/InfoHome" class="list_nav">
          <span class="nav_item">资讯平台</span>
        </router-link>
        <router-link to="/CourseHome" class="list_nav">
          <span class="nav_item">思政课程平台</span>
        </router-link>
        <router-link to="/FAQ" class="list_nav">
          <span class="nav_item">常见问题</span>
        </router-link>
        <router-link to="/aboutUs" class="list_nav">
          <span class="nav_item">关于我们</span>
        </router-link>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Nav',
  components: {},
  data() {
    return {
    }
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
#nav {
  background: #fff;
  padding: 0;
  .list_nav {
    width: 20%;
  }
  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
