/**
 * @description 课程系统常量定义
 * @author LHZ
 */
// 分页查询时每页的默认大小
const PAGESIZE = 20
// 开课学期类型
const TERM = '0'
const PERIOD = '1'
// 分组类型
const COURSE_GROUP = '0'
const EXAM_GROUP = '1'
// 投票类型
const PRO_AND_CON = '0'
const SINGLE = '1'
const MULTIPLE = '2'
// 作业评分类型
const STUDENT_GRADING = '2'
// 签到类型
const ORDINARY = '0'
const GESTURES = '1'
const QRCODE = '2'
const POSITION = '3'
// 评论状态
const TOAUDIT = '0'
const NORMAL = '1'
const OFFLINE = '2'
// 请假审批状态
const NOAPPROVAL = '0'

// 阅卷教师权限
const TEACHER = '1'
const GROUPLEADER = '2'
const ADMIN = '3'

// 考试测试状态
const NOTSTART = '0'
const TESTING = '1'
const COMPIETED = '2'
const REVIEWING = '3'
const WAITERESULT = '4'
const PUBLISHED = '5'
// 学习记录中学习资料类型
const GRAPHIC = '0'
const LECTURE = '1'
const VIDEO = '2'
const AUDIO = '3'
export default {
  PAGESIZE,
  TERM,
  PERIOD,
  COURSE_GROUP,
  EXAM_GROUP,
  PRO_AND_CON,
  SINGLE,
  MULTIPLE,
  STUDENT_GRADING,
  ORDINARY,
  GESTURES,
  QRCODE,
  POSITION,
  TOAUDIT,
  NORMAL,
  OFFLINE,
  NOAPPROVAL,
  TEACHER,
  GROUPLEADER,
  ADMIN,
  NOTSTART,
  TESTING,
  COMPIETED,
  REVIEWING,
  WAITERESULT,
  PUBLISHED,
  GRAPHIC,
  LECTURE,
  VIDEO,
  AUDIO
}
