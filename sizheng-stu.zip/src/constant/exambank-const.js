/**
 * @description 考试与题库系统常量定义
 * @author LHZ
 */
// 分页查询时每页的默认大小
const PAGESIZE = 20
// 试题类型定义
const SINGLE = '0'
const MULTIPLE = '1'
const JUDGEMENT = '2'
const FILLBLANK = '3'
const ESSAY_QUESTION = '4'
const MATERIAL = '5'
const PROGRAMME = '6'
const PROG_FILLBLANK = '7'
const INTERFACE = '8'
const FILE_UPLOAD = '9'

// 试题输入输出类型
const STDIN = '0'
const FILE = '1'
const CMD = '2'
const STDOUT = '0'
// 考试状态
const INTEST = '0'
const TESTED = '1'
const LACKTEST = '2'
const CHEATING = '3'
const DELAYED = '4'
// 考试状态->未登录
const NOTLOGIN = '5'
// 作业状态
const NOTSTART = '0'
const DURATION = '1'
const FINISH = '3'

// 考试记录类型状态
const TEST = '0'
const EXAM = '1'

// 试题难度
const EASY = '1'
const GENERAL = '2'
const DIFFICULT = '3'

// 试题导入模板类型
const SELECTJUDEGE = 'selectjudge_import_template'
const UPLOAD = 'upload_import_template'
const FILLBLANKIMPORT = 'fillblank_import_template'
const MATERIALIMPORT = 'material_import_template'
const MATERIALITEMIMPORT = 'material_item_import_template'
export default {
  EASY,
  GENERAL,
  DIFFICULT,
  PAGESIZE,
  SINGLE,
  MULTIPLE,
  JUDGEMENT,
  FILLBLANK,
  ESSAY_QUESTION,
  MATERIAL,
  PROGRAMME,
  PROG_FILLBLANK,
  INTERFACE,
  FILE_UPLOAD,
  STDIN,
  FILE,
  CMD,
  STDOUT,
  INTEST,
  TESTED,
  DELAYED,
  LACKTEST,
  CHEATING,
  NOTSTART,
  DURATION,
  FINISH,
  TEST,
  EXAM,
  SELECTJUDEGE,
  UPLOAD,
  FILLBLANKIMPORT,
  MATERIALIMPORT,
  MATERIALITEMIMPORT,
  NOTLOGIN
}
