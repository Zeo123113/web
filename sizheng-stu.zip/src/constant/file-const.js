/**
 * @file 文件管理模块常量定义
 * @author lhz
 * @copyright 思政平台项目组
 * @createDate 2020-04-03 07:26:11
 */

/**
 * @constant {number}
 * @default 0
 * @description 文件不存在
 */
const FILE_NOT_EXIST = 0

/**
 * @constant {number}
 * @default 1
 * @description 文件已上传到文件服务器
 */
const FILE_UPLOADED_TO_FASTDFS = 1

/**
 * @constant {number}
 * @default 2
 * @description 文件已上传到本地，但未上传到文件服务器
 */
const FILE_UPLOADED_TO_LOCAL = 2

/**
 * @constant {number}
 * @default 3
 * @description 块不存在
 */
const FILE_CHUNK_NOT_EXIST = 3

/**
 * @constant {number}
 * @default 4
 * @description 块存在
 */
const FILE_CHUNK_EXIST = 4

/**
  * @constant {number}
  * @default 5
  * @description 合并文件失败
  */
const MERGE_FILE_FAILED = 5

/**
  * @constant {number}
  * @default 6
  * @description 校验文件失败
  */
const CHECK_FILE_FAILED = 6

/**
  * @constant {number}
  * @default 7
  * @description 合并文件成功
  */
const MERGE_FILE_SUCCESS = 7

/**
  * @constant {number}
  * @default 8
  * @description 把文件正在上传到fastdfs中
  */
const UPLOAD_FILE_TO_FASTDFS = 8

/**
  * @constant {number}
  * @default 9
  * @description 把文件上传到fastdfs失败
  */
const UPLOAD_FILE_TO_FASTDFS_FAILED = 9

/**
  * @constant {number}
  * @default 10
  * @description 把文件上传到fastdfs成功
  */
const UPLOAD_FILE_TO_FASTDFS_SUCCESS = 10

/**
  * @constant {number}
  * @default 11
  * @description 发送转码消息失败
  */
const SEND_FILE_CONVERT_MSG_FAILED = 11

/**
  * @constant {number}
  * @default 12
  * @description 向消息服务器发送转码消息成功
  */
const SEND_FILE_CONVERT_MSG_SUCCESS = 12

/**
  * @constant {number}
  * @default 13
  * @description 待转码文件格式不正确
  */
const VIDEO_FILE_FORMAT_NOT_CORRECT = 13

/**
  * @constant {number}
  * @default 14
  * @description 视频文件不存在
  */
const VIDEO_FILE_NOT_EXIST = 14

/**
  * @constant {number}
  * @default 16
  * @description 视频文件已成功转码
  */
const VIDEO_FILE_CONVERT_SUCCESS = 15

/**
  * @constant {string}
  * @default '0'
  * @description 未转码
  */
const UNCONVERT_CODE = '0'

/**
  * @constant {string}
  * @default '1'
  * @description 转码准备中
  */
const FILE_DOWNLOADING = '1'

/**
  * @constant {string}
  * @default '2'
  * @description 转码中
  */
const CONVERTING_CODE = '2'

/**
  * @constant {string}
  * @default '3'
  * @description 转码失败
  */
const CONVERT_FAILED = '3'

/**
  * @constant {string}
  * @default '4'
  * @description 转码成功
  */
const CONVERT_SUCCESS = '4'

/**
  * @constant {string}
  * @default '5'
  * @description 文件切片中
  */
const FILE_SLICING = '5'

/**
  * @constant {string}
  * @default '6'
  * @description 文件切片失败
  */
const SLICE_FAILED = '6'

/**
  * @constant {string}
  * @default '7'
  * @description 文件切片成功
  */
const SLICE_SUCCESS = '7'

/**
  * @constant {string}
  * @default '8'
  * @description 切片上传中
  */
const SLICE_UPLOADING = '8'

/**
  * @constant {string}
  * @default '9'
  * @description 切片上传失败
  */

const SLICE_UPLOAD_FAILED = '9'

/**
  * @constant {string}
  * @default '10'
  * @description 文件已成功上传
  */
const SLICE_UPLOAD_SUCCESS = '10'

/**
  * @constant {string}
  * @default '11'
  * @description 查找原视频文件失败
  */
const VIDEOFILE_NOT_EXIST = '11'

/**
  * @constant {string}
  * @default '12'
  * @description 下载原视频文件失败
  */
const DOWNLOAD_FILE_FAILED = '12'

export default {
  FILE_NOT_EXIST,
  FILE_UPLOADED_TO_FASTDFS,
  FILE_UPLOADED_TO_LOCAL,
  FILE_CHUNK_NOT_EXIST,
  FILE_CHUNK_EXIST,
  MERGE_FILE_FAILED,
  CHECK_FILE_FAILED,
  MERGE_FILE_SUCCESS,
  UPLOAD_FILE_TO_FASTDFS,
  UPLOAD_FILE_TO_FASTDFS_FAILED,
  UPLOAD_FILE_TO_FASTDFS_SUCCESS,
  SEND_FILE_CONVERT_MSG_FAILED,
  SEND_FILE_CONVERT_MSG_SUCCESS,
  VIDEO_FILE_FORMAT_NOT_CORRECT,
  VIDEO_FILE_NOT_EXIST,
  VIDEO_FILE_CONVERT_SUCCESS,
  UNCONVERT_CODE,
  FILE_DOWNLOADING,
  CONVERTING_CODE,
  CONVERT_FAILED,
  CONVERT_SUCCESS,
  FILE_SLICING,
  SLICE_FAILED,
  SLICE_SUCCESS,
  SLICE_UPLOADING,
  SLICE_UPLOAD_FAILED,
  SLICE_UPLOAD_SUCCESS,
  VIDEOFILE_NOT_EXIST,
  DOWNLOAD_FILE_FAILED
}
