// 登录类型
const ACCOUNT_LOGIN = 1
const APP_QR_LOGIN = 2
const WECHAT_QR_LOGIN = 3
// 用户类型
const STUDENT = '0'
const TEACHER = '1'
const OTHER = '2'

export default {
  ACCOUNT_LOGIN,
  APP_QR_LOGIN,
  WECHAT_QR_LOGIN,
  STUDENT,
  TEACHER,
  OTHER
}
