// 公告状态
const NORMAL = '1'
const OFFLINE = '2'
export default {
  NORMAL,
  OFFLINE
}
