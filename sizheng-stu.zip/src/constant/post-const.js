// 分页查询时每页的默认大小
const PAGESIZE = 20

export default {
  PAGESIZE
}
