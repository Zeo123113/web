// 试题类型
const SELECT = '0' // 单项选择题
const MULTSELECT = '1' // 多选题
const JUDEGE = '2' // 判断题
const BLANK = '3' // 填空题
const QUESTANSWER = '4' // 问答题
const MATERIAL = '5' // 材料题
const PROGRAM = '6' // 编程题
const PROGRAMBLANK = '7' // 程序填空题
const PROGRAMINTER = '8' // 接口编程题
const FILEUPLOAD = '9' // 文件上传题
export default {
  SELECT,
  MULTSELECT,
  JUDEGE,
  BLANK,
  QUESTANSWER,
  PROGRAM,
  PROGRAMBLANK,
  PROGRAMINTER,
  FILEUPLOAD,
  MATERIAL
}
