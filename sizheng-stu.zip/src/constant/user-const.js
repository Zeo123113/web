// 用户类型
const STUDENT = '0'
const TEACHER = '1'
const OTHER = '2'
// 头衔
const BRASS = '黄铜'
const SILVER = '白银'
const GOLD = '黄金'
const PLATINUM = '白金'
const DIAMOND = '钻石'
const KING = '王者'
// 账号状态
const OK = '0'
const UNAUDITED = '1'
const AUDIT_FAILED = '2'
const DISABLED = '3'
const SUSPEND = '4'
// 分页查询时每页的默认大小
const PAGESIZE = 20
// 头像服务器前缀
const AVATARHTTP = 'http://fileserver:8888/'

export default {
  STUDENT,
  TEACHER,
  OTHER,
  BRASS,
  SILVER,
  GOLD,
  PLATINUM,
  DIAMOND,
  KING,
  OK,
  UNAUDITED,
  AUDIT_FAILED,
  DISABLED,
  SUSPEND,
  PAGESIZE,
  AVATARHTTP
}
