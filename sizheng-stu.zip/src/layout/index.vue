<template>
  <div id="main">
    <Header />
    <Nav />
    <router-view></router-view>
    <Footer />
  </div>
</template>
<script>
import Header from '@/components/header'
import Nav from '@/components/nav'
import Footer from '@/components/footer'
export default {
  name: 'Main',
  components: {
    Header,
    Nav,
    Footer
  }
}
</script>
<style lang="scss" scoped>
</style>
