import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import '@/assets/css/css.css'
import '@/assets/theme/index.css'
import '@/assets/css/banner_auto.css'
import '@/assets/css/communal.css'
import '@/assets/iconfont/iconfont.css'
import '@/assets/css/animate.css'
import '@/permission' // permission control
import * as filters from './filters' // global filters
import { selectDictLabel, getDataByType } from '@/utils/dict' // 数据字典
import VueAwesomeSwiper from 'vue-awesome-swiper'
import 'swiper/css/swiper.min.css' // swiper的css
import '@/assets/icon/iconfont.js'
import echarts from 'echarts'
import 'timescale/css/timescale.css'
import 'timescale/js/konva.min.js'
import 'timescale/timescale.js'
Vue.prototype.$echarts = echarts
// 引入vue-amap
import AMap from 'vue-amap'

// 引入视频播放插件样式
import 'video.js/dist/video-js.css'
// 引入弹题时间轴控制

Vue.use(AMap)

// 全局方法挂载
Vue.use(VueAwesomeSwiper)
Vue.use(ElementUI)
// 初始化vue-amap
AMap.initAMapApiLoader({
  // 申请的高德key
  key: '062a971a8fa4b42982f9d19c4e672c69',
  // 插件集合
  plugin: ['']
})
Vue.prototype.selectDictLabel = selectDictLabel
Vue.prototype.getDataByType = getDataByType
Vue.config.productionTip = false
// register global utility filters
Object.keys(filters).forEach((key) => {
  Vue.filter(key, filters[key])
})
router.afterEach((to, from, next) => {
  window.scrollTo(0, 0)
})
new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount('#app')
