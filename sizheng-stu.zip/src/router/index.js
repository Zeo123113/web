import Vue from 'vue'
import VueRouter from 'vue-router'
/* Layout */
import Layout from '@/layout/index'
Vue.use(VueRouter)

const routes = [
  // 处理网页重定向
  {
    path: '/redirect',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '/redirect/:path*',
        component: () => import('@/views/redirect/index')
      }
    ]
  },
  {
    path: '/404',
    component: () => import('@/views/error-page/404'),
    hidden: true
  },
  // 打开首页
  {
    path: '/',
    component: Layout,
    redirect: '/index',
    children: [
      {
        path: 'index',
        component: () => import('@/views/main/index'),
        name: 'index'
      },
      {
        path: 'message',
        component: () => import('@/views/personal/components/message/index'),
        name: 'message'
      },
      {
        path: '/personalcenter',
        name: 'personalcenter',
        component: () => import('@/views/personal/index'),
        redirect: '/personalcenter/MyHomework',
        children: [{
          path: 'MyHomework',
          name: 'MyHomework',
          component: () => import('@/views/personal/components/leftMenu/components/my-homework/index')
        },
        {
          path: 'MyQuestions',
          name: 'MyQuestions',
          component: () => import('@/views/personal/components/leftMenu/components/my-question/index')
        },
        {
          path: 'Mycourses',
          name: 'Mycourses',
          component: () => import('@/views/personal/components/leftMenu/components/my-courses/index')
        },
        {
          path: 'Mytopics',
          name: 'Mytopics',
          component: () => import('@/views/personal/components/leftMenu/components/my-topic/index')
        },
        {
          path: 'Mytests',
          name: 'Mytests',
          component: () => import('@/views/personal/components/leftMenu/components/my-tests/index')
        },
        {
          path: 'MyClass',
          name: 'MyClass',
          component: () => import('@/views/personal/components/leftMenu/components/my-class/index')
        },
        {
          path: 'MyExercise',
          name: 'MyExercise',
          component: () => import('@/views/personal/components/leftMenu/components/my-exercise/index')
        },
        {
          path: 'MyNote',
          name: 'MyNote',
          component: () => import('@/views/personal/components/leftMenu/components/my-note/index')
        }]
      },
      {
        path: '/exercise/:etId/:exerId',
        name: 'exercise',
        component: () =>
          import(
            '@/views/personal/components/leftMenu/components/my-exercise/components/components/exercise/index'
          )
      },
      {
        path: '/exercise-record/:etId/:exerId',
        name: 'exerciseRecord',
        component: () =>
          import(
            '@/views/personal/components/leftMenu/components/my-exercise/components/components/getInfo/index'
          )
      },
      {
        path: '/register',
        name: 'register',
        component: () => import('@/views/register/index')
      },
      {
        path: '/infohome',
        name: 'infohome',
        component: () => import('@/views/infoHome/index')
      },
      {
        path: '/infoDetail',
        name: 'InfoDetail',
        component: () => import('@/views/infoDetail/index')
      },
      {
        path: '/showcategory2',
        name: 'showcategory2',
        component: () => import('@/views/infoHome/components/show-category2/index')
      },
      {
        path: '/topicDetail/:id',
        name: 'topicDetail',
        component: () =>
          import(
            '@/views/courseDetail/components/content/components/detailList/components/components/topicDetail'
          )
      },
      {
        path: '/examDetail/:roundId/:examType',
        name: 'examDetail',
        component: () =>
          import(
            '@/views/personal/components/leftMenu/components/my-tests/components/components/examDetail'
          )
      },
      {
        path: '/stuPaperDetail/:paperId/:roundId/:examType',
        name: 'stuPaperDetail',
        component: () =>
          import(
            '@/views/personal/components/leftMenu/components/my-tests/components/components/stuPaperDetail'
          )
      },
      {
        path: '/markeExamStuAnswer/:index/:roundId/:examType',
        name: 'markeExamStuAnswer',
        component: () =>
          import(
            '@/views/courseManger/components/courseScheme/components/leftNav/examationManger/components/markeStuAnswer'
          )
      },
      {
        path: '/markeTestStuAnswer/:index/:roundId/:examType',
        name: 'markeTestStuAnswer',
        component: () =>
          import(
            '@/views/courseManger/components/courseScheme/components/leftNav/testManager/components/markeStuAnswer'
          )
      },
      {
        path: '/allocatePaper/:teacherId/:courseId/:termId',
        name: 'allocatePaper',
        component: () =>
          import(
            '@/views/courseManger/components/courseScheme/components/leftNav/allocatePaper/components/allocatePaper/allocatePaper'
          )
      },
      {
        path: '/courseManger',
        name: 'courseManger',
        component: () => import('@/views/courseManger/index')
      },
      {
        path: '/homework-correct/:hwId/:stuUserId/:index',
        name: 'homework-correct',
        component: () =>
          import('@/views/courseManger/components/components/correctPage')
      },
      {
        path: 'paperPreview',
        component: () =>
          import(
            '@/views/courseManger/components/courseScheme/components/leftNav/paperManger/components/preview-paper/index'
          ),
        name: 'paperPreview',
        meta: { title: '预览管理' }
      },
      {
        path: '/activities',
        name: 'activities',
        meta: {
          requireAuth: true
        },
        component: () => import('@/views/activities/index')
      }
    ]
  },
  {
    path: '/homeworkInfo/:hwId',
    name: 'homeworkInfo',
    component: () =>
      import(
        '@/views/personal/components/leftMenu/components/my-homework/components/components/homeworkInfo'
      )
  },
  {
    path: '/homeworkRecord/:hwId',
    name: 'homeworkRecord',
    component: () =>
      import(
        '@/views/personal/components/leftMenu/components/my-homework/components/components/homeworkRecord'
      )
  },
  {
    path: '*', // 页面不存在的情况下会跳到404页面
    redirect: '/404',
    name: 'notFound'
  },
  {
    path: '/coursehome',
    name: 'coursehome',
    component: () => import('@/views/courseHome/index')
  },
  {
    path: '/coursedetail/:csId',
    name: 'coursedetail',
    component: () => import('@/views/courseDetail/index')
  },
  {
    path: '/courseSet/:csId/term/:ctId/scheme/:schemeId', // 课程详情页面
    name: 'coursescheme',
    component: () => import('@/views/courseDetail/index')
  },
  {
    path: '/course/:csId/term/:ctId/scheme/:schemeId', // 课程播放页面
    name: 'courseplay',
    component: () =>
      import('@/views/courseDetail/components/continue-learning/index')
  },
  {
    path: '/courseManger/:csId',
    name: 'courseSet',
    component: () =>
      import('@/views/courseManger/components/courseScheme/index'),
    children: [{
      path: 'correct_homework',
      name: 'correctHomework',
      component: () => import('@/views/courseManger/components/courseScheme/components/leftNav/correct-homework/index')
    }]
  },
  {
    path: '/courseManger/:csId/:state/:ctId',
    name: 'courseMangerTerm',
    component: () =>
      import('@/views/courseManger/components/courseScheme/index')
  },
  {
    path: '/courseManger/:csId/:state',
    name: 'courseMangerAllScheme',
    component: () =>
      import('@/views/courseManger/components/courseScheme/index')
  },
  {
    path: '/courseManger/:csId/term/:ctId/scheme/:schemeId/:state',
    name: 'courseMangerScheme',
    component: () =>
      import('@/views/courseManger/components/courseScheme/index')
  },
  {
    path: '/ContinueLearning/cs/:csId/term/:ctId/scheme/:schemeId/courseStudyLog/:courseStudyLogId',
    name: 'ContinueLearning',
    component: () =>
      import('@/views/courseDetail/components/continue-learning/index')
  },
  {
    path: '/aboutUs',
    name: 'aboutUs',
    component: () => import('@/views/aboutUs/index')
  },
  {
    path: '/FAQ',
    name: 'FAQ',
    component: () => import('@/views/FAQ/index')
  },
  {
    path: '/courseManger',
    name: 'courseManger',
    meta: {
      requireAuth: true
    },
    component: () => import('@/views/courseManger/index')
  },
  {
    path: '/popupQuestion/:MaterialId/:csId', // 弹题管理页面
    name: 'popupQuestion',
    component: () =>
      import('@/views/courseManger/components/courseScheme/components/leftNav/popupQuestion/components/updatePopupQuestion')
  }
]

const router = new VueRouter({
  routes
})

export default router
