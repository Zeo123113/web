const getters = {
  baseUrl: state => state.app.baseUrl,
  sidebar: (state) => state.app.sidebar,
  size: (state) => state.app.size,
  device: (state) => state.app.device,
  screenWidth: (state) => state.app.screenWidth,
  token: (state) => state.user.token,
  avatar: (state) => state.user.avatar,
  name: (state) => state.user.name,
  userId: (state) => state.user.userId,
  introduction: (state) => state.user.introduction,
  roles: (state) => state.user.roles,
  menu: (state) => state.user.menu,
  user: (state) => state.user.user,
  errorLogs: (state) => state.errorLog.logs,
  button: (state) => state.user.button,
  currentTime: (state) => state.user.currentTime,
  unReadMessageCount: (state) => state.user.unreadMessageCount,
  paper: (state) => state.bank.paper,
  questionlist: (state) => state.bank.questionlist,
  homeworkallocation: (state) => state.bank.homeworkallocation,
  openlogin: (state) => state.app.login
}
export default getters
