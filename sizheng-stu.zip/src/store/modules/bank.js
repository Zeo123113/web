const state = {
  paper: {},
  questionlist: [],
  homeworkallocation: {}
}
const mutations = {
  SET_PAPER: (state, paper) => {
    state.paper = paper
  },
  SET_QUESTIONLIST: (state, questionlist) => {
    state.questionlist = questionlist
  },
  SET_HOMEWORKALLOCATION: (state, homeworkallocation) => {
    state.homeworkallocation = homeworkallocation
  }
}
export default {
  namespaced: true,
  state,
  mutations
}
