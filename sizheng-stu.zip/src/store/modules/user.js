import User from '@/api/user/user'
import Message from '@/api/info/message'
import { getToken, setToken, removeToken } from '@/utils/auth'
import { resetRouter } from '@/router'
// import Menu from '@/api/user/menu'
const state = {
  token: getToken(),
  name: '',
  userId: null,
  avatar: '',
  introduction: '',
  roles: [],
  menu: [],
  user: {},
  button: [],
  currentTime: '',
  unreadMessageCount: ''
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_INTRODUCTION: (state, introduction) => {
    state.introduction = introduction
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_USERID: (state, userId) => {
    state.userId = userId
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  },
  SET_ROLES: (state, roles) => {
    state.roles = roles
  },
  SET_MENU: (state, menu) => {
    state.menu = menu
  },
  SET_USER: (state, user) => {
    state.user = user
  },
  SET_BUTTON: (state, button) => {
    state.button = button
  },
  SET_TIME: (state, time) => {
    state.currentTime = time
  },
  SET_UNREAD_MESSAGE_COUNT: (state, count) => {
    state.unreadMessageCount = count
  }
}
// 取菜单中的button
function recursionButton(menus, button) {
  menus.forEach(item => {
    button.push(item.path)
    if (item.children) {
      recursionButton(item.children, button)
    }
  })
}
const actions = {
  // user login
  login({ commit }, userInfo) {
    return new Promise((resolve, reject) => {
      User.login(userInfo)
        .then(response => {
          commit('SET_TOKEN', response.token)
          commit('SET_USERID', response.userId)
          setToken(response.token)
          resolve(response)
        })
        .catch(error => {
          reject(error)
        })
    })
  },
  // get user info
  getInfo({ commit, state }) {
    return new Promise((resolve, reject) => {
      User.getInfo()
        .then(response => {
          const { data } = response
          console.log(response)
          if (!data) {
            reject('获取用户信息失败，请重新登录.')
          }

          const { nickName, avatar, introduction, roles, menu } = data
          // roles must be a non-empty array
          if (!menu || !menu.item || menu.item.length <= 0) {
            reject('getInfo: 菜单权限不能是个空数组，请检查登录用户是否分配角色权限!')
          }
          // 将菜单中的权限循环遍历放入数组
          var button = []
          recursionButton(menu.item, button)
          commit('SET_TIME', new Date())
          commit('SET_BUTTON', button)
          commit('SET_NAME', nickName)
          commit('SET_AVATAR', avatar)
          commit('SET_INTRODUCTION', introduction)
          commit('SET_ROLES', roles)
          commit('SET_MENU', menu.item)
          commit('SET_USER', data)
          resolve(data)
        })
        .catch(error => {
          reject(error)
        })
    })
  },

  // user logout
  logout({ commit, state }) {
    return new Promise((resolve, reject) => {
      User.logout(state.token)
        .then(() => {
          commit('SET_TOKEN', '')
          commit('SET_ROLES', [])
          commit('SET_MENU', [])
          commit('SET_USER', {})
          removeToken()
          resetRouter()
          resolve()
        })
        .catch(error => {
          reject(error)
        })
    })
  },

  // remove token
  resetToken({ commit }) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      commit('SET_ROLES', [])
      removeToken()
      resolve()
    })
  },
  // 更新头像
  upadteAvatar({ commit }, avatar) {
    console.log(avatar)
    commit('SET_AVATAR', avatar)
  },
  // 获取用户未读消息个数
  getUnreadMessageCount({ commit, state }, userId) {
    return new Promise((resolve, reject) => {
      Message.getMessageCountByUser(userId).then((result) => {
        console.log(result)
        commit('SET_UNREAD_MESSAGE_COUNT', result.data)
        resolve()
      }).catch((err) => {
        reject(err)
      })
    })
  }

}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
