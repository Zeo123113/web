// import Cookies from 'js-cookie'

const TokenKey = 'Sizheng-Token'
const LastVisitedTimeKey = 'Last-Visited-Key'

export function getToken() {
  // return Cookies.get(TokenKey)
  return sessionStorage.getItem(TokenKey)
}

export function setToken(token) {
  // return Cookies.set(TokenKey, token)
  return sessionStorage.setItem(TokenKey, token)
}

export function removeToken() {
  // return Cookies.remove(TokenKey)
  sessionStorage.removeItem(TokenKey)
}

export function getLastVisitedTime() {
  return sessionStorage.getItem(LastVisitedTimeKey)
}

export function setLastVisitedTime() {
  return sessionStorage.setItem(LastVisitedTimeKey, new Date())
}

export function removeLastVisitedTime() {
  sessionStorage.removeItem(LastVisitedTimeKey)
}

export function tokenIsExpired() {
  const lastVisitedTime = new Date(sessionStorage.getItem(LastVisitedTimeKey))
  if (
    lastVisitedTime === undefined ||
    lastVisitedTime === null ||
    lastVisitedTime === ''
  ) {
    return true
  }
  const diff = new Date().getTime() - lastVisitedTime.getTime() - 30 * 60 * 1000
  return diff >= 0
}
