/**
 * 通用数据字典js方法封装处理
 */
import request from './request'

// 回显数据字典
export function selectDictLabel(datas, value) {
  var actions = []
  Object.keys(datas).map(key => {
    if (datas[key].dictValue === value) {
      actions.push(datas[key].dictLabel)
      return false
    }
  })
  return actions.join('')
}

// 根据字典类型查询字典数据
export function getDataByType(dictType) {
  return request({
    url: '/system/dict-data/selectDictDataByType/' + dictType,
    method: 'get'
  })
}
