import axios from 'axios'
import { Message } from 'element-ui'
import store from '@/store'
import {
  getToken,
  setLastVisitedTime,
  removeToken,
  removeLastVisitedTime
} from '@/utils/auth'
// import router from '@/router'

// create an axios instance
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  // withCredentials: true, // send cookies when cross-domain requests
  timeout: 3 * 60 * 1000 // request timeout
})

// request interceptor
service.interceptors.request.use(
  (config) => {
    // do something before request is sent
    setLastVisitedTime()
    if (store.getters.token) {
      // let each request carry token
      // ['X-Token'] is a custom headers key
      // please modify it according to the actual situation
      config.headers['token'] = getToken()
    }
    return config
  },
  (error) => {
    // do something with request error
    console.log(error) // for debug
    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
   */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  (response) => {
    // 获取验证码，直接返回响应。因为header中包含randomstr
    if (
      response.config.url.indexOf('/code') !== -1 ||
      response.config.url.indexOf('/getSmsCaptcha') !== -1
    ) {
      return response
    } else {
      // 其它情况取响应中的data数据
      const res = response.data

      if (Object.prototype.hasOwnProperty.call(res, 'code')) {
        // if res.code!=0, an error occurred
        if (res.code !== 0) {
          Message({
            message: res.msg || 'Error',
            type: 'error',
            duration: 3 * 1000
          })
          return Promise.reject(res)
        } else {
          return res
        }
      } else {
        return res
      }
    }
  },
  (error) => {
    console.log('err' + error) // for debug
    if (error.response.status === 503) {
      Message({
        message: '服务不可用，请稍后再试！',
        type: 'error',
        duration: 3 * 1000
      })
    } else if (error.response.status === 504) {
      Message({
        message: '请求网关超时，服务不可用！',
        type: 'error',
        duration: 3 * 1000
      })
    } else if (error.response.status === 401) {
      // 50007:Token Null; 50008:Illegal token; 50009: Other clients logged in; 50010: Token expired;
      if (
        error.response.data.code === 50007 ||
        error.response.data.code === 50008 ||
        error.response.data.code === 50009 ||
        error.response.data.code === 50010
      ) {
        // to re-login
        Message({
          message: `您未登录或已登出，请重新登录！`,
          type: 'warning',
          duration: 3 * 1000
        })
        removeToken()
        removeLastVisitedTime()
        store.dispatch('user/resetToken')
        // router.replace({
        //   path: '/login/true'
        //   // query: { redirect: router.currentRoute.fullPath }
        // })
        store.commit('app/SET_LOGIN', true)
      } else {
        Message({
          message: `url:${
            error.config.url || error.response.data.path}，错误代码：${
            error.response.data.code || error.response.status}，错误信息：${
            error.response.data.msg || error.response.statusText}`,
          type: 'error',
          duration: 3 * 1000
        })
      }
    } else if (error.response.status === 404 || error.response.status === 500) {
      Message({
        message: `url:${
          error.config.url || error.response.data.path}，错误代码：${
          error.response.data.code || error.response.status}，错误信息：${
          error.response.data.msg || error.response.statusText}`,
        type: 'error',
        duration: 3 * 1000
      })
    } else {
      Message({
        message: error.message,
        type: 'error',
        duration: 3 * 1000
      })
    }
    return Promise.reject(error)
  }
)

export default service
