<template>
  <div id="aboutas">
    <center><h1>关于我们</h1></center>
    <p>北京高校思想政治理论课高精尖创新中心是在北京市委教育工委、市教委的大力支持与直接领导下成立的首批高精尖创新中心之一。</p>
    <center><img src="@/assets/images/img_01.jpg" alt="图片丢失"></center>
    <p>中心充分发挥北京高校在思想政治理论课教育教学上的人才优势、资源优势、技术优势，通过建设马克思主义理论研究和文献支撑平台、思想政治理论课教学资源共享平台、思想政治理论课数字化教学平台、大学生思想政治教育质量评估平台和大学生思想动态调查分析平台，为高校思想政治理论课教育教学提供全方位、立体化服务。同时，中心立足北京、联动全国、辐射全球，通过凝聚国内外马克思主义理论学科顶尖学者，培养优秀的学生和优质的师资，发挥汇聚和培养马克思主义理论研究和教学人才的集装箱和孵化器的功能。在此基础上，中心立足理论与实践急需，释放理论创新活力，搭建实践创新平台，打造服务和引领北京社会治理、理论创新、决策咨询、舆情研判的思想智库和创新基地。</p>
  </div>
</template>
<script>
export default {
  name: 'AboutUs',
  data() {
    return {

    }
  }
}
</script>
<style lang="scss" scoped>
#aboutas{
  color: #666;
  padding-bottom: 10%;
}
h1{
  font-size: 24px;
  padding: 5%;
}
p{
  line-height: 30px;
  text-indent:2em;
  font-size: 16px;
}
img{padding: 5% 0;}
</style>
