<template>
  <div id="contactus">
    <center>
      <h1>联系我们</h1>
    </center>
    <p>
      中心地址：北京市海淀区中关村大街甲59号
      <br />联系电话：010-62516399
      <br />联 系 人：薛明达
      <br />邮 箱：xuemingda@ruc.edu.cn
      <br />邮 编：100872
      <br />传 真：010-62519525
      <br />
    </p>
    <div class="container">
      <div class="maploader">
        <div id="mymap" class="map"></div>
      </div>
    </div>
  </div>
</template>
<script>
import AMap from '@/assets/AMap/AMap.js'
export default {
  name: 'ContactUs',
  data() {
    return {
      map: null
    }
  },
  mounted() {
    this.init()
    this.$emit('toparent', this.title)
  },
  methods: {
    init: function() {
      var map = new AMap.Map('mymap', {
        resizeEnable: true,
        zoom: 11,
        center: [116.397428, 39.90923]
      })
      // 构造点标记
      var marker = new AMap.Marker({
        icon: 'https://webapi.amap.com/theme/v1.3/markers/n/mark_b.png',
        position: [121.527246, 31.226786]

      })
      // 构造矢量圆形
      var circle = new AMap.Circle({
        center: new AMap.LngLat('121.527246', '31.226786'), // 圆心位置
        radius: 10,  // 半径
        strokeColor: '#b1d0f2',  // 线颜色
        strokeOpacity: 1,  // 线透明度
        strokeWeight: 1,  // 线粗细度
        fillColor: '#d7e4f0',  // 填充颜色
        fillOpacity: 0.8 // 填充透明度
      })

      // 将以上覆盖物添加到地图上
      // 单独将点标记添加到地图上
      // map.add(marker);
      // add方法可以传入一个覆盖物数组，将点标记和矢量圆同时添加到地图上
      map.add([marker, circle])
      map.setFitView()
    }
  }
}
</script>
<style lang="scss" scoped>
#contactus {
  color: #666;
  padding-bottom: 10%;
}
h1 {
  font-size: 24px;
  padding: 5%;
}
p {
  // text-indent:2em;
  padding-left: 15%;
  font-size: 16px;
}
.map {
  margin: 5% 10%;
  height: 300px;
  width: 60%;
}
</style>
