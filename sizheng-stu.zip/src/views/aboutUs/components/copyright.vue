<template>
  <div id="copyright">
    <center><h1>关于我们</h1></center>
    <p>凡本网注明“来源：北京高校思想政治理论课资源平台”的所有作品，或者带有北京高校思想政治理论课资源平台LOGO、水印的所有文字、图片和音视频稿件，均为北京高校思想政治理论课资源平台合法拥有版权或有权使用的作品，任何媒体、网站单位和个人未经本网授权不得转载、摘编或利用其它方式使用上述作品。否则，本网将依法追究其法律责任。</p>
    <p>已经本网授权使用作品的，应在授权范围内使用，并注明“来源：北京高校思想政治理论课资源平台”。违反上述声明者，本网将追究其相关法律责任。</p>
    <p>凡本网注明“来源：XXX（非北京高校思想政治理论课资源平台）”的作品，均转载自其它媒体，转载目的在于传递更多信息，并不代表本网赞同其观点和对其真实性负责。</p>
    <p>本网提供的资料如与相关纸质文本不符，以纸质文本为准。</p>
    <!-- <center><img src="@/assets/images/copyright.png" alt="图片丢失"></center> -->
  </div>
</template>
<script>
export default {
  name: 'CopyRight',
  data() {
    return {

    }
  }
}
</script>
<style lang="scss" scoped>
#copyright{
  color: #666;
  padding-bottom: 10%;
}
h1{
  font-size: 24px;
  padding: 5%;
}
p{
  text-indent:2em;
  font-size: 16px;
  padding-left: 10%;
  padding-bottom: 5%;
  line-height: 30px;
}
img{padding: 5% 0;width: 50%;height: auto;}
</style>
