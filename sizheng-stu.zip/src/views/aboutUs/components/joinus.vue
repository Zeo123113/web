<template>
  <div id="joinus">
    <center>
      <h1>人才招聘</h1>
    </center>
    <p>【招聘】国际合作项目专员——北京高校思想政治理论课高精尖创新中心</p>
    <p>北京高校思想政治理论课高精尖创新中心是国家“2011”协同创新体系的重要组成部分，是首批获得北京市教委认证的13所创新中心之一。中心致力于建设成为巩固马克思主义指导地位的新型高端智库、思想政治理论课的共建共享平台、马克思主义理论教学和研究的优秀人才高地。</p>
  </div>
</template>
<script>
export default {
  name: 'JoinUs',
  data() {
    return {

    }
  }
}
</script>
<style lang="scss" scoped>
#joinus {
  color: #666;
  padding-bottom: 10%;
}
h1 {
  font-size: 24px;
  padding: 5%;
}
p {
  text-indent: 2em;
  font-size: 16px;
  padding-left: 5%;
  padding-bottom: 5%;
  line-height: 30px;
}
img {
  padding: 5% 0;
  width: 50%;
  height: auto;
}
</style>
