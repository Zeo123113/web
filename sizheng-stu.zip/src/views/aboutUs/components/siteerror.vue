<template>
  <div id="siteerror">
    <center><h1>网站纠错</h1></center>
    <p>感谢您对北京高校思想政治理论课资源平台的关注，如发现内容有误，请发送邮件至：sunxf@crup.com.cn</p>
  </div>
</template>
<script>
export default {
  name: 'SiteError',
  data() {
    return {

    }
  }
}
</script>
<style lang="scss" scoped>
#siteerror{
  color: #666;
  padding-bottom: 10%;
}
h1{
  font-size: 24px;
  padding: 5%;
}
p{
  text-indent:2em;
  font-size: 16px;
  padding-left: 5%;
  padding-bottom: 5%;
  line-height: 30px;
}
img{padding: 5% 0;width: 50%;height: auto;}
</style>
