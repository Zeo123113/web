<template>
  <div>
    <Header />
    <Nav />
    <div id="aboutus">
      <!-- 左 -->
      <div id="minnav">
        <ul>
          <li name="1" :class="{active:name==1}" @click="change(1)">关于我们</li>
          <li name="2" :class="{active:name==2}" @click="change(2)">联系我们</li>
          <li name="3" :class="{active:name==3}" @click="change(3)">版权声明</li>
          <li name="4" :class="{active:name==4}" @click="change(4)">网站纠错</li>
          <li name="5" :class="{active:name==5}" @click="change(5)">诚聘英才</li>
        </ul>
      </div>
      <!-- 右 -->
      <div id="content">
        <div v-if="name==1"><AboutUs /></div>
        <div v-else-if="name==2"><ContactUs /></div>
        <div v-else-if="name==3"><CopyRight /></div>
        <div v-else-if="name==4"><JoinUs /></div>
        <div v-else-if="name==5"><SiteError /></div>
      </div>
    </div>
    <Footer />
  </div>
</template>
<script>
import Header from '@/components/header'
import Nav from '@/components/nav'
import Footer from '@/components/footer'
import AboutUs from './components/aboutus'
import ContactUs from './components/contactus'
import CopyRight from './components/copyright'
import JoinUs from './components/siteerror'
import SiteError from './components/joinus'
export default {
  name: 'Aboutus',
  components: {
    Header,
    Nav,
    AboutUs,
    ContactUs,
    CopyRight,
    JoinUs,
    SiteError,
    Footer
  },
  data() {
    return {
      name: 1
    }
  },
  methods: {
    change(name) {
      this.name = name
    }
  }
}
</script>
<style lang="scss" scoped>
#aboutus{
  width: 100%;
  display: flex;
  padding: 0 10%;
}
#minnav{
  width: 30%;
}
#content{
  width: 70%;
}
ul{
  padding: 5% 0;
}
ul li{
  border-bottom: 1px solid #eee;
  font-size: 20px;
  padding: 3%;
}
ul li:hover{
  background-color: rgb(242, 242, 242);
}
.active{
  background-color: rgb(242, 242, 242);
}
</style>
