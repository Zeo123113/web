<template>
  <div>
    <div class="content">
      <div class="activities_head">
        <img class="image" src="@/assets/images/img_banner_2.png">
        <div class="activities_title">
          <div><p class="detail-pp">{{ activityDetail.title }}</p></div>
          <div class="address-info-wrap">
            <div>{{ activityDetail.date }}</div>
            <div style="margin-left: 30px;color: #aaaaaa;font-size: 14px;">限额{{ activityDetail.count }}人</div>
          </div>
          <div style="font-size: 14px;">{{ activityDetail.address }}</div>
          <el-button type="danger" plain style="width:100px;height:40px;float:right;margin-right:30px;margin-top:20px;" @click="apply()">我要报名</el-button>
        </div>
      </div>
      <div class="activities_content">
        <div class="detail-pp1">活动内容</div>
        <center>
          <img src="@/assets/images/a1.png" width="1100px" alt="">
          <img src="@/assets/images/a2.png" width="1100px" alt="">
          <img src="@/assets/images/a3.png" width="1100px" alt="">
        </center>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      activityDetail: {
        title: '2020（光明区）生命科学产业投融资对接会',
        date: '2020年6月30日 14:00 ～ 2020年6月30日 18:00',
        count: 100,
        address: '（广东深圳）光明区光明街道观光路3009号招商局智慧城A2栋3楼招商局智慧城众创空间'
      }
    }
  },
  methods: {
    apply() {
      alert('报名成功！')
    }
  }
}
</script>
<style lang="scss" scoped>
*{
  margin: 0;
  padding: 0;
  -webkit-font-smoothing: antialiased;
}
body{
  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  font-size: 12px;
  line-height: 1.42857143;
  color: #333;
  background-color: #fff;
}
div{
  display: block;
}
.content{
  width: 1080px;
  margin-right: auto;
  margin-left: auto;
}
.image{
  flex-shrink: 0;
  width: 456px;
  height: 270px;
  border-radius: 2px;
  margin-top: 3px;
  margin-left: 3px;
  border: none;
  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}
.media-heading{
  position: relative;
  height: 262px;
  margin-bottom: 40px;
  max-height: 48px;
  margin-bottom: 15px;
  -webkit-line-clamp: 2;
}
.activities_head{
  display: flex;
  padding: 10px 0;
}
.activities_title{
  padding: 10px;
}
.detail-pp {
    margin-right: 15px;
    overflow: hidden;
    line-height: 1.3;
    max-height: 62px;
    width: 555px;
    font-size: 24px;
    color: #000000;
}
.detail-pp1 {
    margin-right: 15px;
    overflow: hidden;
    line-height: 1.3;
    max-height: 62px;
    width: 555px;
    font-size: 24px;
    color: #000000;
    margin: 20px 0;
}
.address-info-wrap {
    display: flex;
    margin-bottom: 4px;
}
.activities_content{
  padding-bottom: 20px;
}
</style>
