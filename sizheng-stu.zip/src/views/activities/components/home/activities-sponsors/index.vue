<template>
  <div>
    <div class="recommend">
      <div class="fz26 pb15" style="color:rgb(225,3,18);border-bottom:1px solid #eee;margin-bottom:10px;">
        <span>活跃主办方</span>
        <span class="fr">更多</span>
      </div>
      <div class="sponsor">
        <div class="first_sponsor" @click="toSponsor()">
          <div class="recommend_list">
            <div class="recommend_list_1_1"><img :src="imgList[0].idView" width="200px" height="200px" alt=""></div>
            <div class="recommend_list_2_1">
              <div class="recommend_title">{{ imgList[0].title }}</div>
              <div class="recommend_type">{{ imgList[0].briefintroduction }}</div>
              <div class="recommend_count">活动&nbsp;{{ imgList[0].activitiescount }}</div>
            </div>
          </div>
        </div>
        <ul class="recommend_ul">
          <li v-for="item in imgList.slice(1,5)" :key="item.id">
            <div class="recommend_list" @click="toSponsor()">
              <div class="recommend_list_1"><img :src="item.idView" width="100px" alt=""></div>
              <div class="recommend_list_2">
                <div class="recommend_title">{{ item.title }}</div>
                <div class="recommend_type clamp_5">{{ item.briefintroduction }}</div>
                <div class="recommend_count">活动&nbsp;{{ item.activitiescount }}</div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  components: {
  },
  data() {
    return {
      imgList: [
        { id: 1, type: '校园活动', name: '详情', idView: require('@/assets/images/ico_news_2.jpg'), activitiescount: '111', briefintroduction: 'Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式JavaScript框架。', title: '某某平台' },
        { id: 2, type: '校园活动', name: '详情', idView: require('@/assets/images/ico_news_2.jpg'), activitiescount: '111', briefintroduction: 'Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式JavaScript框架。', title: '某某平台' },
        { id: 3, type: '校园活动', name: '详情', idView: require('@/assets/images/ico_news_2.jpg'), activitiescount: '111', briefintroduction: 'Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式JavaScript框架。', title: '某某平台' },
        { id: 4, type: '校园活动', name: '详情', idView: require('@/assets/images/ico_news_2.jpg'), activitiescount: '111', briefintroduction: 'Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式JavaScript框架。', title: '某某平台' },
        { id: 5, type: '校园活动', name: '详情', idView: require('@/assets/images/ico_news_2.jpg'), activitiescount: '111', briefintroduction: 'Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式JavaScript框架。', title: '某某平台' },
        { id: 6, type: '校园活动', name: '详情', idView: require('@/assets/images/ico_news_2.jpg'), activitiescount: '111', briefintroduction: 'Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式JavaScript框架。', title: '某某平台' },
        { id: 7, type: '校园活动', name: '详情', idView: require('@/assets/images/ico_news_2.jpg'), activitiescount: '111', briefintroduction: 'Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式JavaScript框架。', title: '某某平台' },
        { id: 8, type: '校园活动', name: '详情', idView: require('@/assets/images/ico_news_2.jpg'), activitiescount: '111', briefintroduction: 'Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式JavaScript框架。', title: '某某平台' }
      ]
    }
  },
  methods: {
    toSponsor() {
      this.$emit('change', 3)
    }
  }
}
</script>

<style lang="scss" scoped>
.recommend{
  margin: 0 10%;
}
.recommend_ul{
  margin-left: 10px;
  border: 1px solid #eee;
  padding: 10px;
  display: flex;
  flex-wrap: wrap;
  flex: 2;
}
.recommend_list{
  display: flex;
  cursor: pointer;
  // width: 300px;
  // height: 200px;
//   margin-bottom: 20px;
}
.recommend_ul li:nth-child(2),li:nth-child(4){
  padding-left: 10px;
}
.recommend_ul li{
    width: 50%;
}
.recommend_date{
  margin-top: 14px;
  color: #999;
  font-size: 12px;
}
.recommend_title{
    display: block;
    margin-top: 8px;
    color: #2b312b;
    font-size: 15px;
    line-height: 22px;
    height: 44px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    transition: all 0.3s ease;
    }
.recommend_title:hover{
  color: rgb(229, 1, 18);
}
.recommend_type{
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
//   white-space: nowrap;
  color: #999;
}
.recommend_count{
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
//   white-space: nowrap;
  color: #999;
//   position: relative;
//   bottom: 0;
}
.first_sponsor{
  padding: 10px;
  border: 1px solid #eee ;
  width: 400px;
  flex: 1;
  cursor: pointer;
}
.sponsor{
    display: flex;
    margin-bottom: 20px;
}
.recommend_list_1{
    flex: 1;
}
.recommend_list_2{
    flex: 3;
    padding-left: 10px;
}
.recommend_list_1_1{
    flex: 1;
}
.recommend_list_2_1{
    padding-left: 10px;
    flex: 1;
}
.clamp_5 {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
    -moz-line-clamp: 3;
    text-overflow: ellipsis;
    box-orient: vertical;
    line-clamp: 3;
    overflow: hidden;
}
</style>

