<template>
  <div>
    <div class="recommend">
      <div class="fz26 pb15" style="color:rgb(225,3,18);border-bottom:1px solid #eee;margin-bottom:10px;">
        <span>平台活动</span>
        <span class="fr">更多</span>
      </div>
      <div class="">
        <ul class="recommend_ul">
          <li v-for="item in imgList" :key="item.id">
            <div class="recommend_list" @click="todetail()">
              <div><img :src="item.idView" width="100%" alt=""></div>
              <div class="recommend_date">{{ item.date }}&nbsp;&nbsp;{{ item.time }}</div>
              <div class="recommend_title">{{ item.title }}</div>
              <div class="recommend_type">{{ item.type }}</div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  components: {
  },
  data() {
    return {
      imgList: [
        { id: 0, type: '平台活动', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 1, type: '平台活动', name: '详情', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 2, type: '平台活动', name: '推荐', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 3,  type: '平台活动', name: '推荐', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 4, type: '平台活动', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 5, type: '平台活动', name: '详情', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 6, type: '平台活动', name: '推荐', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 7,  type: '平台活动', name: '推荐', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' }
      ]
    }
  },
  methods: {
    todetail() {
      this.$emit('change', false)
      // console.log(this.choice)
    }
  }
}
</script>

<style lang="scss" scoped>
.recommend{
  margin: 0 10%;
}
.recommend_ul{
  display: flex;
   flex-wrap: wrap;
}
.recommend_list{
  // width: 300px;
  // height: 200px;
  padding-bottom: 20px;
  cursor: pointer;
}
.recommend_ul li:nth-child(2),li:nth-child(3),li:nth-child(4),li:nth-child(6),li:nth-child(7),li:nth-child(8){
  padding-left: 10px;
}
.recommend_ul li{
    width: 25%;
}
.recommend_date{
  margin-top: 14px;
  color: #999;
  font-size: 12px;
}
.recommend_title{
    display: block;
    margin-top: 8px;
    color: #2b312b;
    font-size: 15px;
    line-height: 22px;
    height: 44px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    transition: all 0.3s ease;
    }
.recommend_title:hover{
  color: rgb(229, 1, 18);
}
.recommend_type{
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #999;
}
</style>

