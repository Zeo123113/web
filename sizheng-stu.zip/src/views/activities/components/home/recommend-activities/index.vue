<template>
  <div>
    <div class="recommend">
      <el-carousel :interval="4000" type="card" style="margin-top:10px;">
        <el-carousel-item v-for="item in imgList" :key="item.id">
          <el-row>
            <el-col :span="24"><img ref="imgHeight" :src="item.idView" class="banner_img" /></el-col>
          </el-row>
        </el-carousel-item>
      </el-carousel>
      <div class="fz26 pb15" style="color:rgb(225,3,18);border-bottom:1px solid #eee;margin-bottom:10px;">
        <span>推荐活动</span>
        <span class="fr">更多</span>
      </div>
      <div class="">
        <ul class="recommend_ul">
          <li v-for="item in imgList" :key="item.id">
            <div class="recommend_list" @click="todetail()">
              <div><img :src="item.idView" width="100%" alt=""></div>
              <div class="recommend_date">{{ item.date }}&nbsp;&nbsp;{{ item.time }}</div>
              <div class="recommend_title">{{ item.title }}</div>
              <div class="recommend_type">{{ item.type }}</div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  components: {
  },
  data() {
    return {
      imgList: [
        { id: 0, type: '平台活动', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 1, type: '平台活动', name: '详情', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 2, type: '校园活动', name: '推荐', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' },
        { id: 3,  type: '校园活动', name: '推荐', idView: require('@/assets/images/img_banner_2.png'), date: '10月10日', time: '19:00', title: '某某平台活动点点点' }
      ]
    }
  },
  methods: {
    todetail() {
      this.$emit('change', false)
      // console.log(this.choice)
    }
  }
}
</script>

<style lang="scss" scoped>
.el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
  }

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n+1) {
  background-color: #d3dce6;
}
.banner_img{
  width: 100%;
}
.recommend{
  margin: 0 10%;
}
.recommend_ul{
  display: flex;
}
.recommend_list{
  // width: 300px;
  // height: 200px;
  cursor: pointer;
  padding-bottom: 20px;
}
.recommend_ul li:nth-child(2),li:nth-child(3),li:nth-child(4){
  padding-left: 10px;
}
.recommend_date{
  margin-top: 14px;
  color: #999;
  font-size: 12px;
}
.recommend_title{
    display: block;
    margin-top: 8px;
    color: #2b312b;
    font-size: 15px;
    line-height: 22px;
    height: 44px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    transition: all 0.3s ease;
    }
.recommend_title:hover{
  color: rgb(229, 1, 18);
}
.recommend_type{
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #999;
}
</style>

