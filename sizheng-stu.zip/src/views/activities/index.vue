<template>
  <div id="activities">
    <div v-if="choice===1">
      <RecommendActivities @change="updateContent" />
      <PlatformActivities @change="updateContent" />
      <UnivercityActivities @change="updateContent" />
      <ActivitiesSponsors @change="updateContent" />
    </div>
    <div v-else-if="choice===2">
      <Detail />
    </div>
    <div v-else-if="choice===3">
      <Sponsors />
    </div>
  </div>
</template>
<script>
import PlatformActivities from './components/home/platform-activities/index'
import UnivercityActivities from './components/home/univercity-activities/index'
import RecommendActivities from './components/home/recommend-activities/index'
import ActivitiesSponsors from './components/home/activities-sponsors/index'
import Detail from './components/detail/index'
import Sponsors from './components/sponsor/index'
export default {
  components: {
    PlatformActivities,
    UnivercityActivities,
    RecommendActivities,
    ActivitiesSponsors,
    Detail,
    Sponsors
  },
  data() {
    return {
      choice: 1
    }
  },
  methods: {
    updateContent(choice) {
      this.choice = choice
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
