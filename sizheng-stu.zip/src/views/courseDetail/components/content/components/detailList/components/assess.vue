<!--
@description 课程评价
@author cgy
-->
<template>
  <div id="assess">
    <section v-loading="loading">
      <ol class="db">
        <li v-for="(item,index) of courseRatingList" :key="index" class="mod-qa-list">
          <!-- 展示头像 -->
          <div>
            <img v-if="item.avatar" :src="item.avatar" class="img2 ml55" />
            <img v-else src="@/assets/images/avatar.png" class="img2 ml55" />
          </div>
          <!-- 评分展示 -->
          <div class="qt-tit ml124 click">
            {{ item.realName }}
            <!-- <el-rate
              value="item.rate"
              disabled
              show-score
              text-color="#ff9900"
            ></el-rate>-->
            <span style="margin-left: 5rem">{{ item.rate }}分</span>
            <span style="margin-right: 1rem">{{ item.createTime }}</span>
          </div>
          <!-- 评论内容展示 -->
          <div class="xcontent ml124 mt7">
            <div class="content click" v-html="item.commentContent">{{ item.commentContent }}</div>
          </div>
        </li>
      </ol>
      <div v-if="!courseRatingList.length" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>该课程没有评价</p>
      </div>
    </section>
    <!--分页-->
    <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
import COURSE_CONST from '@/constant/course-const'
import courseRatingApi from '@/api/course/courseManage/courseRating'
export default {
  name: 'Assess',
  data() {
    return {
      // 评论列表
      courseRatingList: [],
      // 查询对象
      courseRating: {},
      // 初始页
      pageIndex: 1,
      total: 1,
      // 默认分页参数
      pageSize: COURSE_CONST.PAGESIZE,
      loading: false,
      schemeId: null
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    getList() {
      // 获取课程详情
      this.schemeId = this.$route.params.schemeId
      this.loading = true
      this.courseRating.status = 1
      this.courseRating.schemeId = parseInt(this.schemeId)
      courseRatingApi.getCourseRatingBySchemeId(this.courseRating, this.pageIndex, this.pageSize).then(resp => {
        this.courseRatingList = resp.data.list
        this.loading = false
        this.total = resp.data.total
      })
    },
    handleCurrentChange(val) {
      if (this.isall) {
        this.loading = true
        this.params.status = 0
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      } else {
        this.loading = true
        this.params.status = 1
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      }
    },
    getRating(val) {
      return val.rating.toString()
    }
  }
}
</script>

<style lang="scss" scoped>
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
</style>
<style lang="scss" scoped>
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  padding: 32px;
  margin: 0 32px;
  margin-bottom: 18px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 16px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  margin-top: -42px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
</style>
