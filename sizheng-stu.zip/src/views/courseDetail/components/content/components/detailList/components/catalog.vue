<!--
@description 课程详情页-目录
@author cgy
-->
<template>
  <div v-loading="loading" class="catalog">
    <el-collapse v-for="(item,i) of courseChapter" :key="i" style="border:0;">
      <el-collapse-item v-if="item != null && item.chapterType !== '2'">
        <!-- 一级菜单（章） -->
        <template slot="title">
          <i class="ico_chapter_sty" style="margin-right:10px;"></i>
          <div style="font-size:16px;font-weight:bold;">{{ chapterTitle(item) }}</div>
          <!-- 按钮组 -->
          <div style="display:inline-block;position:absolute;left:90%;"></div>
        </template>
        <!-- 二级菜单（节） -->
        <el-collapse v-for="(items,ind) of item.children" :key="ind" style="border:0;padding:0 3%;">
          <el-collapse-item v-if="items.chapterType === '1'">
            <template slot="title">
              <div
                class="cf chapter_menu_2"
                style="width:100%;padding: 0;margin:0;background:none;"
              >
                <div class="fl">
                  <span class="ml10 course_fz_sty">{{ chapterTitle(items) }}</span>
                </div>
              </div>
            </template>
            <!-- 三级菜单（单元） -->
            <el-collapse-item v-for="(itemss,inde) in items.children" :key="inde">
              <template slot="title">
                <div
                  class="cf chapter_menu_2"
                  style="width:100%;padding: 0;margin:0;background:none;"
                >
                  <span>{{ chapterTitle(itemss) }}</span>
                </div>
              </template>
              <!-- 四级菜单（课时） -->
              <el-collapse-item v-for="(itemsss,index) in itemss.children" :key="index">
                <template slot="title">
                  <div
                    class="cf chapter_menu_2"
                    style="width:100%;padding: 0;margin:0;background:none;"
                  >
                    <span>{{ taskTitle(itemsss) }}</span>
                    <div class="fr">
                      <a class="start_learning_btn mr10" @click="continueLearning(itemsss)">开始学习</a>
                    </div>
                  </div>
                </template>
              </el-collapse-item>
            </el-collapse-item>
          </el-collapse-item>
        </el-collapse>
        <!-- 二级菜单（节） -->
        <el-collapse
          v-for="(items,index) of item.children"
          :key="'unit'+index"
          style="border:0;padding:0 3%;"
        >
          <template slot="title">
            <div class="cf chapter_menu_2" style="width:100%;padding: 0;margin:0;background:none;">
              <div class="fl">
                <span class="ml10 course_fz_sty">{{ chapterTitle(items) }}</span>
              </div>
            </div>
          </template>
          <!-- 三级菜单（授课任务） -->
          <el-collapse-item v-if="items != null && items.chapterType === '2'">
            <template slot="title">
              <div
                class="cf chapter_menu_2"
                style="width:100%;padding: 0;margin:0;background:none;"
              >
                <span>{{ chapterTitle(items) }}</span>
              </div>
            </template>
            <!-- 四级菜单（课时） -->
            <el-collapse-item v-for="(itemsss,inde) in items.children" :key="inde">
              <template slot="title">
                <div
                  class="cf chapter_menu_2"
                  style="width:100%;padding: 0;margin:0;background:none;"
                >
                  <span>{{ taskTitle(itemsss) }}</span>
                  <div class="fr">
                    <a class="start_learning_btn mr10" @click="continueLearning(itemsss)">开始学习</a>
                  </div>
                </div>
              </template>
            </el-collapse-item>
          </el-collapse-item>
        </el-collapse>
      </el-collapse-item>
      <!-- 一级单元 -->
      <el-collapse-item
        v-if="item != null && item.chapterType === '2'"
        style="border:0;padding:0 3%;"
      >
        <template slot="title">
          <div class="cf chapter_menu_2" style="width:100%;padding: 0;margin:0;background:none;">
            <span>{{ chapterTitle(item) }}</span>
            <div class="fr">
              <a class="start_learning_btn mr10" @click="continueLearning(item)">开始学习</a>
            </div>
          </div>
        </template>
      </el-collapse-item>
    </el-collapse>
    <div v-if="!courseChapter.length" class="nodata">
      <p>
        <svg class="icon icon-tishi" aria-hidden="true">
          <use xlink:href="#icon-tishi" />
        </svg>
      </p>
      <p>什么都没有，快去添加一个课时</p>
    </div>
  </div>
</template>
<script>
import courseChapterApi from '@/api/course/courseManage/courseChapter'
import { mapGetters } from 'vuex'
import studyLogApi from '@/api/course/courseTask/studyLog'
export default {
  name: 'Catalog',
  data() {
    return {
      courseChapter: [],
      courseChapterType: [],
      loading: false,
      chapter: {},
      courseStudyLog: {}
    }
  },
  // 从状态管理器获取按钮权限数组button
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {
    // 课程章节类型数据字典获取
    this.getDataByType('course_chapter_type').then(response => {
      this.courseChapterType = response.data
    })
    this.getTreeBySchemeId()
  },
  methods: {
    // 点击继续学习跳转
    continueLearning(courseChapter) {
      console.log('continueLearning---courseChapter = ', courseChapter)
      this.chapter = { ...courseChapter }
      this.findStudyLog(courseChapter.jmaterials.fileId, courseChapter.pstId)
    },
    routerLearning() {
      const csId = this.$route.params.csId
      const ctId = this.$route.params.ctId
      const schemeId = this.$route.params.schemeId
      const { studyLogId } = this.courseStudyLog
      this.$router.push(`/ContinueLearning/cs/${csId}/term/${ctId}/scheme/${schemeId}/courseStudyLog/${studyLogId}`)
    },
    initCourseStudyLog() {
      this.courseStudyLog = {
        studyLogId: null,
        csId: this.chapter.csId,
        ctId: this.chapter.ctId,
        schemeId: this.chapter.schemeId,
        unitId: this.chapter.sourceUnitId,
        mgId: null,
        pstId: this.chapter.pstId,
        smType: '2',
        smId: this.chapter.jmaterials.fileId,
        studyMaterial: JSON.stringify(this.chapter.jmaterials),
        studyStartTime: this.format(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        studyEndTime: null,
        duration: 0,
        userId: this.user.userId,
        stuId: this.user.stuId,
        realName: this.user.realName,
        isFinished: false,
        studyScore: 0,
        lastPosition: 0,
        lastPages: 0
      }
    },
    // 查找学习记录，找不到就添加
    findStudyLog(smId, pstId) {
      var data = {
        userId: this.user.userId,
        smId: smId,
        pstId: pstId
      }
      studyLogApi.getStudyLog(data).then((result) => {
        if (result.data.studyLogId !== null) {
          this.courseStudyLog = result.data
          this.courseStudyLog.studyStartTime = this.courseStudyLog.studyEndTime
          this.routerLearning()
        } else {
          this.initCourseStudyLog()
          console.log('StudentAddStudyLog==============')
          studyLogApi.StudentAddStudyLog(this.courseStudyLog).then((result) => {
            if (result.code === 0) {
              this.courseStudyLog = result.data
              this.routerLearning()
            }
          })
        }
      })
    },
    updateCourseStudyLog() {
      if (this.chapter.jmaterials.condition === '0' || this.chapter.jmaterials.condition === '学习到最后') {
        if (this.courseStudyLog.duration === this.myPlayer.duration() * 1000) {
          this.courseStudyLog.isFinished = true
          this.courseStudyLog.studyScore = this.chapter.jmaterials.score
          studyLogApi.updateStudyLog(this.courseStudyLog)
        } else {
          studyLogApi.updateStudyLog(this.courseStudyLog)
        }
      } else {
        if (this.formatSeconds(this.chapter.duration).toString() === this.courseStudyLog.jmaterials.finshTime) {
          this.courseStudyLog.isFinished = true
          this.courseStudyLog.studyScore = this.chapter.jmaterials.score
          studyLogApi.updateStudyLog(this.courseStudyLog)
        } else {
          studyLogApi.updateStudyLog(this.courseStudyLog)
        }
      }
    },
    /**
     * 获取当前时间
     */
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    },
    // 任务名称
    taskTitle(chapter) {
      // console.log('chapter = ', chapter)
      return chapter.chapterTitle
    },
    /** 课程章节名称 */
    chapterTitle(row) {
      return '第' + row.chapterSeq + this.typeFormat(row) + ' ' + row.chapterTitle
    },
    /** 字典类型字典翻译 */
    typeFormat(row) {
      return this.selectDictLabel(this.courseChapterType, row.chapterType)
    },
    getTreeBySchemeId() {
      // 获取课程详情
      const schemeId = this.$route.params.schemeId
      if (schemeId === undefined || schemeId == null) {
        return
      }
      this.loading = true
      // 获取章节列表
      courseChapterApi.getFrontlist(schemeId).then(response => {
        this.courseChapter = response.data
        this.loading = false
      })
    }
  }
}
</script>
<style lang="scss" scoped>
/* 分页 */
.el-pager li.active {
  color: #e50112;
}
.el-pager li {
    color: #e50112;
}
.el-pager li:hover {
  color: #e50112;
}
.el-pagination button,
.el-pagination span:hover {
  color: #e50112;
}

.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
</style>
