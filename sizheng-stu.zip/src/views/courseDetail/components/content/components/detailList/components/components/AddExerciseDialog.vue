<template>
  <el-dialog
    title="添加练习任务"
    :visible.sync="dialogFormVisible"
    @open="open"
    @close="resetForm('cExercise')"
  >
    <el-form ref="cExercise" :model="cExercise" :rules="rules" label-width="100px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="章节" prop="chapterId">
            <treeselect
              v-model="cExercise.chapterId"
              :options="chapterOptions"
              style="display: inline-block;width:220px;"
              placeholder="请选择章节"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="难易度" prop="diffLevel">
            <el-select v-model="cExercise.diffLevel" clearable>
              <el-option
                v-for="item in diffLevelOptions"
                :key="item.dictValue"
                :label="item.dictLabel"
                :value="item.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="抽取试题数" prop="amount">
            <el-input-number
              v-model="cExercise.amount"
              controls-position="right"
              :min="1"
              :max="10"
            />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="知识点" placeholder="请选择知识点" prop="kidList">
            <el-select v-model="cExercise.kidList" clearable multiple filterable>
              <el-option
                v-for="item in knowledgeOptions"
                :key="item.knowledgeId"
                :label="item.knowledgeName"
                :value="item.knowledgeId"
              />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="mini" @click="saveComment('cExercise')">保存</el-button>
      <el-button size="mini" @click="resetForm('cExercise')">取消</el-button>
    </div>
  </el-dialog>
</template>
<script>
import cExerciseApi from '@/api/course/courseTask/cExercise'
import Treeselect from '@riophae/vue-treeselect'
import chapterApi from '@/api/exambank/chapter'
import knowledgeApi from '@/api/exambank/knowledge'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  components: {
    Treeselect
  },
  props: {
    // 打开弹窗标志
    dialogFormVisible: {
      type: Boolean,
      default: false
    },
    // 练习任务
    cExercise: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 验证规则
      rules: {
        // csId: [{ required: true, message: '请选择课程设置', trigger: 'blur' }],
        // ctId: [{ required: true, message: '请选择课程学期', trigger: 'blur' }],
        // schemeId: [{ required: true, message: '请选择教学方案', trigger: 'blur' }],
        // mgId: [{ required: true, message: '请选择学员分组', trigger: 'blur' }],
        // unitId: [{ required: true, message: '请选择授课单元ID', trigger: 'blur' }],
        // orgId: [{ required: true, message: '组织机构不能为空', trigger: 'blur' }],
        amount: [{ required: true, message: '抽取题数不能为空', trigger: 'blur' }]
      },
      // 表单属性宽度
      formLabelWidth: '100px',
      // 富文本开启标志
      saveFlag: false,
      // 组织结构
      orgOptions: [],
      // 课程
      courseOptions: [],
      // 课程学期
      courseTermOptions: [],
      // 教学方案
      schemeOptions: [],
      // 学员分组
      courseMgOptions: [],
      // 授课单元
      cExerciseOptions: [],
      // 评分颜色
      colors: ['#99A9BF', '#F7BA2A', '#FF9900'],
      // 章节列表
      chapterOptions: [],
      // 知识点列表
      knowledgeOptions: [],
      // 试题难易水平
      diffLevelOptions: []
    }
  },
  created() {
    // 难易度字典获取
    this.getDataByType('exambank_diff_level').then(response => {
      this.diffLevelOptions = response.data
    })
  },
  methods: {
    /** 打开弹窗放入富文本内容 */
    open() {
      chapterApi.getChapterTreeByCourseId(this.cExercise.csId).then(response => {
        this.chapterOptions = response.data
        this.knowledgeOptions = []
        this.cExercise.chapterId = null
        this.cExercise.kidList = null
      })
      knowledgeApi.getKnownledgeListByCourseId(this.cExercise.csId).then(response => {
        this.knowledgeOptions = response.data
        this.cExercise.knowledgeId = null
      })
      this.editsaveFlag()
    },
    editsaveFlag() {
      setTimeout(() => {
        this.saveFlag = !this.saveFlag
      }, 500)
    },
    // 保存表单
    saveComment(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.cExercise.orgId = this.$store.getters.user.orgId
          this.cExercise.kidList = JSON.stringify(this.cExercise.kidList)
          cExerciseApi.add(this.cExercise).then(resp => {
            this.resetForm('cExercise')
            // this.$emit('getList')
            if (resp.code === 0) {
              // 打开详情
              this.$router.push({
                name: `exercise`,
                params: {
                  exercise: this.cExercise
                }
              })
            } else {
              this.$message({
                message: resp.msg,
                type: 'error'
              })
            }
          })
        }
      })
    },
    // 重置表单
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.cExercise.commentContent = ''
      this.saveFlag = true
      this.editsaveFlag()
      this.$emit('closeAdd')
    }
  }
}
</script>
<style scoped>
.el-dialog__wrapper >>> .el-dialog {
  width: 55%;
}
.el-dialog__wrapper {
  z-index: 1200 !important;
}
.el-form-item >>> .el-form-item__content {
  height: 36px;
}
.el-select {
  width: 100%;
}
</style>
<style scoped>
.el-select >>> .el-select__tags{
  overflow-x: hidden;
}
</style>
