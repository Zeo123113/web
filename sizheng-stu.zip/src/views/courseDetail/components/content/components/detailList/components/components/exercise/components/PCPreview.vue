<!--
@description 学生端练习
@author CPY
-->
<template>
  <div class="preview-content-area">
    <!--结束左侧时间题卡-->
    <!--中间试题列表-->
    <div class="doexam-main">
      <!--试卷名称-->
      <div class="header">
        <p>{{ exercise.exerTitle }}</p>
        <strong class="time-left">
          <svg class="icon incontest" aria-hidden="true">
            <use xlink:href="#icon-jishi1" />
          </svg>
          {{ minute }}:{{ second }}
        </strong>
      </div>
      <div
        v-for="(question,index) in questionlist"
        :key="index"
        :style="current == question.tqSeq? equalCurrent:NotCurrent"
        class="row-box"
      >
        <div v-if="question.tqSeq == current" style="answer-list">
          <div class="subject-title-box">
            <span class="answer-progress">{{ question.tqSeq }}/ {{ questionlist.length }}</span>&emsp;
            <svg class="icon incontest" style="color:#FF652F" aria-hidden="true">
              <use xlink:href="#icon-wenti" />
            </svg>&emsp;
            <span v-for="(type,typeIndex) in questionTypeOptions" :key="typeIndex">
              <em v-if="type.dictValue == question.tqTypeId" class="span1">[{{ type.dictLabel }}]</em>
            </span>
          </div>
          <div class="content" v-html="question.content"></div>
          <!--单选题/判断题-->
          <el-radio-group
            v-if="question.tqTypeId.toString()===SINGLE || question.tqTypeId.toString()===JUDGEMENT"
            v-model="question.userAnswer"
          >
            <el-radio v-for="item in question.options" :key="item.value" border :label="item.value">
              <span v-html="item.label">{{ item.label }}</span>
            </el-radio>
          </el-radio-group>
          <!--多选题-->
          <el-checkbox-group
            v-if="question.tqTypeId.toString()===MULTIPLE"
            v-model="question.userAnswerOptions"
          >
            <el-checkbox
              v-for="item in question.options"
              :key="item.value"
              border
              :label="item.value"
              style="margin-top:10px;display:block;"
            >
              <span v-html="item.label"></span>
            </el-checkbox>
          </el-checkbox-group>
          <!--填空题-->
          <div v-if="question.tqTypeId.toString()===FILLBLANK">
            <tinymce
              v-if="question.tqTypeId.toString()==PROG_FILLBLANK"
              v-model="question.code"
              plugins="codesample"
              toolbar="false"
              menubar="false"
              inline="true"
              :height="400"
            />
            <div v-for="item in question.options" :key="item">
              <el-row>
                <el-col :span="1" style="margin-top:20px;">{{ item }}.</el-col>
                <el-col :span="15">
                  <el-input style="margin-top:10px;" placeholder="请输入内容"></el-input>
                </el-col>
              </el-row>
            </div>
          </div>
          <!--简答题/编程题-->
          <div
            v-if="question.tqTypeId.toString() === ESSAY_QUESTION || question.tqTypeId.toString() == PROGRAMME"
          >
            <tinymce ref="content" v-model="question.userAnswer" :save-flag="saveFlag" :height="250" />
          </div>
          <!--上传题-->
          <div v-if="question.tqTypeId.toString() === FILE_UPLOAD">
            <el-button size="small" type="primary">点击上传</el-button>
          </div>
          <!--材料题-->
          <div v-if="question.tqTypeId.toString() === MATERIAL">
            <div
              v-for="(master,masterIndex) in question.materialQuestions"
              :key="masterIndex"
              style="margin-left:2em;margin-top:1em"
            >
              <span class="span1">{{ question.tqSeq }}.{{ masterIndex+1 }}</span>
              <span v-for="(type,typeIndex) in questionTypeOptions" :key="typeIndex">
                <span
                  v-show="type.dictValue == master.tqTypeId"
                  class="span1"
                >[{{ type.dictLabel }}]</span>
              </span>
              <!-- <div class="content" v-html="master.content"></div> -->
              <SelectQuestionPreview
                v-if="master.tqTypeId.toString() !== MATERIAL&&master.tqTypeId.toString()!==PROG_FILLBLANK"
                ref="SelectQuestionPreview"
                :question="master"
                @saveQuestion="saveQuestion($event)"
              ></SelectQuestionPreview>
            </div>
          </div>
          <!--程序填空题-->
          <ProFillBlankPreview
            v-if="question.tqTypeId.toString() === PROG_FILLBLANK"
            :question="question"
          ></ProFillBlankPreview>
          <!--接口编程题-->
          <div v-if="question.tqTypeId.toString() === INTERFACE">
            <tinymce ref="content" v-model="question.userAnswer" :save-flag="saveFlag" :height="250" />
          </div>
          <!--选项结束-->
        </div>
      </div>
    </div>
    <div class="submit-buttons">
      <el-button
        v-show="current != 1"
        :style="{display:current == 1? 'none':'block' }"
        @click="currentPrevious()"
      >上一题</el-button>
      <el-button
        v-show="current != questionlist.length"
        :style="{padding:current == 1? '10px 130px' :'10px 65px' }"
        type="primary"
        @click="currentNext()"
      >下一题</el-button>
      <el-button v-show="current == questionlist.length" type="primary" @click="submitPaper()">提 交</el-button>
      <div class="subject-new-tips">* 提交即可查看全部答案和解析</div>
    </div>
    <!--结束中间试题列表-->
    <!--时间/题卡-->
    <div class="left">
      <!--考试剩余时间/题数-->
      <div class="time-main">
        <div class="page">共{{ questionlist.length }}道题</div>
      </div>
      <!--结束考试剩余时间/题数-->
      <!--题卡-->
      <div class="question-lists">
        <el-button v-if="!openList" class="card-unfold" type="text" @click="covert()">
          收起答题卡
          <i class="el-icon-arrow-down"></i>
        </el-button>
        <el-button v-else class="card-unfold" type="text" @click="covert()">
          展开答题卡
          <i class="el-icon-arrow-up"></i>
        </el-button>
        <ul v-if="!openList">
          <li
            v-for="question in questionlist"
            :key="question.tqSeq"
            :style="{border:current != question.tqSeq?'1px solid #bbb':'1px solid #67C23A',background:question.userAnswer|| question.userAnswerOptions.length? '#67C23A':'#ffffff',color:question.userAnswer|| question.userAnswerOptions.length?'#ffffff':'#333'}"
            @click="current = question.tqSeq"
          >{{ question.tqSeq }}</li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
import Tinymce from '@/components/Tinymce'
import ProFillBlankPreview from './ProgFillBlankPreview'
import SelectQuestionPreview from './SelectQuestionPreview'
import answerRecordApi from '@/api/exambank/exercise-record'
export default {
  components: { Tinymce, ProFillBlankPreview, SelectQuestionPreview },
  props: {
    questionlist: {
      type: Array,
      required: true
    },
    exercise: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 时间
      minutes: 0,
      seconds: 0,
      // 试题类型
      questionTypeOptions: [],
      // 当前试题
      current: 1,
      // 试题类型常量定义
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      ESSAY_QUESTION: EXAMBANK_CONST.ESSAY_QUESTION,
      PROGRAMME: EXAMBANK_CONST.PROGRAMME,
      FILE_UPLOAD: EXAMBANK_CONST.FILE_UPLOAD,
      MATERIAL: EXAMBANK_CONST.MATERIAL,
      PROG_FILLBLANK: EXAMBANK_CONST.PROG_FILLBLANK,
      INTERFACE: EXAMBANK_CONST.INTERFACE,
      content: [],
      options: [],
      selectValue: [],
      // 富文本标志
      saveFlag: false,
      // 样式绑定
      equalCurrent: {
        display: 'block'
      },
      NotCurrent: {
        display: 'none'
      },
      // 做过的题
      selected: {
        'background-color': '#67C23A',
        color: '#ffffff'
      },
      // 未做过的题
      notSelected: {
        background: '#ffffff'
      },
      // 程序编程题code
      code: '',
      // 材料题子题列表
      masterialQuestion: {},
      // 材料题
      masterialList: [],
      init: {
        language_url: 'tinymce/langs/zh_CN.js',
        language: 'zh_CN',
        skin_url: 'tinymce/skins/ui/oxide',
        max_height: 650,
        min_height: 400,
        plugins: 'codesample',
        toolbar: false,
        inline: true,
        menubar: false
      },
      // 是否展开练习题卡
      openList: false
    }
  },
  computed: {
    second: function() {
      return this.num(this.seconds)
    },
    minute: function() {
      return this.num(this.minutes)
    }
  },
  watch: {
    second: {
      handler(newVal) {
        this.num(newVal)
      }
    },
    minute: {
      handler(newVal) {
        this.num(newVal)
      }
    }
  },
  mounted() {
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.questionTypeOptions = response.data
    })
    // 开始计时
    this.add()
    this.openDialog(this.questionlist)
    this.questionlist.forEach(item => {
      if (item.tqTypeId.toString() === this.MATERIAL) {
        this.openDialog(item.materialQuestions)
      }
    })
  },
  methods: {
    // 渲染试题
    openDialog(list) {
      list.forEach(question => {
        if (question.tqTypeId.toString() === this.SINGLE || question.tqTypeId.toString() === this.JUDGEMENT) {
          this.selectValue = ''
        } else if (question.tqTypeId.toString() === this.MULTIPLE) {
          this.selectValue = []
        } else {
          this.selectValue = []
          this.content = []
          this.options = []
        }
        const dom = this.collectionToArray(this.parseDom(question.content))
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text' || (dom[i].nodeName === 'P' && dom[i].innerText.trim() === '')) {
            dom.splice(i, 1)
            i--
          }
        }

        if (
          question.tqTypeId.toString() === this.SINGLE ||
          question.tqTypeId.toString() === this.JUDGEMENT ||
          question.tqTypeId.toString() === this.MULTIPLE
        ) {
          let ol_pos = -1
          for (let i = 0; i < dom.length; i++) {
            if (dom[i].nodeName === 'OL') {
              ol_pos = i
            }
          }
          if (ol_pos > 0) {
            const ol = dom[ol_pos]
            dom.splice(ol_pos, 1)
            let str = ''
            for (let i = 0; i < dom.length; i++) {
              str += dom[i].innerHTML + '<br/>'
            }
            question.content = '<p>' + str + '</p>'
            str = ''
            for (let i = 0; i < ol.children.length; i++) {
              const index = String.fromCharCode(i + 65)
              const item = {}
              item.value = index
              item.label = ol.children[i].innerHTML
              this.options[i] = item
            }
            question.options = this.options
          } else {
            this.content = []
            this.options = []
          }
        } else {
          let k = 1
          for (let i = 0; i < dom.length; i++) {
            this.content[i] = dom[i].innerHTML
            let index = this.content[i].indexOf('&lt;blank&gt;', 0)
            while (index >= 0) {
              const str = ' ( ' + k + ' ) '
              k++
              this.content[i] = this.content[i].replace('&lt;blank&gt;', str)
              index = this.content[i].indexOf('&lt;blank&gt;', index + 7)
            }
            var objE = document.createElement('p')
            objE.innerHTML = this.content[i]
            this.content[i] = objE.outerHTML
          }
          let str = ''
          for (let i = 0; i < this.content.length; i++) {
            str += this.content[i]
          }
          this.content = str
          this.options = []
          for (let i = 0; i < k - 1; i++) {
            this.options[i] = i + 1
          }
          question.options = this.options
          question.content = this.content
        }
        this.options = []
        this.content = ''
      })
    },
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    },
    // 是否
    covert() {
      this.openList = !this.openList
    },
    // 保存材料子题
    saveQuestion(master) {},
    // 交卷
    submitPaper() {
      this.$confirm('再次确定是否交卷, 交卷后将不能继续答题！', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.questionlist.forEach(item => {
            if (item.tqTypeId.toString() === this.MULTIPLE) {
              item.userAnswer = item.userAnswerOptions.join('|')
            }
          })
          this.exercise.exerciseListList = this.questionlist
          this.exercise.duration = this.exercise.duration + this.minutes * 60 + this.seconds
          answerRecordApi.updateStudentAnswer(this.exercise).then(resp => {
            if (resp.code === 0) {
              // 转向练习列表
              this.$router.go(-1)
              this.$message({
                type: 'success',
                message: '提交成功!'
              })
            }
          })
        })
    },
    // 上一道
    currentPrevious() {
      this.current--
    },
    // 下一道
    currentNext() {
      this.current++
    },
    num(n) {
      return n < 10 ? '0' + n : '' + n
    },
    add() {
      var _this = this
      window.setInterval(() => {
        if (_this.seconds === 59) {
          _this.minutes += 1
          _this.seconds = 0
        } else {
          _this.seconds += 1
        }
      }, 1000)
    }
  }
}
</script>
<style lang="scss" scoped>
.preview-content-area {
  height: 960px;
  margin-top: 46px;
  margin-left: 20px;
  margin-right: 20px;
  height: 800px;
  display: block;
  position: relative;
}
.container {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
.left {
  background-color: #ffffff;
  padding: 10px;
  position: relative;
}
.content {
  padding: 20px;
  font-size: 14px;
  line-height: 1.6;
}
.left > p {
  padding-top: 11px;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  white-space: normal;
}

.incontest {
  width: 1.5em;
  height: 1.5em;
}
.time-main {
  margin: 25px 0;
  font-size: 18px;
  color: #333;
  display: inline-block;
  position: absolute;
  right: 30px;
  top: 0;
}
.page {
  margin: 25px 0;
  font-size: 16px;
  color: #333;
}
.row-box {
  margin-bottom: 0px;
  span[data-v-3cafcba0] {
    color: #333;
  }
}
span[data-v-3cafcba0] {
  color: #333;
}
.question-lists {
  padding: 0px 8px 0px 0px;
  border-top: 1px dashed #ddd;
  padding: 20px;
  font-size: 16px;
  background: #fff;
  ul {
    margin-top: 15px;
  }
  .el-button {
    font-size: 16px;
    color: black;
  }
}
.question-lists li {
  font-size: 12px;
  display: block;
  padding: 4px 0;
  border: 1px solid #bbb;
  border-radius: 2px;
  float: left;
  margin-right: 8px;
  margin-bottom: 9px;
  min-width: 25px;
  color: #666;
  cursor: pointer;
  text-align: center;
}
.question-lists ul {
  padding: 0;
  overflow: hidden;
}
.questions-lists li.selected,
.questions-lists li:hover {
  background-color: #67c23a;
  color: #fff;
  border: 1px solid #67c23a;
}
.metas-footer {
  line-height: 40px;
  background-color: #f6f6f6;
  font-size: 14px;
}
.metas-footer span {
  color: #aaa;
  margin-right: 5px;
}
.doexam-main {
  background-color: #fff;
  padding-top: 10px;
  position: relative;
}
.row-box {
  background-color: #fff;
  margin: 20px 20px 0 20px;
  padding: 10px;
  // animation: currentSelect 2s;
}
.span1 {
  font-size: 16px;
}
// @keyframes currentSelect {
//   from {
//     box-shadow: 0 2px 12px 0 #67c23a;
//   }
//   to {
//     box-shadow: 0;
//   }
// }
.submit-buttons {
  width: 100%;
  background-color: #fff;
  text-align: right;
  display: table;
  .el-button {
    margin-right: 30px;
  }
}
.el-button--medium {
  padding: 10px 65px;
  font-size: 14px;
  border-radius: 4px;
}
.right {
  margin-left: 20px;
  min-height: 575px;
  background-color: #ffffff;
  padding: 10px;
}
.right ul li {
  line-height: 2em;
}
.el-dialog__wrapper {
  z-index: 1200 !important;
}
</style>
<style lang="scss" scoped>
.header {
  padding: 20px;
  border-bottom: 1px solid #eee;
  p {
    font-size: 20px;
    display: inline-block;
    vertical-align: middle;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    word-wrap: normal;
    max-width: 25em;
  }
  .time-left[data-v-21ad4dce] {
    font-size: 34px;
    font-weight: 400;
    font-size: 20px;
    position: absolute;
    right: 0;
    top: 0;
    border-radius: 0 6px 0 0;
    height: 40px;
    width: 250px;
    padding-top: 10px;
    text-align: center;
    color: #333;
    padding-top: 20px;
  }
}
.subject-title-box {
  padding: 15px;
  .answer-progress {
    background: #e5e5e5;
    padding: 0 5px;
    border-radius: 5px;
    font-size: 16px;
  }
  // span,
  // .icon {
  //   margin-right: 10px;
  // }
}
.answer-list {
  font-size: 14px;
  line-height: 1.6;
  margin-bottom: 20px;
}
.el-radio-group {
  width: 100%;
  .el-radio {
    width: 100%;
    margin-left: 10px;
  }
}
.subject-new-tips {
  clear: both;
  margin-top: 10px;
  color: #888;
  font-size: 14px;
  text-align: right;
  margin-right: 30px;
}
.el-checkbox {
  margin-right: 30px;
  margin-left: 10px;
}
</style>
