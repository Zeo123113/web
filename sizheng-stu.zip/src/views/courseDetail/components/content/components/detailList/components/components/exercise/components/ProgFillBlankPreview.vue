<!--
@description 题库管理--程序填空题效果预览窗口
@author LHZ
-->
<template>
  <div>
    <div v-html="content"></div>
    <tinymce
      v-model="code"
      plugins="codesample"
      toolbar="false"
      menubar="false"
      inline="true"
      :height="400"
    />
    <div v-for="item in options" :key="item">
      <el-row>
        <el-col :span="1" style="margin-top:20px;">{{ item }}.</el-col>
        <el-col :span="15">
          <el-input style="margin-top:10px;"></el-input>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import Tinymce from '@/components/Tinymce'
export default {
  name: 'ProgFillBlankPreviewDialog',
  components: { Tinymce },
  props: {
    question: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      content: [],
      code: '',
      options: [],
      answer: [],
      init: {
        language_url: 'tinymce/langs/zh_CN.js',
        language: 'zh_CN',
        skin_url: 'tinymce/skins/ui/oxide',
        max_height: 650,
        min_height: 400,
        plugins: 'codesample',
        toolbar: false,
        inline: true,
        menubar: false
      }
    }
  },
  // updated() {
  //   this.openDialog()
  // },
  mounted() {
    this.openDialog()
  },
  methods: {
    openDialog() {
      // 题目内容处理
      let dom = this.collectionToArray(this.parseDom(this.question.content))
      for (let i = 0; i < dom.length; i++) {
        if (dom[i].nodeName === '#text' || (dom[i].nodeName === 'P' && dom[i].innerText.trim() === '')) {
          dom.splice(i, 1)
          i--
        }
      }
      let str = ''
      for (let i = 0; i < dom.length; i++) {
        str += dom[i].innerHTML + '<br/>'
      }
      this.content = '<p>' + str + '</p>'
      // 程序体处理
      dom = this.collectionToArray(this.parseDom(this.question.code))

      this.code = []
      this.options = []
      let k = 1
      for (let i = 0; i < dom.length; i++) {
        if (dom[i].nodeName === '#text') {
          this.code[i] = dom[i].nodeValue
          continue
        }
        this.code[i] = dom[i].outerHTML

        let index = this.code[i].indexOf('&lt;blank&gt;', 0)
        while (index >= 0) {
          const str = ' ( ' + k + ' ) '
          k++
          this.code[i] = this.code[i].replace('&lt;blank&gt;', str)
          index = this.code[i].indexOf('&lt;blank&gt;', index + 7)
        }
      }
      str = ''
      for (let i = 0; i < this.code.length; i++) {
        str += this.code[i]
      }
      this.code = str
      // 保存填空数，用于绘制答案文本框
      for (let i = 0; i < k - 1; i++) {
        this.options[i] = i + 1
      }
    },
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    }
  }
}
</script>
<style lang="scss" scoped>
.el-dialog__wrapper {
  z-index: 1200 !important;
}
</style>
