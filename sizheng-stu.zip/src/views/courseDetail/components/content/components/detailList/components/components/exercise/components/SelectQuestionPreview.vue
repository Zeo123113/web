<!--
@description 试卷--选择试题效果预览窗口
@author CPY
-->
<template>
  <div>
    <div v-html="question.content"></div>
    <el-radio-group
      v-if="question.tqTypeId.toString()===SINGLE || question.tqTypeId.toString()===JUDGEMENT"
      v-model="question.answer"
    >
      <el-radio
        v-for="item in question.options"
        :key="item.value"
        style="margin-top:10px;display:block;"
      >
        <span v-html="item.label"></span>
      </el-radio>
    </el-radio-group>
    <el-checkbox-group v-if="question.tqTypeId.toString()===MULTIPLE" v-model="question.options">
      <el-checkbox
        v-for="item in question.options"
        :key="item.value"
        style="margin-top:10px;display:block;"
      >
        <span v-html="item.label"></span>
      </el-checkbox>
    </el-checkbox-group>
    <div v-if="question.tqTypeId.toString()===FILLBLANK">
      <div v-for="item in question.options" :key="item">
        <el-row>
          <el-col :span="1" style="margin-top:20px;">{{ item }}.</el-col>
          <el-col :span="15">
            <el-input v-model="question.answer" style="margin-top:10px;"></el-input>
          </el-col>
        </el-row>
      </div>
    </div>
    <div v-if="question.tqTypeId.toString()===ESSAY_QUESTION">
      <tinymce ref="content" v-model="question.answer" :save-flag="saveFlag" :height="250" />
    </div>
  </div>
</template>
<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
import Tinymce from '@/components/Tinymce'
export default {
  name: 'SelectQuestionPreviewDialog',
  components: {
    Tinymce
  },
  props: {
    question: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 试题类型常量定义
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      ESSAY_QUESTION: EXAMBANK_CONST.ESSAY_QUESTION
    }
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
</style>
