<!--
@description 试卷管理预览头部
@author CPY
-->
<template>
  <el-row class="container">
    <el-col :span="24">
      <section v-loading="loading">
        <PCPreview ref="pcpreview" :questionlist="questionlist" :exercise="exercise"></PCPreview>
      </section>
    </el-col>
  </el-row>
</template>
<script>
import PCPreview from './components/PCPreview'
import exerciseAnswerApi from '@/api/exambank/exercise-answer'
import exerciseApi from '@/api/course/courseTask/cExercise'
export default {
  components: {
    PCPreview
  },
  data() {
    return {
      questionlist: [],
      exercise: {
        exerId: null
      },
      exerId: null,
      loading: false
    }
  },
  mounted() {
    this.etId = this.$route.params.etId
    this.exerId = this.$route.params.exerId
    this.getList()
  },
  methods: {
    getList() {
      this.loading = true
      exerciseApi.getById(this.etId).then(resp => {
        this.exercise = resp.data
      })
      exerciseAnswerApi.selectAnswerByErId(this.exerId).then(resp => {
        this.questionlist = resp.data
        this.$refs.pcpreview.openDialog(this.questionlist)
        this.loading = false
      })
    }
  }
}
</script>
<style scoped>
.container {
  margin-top: 0px;
  min-height: 600px;
  background-color: #f3f4f8;
}
</style>
