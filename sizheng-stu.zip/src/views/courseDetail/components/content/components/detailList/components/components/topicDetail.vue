
<template>
  <div style="background:#fff">
    <Header />
    <Nav />
    <div>
      <div class="mt15 w850 all">
        <div>
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item><a href="/">活动管理</a></el-breadcrumb-item>
            <el-breadcrumb-item>活动列表</el-breadcrumb-item>
            <el-breadcrumb-item>活动详情</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div><img :src="topic.avatar" class="mt20 img2">
          <div class="name">{{ topic.realName }}</div>
        </div>
        <!-- 话题标题展示 -->
        <div class="qt-tit">
          {{ topic.topicTitle }}
        </div>
        <!-- 话题内容展示 -->
        <div class="xcontent  mt7" v-html="topic.topicContent">
          {{ topic.topicContent }}
        </div>
        <div class="mt40 ml124 bottom-border">
          <span class="mf mr30 static-color">{{ topic.createTime }}</span>
          <span class="static-color">源自:社会科学</span>
          <span class="r static-color">{{ topic.readCount }} 阅读</span>
          <span class="r mr30  static-color">{{ topic.replyCount }} 回复</span>
        </div>

        <!-- 话题回复列表 -->
        <div v-for="(topicReply,index) of replyList" :key="index" class="topic-reply">
          <div class="ml30">
            <img :src="topicReply.avatar" class="mt20 img2">
            <span class="topic-reply-name">{{ topicReply.realName }}</span>
          </div>
          <div class="reply-content">
            <p v-html="topicReply.replyContent">{{ topicReply.replyContent }}</p>
          </div>

          <!-- 回复点赞举报操作 -->
          <div class="mt40 reply-like">
            <span class="ml30 static-color">{{ topicReply.createTime }}</span>
            <span class="r  static-color click" @click="replyLike(topicReply)">
              <svg class="icon" style="font-size:12px" aria-hidden="true">
                <use xlink:href="#icon-dianzan" />
              </svg>{{ topicReply.likeCount }}</span>
            <span class="r mr30 static-color click" @click="reply(index)"><i class="el-icon-chat-dot-square" style="font-size:12px"></i> 回复</span>
            <span class="r mr30 static-color click">举报</span>
          </div>
          <!-- 回复话题回复 -->
          <div v-show="index===btnReply" class="reply">
            <img :src="user.avatar" class="mt20 img2">
            <textarea class="textarea" placeholder="写下你的回复..."></textarea>
            <div class="mt10 mb20">
              <el-button type="danger" size="small" class="r">提交</el-button>
              <el-button size="small" class="r mr10" @click="btnReply=''">取消</el-button>
            </div>
          </div>
        </div>
        <!-- 发表回复 -->
        <div class="report ml40">
          <el-avatar :size="36" :src="user.avatar" class="mt20"></el-avatar>
          <tinymce v-model="replyContent" :save-flag="saveFlag" :height="300" class="tinymce" />
          <el-button type="danger" class="r mt10 w115 " @click="report()">发表</el-button>
        </div>
      </div>
      <div></div>
    </div>
    <Footer />
  </div>
</template>
<script>
import userApi from '@/api/user/user'
import { mapGetters } from 'vuex'
import topicApi from '@/api/course/courseTask/topic'
import topicReplyApi from '@/api/course/courseTask/topicReply'
import Tinymce from '@/components/Tinymce'
import Header from '@/components/header'
import Nav from '@/components/nav'
import Footer from '@/components/footer'
export default {
  name: 'CourseDetail',
  components: {
    Header,
    Nav,
    Tinymce,
    Footer
  },
  data() {
    return {
      saveFlag: false,
      replyList: [],
      replyData: {
      },
      topic: {},
      replyContent: '',
      btnReply: ''
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  mounted() {
    var Id = this.$route.params.id
    this.getTopicById(Id)
    this.getReplayListBytTopicId(Id)
  },
  methods: {
    reply(index) {
      this.btnReply = index
    },
    /** 初始化话题回复任务对象 */
    inittopicReply() {
      this.replyData = {
        replyId: null,
        csId: this.topic.csId,
        ctId: this.topic.ctId,
        schemeId: this.topic.schemeId,
        mgId: null,
        cqId: this.$route.params.id,
        replyContent: this.replyContent,
        userId: this.user.userId,
        stuId: this.user.stuId,
        realName: this.user.realName,
        status: '0',
        likeCount: '0',
        studyScore: '0',
        createOrgId: null,
        orgId: this.user.orgId
      }
    },
    getTopicById(Id) {
      topicApi.getById(Id).then(response => {
        this.topic = response.data
        this.getAvator(this.topic)
        console.log(this.topic)
      })
    },
    getReplayListBytTopicId(Id) {
      topicReplyApi.getReplayListBytTopicId(Id).then(response => {
        this.replyList = response.data
        console.log(this.replyList)
      })
    },
    getAvator(item) {
      userApi.getAvatarByUserId(item.topicUserId).then(response => {
        this.$set(item, 'avatar', response.data.avatar)
      })
    },
    // 点赞
    replyLike(topicReply) {
      topicReplyApi.replyLike(topicReply.replyId).then(response => {
        if (response.code === 0) {
          this.$message({
            type: 'success',
            message: '点赞成功'
          })
          topicReply.likeCount = topicReply.likeCount + 1
        } else {
          this.$message({
            type: 'error',
            message: '点赞失败'
          })
        }
      })
    },
    // 回复
    report() {
      this.inittopicReply()
      topicReplyApi.addEntry(this.replyData).then(response => {
        if (response.code === 0) {
          this.$message({
            type: 'success',
            message: '回复成功，审核通过后才显示'
          })
          this.replyContent = ''
        } else {
          this.$message({
            type: 'error',
            message: '回复失败'
          })
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.all{
    margin-left:150px;
    margin-bottom:200px;
}
.courseDetail {
  width: 100%;
}
.name{
    font:14px/1.5 "PingFang SC","微软雅黑","Microsoft YaHei",Helvetica,"Helvetica Neue",Tahoma,Arial,sans-serif;
    margin-top: -30px;
    margin-left:50px
}
    .qt-tit{
    font-size: 16px;
    font-weight: 700;
    word-break: break-all;
    word-wrap: break-word;
    color: #07111b;
    line-height: 24px;
    margin-top:20px;
    margin-left:48px;
}
.xcontent{
      padding-left: 20px;
    color: #545c63;
    font-size: 12px;
    line-height: 20px;
    word-wrap: break-word;
    word-break: break-all;
    overflow: hidden;
    margin-top:10px;
    margin-left:29px;
    font:14px/1.5 "PingFang SC","微软雅黑","Microsoft YaHei",Helvetica,"Helvetica Neue",Tahoma,Arial,sans-serif;
}
.r{
  float:right
}
.static-color{
  color:#93999f;
}
.mf{
  margin-left:48px;
}
.topic-reply
{
    position: relative;
    min-height: 80px;
    border-bottom: 1px solid #edf1f2;
    padding-bottom:30px
}
.bottom-border{
    border-bottom: 1px solid #edf1f2;
    padding-bottom:20px;
}
.topic-reply-name{
    display: block;
    line-height: 1.2em;
    height: 18px;
    margin: 3px -18px auto;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width:70px;
    text-align: center;
}
.reply-content
{
    line-height: 1.76em;
    font-size: 14px;
    margin-left:93px;
    margin-top:-55px;
}
.reply-like
{
    margin-left:65px;
}
.reply{
margin-left:111px;
}
.textarea{
padding: 7px;
    resize: none;
    height: 80px;
    line-height: 1.7em;
    width: 93%;
    box-sizing: border-box;
    font-size: 12px;
    margin-left:53px;
    margin-top:-38px;
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(28,31,33,.4);
}
.click{
  cursor: pointer
}
.tinymce{
      margin-left:53px;
    margin-top:-38px;
    width: 93%;
}
</style>
