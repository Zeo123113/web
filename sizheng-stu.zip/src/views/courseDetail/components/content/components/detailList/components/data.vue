<!--
@description 课程资料
@author cgy
-->
<template>
  <div id="data">
    <section v-loading="loading">
      <ol class="db">
        <li v-for="(item,index) of courseMaterialList" :key="index" class="mod-qa-list">
          <!-- 资料展示 -->
          <div class="file-name">
            <a @click="handleDownload(item.url, item.title)">{{ item.title }}</a>
          </div>
          <!-- 资料内容展示 -->
          <span>
            {{ changeFileSize(item.length, 2) }} *
            <a>任务</a>
            * {{ item.createTime }}
          </span>
          <!-- 完成条件 -->
          <span style="display: block;margin-bottom: 0.7rem;">完成条件：{{ item.condition }}</span>
          <!-- 获得积分 -->
          <span style="display: block;margin-bottom: 0.7rem;">积分：{{ item.score }}</span>
        </li>
      </ol>
      <div v-if="!courseMaterialList.length" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>该课程没有上传资料</p>
      </div>
    </section>
    <!--分页-->
    <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
import { downloadByLink } from '@/utils/index'
import COURSE_CONST from '@/constant/course-const'
import prepareStudyTaskApi from '@/api/course/courseTask/prepareStudyTask'
export default {
  name: 'Data',
  data() {
    return {
      // 资料列表
      courseMaterialList: [],
      // 查询对象
      courseMaterial: {},
      // 初始页
      pageIndex: 1,
      total: 1,
      // 默认分页参数
      pageSize: COURSE_CONST.PAGESIZE,
      loading: false,
      schemeId: null
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    // 对文件（字节）大小进行处理
    changeFileSize(a, b) {
      if (a === 0) {
        return '0 Bytes'
      }
      const c = 1024
      const d = b || 2
      const e = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
      const f = Math.floor(Math.log(a) / Math.log(c))
      return parseFloat((a / Math.pow(c, f)).toFixed(d)) + ' ' + e[f]
    },
    getList() {
      // 获取课程详情
      this.schemeId = parseInt(this.$route.params.schemeId)
      this.loading = true
      this.courseMaterial.schemeId = parseInt(this.schemeId)
      prepareStudyTaskApi.getRefMaterialBySchemeId(this.courseMaterial, this.pageIndex, this.pageSize).then(resp => {
        this.courseMaterialList = resp.data.list
        this.loading = false
        this.total = resp.data.total
      })
    },
    handleCurrentChange(val) {
      if (this.isall) {
        this.loading = true
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      } else {
        this.loading = true
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      }
    },
    // 文件下载
    handleDownload(fileUrl, fileName) {
      downloadByLink(process.env.VUE_APP_FILE_SERVER, fileUrl, fileName)
    }
  }
}
</script>
<style lang="scss" scoped>
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
</style>
<style lang="scss" scoped>
.file-name {
  margin-top: 0.8rem;
  // scroll-margin-bottom: 2rem;
  margin-bottom: 0.7rem;
}
.file-name a {
  cursor: pointer;
}
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
  font-size: 16px;
  position: relative;
  margin-bottom: 18px;
  padding: 32px;
  margin: 0 32px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 16px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  margin-top: -42px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
</style>
