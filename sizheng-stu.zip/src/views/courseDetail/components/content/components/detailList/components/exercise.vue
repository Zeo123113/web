<template>
  <div id="topicNav">
    <div class="cf">
      <div class="ov news_dynamic_height">
        <div class="pa30 bgf fr" style="width:100%">
          <div class="plea_box">
            <!--全部-->
            <ol class="db">
              <li class="zo">
                <section v-loading="loading">
                  <el-button type="success" @click="addExercise">
                    <i
                      class="el-icon-plus"
                    ></i>抽题练习
                  </el-button>
                  <!--分页-->
                  <el-row :gutter="20">
                    <el-col v-for="(item, index) in exerciseList" :key="index" :span="12">
                      <div
                        class="exercise-list"
                        :style="{border: showInfo && current == index? '1px solid #989797' : '1px solid #eaeaea',position: 'relative'}"
                        @mouseenter="showInfo = true; current = index"
                        @mouseleave="showInfo = false; current = null"
                      >
                        <div class="exervise-title">{{ item.exerTitle }}
                          <el-button
                            type="text"
                            icon="el-icon-close"
                            @click="deleteExercise(item)"
                          ></el-button>
                        </div>
                        <ol>
                          <li>
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-wanchengshijian-hui" />
                            </svg>
                            完成时间：{{ item.startTime }}
                          </li>
                          <li>
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-defen" />
                            </svg>
                            得分：{{ item.studyScore }}
                          </li>
                          <li>
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-shichang" />
                            </svg>
                            做题时长：{{ item.duration }}
                            <span
                              v-if="showInfo && current == index"
                              style="margin-left: 10px; color: #E70B1C"
                              @click="gotoInfo(item)"
                            >查看详情</span>
                            <span
                              v-if="showInfo && current == index"
                              style="margin-left: 10px; color: #E70B1C"
                              @click="gotoExercise(item)"
                            >再做一次</span>
                          </li>
                        </ol>
                      </div>
                    </el-col>
                  </el-row>
                </section>
              </li>
            </ol>
            <div v-if="!exerciseList.length" class="nodata">
              <p>
                <svg class="icon icon-tishi" aria-hidden="true">
                  <use xlink:href="#icon-tishi" />
                </svg>
              </p>
              <p>你还没有练习记录，快去做些练习题吧！</p>
            </div>
            <AddExerciseDialog :c-exercise="exercise" :dialog-form-visible="dialogFormVisible" @closeAdd="closeAdd" @getList="getList"></AddExerciseDialog>
            <div v-if="exerciseList.length > 0" class="page_box mt30 pt10 mb10 tac">
              <el-pagination
                :current-page="pageIndex"
                :page-size="pageNum"
                layout="prev, pager, next"
                :total="exerciseList.length"
                prev-text="上一页"
                next-text="下一页"
                @current-change="handleCurrentChange"
              ></el-pagination>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import exerciseApi from '@/api/course/courseTask/cExercise'
import USER_CONST from '@/constant/user-const'
import AddExerciseDialog from './components/AddExerciseDialog'
import exerciseRecordApi from '@/api/exambank/exercise-record'
export default {
  name: 'ExerciseNav',
  components: {
    AddExerciseDialog
  },
  data() {
    return {
      exerciseList: [{
        tqSeq: null
      }],
      // 当前页
      pageIndex: 1,
      // 页数限制
      pageNum: USER_CONST.PAGESIZE,
      // 总记录数
      total: 0,
      loading: false,
      // 查询实体
      cExerciseSelect: {
        userId: this.$store.getters.user.userId
      },
      /** 是否鼠标悬浮 */
      showInfo: false,
      // 当前悬浮
      current: null,
      questionList: [],
      exercise: {},
      flag: 0,
      // 添加练习弹窗
      dialogFormVisible: false
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    // 获取列表
    getList() {
      this.loading = true
      // 获取课程详情
      const schemeId = this.$route.params.schemeId
      const csId = this.$route.params.csId
      if (schemeId !== undefined && schemeId != null) {
        this.cExerciseSelect.schemeId = parseInt(schemeId)
      }
      if (csId !== undefined && csId != null) {
        this.cExerciseSelect.csId = parseInt(csId)
      }
      exerciseApi.list(this.cExerciseSelect, this.pageIndex, this.pageNum).then(resp => {
        this.exerciseList = resp.data.list
        this.loading = false
      })
    },
    // 打开详情
    gotoExercise(item) {
      this.$router.push({
        path: `/exercise/${item.etId}/${item.exerId}`
      })
    },
    gotoInfo(item) {
      this.$router.push({
        path: `/exercise-record/${item.etId}/${item.exerId}`
      })
    },
    // 添加新的练习
    addExercise() {
      this.clearExercise()
      const schemeId = this.$route.params.schemeId
      const ctId = this.$route.params.ctId
      const csId = this.$route.params.csId
      this.flag = 0
      if (schemeId !== undefined && schemeId !== null) {
        this.exercise.schemeId = schemeId
        this.flag++
      }
      if (ctId !== undefined && ctId !== null) {
        this.exercise.ctId = ctId
        this.flag++
      }
      if (csId !== undefined && csId !== null) {
        this.exercise.csId = csId
        this.flag++
      }
      if (this.flag < 3) {
        console.log(this.exercise)
        this.$message({
          message: '请先选择课程学期和教学计划后再添加练习',
          type: 'error'
        })
        return
      }
      this.dialogFormVisible = true
    },
    // clear
    clearExercise() {
      this.exercise = {
        etId: null,
        csId: null,
        ctId: null,
        schemeId: null,
        mgId: null,
        unitId: null,
        userId: null,
        stuId: null,
        exerTitle: null,
        orgId: null,
        realName: null,
        startTime: null,
        duration: null,
        exerId: null,
        score: null,
        studyScore: null,
        kidList: null,
        chapterId: null,
        diffLevel: null,
        amount: null
      }
    },
    closeAdd() {
      this.dialogFormVisible = false
    },
    // 单个删除
    deleteExercise(item) {
      console.log(item)
      this.$confirm('此操作将删除该练习记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        exerciseApi.deleteBatch(item.etId).then(resp => {
          if (resp.code === 0) {
            this.getList()
            this.$message({
              type: 'success',
              message: '删除练习任务成功'
            })
          } else {
            this.$message({
              type: 'error',
              message: '删除练习任务失败'
            })
          }
        })
        exerciseRecordApi.delete(item.exerId).then(resp => {
          if (resp.code === 0) {
            this.$message({
              type: 'success',
              message: '删除练习记录成功'
            })
          } else {
            this.$message({
              type: 'error',
              message: '删除练习记录失败'
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    }
  }
}
</script>

<style lang="scss" scoped>
#coursesNav {
  width: 100%;
}
.fl_dib li,
.fl_dib dl {
  font-size: 20px;
}
@media screen and (max-width: 760px) {
  .plea_tab {
    .fr {
      float: left;
    }
  }
}
@media screen and (max-width: 640px) {
  .fl_dib li,
  .fl_dib dl {
    font-size: 10px;
  }
}
.nodata {
  padding: 150px 0;
  text-align: center;
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.exercise-list {
  margin-top: 20px;
  border: 1px solid #eaeaea;
  border-radius: 5px;
  padding: 20px;
  cursor: pointer;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  li {
    height: 25px;
    line-height: 25px;
  }
}
.exervise-title {
  height: 50px;
  overflow: hidden;
  padding: 0 25px;
  text-align: center;
  margin-bottom: 10px;
  font-size: 14px;
  line-height: 1.8;
  .el-button {
    position: absolute;
    right: 15px;
    top: 0px;
  }
}
.icon {
  color: #a7a7a7;
  margin-right: 5px;
}

</style>
<style lang="scss" scoped>
ul {
  li {
    display: block;
    color: #fff;
    font-size: 16px;
    width: 40px;
    text-align: center;
    height: 40px;
    line-height: 40px;
  }
}
.result-question-box {
    padding: 30px;
    border-bottom: 1px solid #ececec;
}
</style>
