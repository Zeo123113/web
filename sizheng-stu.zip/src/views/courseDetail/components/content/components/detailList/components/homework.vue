<!--
  @description 作业任务
  @author cgy
-->
<template>
  <div id="test ">
    <section v-loading="loading">
      <div v-if="total > 0">
        <ul id="nav" class="chapter_sel_item" style="padding:0;">
          <li
            v-for="(courseChapter, index) of homeworkTasks.slice((pageIndex - 1) * pageSize, pageIndex * pageSize)"
            :key="index"
          >
            <div class="firsttitle">{{ chapterTitle(courseChapter) }}</div>
            <ul
              v-for="(item,i) of courseChapter.homeworkTasks"
              :key="i"
              style="padding:0;margin-bottom:20px;"
            >
              <li v-if="item.hwArrange != null" id="navli" class="chapter_sel_item_2">
                <div class="secondtitle" @click="DoMenu('ChildMenu' + index)">
                  <span>{{ item.hwTitle }}</span>
                  <el-button type="danger" plain class="btn fr" @click="toTest(item)">前往作业</el-button>
                </div>
                <ul :id="forId(index)" class="collapsed">
                  <div>
                    <div class="lefttitle">作业简述</div>
                    <div class="rightcontent">
                      <span>{{ item.hwArrange.hwtitle }}</span>
                    </div>
                  </div>
                  <div>
                    <div class="lefttitle">
                      <span>作业要求</span>
                    </div>
                    <div class="rightcontent">{{ item.hwArrange.hwdemand }}</div>
                  </div>
                  <div>
                    <div class="lefttitle">
                      <span>开始时间</span>
                    </div>
                    <div class="rightcontent">{{ item.hwArrange.startTime }}分</div>
                  </div>
                  <div>
                    <div class="lefttitle">
                      <span>终止时间</span>
                    </div>
                    <div class="rightcontent">{{ item.hwArrange.hwEndTime }}分</div>
                  </div>
                  <div>
                    <div v-if="item.hwArrange.isallowdelay">
                      <div class="lefttitle">
                        <span>补交截止时间</span>
                      </div>
                      <div class="rightcontent">{{ item.hwArrange.delaytime }}</div>
                    </div>
                  </div>
                </ul>
              </li>
            </ul>
          </li>
        </ul>
      </div>
      <!--分页-->
      <!-- <div v-if="total > 0">
        <el-pagination
          :current-page="pageIndex"
          :page-size="pageSize"
          layout="prev, pager, next"
          :total="total"
          prev-text="上一页"
          next-text="下一页"
          @current-change="handleCurrentChange"
        ></el-pagination>
      </div>-->
      <div v-if="total === 0" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>老师还没有发布作业，请耐心等待</p>
      </div>
    </section>
  </div>
</template>

<script>
import homeworkApi from '@/api/course/courseTask/homeworkTask'
import COURSE_CONST from '@/constant/course-const'
import homeworkRecordApi from '@/api/exambank/homework-record'
export default {
  name: 'Test',
  data() {
    return {
      pageSize: COURSE_CONST.PAGESIZE,
      pageIndex: 1,
      total: 0,
      loading: false,
      evaluationMethodOptions: [],
      homeworkTasks: [],
      LastLeftID: '',
      courseChapterType: [],
      // 进入作业
      homeworkRecord: {
        hwId: null
      }
    }
  },
  mounted() {
    // 作业评价方法字典获取
    this.getDataByType('course_ht_evaluation_method').then(response => {
      this.evaluationMethodOptions = response.data
    })
    // 课程章节类型数据字典获取
    this.getDataByType('course_chapter_type').then(response => {
      this.courseChapterType = response.data
    })
    this.getlist()
    // this.GetMenuID() //* 这两个function的顺序要注意一下，不然在Firefox里GetMenuID()不起效果
    // this.menuFix()
  },
  methods: {
    /** 作业评价方法字典翻译 */
    evaluationMethodFormat(row) {
      return this.selectDictLabel(this.evaluationMethodOptions, row.evaluationMethod)
    },
    // 前往作业按钮
    toTest(current) {
      console.log(current)
      // 未到作业时间
      var nowTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
      if (nowTime <= current.hwArrange.startTime) {
        this.$message({
          type: 'error',
          message: '还没到作业开始时间，请耐心等待！'
        })
        return
      }
      // 时间已过(并且不可以补交)或时间已过，补交时间也已经过了
      if ((nowTime > current.hwArrange.hwEndTime && !current.hwArrange.isallowdelay) || (current.hwArrange.isallowdelay && current.hwArrange.delaytime < current)) {
        this.$message({
          type: 'error',
          message: '作业时间已结束！'
        })
        return
      }
      // 时间正确

      if (!current.hwArrange.stuUserId) {
        this.homeworkRecord.hwId = current.hwArrange.hwId
        homeworkRecordApi.addHomeworkRecord(this.homeworkRecord).then(resp => {
          console.log(resp.data)
          this.$router.push({
            path: '/homeworkInfo/' + current.hwId
          })
        })
      } else {
        this.$router.push({
          path: '/homeworkInfo/' + current.hwId
        })
      }
    },
    /**
     * 获取当前时间
     */
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    },
    forId: function(index) {
      return 'ChildMenu' + index
    },
    menuFix() {
      var obj = document.getElementById('navli')
      for (var i = 0; i < obj.length; i++) {
        obj[i].onmouseover = function() {
          this.className += (this.className.length > 0 ? ' ' : '') + 'sfhover'
        }
        obj[i].onMouseDown = function() {
          this.className += (this.className.length > 0 ? ' ' : '') + 'sfhover'
        }
        obj[i].onMouseUp = function() {
          this.className += (this.className.length > 0 ? ' ' : '') + 'sfhover'
        }
        obj[i].onmouseout = function() {
          this.className = this.className.replace(new RegExp('( ?|^)sfhover//b'), '')
        }
      }
    },
    DoMenu(emid) {
      var obj = document.getElementById(emid)
      obj.className = (obj.className.toLowerCase() === 'expanded' ? 'collapsed' : 'expanded')
      if ((this.LastLeftID !== '') && (emid !== this.LastLeftID)) { // 关闭上一个Menu
        document.getElementById(this.LastLeftID).className = 'collapsed'
      }
      this.LastLeftID = emid
    },
    GetMenuID() {
      var MenuID = ''
      var _paramStr = 'window.location.href'
      var _sharpPos = _paramStr.indexOf('#')

      if (_sharpPos >= 0 && _sharpPos < _paramStr.length - 1) {
        _paramStr = _paramStr.substring(_sharpPos + 1, _paramStr.length)
      } else {
        _paramStr = ''
      }

      if (_paramStr.length > 0) {
        var _paramArr = _paramStr.split('&')
        if (_paramArr.length > 0) {
          var _paramKeyVal = _paramArr[0].split('=')
          if (_paramKeyVal.length > 0) {
            MenuID = _paramKeyVal[1]
          }
        }
        /*
    if (_paramArr.length>0)
    {
    var _arr = new Array(_paramArr.length);
    }

    //取所有#后面的，菜单只需用到Menu
    //for (var i = 0; i < _paramArr.length; i++)
    {
    var _paramKeyVal = _paramArr[i].split('=');

    if (_paramKeyVal.length>0)
    {
      _arr[_paramKeyVal[0]] = _paramKeyVal[1];
    }
    }
    */
      }
      if (MenuID !== '') {
        this.DoMenu(MenuID)
      }
    },
    getTestType(item) {
      return item.testType === '0' ? '普通考试' : '可重做考试'
    },
    /** 课程章节名称 */
    chapterTitle(row) {
      return '第' + row.chapterSeq + this.typeFormat(row) + ' ' + row.chapterTitle
    },
    /** 字典类型字典翻译 */
    typeFormat(row) {
      return this.selectDictLabel(this.courseChapterType, row.chapterType)
    },
    handleCurrentChange(val) {
      this.getList()
    },
    getlist() {
      const schemeId = this.$route.params.schemeId
      if (schemeId === undefined || schemeId == null) {
        return
      }
      this.loading = true
      homeworkApi.getHomeworkTasksBySchemeId(schemeId, this.pageIndex, this.pageSize).then(resp => {
        this.homeworkTasks = resp.data.list
        this.total = resp.data.total
        this.loading = false
        console.log('this.homeworkTasks = ', this.homeworkTasks)
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.expanded {
  line-height: 32px;
  background: #FAFAFA;
  border-radius: 5px;
  padding: 24px 12px;
  margin: 10px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
</style>
<style lang="scss" scoped>
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
#nav ul.collapsed {
  display: none;
}
.chapter_sel_item,
.chapter_sel_item_2 {
  border: 0;
  display: inline-block;
}
.firsttitle {
  padding-left: 3.5%;
  font-size: 16px;
  color: #888;
  font-weight: 700;
}
.secondtitle {
  width: 100%;
  padding-left: 3.5%;
  font-size: 14px;
  color: #888;
  font-weight: 300;
}
.secondtitle:hover {
  background: #ffd8db;
  color:#e50012;
  border-radius: 5px;
}
.firsttitle:hover {
  background: #ffd8db;
  color: #e50012;
  border-bottom-color: #fff;
  border-radius: 5px;
}
.chapter_sel_item {
  width: 100%;
  height: 55px;
  line-height: 55px;
}
.chapter_sel_item_2 {
  padding-left: 5%;
  height: 55px;
  line-height: 55px;
  font-size: 12px;
  color: #888;
  width: 100%;
}
.chapter_sel_item_2:hover {
  background: #fff;
  border-bottom-color: #fff;
}
.lefttitle {
  margin-left: 10px;
  width: 150px;
  display: inline-block;
}
.rightcontent {
  display: inline-block;
}
.btn {
  // display: inline-block;
  margin-top: 7px;
  margin-right: 10px;
  // padding: 0 18px;
  // height: 35px;
  // line-height: 35px;
  // background: rgb(255, 0, 0);
}
.modal .form {
  position: absolute;
  left: 50%;
  top: 50%;
  /* 实现居中 */
  transform: translate(-50%, -50%);
  background: #fff;
  padding: 16px;
  border-radius: 8px;
}
.modal .form-item {
  display: block;
  text-align: left;
  margin-top: 10px;
}
</style>
