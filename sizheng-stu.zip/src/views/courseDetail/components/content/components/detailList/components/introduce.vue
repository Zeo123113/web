<template>
  <div id="introduce">
    <p style="font-size: 18px" v-html="coursedetail.briefIntroduction">{{ coursedetail.briefIntroduction }}</p>
  </div>
</template>

<script>
export default {
  name: 'Introduce',
  props: {
    coursedetail: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      briefIntroduction: ''
    }
  },
  methods: {
    getBriefIntroduction() {
      // 获取课程详情
      this.briefIntroduction = this.coursedetail.briefIntroduction
    }
  }
}
</script>

<style lang="scss" scoped>
p {
  text-indent: 2em;
}
#introduce {
  position: relative;
  margin-bottom: 30px;
  margin-top: 20px;
}
</style>
