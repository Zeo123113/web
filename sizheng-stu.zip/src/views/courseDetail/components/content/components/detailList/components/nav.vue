<!--
@description 介绍，公告，目录，作业，测验，练习，考试，资料区，评价
@author cgy
-->
<template>
  <div class="nav ov news_dynamic_height pa30 bgf plea_tab">
    <div class="pt10 pb15">
      <div class="plea_menu">
        <ul class="plea_menu_ul fl_dib course_catalogue_tab">
          <li
            v-for="(item,i) in nav"
            :key="i"
            class="p_m_li"
            :class="{ischeck: item.comp == isnav}"
            @click="seleted(item.comp)"
          >{{ item.title }}</li>
        </ul>
      </div>
      <!--plea_menu-->
    </div>
    <!--bb1-->
    <component :is="state" v-if="update" :coursedetail="coursedetail" :course-terms="courseTerms" />
  </div>
</template>
<script>
import Test from './test'
import Exam from './exam'
import Notice from './notice'
import Catalog from './catalog'
// import Topic from './topic'
// import Question from './question'
// import Note from './note'
import Data from './data'
import Assess from './assess'
import Introduce from './introduce'
import Homework from './homework'
import Exercise from './exercise'
export default {
  name: 'Nav',
  components: {
    Catalog,
    // Topic,
    // Question,
    // Note,
    Data,
    Assess,
    Introduce,
    Exercise,
    Test,
    Notice,
    Homework,
    Exam
  },
  props: {
    coursedetail: {
      type: Object,
      required: true
    },
    courseTerms: {
      type: Array,
      required: true
    },
    status: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      nav: [
        { title: '介绍', comp: 'Introduce' },
        { title: '公告', comp: 'Notice' },
        { title: '目录', comp: 'Catalog' },
        { title: '作业', comp: 'Homework' },
        { title: '测验', comp: 'Test' },
        { title: '练习', comp: 'Exercise' },
        { title: '考试', comp: 'Exam' },
        { title: '资料区', comp: 'Data' },
        { title: '评价', comp: 'Assess' }
      ],
      nav1: [
        { title: '介绍', comp: 'Introduce' },
        { title: '公告', comp: 'Notice' },
        { title: '资料区', comp: 'Data' },
        { title: '评价', comp: 'Assess' }
      ],
      update: true,
      isnav: 'Introduce',
      state: 'Introduce'
    }
  },
  created() {
    console.log('this.state === ', this.state)
    if (this.status !== undefined && this.status !== null && this.status !== '' && this.status !== '进入学习') {
      this.nav = [
        { title: '介绍', comp: 'Introduce' },
        { title: '公告', comp: 'Notice' },
        { title: '资料区', comp: 'Data' },
        { title: '评价', comp: 'Assess' }
      ]
    } else {
      this.nav = [
        { title: '介绍', comp: 'Introduce' },
        { title: '公告', comp: 'Notice' },
        { title: '目录', comp: 'Catalog' },
        { title: '作业', comp: 'Homework' },
        { title: '测验', comp: 'Test' },
        { title: '练习', comp: 'Exercise' },
        { title: '考试', comp: 'Exam' },
        { title: '资料区', comp: 'Data' },
        { title: '评价', comp: 'Assess' }
      ]
    }
  },
  methods: {
    seleted: function(comp) {
      console.log('comp = ', comp)
      // 移除组件
      this.update = false
      this.state = comp
      this.isnav = comp
      this.update = true
    }
  }
}
</script>
<style lang="scss" scoped>
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
@media screen and (max-width: 650px) {
  .course_catalogue_tab li {
    font-size: 12px;
  }
  .pt10 {
    padding: 0;
  }
  .pb15 {
    padding: 0;
  }
  .pa30 {
    padding: 0;
  }
}
@media screen and (min-width: 576px) {
  .course_catalogue_tab li {
    font-size: 20px;
  }
}
.course_catalogue_tab {
  display: flex;
}
.course_catalogue_tab li {
  flex: 1;
  width: 100px;
  margin-right: 0;
  padding: 0;
  text-align: center;
}
.ischeck {
  background: red;
  color: white;
}
</style>
