<template>
  <div id="note">
    <div class="comp-filter-bar clearfix">
      <el-button
        type="danger"
        :class="[isall === true ? 'all all-background' : 'all']"
        round
        @click="getList"
      >全部</el-button>
      <el-button
        type="danger"
        :class="[isall === false ? 'all  all-background ' : 'all']"
        round
        @click="getMyList"
      >我的</el-button>
    </div>
    <section v-loading="loading">
      <ol class="db">
        <li v-for="(note,index) in noteList" :key="index" class="mod-qa-list">
          <!-- 展示头像 -->
          <div class="item-left">
            <svg class="icon" style="font-size:24px" aria-hidden="true">
              <use xlink:href="#icon-biji" />
            </svg>
          </div>
          <div class="tit">
            <a href="/u/8543429/courses" target="_blank">{{ note.realName }}</a>
          </div>
          <div class="note-media">
            <a href="/video/19047" class="from l">源自：{{ note.courseTitle }}</a>
          </div>
          <div class="item-content" v-html="note.noteContent">{{ note.noteContent }}</div>
          <div class="item-bottom clearfix">
            <!-- 点赞 -->
            <a href="javascript:;" class="likes js-likes clearfix disabled" @click="giveLike(note)">
              <svg class="icon" style="font-size:24px" aria-hidden="true">
                <use xlink:href="#icon-dianzan" />
              </svg>
              <span class>&nbsp;&nbsp;{{ note.likeCount }}</span>
            </a>
            <!-- 查看全文 -->
            <a
              href="javascript:;"
              class="edit js-edit clearfix"
              @click="lookNote(note.noteContent)"
            >
              <span>查看全文</span>
            </a>
            <!--创建时间-->
            <span class="ctime">{{ note.createTime }}</span>
          </div>
        </li>
      </ol>
      <div v-if="!noteList.length" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>该课程没有笔记</p>
      </div>
    </section>
    <!--分页-->
    <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
    <!-- 笔记详情弹框 -->
    <el-dialog title="笔记详情" :visible.sync="itemContent" width="50%" @close="cancel()">
      <div class="item-content" v-html="noteContent">{{ noteContent }}</div>
      <span slot="footer" class="dialog-footer">
        <el-button class="fz30 all-background fffcolor" round @click="cancel()">关闭</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import courseNoteApi from '@/api/course/courseManage/courseNote'
import COURSE_CONST from '@/constant/course-const'
export default {
  name: 'Note',
  data() {
    return {
      // 笔记数组
      noteList: [],
      // 查询对象
      courseNote: {},
      // 初始页
      pageIndex: 1,
      total: 1,
      // 默认分页参数
      pageSize: COURSE_CONST.PAGESIZE,
      loading: false,
      // 点赞对象
      courseNoteLike: {},
      // 展示详情对象
      itemContent: false,
      // 富文本
      saveFlag: false,
      // 是全部还是我的
      isall: true,
      // 笔记内容
      noteContent: '',
      schemeId: null
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    getList() {
      // 获取课程详情
      this.schemeId = this.$route.params.schemeId
      this.loading = true
      this.courseNote.userId = null
      // this.courseNote.csId = 1
      // this.courseNote.ctId = 1
      this.courseNote.schemeId = parseInt(this.schemeId)
      courseNoteApi.selectCourseNoteByCourse(this.courseNote, this.pageIndex, this.pageSize).then(resp => {
        this.noteList = resp.data.list
        this.loading = false
      })
    },
    getMyList() {
      this.loading = true
      this.courseNote.userId = this.$store.getters.user.userId
      // this.courseNote.csId = 1
      // this.courseNote.ctId = 1
      this.courseNote.schemeId = parseInt(this.schemeId)
      courseNoteApi.selectCourseNoteByCourse(this.courseNote, this.pageIndex, this.pageSize).then(resp => {
        this.noteList = resp.data.list
        this.loading = false
      })
    },
    // 查看笔记
    lookNote(note) {
      this.itemContent = true
      this.saveFlag = true
      this.noteContent = note
    },
    // 关闭查看笔记
    cancel() {
      this.itemContent = false
    },
    // 点赞笔记
    giveLike(note) {
      this.courseNoteLike.noteId = note.noteId
      note.likeCount = note.likeCount + 1
      this.courseNoteLike.likeCount = note.likeCount
      courseNoteApi.giveLike(this.courseNoteLike).then(result => {
        if (result.code === 0) {
          this.$message({
            type: 'success',
            message: '点赞成功'
          })
        } else {
          this.$message({
            type: 'error',
            message: '点赞成功'
          })
        }
      })
    },
    handleCurrentChange(val) {
      if (this.isall) {
        this.loading = true
        this.params.isElite = 0
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      } else {
        this.loading = true
        this.params.isElite = 1
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
      display: block;
    text-align: left;
    margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
  padding-top: 20px;
  margin: 0 32px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.item-left {
  float: left;
  width: 48px;
  box-sizing: border-box;
  min-height: 24px;
}
.item-content {
  font-size: 16px;
  color: #07111b;
  line-height: 32px;
  padding: 12px 0 12px 0;
}
.item-bottom {
  .likes {
    .icon {
      font-size: 12px !important;
    }
    background-color: #f8fafc;
    border-color: #f8fafc;
  }
  a {
    display: inline-block;
    border-radius: 2px;
    height: 32px;
    margin-left: 8px;
    padding: 0 12px;
    line-height: 32px;
  }
  .ctime {
    float: right;
    margin-left: 24px;
    height: 32px;
    line-height: 32px;
  }
}
.tit a {
  font-size: 14px;
  color: #1c1f21;
  font-weight: 700;
}
.note-media a {
  color: #9199a1;
}
.note-look-tool {
  margin-top: 20px;
  a {
    display: inline-block;
    background-color: #f8fafc;
    border: 1px solid #d9dde1;
    border-radius: 2px;
    height: 32px;
    margin-left: 8px;
    padding: 0 12px;
    line-height: 32px;
  }
  .moco-btn {
    float: right;
    margin-left: 24px;
    height: 32px;
    line-height: 32px;
  }
}
.fffcolor {
  color: #fff;
}
</style>
