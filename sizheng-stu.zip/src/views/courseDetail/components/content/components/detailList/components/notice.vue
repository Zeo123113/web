<template>
  <div v-loading="loading" class="list">
    <section>
      <ol class="db">
        <li v-for="(item,index) of noticeList" :key="index">
          <div class="notice">
            <h2 class="title">{{ item.noticeTitle }}</h2>
            <div class="detail" v-html="item.noticeContent"></div>
            <div class="date">
              <div class="f-fr">{{ item.createTime }}</div>
            </div>
          </div>
        </li>
      </ol>
    </section>
    <div v-if="!noticeList.length" class="nodata">
      <p>
        <svg class="icon icon-tishi" aria-hidden="true">
          <use xlink:href="#icon-tishi" />
        </svg>
      </p>
      <p>公告未发布，请耐心等待</p>
    </div>
  </div>
</template>

<script>
import courseNoticeApi from '@/api/course/courseManage/courseNotice'
export default {
  data() {
    return {
      // 话题讨论列表
      noticeList: [],
      // 查询条件
      params: {
        csId: undefined,
        ctId: undefined,
        schemeId: undefined
      },
      loading: true
    }
  },
  created() {
    // 获取课程详情
    this.params.csId = parseInt(this.$route.params.csId)
    this.params.ctId = parseInt(this.$route.params.ctId)
    this.params.schemeId = parseInt(this.$route.params.schemeId)
    this.getData(this.params)
  },
  methods: {
    getData(params) {
      courseNoticeApi.getCourseNoticeList(params).then(response => {
        this.noticeList = response.data
        this.loading = false
      })
    }

  }
}
</script>

<style lang="scss" scoped>
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.notice {
  padding: 30px 0;
  margin-bottom: 20px;
  border-bottom: 1px solid #eee;
}
h2 {
  font-size: 1.5em;
}
.title {
  margin-bottom: 10px;
}
.detail {
  margin-top: 15px;
}
.date {
  margin-top: 2px;
  margin-right: 15px;
  color: #aaa;
  font-size: 12px;
}
.f-fr {
  float: right;
}
</style>
