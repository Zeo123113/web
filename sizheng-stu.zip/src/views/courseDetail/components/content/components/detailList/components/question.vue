<template>
  <div id="question">
    <div class="comp-filter-bar clearfix">
      <el-button
        type="danger"
        :class="[isall ===true ? 'all all-background' : 'all']"
        round
        @click="getAllTopic()"
      >全部</el-button>
      <el-button
        type="danger"
        :class="[isall ===false ? 'all  all-background ' : 'all']"
        round
        @click="getEliteTopic()"
      >精华</el-button>
      <el-button type="danger" class="publish" round @click="askQuestion()">我要提问</el-button>
    </div>
    <section v-loading="loading">
      <ol class="db">
        <li v-for="(topic,index) of TopicData" :key="index" class="mod-qa-list">
          <!-- 展示头像 -->
          <div>
            <img :src="topic.avatar" class="ml55 img2" />
          </div>
          <!-- 话题标题展示 -->
          <div class="qt-tit ml124 click" @click="topicDetail(topic.cqId)">{{ topic.topicTitle }}</div>
          <!-- 话题内容展示 -->
          <div class="xcontent ml124 mt7">
            <div
              class="content click"
              @click="topicDetail(topic.cqId)"
              v-html="topic.topicContent"
            >{{ topic.topicContent }}</div>
          </div>
          <!-- 阅读数 回复数 及 创建时间 -->
          <div class="mt40 ml124">
            <span
              class="mr static-color click"
              @click="topicDetail(topic.cqId)"
            >{{ topic.replyCount }} 回复</span>
            <span
              class="read static-color click"
              @click="topicDetail(topic.cqId)"
            >{{ topic.readCount }} 阅读</span>
            <span class="r static-color">{{ topic.createTime }}</span>
          </div>
        </li>
      </ol>
      <div v-if="!TopicData.length" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>
          该课程下没有问题
          <a style="cursor: pointer" @click="askQuestion()">去提问</a>
        </p>
      </div>
    </section>
    <!--分页-->
    <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
    <!--分页-->
    <!-- 提问弹框 -->
    <el-dialog title="我要提问" :visible.sync="dialogVisible" width="50%" @close="closeQuestion()">
      <el-form ref="formQuestion" label-width="80px" :rules="rules" :model="formQuestion">
        <el-form-item prop="topicTitle" label="问题标题">
          <el-input v-model="formQuestion.topicTitle"></el-input>
        </el-form-item>
        <el-form-item label="问题内容" prop="topicContent">
          <tinymce
            ref="topicContent"
            v-model="formQuestion.topicContent"
            :save-flag="saveFlag"
            :height="300"
          />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button class="fz30 all-background fffcolor" round @click="submit('formQuestion')">提交</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Tinymce from '@/components/Tinymce'
import topicApi from '@/api/course/courseTask/topic'
export default {
  name: 'Question',
  components: {
    Tinymce
  },
  data() {
    return {
      pageSize: 6,
      pageIndex: 1,
      total: 1,
      // 是全部还是精华
      isall: true,
      // 话题讨论列表
      TopicData: [],
      // 查询条件
      params: {
        schemeId: null,
        topicType: 1,
        isElite: 0
      },
      loading: true,
      // 提问弹框
      dialogVisible: false,
      // 问题对象
      question: {

      },
      formQuestion: {
        topicTitle: '',
        topicContent: ''
      },
      saveFlag: false,
      rules: {
        topicTitle: [{ required: true, message: '请输入问题标题', trigger: 'blur' }],
        topicContent: [{ required: true, message: '请填写问题内容', trigger: 'blur' }]
      },
      schemeId: null
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {
    // 获取课程详情
    this.schemeId = this.$route.params.schemeId
    this.getAllTopic()
  },
  methods: {
    initquestion() {
      this.question = {
        cqId: null,
        csId: 1,
        ctId: 1,
        schemeId: 1,
        unitId: 1,
        topicType: 1,
        topicTitle: this.formQuestion.topicTitle,
        topicContent: this.formQuestion.topicContent,
        topicUserId: this.user.userId,
        realName: this.user.realName,
        readCount: 0,
        replyCount: 0,
        hitCount: 0,
        isStick: false,
        isElite: false,
        status: 0,
        studyScore: 0,
        orgId: this.user.orgId
      }
    },
    getAllTopic() {
      this.isall = true
      this.loading = true
      this.params.isElite = 0
      this.params.schemeId = parseInt(this.schemeId)
      this.getList(this.params, this.pageIndex, this.pageSize)
    },
    getEliteTopic() {
      this.isall = false
      this.loading = true
      this.params.isElite = 1
      this.params.schemeId = parseInt(this.schemeId)
      this.getList(this.params, this.pageIndex, this.pageSize)
    },
    handleCurrentChange(val) {
      if (this.isall) {
        this.loading = true
        this.params.isElite = 0
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      } else {
        this.loading = true
        this.params.isElite = 1
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      }
    },
    getList(params, pageIndex, pageSize) {
      topicApi.getTopicBySchemeId(params, pageIndex, pageSize).then(response => {
        this.TopicData = response.data.list
        this.total = response.data.total
        this.loading = false
        console.log(this.TopicData)
      })
    },
    askQuestion() {
      this.dialogVisible = true
    },
    submit(formName) {
      this.initquestion()
      this.$refs[formName].validate((valid) => {
        if (valid) {
          topicApi.addEntry(this.question).then(response => {
            if (response.code === 0) {
              this.$message({
                type: 'success',
                message: '提问成功，审核通过后显示'
              })
              this.dialogVisible = false
            } else {
              this.$message({
                type: 'error',
                message: '提问失败'
              })
              this.dialogVisible = false
            }
          })
        }
      })
    },
    topicDetail(id) {
      this.$router.push({  // 核心语句
        path: `/topicDetail/${id}`   // 跳转的路径
      })
    },
    closeQuestion() {
      this.$refs['formQuestion'].clearValidate()
      this.formQuestion.topicTitle = ''
      this.formQuestion.topicContent = ''
    }
  }
}
</script>

<style lang="scss" scoped>
.publish {
  position: absolute;
  right: 0;
  font-size: 16px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
  background: #e50012;
}
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
 position: relative;
  padding: 32px;
  margin: 0 32px;
  margin-bottom: 18px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 16px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  margin-top: -42px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.fffcolor {
  color: #fff;
}
.click {
  cursor: pointer;
}
</style>
