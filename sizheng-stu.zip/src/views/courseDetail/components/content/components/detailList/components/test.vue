<template>
  <section id="exam" v-loading="loading">
    <!-- 全部考试 -->
    <ol class="db">
      <li v-for="(test,index) of testTaskList.slice((pageNum-1)*pageSize, pageNum*pageSize)" :key="index" class="zo">
        <div class="">
          <div class="mt20 my_exam_area">
            <!-- 右边部分 -->
            <div class="cf">
              <div class="fr w137 tac">
                <p class="fz20 fwb cor_ff8">{{ courseExamStatusFormat(test) }}</p>
                <!--右侧按钮（未开始）-->
                <div v-if="test.examStatus === NOTSTART">
                  <div class="mt40">
                    <span v-if="test.time.day!==0" class="exam_btn_sty">{{ test.time.day }}天</span>
                  </div>
                  <p v-if="test.time.day!==0" class="mt10 cor_2">距离考试开始还有</p>
                </div>
                <div v-if="test.examStatus === TESTING && test.examLog.examStatus === INTEST">
                  <div class="mt40">
                    <span v-if="test.time.day === 0" class="exam_btn_sty click" @click="startExam(test)">开始考试</span>
                  </div>
                </div>
                <div v-if="test.examLog.examStatus">
                  <div class="mt40 click">
                    <span v-if="test.examLog.examStatus === TESTED && test.examStatus !== PUBLISHED" class="exam_scores_btn">已完成 </span>
                    <span v-if="test.examLog.examStatus === LACKTEST && test.examStatus === PUBLISHED " class="exam_scores_btn">缺考 </span>
                    <span v-if="test.examLog.examStatus === CHEATING && test.examStatus === PUBLISHED " class="exam_scores_btn">作弊 </span>
                    <span v-if="test.examLog.examStatus === DELAYED && test.examStatus === PUBLISHED " class="exam_scores_btn">缓考 </span>
                  </div>
                  <div v-if="test.examStatus === PUBLISHED && test.examLog.examStatus === TESTED" class="mt40 click" @click="viewPaperDetail(test)"><span class="exam_scores_btn">{{ test.examLog.score }}分</span></div>
                </div>
              </div>
              <!-- 右边部分 -->
              <!-- 整块 -->
              <div class="ov">
                <p class>
                  <i class="ico_examination_subjects"></i>
                  <span class="ml20 fz22">{{ test.examTitle }}</span>
                </p>
                <div class="mt15 cf">
                  <div class="fl w270">
                    <p class="fz15 lh30">
                      <span class="cor_bdb">开始时间</span>
                      <span class="ml25">{{ test.examStartTime }}</span>
                    </p>
                    <p class="fz15 lh30">
                      <span class="cor_bdb">发布老师</span>
                      <span class="ml25">{{ test.createBy }}</span>
                    </p>
                  </div>
                  <div class="ov">
                    <p class="fz15 lh30">
                      <span class="cor_bdb">考试时长(分钟)</span>
                      <span class="ml25">{{ test.limitTime }}</span>
                    </p>
                  </div>
                </div>
              </div>
              <!-- 整块 -->
            </div>
          </div>
        </div>
      </li>
    </ol>
    <!--分页-->
    <div v-if="total!==0" class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageNum"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
    <!--分页-->
    <div v-if="testTaskList.length === 0" class="nodata">
      <p>
        <svg class="icon icon-tishi" aria-hidden="true">
          <use xlink:href="#icon-tishi" />
        </svg>
      </p>
      <p>考试未发布，请耐心等待</p>
    </div>
  </section>
</template>

<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
import testTaskApi from '@/api/course/courseTask/testTask.js'
import COURSE_CONST from '@/constant/course-const'
import examLogApi from '@/api/exambank/exam-record'
export default {
  name: 'Exam',
  data() {
    return {
      testTaskList: [],
      loading: false,
      pageNum: 1, // 初始页
      pageSize: 4, // 每页的数据
      total: 0,
      courseExamStatusTypeDict: [],
      NOTSTART: COURSE_CONST.NOTSTART,
      TESTING: COURSE_CONST.TESTING,
      COMPIETED: COURSE_CONST.COMPIETED,
      REVIEWING: COURSE_CONST.REVIEWING,
      WAITERESULT: COURSE_CONST.WAITERESULT,
      PUBLISHED: COURSE_CONST.PUBLISHED,
      INTEST: EXAMBANK_CONST.INTEST,
      TESTED: EXAMBANK_CONST.TESTED,
      LACKTEST: EXAMBANK_CONST.LACKTEST,
      CHEATING: EXAMBANK_CONST.CHEATING,
      DELAYED: EXAMBANK_CONST.DELAYED
    }
  },
  created() {
    this.getlist()
    // 考试状态数据字典获取
    this.getDataByType('course_exam_status').then(response => {
      this.courseExamStatusTypeDict = response.data
    })
  },
  methods: {
    getlist() {
      var ctId = this.$route.params.ctId
      const csId = this.$route.params.csId
      var schemeId = this.$route.params.schemeId
      if (ctId === undefined || ctId == null) {
        return false
      }
      if (ctId === undefined || ctId == null) {
        return false
      }
      this.loading = true
      var examation = {
        csId: csId,
        ctId: ctId,
        schemeId: schemeId
      }
      testTaskApi.getTestTaskListByUserId(this.$store.getters.user.userId, this.pageNum, this.pageSize, examation).then(resp => {
        console.log(resp)
        if (resp.data.list.length === 0) {
          this.loading = false
          return false
        }
        this.total = resp.data.total
        this.testTaskList = resp.data.list
        this.loading = false
        this.testTaskList.forEach(item => {
          this.$set(item, 'time', this.getDate(item.examStartTime))
          var examLog =  {
            roundId: item.examArrangeId,
            stuUserId: this.$store.getters.user.userId,
            examType: EXAMBANK_CONST.EXAM
          }
          examLogApi.getOneExamLogAndScore(examLog).then((result) => {
            if (result.code === 0) {
              this.$set(item, 'examLog', result.data[0])
            }
          })
        })
      })
      this.loading = false
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    },
    continueExam(test) {
      this.$router.push({  // 核心语句
        path: `/examDetail/${test.roundId}/${EXAMBANK_CONST.EXAM}`   // 跳转的路径
      })
    },
    /**
     * 计算考试开始时间和当前时间相差数
     */
    GetDateDiff(startTime, endTime, diffType) {
      startTime = startTime.replace(/\-/g, '/')
      endTime = endTime.replace(/\-/g, '/')
      diffType = diffType.toLowerCase()
      var sTime = new Date(startTime)    // 开始时间
      var eTime = new Date(endTime)  // 结束时间</font>
      // 作为除数的数字
      var divNum = 1
      switch (diffType) {
        case 'second':
          divNum = 1000
          break
        case 'minute':
          divNum = 1000 * 60
          break
        case 'hour':
          divNum = 1000 * 3600
          break
        case 'day':
          divNum = 1000 * 3600 * 24
          break
        default:
          break
      }
      return parseInt((eTime.getTime() - sTime.getTime()) / parseInt(divNum))
    },
    /**
     * 获取当前时间
     */
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    },
    /** 课程考试状态类型类型字典翻译 */
    courseExamStatusFormat(row) {
      return this.selectDictLabel(this.courseExamStatusTypeDict, row.examStatus)
    },
    getDate(strDate) {
      var st = strDate
      var time = {
        day: '',
        hour: ''
      }
      var a = st.split(' ') // 这个根据你的字符串决定，如果中间为T则改T
      var b = a[0].split('-')
      if (parseInt(b[1]) === new Date().getMonth() + 1) {
        time.day = b[2] - new Date().getDate()
      } else {
        time.day = b[2] - new Date().getDate() + (parseInt(b[1]) - new Date().getMonth() + 1) * 30
      }
      return time
    },
    startExam(test) {
      /**
       * 增加考试记录
       */
      var nowTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
      var remainTime =  this.GetDateDiff(nowTime, test.startTime, 'second')
      if (remainTime > 0 || !test.isBeginExam) {
        console.log(test)
        console.log(test.isBeginExam)
        this.$message({
          message: '考试未开始',
          type: 'warning'
        })
        return false
      }
      this.$router.push({  // 核心语句
        path: `/examDetail/${test.roundId}/${EXAMBANK_CONST.TEST}`   // 跳转的路径
      })
    },
    viewPaperDetail(test) {
      this.$router.push({  // 核心语句
        path: `/stuPaperDetail/${test.examLog.paperId}/${test.roundId}/${test.examLog.examType}`   // 跳转的路径
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  padding: 32px;
  margin: 0 32px;
  margin-bottom: 18px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 16px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  margin-top: -42px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
</style>
