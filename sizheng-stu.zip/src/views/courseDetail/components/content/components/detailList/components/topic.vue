<template>
  <div id="topic">
    <div class="comp-filter-bar clearfix">
      <el-button
        type="danger"
        :class="[isall ===true ? 'all all-background' : 'all']"
        round
        @click="getAllTopic()"
      >全部</el-button>
      <el-button
        type="danger"
        :class="[isall ===false ? 'all  all-background ' : 'all']"
        round
        @click="getEliteTopic()"
      >精华</el-button>
    </div>
    <section v-loading="loading">
      <ol class="db">
        <li v-for="(topic,index) of TopicData" :key="index" class="mod-qa-list">
          <!-- 展示头像 -->
          <div>
            <img :src="topic.avatar" class="img2 ml55" />
          </div>
          <!-- 话题标题展示 -->
          <div class="qt-tit ml124 click" @click="topicDetail(topic.cqId)">{{ topic.topicTitle }}</div>
          <!-- 话题内容展示 -->
          <div class="xcontent ml124 mt7" @click="topicDetail(topic.cqId)">
            <div class="content click" v-html="topic.topicContent">{{ topic.topicContent }}</div>
          </div>
          <!-- 阅读数 回复数 及 创建时间 -->
          <div class="mt40 ml124">
            <span
              class="mr static-color click"
              @click="topicDetail(topic.cqId)"
            >{{ topic.replyCount }} 回复</span>
            <span
              class="read static-color click"
              @click="topicDetail(topic.cqId)"
            >{{ topic.readCount }} 阅读</span>
            <span class="r static-color">{{ topic.createTime }}</span>
          </div>
        </li>
      </ol>
      <div v-if="!TopicData.length" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>该课程下没有讨论</p>
      </div>
    </section>
    <!--分页-->
    <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
    <!--分页-->
  </div>
</template>

<script>
import topicApi from '@/api/course/courseTask/topic'
export default {
  name: 'Topic',
  data() {
    return {
      pageSize: 10,
      pageIndex: 1,
      total: 1,
      // 是全部还是精华
      isall: true,
      // 话题讨论列表
      TopicData: [],
      // 查询条件
      params: {
        schemeId: null,
        topicType: 0,
        isElite: 0
      },
      loading: true,
      schemeId: null
    }
  },
  created() {
    // 获取课程详情
    this.schemeId = this.$route.params.schemeId
    this.getAllTopic()
  },
  methods: {
    getAllTopic() {
      this.isall = true
      this.loading = true
      this.params.isElite = 0
      this.params.schemeId = parseInt(this.schemeId)
      this.getList(this.params, this.pageIndex, this.pageSize)
    },
    getEliteTopic() {
      this.isall = false
      this.loading = true
      this.params.isElite = 1
      this.params.schemeId = parseInt(this.schemeId)
      this.getList(this.params, this.pageIndex, this.pageSize)
    },
    handleCurrentChange(val) {
      if (this.isall) {
        this.loading = true
        this.params.isElite = 0
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      } else {
        this.loading = true
        this.params.isElite = 1
        this.params.schemeId = parseInt(this.schemeId)
        this.getList(this.params, val, this.pageSize)
      }
    },
    getList(params, pageIndex, pageSize) {
      topicApi.getTopicBySchemeId(params, pageIndex, pageSize).then(response => {
        this.TopicData = response.data.list
        this.total = response.data.total
        this.loading = false
        console.log(this.TopicData)
      })
    },
    topicDetail(id) {
      this.$router.push({  // 核心语句
        path: `/topicDetail/${id}`   // 跳转的路径
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  padding: 32px;
  margin: 0 32px;
  margin-bottom: 18px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 16px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  margin-top: -42px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
</style>
