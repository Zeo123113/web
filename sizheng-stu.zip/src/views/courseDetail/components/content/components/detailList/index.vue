<!--
@description 课程详情页的下中部 的左部分（介绍，公告，目录，作业，测验，练习，考试，资料区，评价）
@author cgy
-->
<template>
  <div class="DetailList mt15">
    <!-- 介绍，公告，目录，作业，测验，练习，考试，资料区，评价 -->
    <Nav :coursedetail="coursedetail" :course-terms="courseTerms" :status="status" />
  </div>
</template>
<script>
import Nav from './components/nav'
export default {
  name: 'DetailList',
  components: {
    Nav
  },
  props: {
    coursedetail: {
      type: Object,
      required: true
    },
    courseTerms: {
      type: Array,
      required: true
    },
    status: {
      type: String,
      required: true
    }
  },
  data() {
    return {
    }
  }
}
</script>
<style lang="scss" scoped>
.DetailList {
  width: 100%;
  float: left;
  // height: 1000px;
}
</style>
