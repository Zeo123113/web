<template>
  <div class="DetailTeacher" style="width: 100%; height: 1220px;">
    <div class="mt15 mar_auto">
      <div class="cf">
        <div class="ml15 fr w282 nav_right_height bgf">
          <div class="header_bg_sty hidden-sm hidden-xs">
            <img :src="teacherPhoto" class="header_img" alt />
          </div>
          <div class="pl20 pr20 hidden-sm hidden-xs">
            <p class="mt10 fz22 tac">{{ name }}</p>
            <p class="mt10 pb25 fz15 cor_2 tac bb1">{{ type }}</p>
          </div>
          <!-- xs显示头像 -->
          <div style="height: 100px;" class="visible-xs visible-sm">
            <div class="header_bg_sty">
              <img :src="teacherPhoto" class="header_img" alt />
            </div>
            <div
              class="visible-xs visible-sm tx"
              style="display: inline-block; width: 15%; float: left;"
            >
              <p class="mt10 fz16 tac">{{ name }}</p>
              <p class="mt10 pb25 fz12 cor_2 tac bb1">{{ type }}</p>
            </div>
            <div style="float: right;">
              <a href>
                <p class="mt30 mr10 fz16 tac">查看更多</p>
              </a>
            </div>
          </div>
          <!--pl20 pr20-->
          <!--最新学员-->
          <!-- <div class="mt25">
            <div class="title_area_sty">
              <span class="pr5">最新学员</span>
            </div>
            <ul class="mt30 fl_dib student_list_area">
              <center>
                <li v-for="(item, i) in students" :key="i">
                  <img :src="item.stuPhoto" class="img26" alt />
                  <p class="mt10 ell">{{ item.stuName }}</p>
                </li>
              </center>
            </ul>
          </div> -->
          <!--最新学员-->

          <!--学员动态-->
          <!-- <div class="mt20">
            <div class="title_area_sty">
              <span class="pr5">学员动态</span>
            </div>
            <ul class="mt25 student_dynamic_list">
              <li v-for="(item, i) in students" :key="i" class="active">
                <center>
                  <div style="display: inline-block;">
                    <span>{{ item.stuName }}</span>
                    <span class="mar1">{{ item.stuStatus }}</span>
                    <span>学习</span>
                  </div>
                </center>
              </li>
            </ul>
          </div> -->
          <!--学员动态-->

          <!--热门标签-->
          <!-- <div class="mt40 pb68 w258 mar_auto">
            <div class="title_area_sty">
              <span class="pr5">热门标签</span>
            </div>
            <ul v-for="(item, i) in labels" :key="i" class="mt30 hot_tags_list fl_dib">
              <center>
                <li>
                  <span class="hot_tags_1">{{ item.label1 }}</span>
                </li>
                <li>
                  <span class="hot_tags_2">{{ item.label2 }}</span>
                </li>
                <li>
                  <span class="hot_tags_3">{{ item.label3 }}</span>
                </li>
              </center>
            </ul>
          </div> -->
          <!--热门标签-->
        </div>
      </div>
    </div>
    <!--右侧栏-->
  </div>
</template>
<script>
import teacherPhotourl from '../../../../../../assets/images/ico_famous_teacher_1.png'
import stuPhotourl from '../../../../../../assets/images/ico_famous_teacher_1.png'
export default {
  name: 'DetailTeacher',
  data() {
    return {
      teacherPhoto: teacherPhotourl,
      name: '王晓梅',
      type: '教师',
      students: [
        {
          stuName: '王',
          stuPhoto: stuPhotourl,
          stuStatus: '已完成'
        },
        {
          stuName: '王',
          stuPhoto: stuPhotourl,
          stuStatus: '已完成'
        },
        {
          stuName: '王晓梅',
          stuPhoto: stuPhotourl,
          stuStatus: '已完成'
        },
        {
          stuName: '王晓梅',
          stuPhoto: stuPhotourl,
          stuStatus: '已完成'
        },
        {
          stuName: '王晓梅',
          stuPhoto: stuPhotourl,
          stuStatus: '未完成'
        }
      ],
      labels: [
        {
          label1: '思政',
          label2: 'sizehng',
          label3: 'sizheng'
        },
        {
          label1: '思政',
          label2: 'sizehng',
          label3: 'sizheng'
        }
      ]
    }
  }
}
</script>
<style lang="scss" scoped>
@media screen and (min-width: 576px) {
  .tx {
    padding-top: 2%;
  }
}

@media screen and (max-width: 576px) {
  .fz16 {
    font-size: 8px;
    font-weight: bold;
  }
  .fz12 {
    font-size: 6px;
    font-weight: bold;
  }
  .tx {
    padding-top: 5%;
  }
  // .header_bg_sty .header_img{width: 50px;height: 50px;}
  // .DetailTeacher{padding: 0 8%;}
}
@media screen and (max-width: 992px) {
  .header_bg_sty {
    background: none;
    padding-top: 0;
    display: inline-block;
    width: 100px;
  }
  .DetailTeacher {
    padding: 0 10%;
  }
}

.header_bg_sty {
  background-position: center;
  height: auto;
}
.student_list_area li {
  width: 52px;
}
.w282 {
  width: 100%;
}
.title_area_sty {
  background-position: center;
  background-size: 100%;
  width: 100%;
}
.student_list_area {
  width: 100%;
}
.student_dynamic_list {
  width: 100%;
}
.w258 {
  width: 100%;
}
.hot_tags_list li {
  width: 29%;
}
</style>
