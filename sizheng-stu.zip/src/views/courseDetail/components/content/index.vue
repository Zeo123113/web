<!--
@description 课程详情页的下中部
@author cgy
-->
<template>
  <div>
    <el-container id="courseContent" style="padding:0 8%;">
      <el-main style>
        <!-- 介绍，公告，目录，作业，测验，练习，考试，资料区，评价 -->
        <DetailList :coursedetail="coursedetail" :course-terms="courseTerms" :status="status" />
      </el-main>
      <el-aside class="hidden-sm hidden-xs" width="25%">
        <!-- 教师团队展示（这个还没做） -->
        <DetailTeacher />
      </el-aside>
    </el-container>
  </div>
</template>
<script>
import DetailList from './components/detailList/index'
import DetailTeacher from './components/teacher/DetailTeacher'
export default {
  name: 'CourseContent',
  components: {
    DetailList,
    DetailTeacher
  },
  props: {
    coursedetail: {
      type: Object,
      required: true
    },
    courseTerms: {
      type: Array,
      required: true
    },
    status: {
      type: String,
      required: true
    }
  }
}
</script>
<style lang="scss" scoped>
@media screen and (max-width: 576px) {
  .el-main {
    padding: 0;
  }
}
@media screen and (max-width: 768px) {
  .el-aside {
    display: block;
  }
}
@media screen and (min-width: 992px) {
  .el-main {
    padding-top: 0;
    padding-left: 0;
  }
}
.courseContent {
  display: flex;
}
</style>
