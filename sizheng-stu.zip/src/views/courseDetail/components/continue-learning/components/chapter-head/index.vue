<template>
  <div id="chapterhead">
    <div class="fuc_tab_click">
      <p class="card_title_fz">
        目录章节
        <a href="javascript:void(0);" class="ico_close_sty" @click="hiddenChapter()"></a>
      </p>
      <div>
        <ul style="padding:0;margin:0;" class="chapter_sel_item">
          <li v-for="(item,i) in courseChapter" :key="item.chapterId" style="padding:0;margin:0;">
            <div @click="show2(item.chapterId)">
              <em class="cor_e10" style="margin-left:25px;">●</em>
              <span class="w50">第{{ i+1 }}章</span>
              <span class="ml25 clamp">{{ item.chapterTitle }}</span>
            </div>
            <ul style="padding:0;margin:0;">
              <li
                v-for="(item2,ii) in item.children"
                v-show="item.chapterId===courseChapter2.chapterId"
                :key="item2.chapterId"
                style="padding:0;margin:0;"
              >
                <div class="content" @click="show3(item2.chapterId)">
                  <em class="cor_e10" style="margin-left:25px;">●</em>
                  <span class="w50">{{ i+1 }}.{{ ii+1 }}</span>
                  <span class="ml25 clamp">{{ item2.chapterTitle }}</span>
                </div>
                <ul style="padding:0;margin:0;">
                  <li
                    v-for="(item3,iii) in item2.children"
                    v-show="item2.chapterId===courseChapter2.childrenchapterId"
                    :key="item3.chapterId"
                    style="padding:0;margin:0;"
                  >
                    <div class="content" @click="show4(item3.chapterId)">
                      <em class="cor_e10" style="margin-left:25px;">●</em>
                      <span class="w50">{{ i+1 }}.{{ ii+1 }}.{{ iii+1 }}</span>
                      <span class="ml25 clamp">{{ item3.chapterTitle }}</span>
                    </div>
                    <ul style="padding:0;margin:0;">
                      <li
                        v-for="(item4,iiii) in item3.children"
                        v-show="item3.chapterId===courseChapter2.children2chapterId"
                        :key="item4.chapterTitle"
                        style="padding:0;margin:0;"
                      >
                        <div class="content">
                          <em class="cor_e10" style="margin-left:25px;">●</em>
                          <span class="w50">{{ i+1 }}.{{ ii+1 }}.{{ iii+1 }}.{{ iiii+1 }}</span>
                          <el-tooltip class="item" effect="dark" :content="item4.chapterTitle" placement="top-start">
                            <span class="ml25 clamp title" @click="getPrepareStudyTask(item4)">{{ item4.chapterTitle }}</span>
                          </el-tooltip>
                        </div>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
import courseChapterApi from '@/api/course/courseManage/courseChapter'
export default {
  props: {
    fschemeId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      courseChapter: [],
      courseChapter2: {
        chapterId: null,
        childrenchapterId: null,
        children2chapterId: null
      }
    }
  },
  created() {
    this.getChapter()
  },
  methods: {
    show2(index) {
      if (this.courseChapter2.chapterId === index) {
        this.courseChapter2.chapterId = -1
      } else {
        this.courseChapter2.chapterId = index
      }
    },
    show3(index) {
      if (this.courseChapter2.childrenchapterId === index) {
        this.courseChapter2.childrenchapterId = -1
      } else {
        this.courseChapter2.childrenchapterId = index
      }
    },
    show4(index) {
      if (this.courseChapter2.children2chapterId === index) {
        this.courseChapter2.children2chapterId = -1
      } else {
        this.courseChapter2.children2chapterId = index
      }
    },
    // 根据单元chapter获取预习，学习任务
    getPrepareStudyTask(chapter) {
      console.log('chapter = ', chapter)
      this.$emit('getPrepareStudyTask', chapter)
    },
    getChapter() {
      // 获取章节列表
      courseChapterApi.getFrontlist(parseInt(this.fschemeId)).then(response => {
        this.courseChapter = response.data
      })
    },
    hiddenChapter() {
      this.$emit('model', false)
    }
  }
}
</script>
<style lang="scss" scoped>
.chapter_sel_item,
.chapter_sel_item_2 {
  height: 40px;
  line-height: 40px;
  padding: 0;
  margin: 0px;
}
// .chapter_sel_item_3:hover {
//   background: #fff;
// }
.w50{
  width: 50px;
  display: inline-block;
}
.clamp {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space:nowrap;
}
.df{
  display: flex;
}
.content{
  display: flex;
  position: relative;
}
.titledetail{
  position: absolute;
  // left: 0;
  // top: 20px;
  // width: 100px;
  // height: 100px;
background-color: blanchedalmond;
}
</style>
