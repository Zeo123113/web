<template>
  <!--音乐播放器放置区域-->
  <div class="b3">
    <aplayer ref="aplayer" autoplay :music="music" :list="musicList" />
    <span v-show="false">{{ url }}</span>
  </div>
  <!--播放器放置区域-->
</template>
<script>
import Aplayer from 'vue-aplayer'
export default {
  name: 'Music',
  components: {
    Aplayer
  },
  props: {
    title: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    },
    artist: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      update: true,
      musicList: [],
      music: {}
    }
  },
  watch: {
    url: function(val) {
      console.log('val===', val)
      // this.update = false
      const music = {}
      music.src = val
      music.lrc = '[00:00.00]lrc here\n[00:01.00]aplayer'
      music.pic = 'https://p1.music.126.net/gjvguk9I-QwuyWFjQHM9SA==/109951163189947600.jpg'
      music.artist = this.artist
      music.title = this.title
      // this.update = true
      const audio2 = this.musicList.filter(item => item.src === val)
      this.music = { ...music }
      if (audio2.length === 0) {
        this.musicList.push(music)
      }
      // this.$refs.aplayer.switch(1)
    }
  },
  created() {
    // const music = {}
    this.music.src = this.url
    this.music.title = this.title
    this.music.artist = this.artist
    this.music.lrc = '[00:00.00]lrc here\n[00:01.00]aplayer'
    this.music.pic = 'https://p1.music.126.net/gjvguk9I-QwuyWFjQHM9SA==/109951163189947600.jpg'
    this.musicList.push(this.music)
    // this.$refs.aplayer.play()
  },
  methods: {
    reload() {
      this.$forceUpdate()
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
