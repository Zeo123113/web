<template>
  <div>
    <div v-if="showWriteNote" class="fuc_tab_click">
      <p class="card_title_fz">
        写笔记
        <span style="position:absolute;right:40px;" @click="noteList()">
          <svg class="icon icon-zhangjie" aria-hidden="true">
            <use xlink:href="#icon-zhangjie" />
          </svg>
        </span>
      </p>
      <div class="pa20">
        <!-- 富文本 -->
        <Tinymce ref="content" v-model="note.noteContent" :save-flag="saveFlag" :height="250" />
        <!--提交笔记按钮-->
        <div class="mt40 tac">
          <el-button @click="addNote()">提交</el-button>
        </div>
      </div>
    </div>
    <div v-else class="fuc_tab_click">
      <p class="card_title_fz pl20">
        我的笔记
        <a href="javascript:void(0);" class="ico_close_sty" @click="hiddenChapter()"></a>
      </p>
      <ul class="pl20" style="border-bottom:1px solid #eee;">
        <li v-for="(item,i) in myNoteList" :key="item.noteId">
          <div class="mt20 cf">
            <p class="mr15 fl fz18 fwb">{{ i+1 }}</p>
            <div class="ov">
              <p class="fz16 lh24" style="max-height:200px;" v-html="item.noteContent"></p>
            </div>
          </div>
        </li>
      </ul>
      <center>
        <span title="添加笔记" @click="noteList()">
          <svg class="icon icon-jia" aria-hidden="true">
            <use xlink:href="#icon-jia" />
          </svg>
        </span>
      </center>
    </div>
  </div>
</template>
<script>
import Tinymce from '@/components/Tinymce'
import courseNoteApi from '@/api/course/courseManage/courseNote'
export default {
  components: { Tinymce },
  props: {
    fschemeId: {
      type: Number,
      required: true
    },
    fcsId: {
      type: Number,
      required: true
    },
    fctId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      // 富文本标志
      saveFlag: false,
      note: {},
      queryParams: {
        userId: this.$store.getters.user.userId
      },
      myNoteList: [],
      showWriteNote: true
    }
  },
  created() {
    this.showMyNote()
  },
  methods: {
    noteList() {
      this.showWriteNote = !this.showWriteNote
    },
    hiddenChapter() {
      this.$emit('model', false)
    },
    // 添加笔记
    addNote() {
      console.log(this.note.noteContent)
      if (this.note.noteContent === undefined) {
        alert('请输入内容再提交！')
      } else {
        this.note = {
          noteId: null,
          orgId: 100,
          csId: this.fcsId,
          ctId: this.fctId,
          schemeId: this.fschemeId,
          mgId: 0,
          unitId: 5,
          noteStatus: 0,
          likeCount: 0,
          userId: this.$store.getters.user.userId,
          stuId: 0,
          realName: this.$store.getters.user.realName,
          noteContent: this.note.noteContent
        }
        if (this.note.noteId === null) {
          courseNoteApi.addCourseNote(this.note).then(result => {
            if (result.code === 0) {
              this.note.noteContent = ''
              this.showMyNote()
              this.showWriteNote = !this.showWriteNote
              this.$emit('showNote', 3)
              // this.$message({
              // type: 'success'
              // message: '添加成功'
              // })
            } else {
              // this.$message({
              //   type: 'error',
              //   message: '添加失败'
              // })
            }
            this.$emit('reset')
            // this.dialog.isAddEditDialogVisible = false
          })
        } else {
          courseNoteApi.updateCourseNote(this.note).then(result => {
            if (result.code === 0) {
              this.showMyNote()
              this.$message({
                type: 'success',
                message: '修改成功'
              })
            } else {
              this.$message({
                type: 'error',
                message: '修改失败'
              })
            }
            this.$emit('reset')
            // this.dialog.isAddEditDialogVisible = false
          })
        }
      }
    },
    // 展示我的笔记
    showMyNote() {
      courseNoteApi.getCourseNoteList(this.queryParams).then(response => {
        this.myNoteList = response.data
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.icon-jia {
  width: 3em;
  height: 3em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  color: #111;
}
.icon-jia:hover{
  color: rgb(229,0,18);
}
.clamp_5 {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 5;
  -moz-box-orient: vertical;
  -moz-line-clamp: 5;
  text-overflow: ellipsis;
  display: flex;
  box-orient: vertical;
  line-clamp: 5;
  overflow: hidden;
}
</style>

