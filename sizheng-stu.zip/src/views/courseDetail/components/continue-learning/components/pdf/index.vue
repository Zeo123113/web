<template>
  <div v-loading="loading" class="pdf">
    <!--pdf播放放置区域-->
    <pdf
      ref="pdf"
      :src="src"
      :page="currentPage"
      @num-pages="pageCount=$event"
      @page-loaded="currentPage=$event"
      @loaded="loadPdfHandler"
      @error="error"
    />
    <p class="arrow">
      <span class="turn" :class="{grey: currentPage==1}" @click="changePdfPage(0)">上一页</span>
      {{ currentPage }} / {{ pageCount }}
      <span
        class="turn"
        :class="{ grey: currentPage==pageCount }"
        @click="changePdfPage(1)"
      >下一页</span>
    </p>
  </div>
</template>
<script>
import pdf from 'vue-pdf'
import { mapGetters } from 'vuex'
import studyLogApi from '@/api/course/courseTask/studyLog'
import COURSE_CONST from '@/constant/course-const'
export default {
  name: 'Pdf',
  components: {
    pdf
  },
  props: {
    url: {
      type: String,
      required: true
    },
    chapter: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      courseStudyLog: {},
      loadedRatio: 0,
      // 加载效果
      loading: false,
      // pdf文件页码
      currentPage: 1,
      // pdf文件总页数
      pageCount: 0,
      // 文件类型
      fileType: 'pdf',
      // pdf文件地址
      src: ''
    }
  },
  // 从状态管理器获取按钮权限数组button
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  watch: {
    currentPage: function(val) {
      console.log('currentPage---val===', val)
      if (val === undefined) {
        this.loading = true
        return
      }
      // 当前页
      if (val < 1) {
        // 加载效果
        this.loading = true
      } else {
        this.loading = false
      }
      // 当前页
      this.courseStudyLog.lastPages = val
      // 填入学习页数
      if (this.courseStudyLog.lastPages < val) {
        this.courseStudyLog.pages = this.courseStudyLog.pages  + 1
      }
      if (val > 1) {
        // 修改到学习记录表中
        this.updateCourseStudyLog()
      }
    },
    url: function(val) {
      console.log('pdf---val===', val)
      console.log(this.chapter)
      if (this.chapter.jmaterials.fileId === undefined || this.chapter.jmaterials.fileId === '') {
        this.findStudyLog2()
      // this.initPageUrl()
      } else {
        this.findStudyLog(this.chapter.jmaterials.fileId, this.chapter.pstId)
      // this.initPageUrl()
      }
      // setTimeout(() => {
      //   console.log(this.courseStudyLog)
      //   this.src = pdf.createLoadingTask({ url: val })
      // }, 500)

      console.log('scr=====', this.scr)
    }

  },
  created() {
    if (this.chapter.jmaterials.fileId === undefined || this.chapter.jmaterials.fileId === '') {
      this.findStudyLog2()
      // this.initPageUrl()
    } else {
      this.findStudyLog(this.chapter.jmaterials.fileId, this.chapter.pstId)
      // this.initPageUrl()
    }
  },
  methods: {
    // 添加学习记录
    StudentAddStudyLog() {
      studyLogApi.StudentAddStudyLog(this.courseStudyLog).then((result) => {
        if (result.code === 0) {
          this.courseStudyLog = result.data
        }
      })
    },
    // 初始化url,当前页
    initPageUrl() {
      console.log('this.courseStudyLog = ', this.courseStudyLog)
      const url = '/file-server/' + this.chapter.fileUrl
      this.src = pdf.createLoadingTask({ url: url })
      // 初始化url,当前页
      this.loadPdfHandler()
    },
    // 改变PDF页码,val传过来区分上一页下一页的值,0上一页,1下一页
    changePdfPage(val) {
      // console.log(val)
      if (val === 0 && this.currentPage > 1) {
        this.currentPage--
        console.log('this.currentPage-- ', this.currentPage)
      }
      if (val === 1 && this.currentPage < this.pageCount) {
        this.currentPage++
        console.log('this.currentPage++ ', this.currentPage)
      }
    },
    // pdf加载时
    loadPdfHandler() {
      // 加载的时候先加载第一页
      if (this.courseStudyLog.lastPages !== 0) {
        this.currentPage = this.courseStudyLog.lastPages
      } else {
        this.currentPage  = 1
      }
    },
    error(err) {
      console.log('err = ', err)
    },
    initCourseStudyLog() {
      this.courseStudyLog = {
        studyLogId: null,
        csId: this.chapter.csId,
        ctId: this.chapter.ctId,
        schemeId: this.chapter.schemeId,
        unitId: this.chapter.unitId,
        mgId: null,
        pstId: this.chapter.pstId,
        smType: COURSE_CONST.LECTURE,
        smId: this.chapter.jmaterials.fileId,
        studyMaterial: JSON.stringify(this.chapter.jmaterials),
        studyStartTime: this.format(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        studyEndTime: null,
        duration: 0,
        userId: this.user.userId,
        stuId: this.user.stuId,
        realName: this.user.realName,
        isFinished: false,
        studyScore: 0,
        lastPosition: 0,
        lastPages: 0,
        orgId: this.user.orgId,
        createOrgId: this.user.orgId
      }
    },
    findStudyLog(smId, pstId) {
      var data = {
        userId: this.user.userId,
        smId: smId,
        pstId: pstId
      }
      studyLogApi.getStudyLog(data).then(result => {
        if (result.data.studyLogId !== null) {
          this.courseStudyLog = result.data
          this.courseStudyLog.studyStartTime = this.courseStudyLog.studyEndTime
          this.$router.push({
            params: {
              courseStudyLogId: this.courseStudyLog.studyLogId
            }
          })
          this.initPageUrl()
        } else {
          this.initCourseStudyLog()
          console.log('StudentAddStudyLog======video========')
          studyLogApi.StudentAddStudyLog(this.courseStudyLog).then((result) => {
            if (result.code === 0) {
              this.courseStudyLog = result.data
              this.$router.push({
                params: {
                  courseStudyLogId: this.courseStudyLog.studyLogId
                }
              })
            }
          })
        }
      })
    },
    findStudyLog2() {
      var data = {
        userId: this.user.userId,
        csId: parseInt(this.$route.params.csId),
        ctId: parseInt(this.$route.params.ctId),
        schemeId: parseInt(this.$route.params.schemeId),
        stuId: this.user.stuId,
        realName: this.user.realName
      }
      studyLogApi.getStudyLogBySchemeIdUserId(data).then(result => {
        if (result.data.studyLogId !== null) {
          this.courseStudyLog = result.data
          console.log('this.courseStudyLog = ', this.courseStudyLog)
          this.courseStudyLog.studyStartTime = this.courseStudyLog.studyEndTime
          this.initPageUrl()
        } else {
          this.$message({
            message: '父组件ContinueLearning已经创建过默认的，这里不用创建',
            type: 'error'
          })
        }
      })
    },
    updateCourseStudyLog() {
      const studyMaterial = JSON.parse(this.courseStudyLog.studyMaterial)
      if (studyMaterial.condition === '0' || studyMaterial.condition === '学习到最后') {
        if (this.courseStudyLog.pages >= Math.floor(studyMaterial.length)) {
          this.courseStudyLog.isFinished = true
          this.courseStudyLog.studyScore = this.chapter.jmaterials.score
          studyLogApi.updateStudyLog(this.courseStudyLog)
        } else {
          studyLogApi.updateStudyLog(this.courseStudyLog)
        }
      } else {
        if (this.courseStudyLog.pages >= parseInt(studyMaterial.finshTime)) {
          this.courseStudyLog.isFinished = true
          this.courseStudyLog.studyScore = this.studyMaterial.score
          studyLogApi.updateStudyLog(this.courseStudyLog)
        } else {
          studyLogApi.updateStudyLog(this.courseStudyLog)
        }
      }
    },
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    }
  }
}
</script>
<style lang="scss" scoped>
span {
	// TODO： 触摸小手
	cursor: pointer;
}
.arrow {
	font-size: 16px;
	color: #fff;
  bottom: -150px;
	background: #333;
  width: 100%;
  text-align: center;
  padding: 5px 0;
}
.pdf {
	width: auto;
  max-height: 460px;
	overflow-y: auto;
  // position: absolute;
}
</style>
