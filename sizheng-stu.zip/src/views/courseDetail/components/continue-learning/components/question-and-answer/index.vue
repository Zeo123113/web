<template>
  <div>
    <div>
      <div class="fuc_tab_click">
        <p class="card_title_fz">
          评论
          <a href="javascript:void(0);" class="ico_close_sty" @click="hiddenChapter()"></a>
        </p>
        <div class="pa20">
          <el-input
            v-model="unitComment.topicContent"
            maxlength="300"
            show-word-limit
            type="textarea"
            :autosize="{ minRows: 4, maxRows: 14}"
            placeholder="请留下你想说的话……"
          />
          <div style="margin-top:20px;">
            <span>评分：</span>
            <el-rate v-model="unitComment.rating" style="display: line-block" :colors="colors"></el-rate>
          </div>
          <!-- <tinymce ref="commentContent" v-model="rating.commentContent" :sael-ve-flag="saveFlag" :height="250" /> -->
          <!--提交问题-按钮-->
          <div class="mt40 tac">
            <center>
              <el-button
                type="text"
                href="javascript:void(0);"
                class="btn_5"
                style="display: inline-block;width: 263px;"
                @click="addTopic()"
              >提交评论</el-button>
            </center>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
// import Tinymce from '@/components/Tinymce'
import unitCommentApi from '@/api/course/courseTask/unitComment'
export default {
  // components: {
  //   Tinymce
  // },
  props: {
    fschemeId: {
      type: Number,
      required: true
    },
    fcsId: {
      type: Number,
      required: true
    },
    fctId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      colors: ['#99A9BF', '#F7BA2A', '#FF9900'],
      unitComment: {}
    }
  },
  methods: {
    hiddenChapter() {
      this.$emit('model', false)
    },
    addTopic() {
      this.unitComment = {
        csId: this.fcsId,
        ctId: this.fctId,
        schemeId: this.fschemeId,
        unitId: 100,
        topicType: 1,
        commentContent: this.unitComment.commentContent,
        topicUserId: this.$store.getters.user.userId,
        realName: this.$store.getters.user.realName,
        rating: this.unitComment.rating
      }
      unitCommentApi.addLike(this.unitComment).then(result => {
        if (result.code === 0) {
          this.unitComment.commentContent = ''
          // this.showMyNote()
          this.$message({
            type: 'success',
            message: '评论成功'
          })
        } else {
          this.$message({
            type: 'error',
            message: '评论失败'
          })
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.el-rate {
  display: inline-block;
  height: 20px;
  line-height: 1;
}
</style>
