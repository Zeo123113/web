<!--
@description 课程评价
@author cgy
-->
<template>
  <div id="assess">
    <section v-loading="loading">
      <ul class="db">
        <li v-for="(item,index) of myNoteList" :key="index" class="mod-qa-list">
          <!-- 展示头像 -->
          <div class="avatar">
            <img
              v-if="item.avatar!=='' && item.avatar != null"
              :image="item.avatar"
              class="img2"
              alt
            />
            <img v-else class="img2" src="@/assets/images/avatar.png" />
          </div>
          <!-- 评论内容展示 -->
          <div>
            <div class="qt-tit click" style="font-size:14px;">
              {{ item.realName }}
              <!-- <span style="margin-right: 2rem">{{ item.createTime.slice(0,10) }}</span> -->
            </div>
            <div class="xcontent mt7">
              <div class="content click" v-html="item.topicContent"></div>
            </div>
          </div>
          <!-- 评分展示 -->
        </li>
      </ul>
      <div v-if="!myNoteList.length" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>该课程没有评价</p>
      </div>
    </section>
    <!--分页-->
    <!-- <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div> -->
  </div>
</template>

<script>
// import COURSE_CONST from '@/constant/course-const'
import courseNoteApi from '@/api/course/courseTask/topic'
export default {
  props: {
    fschemeId: {
      type: Number,
      required: true
    },
    fcsId: {
      type: Number,
      required: true
    },
    fctId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      queryParams: {
        csId: this.fcsId,
        ctId: this.fctId,
        schemeId: this.fschemeId,
        topicType: 1
      },
      myNoteList: [],
      // 初始页
      pageIndex: 1,
      total: 1,
      // 默认分页参数
      // pageSize: COURSE_CONST.PAGESIZE,
      loading: false,
      schemeId: null
    }
  },
  created() {
    this.showMyNote()
  },
  methods: {
    // 展示同学笔记
    showMyNote() {
      courseNoteApi.getCourseTopicList(this.queryParams).then(response => {
        this.myNoteList = response.data
      })
    }
    // handleCurrentChange(val) {
    //   if (this.isall) {
    //     this.loading = true
    //     this.params.status = 0
    //     this.params.schemeId = parseInt(this.schemeId)
    //     this.getList(this.params, val, this.pageSize)
    //   } else {
    //     this.loading = true
    //     this.params.status = 1
    //     this.params.schemeId = parseInt(this.schemeId)
    //     this.getList(this.params, val, this.pageSize)
    //   }
    // }
  }
}
</script>

<style lang="scss" scoped>
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
      display: block;
    text-align: left;
    margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  // padding: 0 32px;
  // margin: 0 32px;
  margin-bottom: 18px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
  display: flex;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 16px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  // margin-top: -42px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  // border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  // line-height: 20px;
  // height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
.avatar{
  padding: 10px;
  // width: 10px;
  // height: 10px;
  // background-color: aqua;
}
</style>
