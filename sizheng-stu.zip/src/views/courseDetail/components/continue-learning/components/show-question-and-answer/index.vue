<!--
@description 课程评价
@author cgy
-->
<template>
  <div id="assess">
    <section v-loading="loading">
      <ul class="db">
        <li v-for="(item,index) of myNoteList" :key="index" class="mod-qa-list">
          <!-- 展示头像 -->
          <div class="mod-qa-list1">
            <div class="avatar">
              <img
                v-if="item.avatar!=='' && item.avatar != null"
                :image="item.avatar"
                class="img2"
                alt
              />
              <img v-else class="img2" src="@/assets/images/avatar.png" />
            </div>
            <!-- 评论内容展示 -->
            <div class="nameandcontent">
              <div class="qt-tit click" style="font-size:14px;">
                {{ item.realName }}
              <!-- <span style="margin-right: 2rem">{{ item.createTime.slice(0,10) }}</span> -->
              </div>
              <div class="xcontent mt7">
                <div class="content click" v-html="item.topicContent"></div>
              </div>
            </div>
          </div>
          <div style="display:inline-block;float:right;">
            <div class="replybtn" @click="showReply(item.cqId)">用户回复
            </div>
            <div class="replybtn" @click="showReplyQuestion(item.cqId)">添加回复
              <svg class="icon" aria-hidden="true">
                <use :xlink:href="'#icon-shuji'" />
              </svg>
            </div>
          </div>
          <div v-show="ReplyBox===item.cqId" class="replybox">
            <ul>
              <li v-for="item2 of replyList" :key="item2.replyId" class="">
                <!-- 展示头像 -->
                <div class="mod-qa-list1">
                  <!-- <div class="avatar">
                    <img
                      v-if="item2.avatar!=='' && item2.avatar != null"
                      :image="item2.avatar"
                      class="img2"
                      alt
                    />
                    <img v-else class="img2" src="@/assets/images/avatar.png" />
                  </div> -->
                  <!-- 评论内容展示 -->
                  <div class="nameandreply">
                    <div class="click" style="font-size:14px;padding-right:10px;line-height:20px;color:#777;">
                      {{ item2.realName }}&nbsp;回复：
                      <!-- <span style="margin-right: 2rem">{{ item.createTime.slice(0,10) }}</span> -->
                    </div>
                    <div class="reply">
                      <div class="content click" style="font-size:14px;padding-right:10px;line-height:20px ;color:#888;" v-html="item2.replyContent"></div>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <!-- 评分展示 -->
        </li>
      </ul>
      <div v-if="!myNoteList.length" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>该课程没有提问和回答</p>
      </div>
    </section>
    <div v-show="showreplyQuestion" class="showpopup">
      <div class="fuc_tab_click">
        <p class="card_title_fz">
          写回复
          <a href="javascript:void(0);" class="ico_close_sty" @click="closereply()"></a>
        </p>
        <div class="pa20">
          <!-- 富文本 -->
          <Tinymce v-model="replyContent" :height="250" />
          <!--提交笔记按钮-->
          <div class="mt40 tac">
            <el-button @click="replyQuestion()">提交</el-button>
          </div>
        </div>
      </div>
    </div>
    <!--分页-->
    <!-- <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div> -->
  </div>
</template>

<script>
import Tinymce from '@/components/Tinymce'
import topicReplyApi from '@/api/course/courseTask/topicReply'
import courseNoteApi from '@/api/course/courseTask/topic'
import TopicReplyApi from '@/api/course/courseTask/topicReply'
export default {
  components: {
    Tinymce
  },
  props: {
    fschemeId: {
      type: Number,
      required: true
    },
    fcsId: {
      type: Number,
      required: true
    },
    fctId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      queryParams: {
        csId: this.fcsId,
        ctId: this.fctId,
        schemeId: this.fschemeId,
        topicType: 0
      },
      // 展示或隐藏回复
      ReplyBox: -1,
      myNoteList: [],
      // 初始页
      pageIndex: 1,
      total: 1,
      loading: false,
      schemeId: null,
      showreplyQuestion: false,
      // 富文本标志
      saveFlag: false,
      reply: {
        csId: this.fcsId,
        ctId: this.fctId,
        schemeId: this.fschemeId,
        userId: this.$store.getters.user.userId,
        realName: this.$store.getters.user.realName,
        replyContent: undefined,
        cqId: 1
      },
      cqId: -1,
      replyContent: '',
      replyList: []
    }
  },
  created() {
    this.showMyNote()
  },
  methods: {
    // 展示隐藏回复
    showReply(index) {
      this.ReplyBox = index
      this.getReplyListBytTopicId(index)
    },
    // 展示问答
    showMyNote() {
      courseNoteApi.getCourseTopicList(this.queryParams).then(response => {
        this.myNoteList = response.data
      })
    },
    // 根据cqId获取问题的回复
    getReplyListBytTopicId(index) {
      TopicReplyApi.getReplayListBytTopicId(index).then(response => {
        this.replyList = response.data
        console.log(this.replyList)
      })
      // for (const item of this.replyList) {
      //   console.log(item) // 'a', 'b', 'c'
      // }
    },
    // 添加回复
    replyQuestion() {
      // var aData = new Date()
      this.showreplyQuestion = true
      this.reply = {
        csId: this.fcsId,
        ctId: this.fctId,
        schemeId: this.fschemeId,
        userId: this.$store.getters.user.userId,
        realName: this.$store.getters.user.realName,
        replyContent: this.replyContent,
        cqId: this.cqId
        // createTime: aData
        // replyCount: replyCount + 1
      }
      topicReplyApi.addEntry(this.reply).then(result => {
        if (result.code === 0) {
          // this.note.noteContent = ''
          this.showMyNote()
          this.showreplyQuestion = !this.showreplyQuestion
          this.ReplyBox = -1
          this.replyContent = ''

          // this.$message({
          // type: 'success'
          // message: '添加成功'
          // })
        } else {
          // this.$message({
          //   type: 'error',
          //   message: '添加失败'
          // })
        }
      })
    },
    closereply() {
      this.showreplyQuestion = !this.showreplyQuestion
    },
    showReplyQuestion(i) {
      this.cqId = i
      this.showreplyQuestion = !this.showreplyQuestion
    }
  }
}
</script>

<style lang="scss" scoped>
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
      display: block;
    text-align: left;
    margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  // padding: 0 32px;
  // margin: 0 32px;
  margin-bottom: 8px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
  // display: flex;
  // justify-content:space-between;
}
.mod-qa-list1{
  // display: flex;
  display: inline-block;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 16px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  padding-top: 10px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  // border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  // line-height: 20px;
  // height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
.avatar{
  padding: 10px;
  display: inline-block;
  position: absolute;
  left: 0;
  top: 0;
}
.replybtn{
  width: 80px;
  height: 50px;
  padding-top: 20px;
  // padding-left: 20px;
  color: rgb(44,62,80);
  font-size: 14px;
  cursor:pointer;
  display: inline-block;
}
.showpopup{
  background-color: #fff;
  width: 400px;
  height: 450px;
  border-radius: 10px;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
}
.nameandcontent{
  display:inline-block;
  margin:0 60px;
}
.nameandreply{
  padding: 0 50px;
    display: flex;
margin-bottom: 10px;
  // background-color: #9199a1;
  // width: 100%;

}
// .replybox{
// }
</style>
