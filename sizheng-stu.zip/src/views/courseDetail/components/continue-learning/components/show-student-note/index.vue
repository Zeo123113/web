<!--
@description 课程评价
@author cgy
-->
<template>
  <div id="assess">
    <section v-loading="loading">
      <ul class="db">
        <li v-for="(item,index) of schemeNoteList" :key="index" class="mod-qa-list">
          <div style="display:flex;">
            <!-- 展示头像 -->
            <div class="avatar">
              <img
                v-if="item.avatar!=='' && item.avatar != null"
                :image="item.avatar"
                class="img2"
                alt
              />
              <img v-else class="img2" src="@/assets/images/avatar.png" />
            </div>
            <!-- 评论内容展示 -->
            <div>
              <div class="qt-tit click" style="font-size:14px;">
                {{ item.realName }}
                <!-- <span style="margin-right: 2rem">{{ item.createTime.slice(0,10) }}</span> -->
              </div>
              <div class="xcontent mt7">
                <el-tooltip placement="right" effect="light">
                  <div slot="content" style="max-width:600px;" v-html="item.noteContent"></div>
                  <div class="content click" style="max-height:100px;" v-html="item.noteContent"></div>
                </el-tooltip>
              </div>
            </div>
          </div>
          <div style="display:flex;">
            <!-- 评分展示 -->
            <div class="likenote" @click="tolikeNote(item.noteId)">
              <svg
                class="icon icon-dianzan"
                :style="{'color':likeNote?'#e50012':'#111'}"
                aria-hidden="true"
              >
                <use xlink:href="#icon-dianzan" />
              </svg>
              <span style="font-size:12px;padding-right:10px;" :style="{'color':likeNote?'#e50012':'#111'}">({{ item.likeCount }})</span>
              <span style="font-size:12px;" @click="showContent()">查看全文</span>
              <!-- 创建时间 -->
              <span style="font-size:12px;padding-right:10px;position:absolute;right:0;bottom:10px;">{{ item.createTime.slice(0,10) }}</span>
            </div>
          </div>
        </li>
      </ul>
      <!--详情弹窗-->
      <el-dialog
        :visible.sync="centerDialogVisible"
        width="50%"
        center
        @close="centerDialogVisible = false"
      >
        <div class="editor-content" v-html="courseNotice.noteContent" />
      </el-dialog>
      <div v-if="!schemeNoteList.length" class="nodata">
        <!-- <div class="box">loader 1 -->
        <div class="loader-02"></div>
        <!-- </div> -->
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>该课程没有评价</p>
      </div>
    </section>
    <!--分页-->
    <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
import COURSE_CONST from '@/constant/course-const'
import courseNoteApi from '@/api/course/courseManage/courseNote'
export default {
  props: {
    fschemeId: {
      type: Number,
      required: true
    },
    fcsId: {
      type: Number,
      required: true
    },
    fctId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      centerDialogVisible: false,
      courseNotice: {},
      likeNote: false,
      queryParams: {
        csId: this.fcsId,
        ctId: this.fctId,
        schemeId: this.fschemeId,
        userId: this.$store.getters.user.userId
      },
      schemeNoteList: [],
      // 初始页
      pageIndex: 1,
      total: 1,
      // 默认分页参数
      pageSize: COURSE_CONST.PAGESIZE,
      loading: false,
      schemeId: null
    }
  },
  created() {
    this.showMyNote()
  },
  methods: {
    showContent() {
      this.centerDialogVisible = true
    },
    tolikeNote(index1) {
      if (this.likeNote === true) {
        this.likeNote = false
      } else {
        var likeNoteList = {
          noteId: index1,
          userId: this.$store.getters.user.userId,
          stuId: 'xiaoshuai',
          realName: this.$store.getters.user.realName
        }
        courseNoteApi.giveLike(likeNoteList).then(response => {
          if (response.code === 0) {
            this.likeNote = true
            this.showMyNote()
          }
        })
      }
    },
    // 展示同学笔记
    showMyNote() {
      this.loading = true
      courseNoteApi.selectCourseNoteByCourse(this.queryParams, this.pageIndex, this.pageSize).then(response => {
        this.schemeNoteList = response.data.list
        this.loading = false
      })
    },
    handleCurrentChange(val) {
      this.pageIndex = parseInt(val)
      this.showMyNote()
    },
    getRating(val) {
      return val.rating.toString()
    }
  }
}
</script>

<style lang="scss" scoped>
.likenote {
  padding-left: 56px;
  padding-bottom: 10px;
  width: 100%;
  position: relative;
}
.icon-dianzan {
  width: 15px;
  height: 15px;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
.all {
  font-size: 14px;
  padding: 0 15px;
  height: 30px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  // padding: 0 32px;
  // margin: 0 32px;
  margin-bottom: 18px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
  // display: flex;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 16px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  padding-top: 16px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-right: 20px;
  // border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  // line-height: 20px;
  // height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
.avatar {
  padding: 10px;
  // width: 10px;
  // height: 10px;
  // background-color: aqua;
}
[class*='loader-'] {
  display: inline-block;
  width: 1em;
  height: 1em;
  color: inherit;
  vertical-align: middle;
  pointer-events: none;
}
.loader-02 {
  width: 50px;
  height: 50px;
  border: 1em solid transparent;
  border-left-color: currentcolor;
  border-right-color: currentcolor;
  border-radius: 50%;
  -webkit-animation: 1s loader-02 linear infinite;
  animation: 1s loader-02 linear infinite;
}
@-webkit-keyframes loader-02 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes loader-02 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
</style>
