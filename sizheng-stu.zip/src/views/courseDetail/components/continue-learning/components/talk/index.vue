<template>
  <div>
    <div>
      <div class="fuc_tab_click">
        <p class="card_title_fz">
          问题
          <a href="javascript:void(0);" class="ico_close_sty" @click="hiddenChapter()"></a>
        </p>
        <div class="pa20">
          <div class="ipt_wrap" style="padding: 0 20px; margin-bottom: 20px;">
            <input v-model="topic.topicTitle" type="text" style="text-align: left;" placeholder="提问：一句话说明你的问题" />
          </div>
          <tinymce ref="content" v-model="topic.topicContent" :save-flag="saveFlag" :height="250" />
          <!--提交问题-按钮-->
          <div class="mt20 tac">
            <center>
              <a
                href="javascript:void(0);"
                class="btn_5"
                style="display: inline-block;width: 263px;"
                @click="addTopic()"
              >提交问题</a></center>
          </div>
          <!-- <ul>
            <li v-for="(item,index) of myNoteList" :key="index">
              <div class="mt20 cf">
                <p class="mr15 fl fz18 fwb" style="color:#000;">{{ index+1 }}</p>
                <div class="ov">
                  <p class="fz16 lh24 pb10 bb1" style="color:#000;">{{ item.topicTitle }}</p>
                </div>
              </div>
            </li>
          </ul> -->
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import courseNoteApi from '@/api/course/courseTask/topic'
import Tinymce from '@/components/Tinymce'
import topicApi from '@/api/course/courseTask/topic'
export default {
  components: {
    Tinymce
  },
  props: {
    fschemeId: {
      type: Number,
      required: true
    },
    fcsId: {
      type: Number,
      required: true
    },
    fctId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      topic: {},
      queryParams: {
        csId: this.fcsId,
        ctId: this.fctId,
        schemeId: this.fschemeId,
        topicUserId: this.$store.getters.user.userId
      },
      myNoteList: [],
      replyList: [],
      allReplyList: [],
      // 富文本开启标志
      saveFlag: false
    }
  },
  created() {
    this.showMyNote()
    this.open()
    // this.getReplyListBytTopicId()
  },
  methods: {
    /** 打开弹窗放入富文本内容 */
    open() {
      this.saveFlag = true
      this.editsaveFlag()
    },
    editsaveFlag() {
      setTimeout(() => {
        this.saveFlag = !this.saveFlag
      }, 500)
    },
    hiddenChapter() {
      this.$emit('model', false)
    },
    // 展示问题的标题
    showMyNote() {
      courseNoteApi.getCourseTopicList(this.queryParams).then(response => {
        this.myNoteList = response.data
      })
    },
    // 添加问题
    addTopic() {
      this.topic = {
        csId: this.fcsId,
        ctId: this.fctId,
        schemeId: this.fschemeId,
        unitId: 100,
        topicType: 0,
        topicContent: this.topic.topicContent,
        topicUserId: this.$store.getters.user.userId,
        realName: this.$store.getters.user.realName,
        topicTitle: this.topic.topicTitle
      }
      topicApi.addEntry(this.topic).then(result => {
        if (result.code === 0) {
          this.topic.topicContent = ''
          this.showMyNote()
          this.$message({
            type: 'success',
            message: '提问成功'
          })
        } else {
          this.$message({
            type: 'error',
            message: '提问失败'
          })
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>

</style>
