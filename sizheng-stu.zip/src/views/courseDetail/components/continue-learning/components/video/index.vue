<template>
  <!--播放器放置区域-->
  <div class="b3">
    <video id="my-video" class="video-js vjs-big-play-centered" controls preload="auto">
      <!-- <source id="video" :src="m3u8Test" type="application/x-mpegURL" /> -->
    </video>
    <!-- 弹题框 -->
    <el-dialog
      title="视频问答"
      :visible.sync="centerDialogVisible"
      width="30%"
      center
      :show-close="false"
      :close-on-press-escape="false"
      :close-on-click-modal="false"
      @open="open"
    >
      <div v-for="(item,index) of questionList" :key="index">
        <div :style="{display: currentIndex === index ? 'block':'none'}">
          <div>{{ index+1 }}.{{ item.content }}</div>
          <el-radio-group
            v-if="item.tqTypeId.toString()===SINGLE || item.tqTypeId.toString()===JUDGEMENT"
            v-model="selectValue"
          >
            <el-radio
              v-for="item1 in item.options"
              :key="item1.value"
              :label="item1.label"
              style="margin-top:10px;display:block;"
            ></el-radio>
          </el-radio-group>
          <el-checkbox-group v-if="item.tqTypeId.toString()===MULTIPLE" v-model="selectValue">
            <el-checkbox
              v-for="item1 in item.options"
              :key="item1.value"
              :label="item1.label"
              style="margin-top:10px;display:block;"
            ></el-checkbox>
          </el-checkbox-group>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submit()">提交</el-button>
      </span>
    </el-dialog>
  </div>
  <!--播放器放置区域-->
</template>
<script>
import videojs from 'video.js'
import 'videojs-contrib-hls'
import { mapGetters } from 'vuex'
import studyLogApi from '@/api/course/courseTask/studyLog'
import popupQuestionApi from '@/api/course/other/popupQuestion'
import COURSE_CONST from '@/constant/course-const'
import EXAMBANK_CONST from '@/constant/exambank-const'
export default {
  name: 'Video',
  props: {
    url: {
      type: String,
      required: true
    },
    chapter: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // M3U8URL: '/api/group2/M00/00/00/J2KSql7pykiAPT6yAAAGCKIylpE15.m3u8',
      m3u8Test: '',
      myPlayer: null,
      queryParams: {
        ctId: this.$route.params.ctId,
        csId: this.$route.params.csId,
        schemeId: this.$route.params.schemeId
      },
      // 学习记录对象
      courseStudyLog: {},
      // 弹题列表
      popupQuestionsList: [],
      // 是否有弹题
      havePopupQuestion: false,
      // 当前弹题
      currentQuestionIndex: 0,
      centerDialogVisible: false,
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      total: 0,
      maps: new Map(),
      questionListMaps: new Map(),
      selectValue: '',
      myMapChangeTracker: 1,
      fullscreen: false
    }
  },
  // 从状态管理器获取按钮权限数组button
  computed: {
    ...mapGetters({
      user: 'user'
    }),
    questionList: function() {
      var x = this.myMapChangeTracker
      console.log(x)
      return this.questionListMaps.get(this.currentQuestionIndex)
    },
    currentIndex: function() {
      var x = this.myMapChangeTracker
      console.log(x)
      return this.maps.get(this.currentQuestionIndex)
    }
  },
  watch: {
    chapter: function(newVal, oldVal) {
      this.chapter = newVal
      this.havePopupQuestion = false
      this.getPopupQuestions()
    },
    url: function(newVal, oldVal) {
      this.havePopupQuestion = false
      this.initVideo()
      this.myPlayer.src({ src: newVal, type: 'application/x-mpegURL' })
      this.myPlayer.load()
      setTimeout(() => {
        this.myPlayer.play()
      }, 500)
    },
    deep: true,
    immediate: true
  },
  beforeDestroy() {
    var nowTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
    this.courseStudyLog.studyEndTime = nowTime
    this.updateCourseStudyLog()
    this.myPlayer.dispose()
  },
  destroyed() {
    this.popupQuestionsList = []
    this.havePopupQuestion = false
    this.myPlayer.dispose()
  },
  created() {
    this.getPopupQuestions()
  },
  mounted() {
    this.initVideo()
    this.myPlayer.src({ src: this.url, type: 'application/x-mpegURL' })
    this.myPlayer.load()
    setTimeout(() => {
      this.myPlayer.play()
    }, 1000)
  },
  methods: {
    open() {
      setTimeout(() => {
        this.myPlayer.pause()
      }, 1000)
    },
    // 弹题提交
    submit() {
      // 当前驻点弹题数量
      var l = this.questionListMaps.get(this.currentQuestionIndex).length
      // 当前驻点弹题索引
      var i = this.maps.get(this.currentQuestionIndex)
      if (i === l - 1) {
        if (this.fullscreen) {
          this.myPlayer.requestFullscreen()
        }
        if (this.currentQuestionIndex < this.total - 1) {
          this.currentQuestionIndex++
          this.centerDialogVisible = false
          this.myPlayer.play()
        } else {
          this.currentQuestionIndex = 0
          this.centerDialogVisible = false
          this.havePopupQuestion = false
          this.myPlayer.play()
        }
      } else {
        this.myMapChangeTracker += 1
        this.maps.set(this.currentQuestionIndex, i + 1)
      }
    },
    initVideo() {
      const options = {
        // 确定播放器是否具有用户可以与之交互的控件。没有控件，启动视频播放的唯一方法是使用autoplay属性或通过Player API。
        controls: true,
        // 自动播放属性,muted:静音播放
        autoplay: false,
        // 视频一结束是否就重新开始播放
        loop: false,
        // 建议浏览器是否应在<video>加载元素后立即开始下载视频数据。
        preload: 'auto',
        // 播放器宽度:获取浏览器窗口文档显示区域的宽度，不包括滚动条
        width: document.documentElement.clientWidth * 0.6,
        // 播放器高度:获取浏览器窗口文档显示区域的高度，不包括滚动条
        height: document.documentElement.clientHeight * 0.74,
        // 播放速度
        playbackRates: [0.7, 1.0, 1.5, 2.0],
        language: 'zh-CN',
        // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
        // aspectRatio: '16:9',
        // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
        fluid: false,
        // 允许覆盖Video.js无法播放媒体源时显示的默认信息。
        notSupportedMessage: '此视频暂无法播放，请稍后再试',
        bigPlayButton: false,
        textTrackDisplay: false,
        posterImage: true,
        errorDisplay: false,
        controlBar: {
          timeDivider: true,
          durationDisplay: true,
          remainingTimeDisplay: true,
          fullscreenToggle: true  // 全屏按钮
        },
        hls: {
          withCredentials: true
        }
      }
      this.myPlayer = videojs('my-video', options,
        () => {
          this.findStudyLog(this.chapter.jmaterials.fileId, this.chapter.pstId)
          var time = 0
          this.getPopupQuestions()
          setTimeout(() => {
            time = this.courseStudyLog.duration
            if (this.courseStudyLog.lastPosition === Math.floor(this.myPlayer.duration())) {
              this.myPlayer.currentTime(0)
            } else {
              this.myPlayer.currentTime(this.courseStudyLog.lastPosition)
              this.myPlayer.play()
            }
            setTimeout(() => {
              var sym
              if (this.courseStudyLog.lastPosition !== 0) {
                sym = this.courseStudyLog.lastPosition
              }
              this.myPlayer.setInterval(() => {
                if (this.havePopupQuestion) {
                  var nowtime = this.myPlayer.currentTime()
                  if (nowtime === 0 && this.courseStudyLog.lastPosition !== 0) {
                    nowtime = this.courseStudyLog.lastPosition
                    this.myPlayer.currentTime(nowtime)
                  }
                  if (Math.floor(nowtime) === this.timeFormat(this.popupQuestionsList[this.currentQuestionIndex].stagnationTime)) {
                    if (this.myPlayer.isFullscreen()) {
                      this.fullscreen = true
                    }
                    this.myPlayer.pause()
                    this.myPlayer.exitFullscreen()
                    this.showQuestion()
                  }
                  if (nowtime - sym > 1) {
                    this.myPlayer.currentTime(sym)
                  }
                  sym = this.myPlayer.currentTime()
                }
              }, 250)
            }, 1000)
            this.myPlayer.on('timeupdate', () => {
              var nowtime = this.myPlayer.currentTime()
              if (Math.floor(nowtime) - time === 5) {
                time = Math.floor(nowtime)
                this.courseStudyLog.duration = this.courseStudyLog.duration + 5
                this.courseStudyLog.lastPosition = this.myPlayer.currentTime()
                this.updateCourseStudyLog()
              }
            })
          }, 1000)
          // 监听点击进度条方法
          this.myPlayer.on('seeked', () => {
            time = Math.floor(this.myPlayer.currentTime())
          })
          // 监听暂停方法
          this.myPlayer.on('pause', () => {
            this.courseStudyLog.lastPosition = this.myPlayer.currentTime()
            this.updateCourseStudyLog()
          })
          // 播放结束时的方法
          this.myPlayer.on('ended', () => {
            var nowTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
            this.courseStudyLog.studyEndTime = nowTime
            this.courseStudyLog.lastPosition = this.myPlayer.currentTime()
            this.updateCourseStudyLog()
            time = 0
          })
        }
      )
    },
    initCourseStudyLog() {
      this.courseStudyLog = {
        studyLogId: null,
        csId: this.chapter.csId,
        ctId: this.chapter.ctId,
        schemeId: this.chapter.schemeId,
        unitId: this.chapter.sourceUnitId,
        mgId: null,
        pstId: this.chapter.pstId,
        smType: COURSE_CONST.VIDEO,
        smId: this.chapter.jmaterials.fileId,
        studyMaterial: JSON.stringify(this.chapter.jmaterials),
        studyStartTime: this.format(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        studyEndTime: null,
        duration: 0,
        userId: this.user.userId,
        stuId: this.user.stuId,
        realName: this.user.realName,
        isFinished: false,
        studyScore: 0,
        lastPosition: 0,
        lastPages: 0,
        orgId: this.user.orgId,
        createOrgId: this.user.orgId
      }
    },

    findStudyLog(smId, pstId) {
      console.log(this.$router)
      var data = {
        userId: this.user.userId,
        smId: smId,
        pstId: pstId
      }
      studyLogApi.getStudyLog(data).then((result) => {
        if (result.data.studyLogId !== null) {
          this.courseStudyLog = result.data
          this.courseStudyLog.studyStartTime = this.courseStudyLog.studyEndTime
          this.$router.push({
            params: {
              courseStudyLogId: this.courseStudyLog.studyLogId
            }
          })
        } else {
          this.initCourseStudyLog()
          console.log('StudentAddStudyLog======video========')
          studyLogApi.StudentAddStudyLog(this.courseStudyLog).then((result) => {
            if (result.code === 0) {
              this.courseStudyLog = result.data
              this.$router.push({
                params: {
                  courseStudyLogId: this.courseStudyLog.studyLogId
                }
              })
            }
          })
        }
      })
    },
    updateCourseStudyLog() {
      if (this.chapter.jmaterials.condition === '0' || this.chapter.jmaterials.condition === '学习到最后') {
        if (this.courseStudyLog.duration >= Math.floor(this.myPlayer.duration())) {
          this.courseStudyLog.isFinished = true
          this.courseStudyLog.studyScore = this.chapter.jmaterials.score
          studyLogApi.updateStudyLog(this.courseStudyLog)
        } else {
          studyLogApi.updateStudyLog(this.courseStudyLog)
        }
      } else {
        if (this.formatSeconds(this.courseStudyLog.duration).toString() >= this.chapter.jmaterials.finshTime) {
          this.courseStudyLog.isFinished = true
          this.courseStudyLog.studyScore = this.chapter.jmaterials.score
          studyLogApi.updateStudyLog(this.courseStudyLog)
        } else {
          studyLogApi.updateStudyLog(this.courseStudyLog)
        }
      }
    },
    // 获取视频的弹题列表
    getPopupQuestions() {
      var data = {
        mediaId: this.chapter.jmaterials.fileId,
        unitId: this.chapter.sourceUnitId
      }
      popupQuestionApi.getListByCondition(data).then((result) => {
        if (result.code === 0) {
          if (result.data.length !== 0) {
            this.total = result.data.length
            this.popupQuestionsList = result.data
            this.havePopupQuestion = true
          } else {
            this.total = 0
            this.popupQuestionsList = []
            this.havePopupQuestion = false
          }
        }
      })
    },
    // 显示弹题
    showQuestion() {
      if (this.centerDialogVisible) {
        return false
      } else {
        this.centerDialogVisible = true
        this.myMapChangeTracker += 1
        var questionList = JSON.parse(this.popupQuestionsList[this.currentQuestionIndex].questionIds)
        this.maps.set(this.currentQuestionIndex, 0)
        questionList = this.Rendering(questionList)
        this.questionListMaps.set(this.currentQuestionIndex, questionList)
        this.myPlayer.pause()
      }
    },
    /*
     * 获取当前时间
     */
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    },
    // 将秒转为时间
    formatSeconds(value) {
      var theTime = parseInt(value)
      var theTime1 = 0
      var theTime2 = 0

      if (theTime >= 60) {
        theTime1 = parseInt(theTime / 60)
        theTime = parseInt(theTime % 60)
        if (theTime1 >= 60) {
          theTime2 = parseInt(theTime1 / 60)
          theTime1 = parseInt(theTime1 % 60)
        }
      }
      if (theTime < 10) {
        theTime = '0' + parseInt(theTime)
      }
      var result = '' + theTime + ''
      if (theTime1 >= 0) {
        if (theTime1 < 10) {
          theTime1 = '0' + parseInt(theTime1)
        }
        result = '' + theTime1 + ':' + result
      }
      if (theTime2 >= 0) {
        if (theTime2 < 10) {
          theTime2 = '0' + parseInt(theTime2)
        }
        result = '' + theTime2 + ':' + result
      }
      return result
    },
    // 将时间转为秒
    timeFormat(time) {
      var hour = time.split(':')[0]
      var min = time.split(':')[1]
      var sec = time.split(':')[2]
      var  s = Number(hour * 3600) + Number(min * 60) + Number(sec)
      return s
    },
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    },
    Rendering(list) {
      var bankList = []
      list.forEach(bank => {
        var options = []
        const dom = this.collectionToArray(this.parseDom(bank.content))
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text' || (dom[i].nodeName === 'P' && dom[i].innerText.trim() === '')) {
            dom.splice(i, 1)
            i--
          }
        }
        let ol_pos = -1
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === 'OL') {
            ol_pos = i
          }
        }
        if (ol_pos > 0) {
          const ol = dom[ol_pos]
          dom.splice(ol_pos, 1)
          let str = ''
          for (let i = 0; i < dom.length; i++) {
            str += dom[i].innerHTML
          }
          bank.content = str
          str = ''
          if (bank.tqTypeId.toString() !== this.JUDGEMENT) {
            for (let i = 0; i < ol.children.length; i++) {
              const index = String.fromCharCode(i + 65)
              const item = {}
              item.value = index
              item.label = ol.children[i].innerHTML
              options[i] = item
            }
          } else {
            for (let i = 0; i < ol.children.length; i++) {
              const item = {}
              item.value = ol.children[i].innerHTML
              item.label = ol.children[i].innerHTML
              options[i] = item
            }
          }
        }
        bank = { ...bank, options: options }
        bankList.push(bank)
      })
      return bankList
    }
  }

}
</script>
<style lang="scss" scoped>
.video-js .vjs-icon-placeholder {
  width: 100%;
  height: 100%;
  display: block;
}
#my-video {
  width: 1022px;
  height: 461px;
}
</style>
