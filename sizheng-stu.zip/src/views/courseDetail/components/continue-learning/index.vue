<template>
  <div id="video">
    <div class="cf">
      <!--上半部分-->
      <div style="height: 550px;">
        <!--header-->
        <div class="header_bg_area">
          <div class="cf">
            <div class="fl">
              <div class>
                <svg class="icon" aria-hidden="true" style="color: #fff" @click="back()">
                  <use xlink:href="#icon-fanhui-xianxing" />
                </svg>
                <span class="ml25 fz16 fwb cor_fff">{{ coursedetail.courseTitle }}</span>
                <el-button
                  href="javascript:void(0);"
                  type="text"
                  class="ml20"
                  :class="active?'collection_btn_styed':'collection_btn_sty'"
                  @click="toFavoriteCourse()"
                >
                  <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-shoucang" />
                  </svg>
                  <span class="ml5">收藏</span>
                </el-button>
              </div>
            </div>
            <div class="fr hidden-xs">
              <router-link to="/coursehome" class="back_btn_sty">
                <svg class="icon" aria-hidden="true">
                  <use xlink:href="#icon-fanhui" />
                </svg>
                <span class="ml10">返回课程首页</span>
              </router-link>
            </div>
          </div>
        </div>
        <!--header-->
        <!--左侧tab栏-->
        <div class="mr12 fl hidden-xs">
          <div class="fixed_left_tab_2">
            <div v-for="(item,i) in navigation" :key="i" class="tab_fun_item">
              <p class="fun_icon" :class="{ 'active': i == show }">
                <a @click="seleted(i)">
                  <svg class="icon" aria-hidden="true">
                    <use :xlink:href="item.ico" />
                  </svg>
                </a>
              </p>
              <p class="fun_fz_sty">{{ item.title }}</p>
            </div>
          </div>
        </div>
        <div class="video_and_right">
          <!--右侧栏-->
          <div v-if="closeRightComponents" class="ml15 fr right_son">
            <div class="fixed_answer_card_3">
              <div v-if="isNavigation===0">
                <ChapterHead
                  :fscheme-id="schemeId"
                  @getPrepareStudyTask="getPrepareStudyTask"
                  @model="closeModel"
                />
              </div>
              <div v-else-if="isNavigation===1">
                <Talk :fscheme-id="schemeId" :fcs-id="csId" :fct-id="ctId" @model="closeModel" />
              </div>
              <div v-else-if="isNavigation===2">
                <QuestionandAnswer
                  :fscheme-id="schemeId"
                  :fcs-id="csId"
                  :fct-id="ctId"
                  @model="closeModel"
                />
              </div>
              <div v-else-if="isNavigation===3">
                <Note
                  :fscheme-id="schemeId"
                  :fcs-id="csId"
                  :fct-id="ctId"
                  @model="closeModel"
                  @showNote="showNote"
                />
              </div>
              <!-- <div v-else-if="isNavigation===4">
                <Question :fscheme-id="schemeId" :fcs-id="csId" :fct-id="ctId" @model="closeModel" />
              </div>-->
            </div>
          </div>
          <!--视频,pdf播放-->
          <div class="ov video_son">
            <!-- <Video :m3u8url="M3U8URL" /> -->
            <component
              :is="state"
              :url="playUrl"
              :title="title"
              :artist="artist"
              :chapter="chapter"
            />
          </div>
        </div>
        <!-- 视频
        <div class="ov">
          <Video :m3u8url="M3U8URL" :file-id="fileId" />
        </div>-->
      </div>
      <!--下半部分-->
      <div class>
        <div class="bottomareaul">
          <ul style="cursor:pointer;">
            <li
              class="bottomareali"
              :class="show == 1? 'bottomareali_active':''"
              @click="showOne(1)"
            >问答</li>
            <li
              class="bottomareali"
              :class="show == 2? 'bottomareali_active':''"
              @click="showOne(2)"
            >评论</li>
            <li
              class="bottomareali"
              :class="show == 3? 'bottomareali_active':''"
              @click="showOne(3)"
            >学生笔记</li>
            <li
              class="bottomareali"
              :class="show == 4? 'bottomareali_active':''"
              @click="showOne(4)"
            >话题</li>
          </ul>
        </div>
        <div class="course-subcontainer">
          <div class="course-left">
            <!-- 问答 -->
            <ShowQuestionandAnswer
              v-if="show===1"
              :fcs-id="csId"
              :fct-id="ctId"
              :fscheme-id="schemeId"
            />
            <!-- 评论 -->
            <ShowComment v-else-if="show===2" :fcs-id="csId" :fct-id="ctId" :fscheme-id="schemeId" />
            <!-- 学生笔记（点赞没做 ） -->
            <ShowStudentNote
              v-else-if="show===3"
              :fscheme-id="schemeId"
              :fcs-id="csId"
              :fct-id="ctId"
            />
            <!-- 话题(未做--和问答类似) -->
            <ShowTopic v-else-if="show===4" :fscheme-id="schemeId" :fcs-id="csId" :fct-id="ctId" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
// import prepareStudyTaskApi from '@/api/course/courseTask/prepareStudyTask'
import { mapGetters } from 'vuex'
import studyLogApi from '@/api/course/courseTask/studyLog'
import USER_CONST from '@/constant/user-const'
import ChapterHead from './components/chapter-head/index'
import Note from './components/note/index'
import ShowTopic from './components/show-topic/index'
import QuestionandAnswer from './components/question-and-answer/index'
import Talk from './components/talk/index'
import Music from './components/music/index'
import Pdf from './components/pdf/index'
import Video from './components/video/index'
import ShowQuestionandAnswer from './components/show-question-and-answer/index'
import ShowComment from './components/show-comment/index'
import ShowStudentNote from './components/show-student-note/index'
import courseSetApi from '@/api/course/courseManage/courseSet'
import courseFavoriteApi from '@/api/course/courseManage/courseFavorite'
export default {
  name: 'ContinueLearning',
  components: {
    ChapterHead,
    Note,
    QuestionandAnswer,
    Talk,
    Video,
    Music,
    Pdf,
    ShowQuestionandAnswer,
    ShowComment,
    ShowStudentNote,
    ShowTopic
  },
  data() {
    return {
      title: '',
      state: '',
      playUrl: '',
      M3U8URL: '',
      // 课程视频的fileId,用于查询是否含有弹题
      fileId: '',
      videoMaterials: [],
      studyTask: {},
      prepareTask: {},
      navigation: [
        { title: '章节', comp: 'Chapter', ico: '#icon-shuji' },
        { title: '问题', comp: 'Question', ico: '#icon-huati' },
        { title: '评论', comp: 'Talk', ico: '#icon-taolunqu' },
        { title: '笔记', comp: 'Note', ico: '#icon-huaban' }
      ],
      isNavigation: 0,
      show: 0,
      csId: null,
      ctId: null,
      schemeId: null,
      coursedetail: [],
      courseFavorite: {},
      active: true,
      isCourseFav: [],
      queryParams: {
        ctId: parseInt(this.$route.params.ctId),
        csId: parseInt(this.$route.params.csId),
        schemeId: parseInt(this.$route.params.schemeId),
        userId: parseInt(this.$store.getters.user.userId)
      },
      // 收藏id
      favId: null,
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      closeRightComponents: false,
      music: {},
      artist: '',
      chapter: {},
      courseStudyLog: {},
      studyLogId: null
    }
  },
  // 从状态管理器获取按钮权限数组button
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {
    this.csId = parseInt(this.$route.params.csId)
    this.ctId = parseInt(this.$route.params.ctId)
    this.schemeId = parseInt(this.$route.params.schemeId)
    this.studyLogId =  parseInt(this.$route.params.courseStudyLogId)
    this.getCourseInfo()
    this.isFavoriteCourse()
    // 查找学习记录
    this.findStudyLog()
  },
  methods: {
    initCourseStudyLog() {
      this.courseStudyLog = {
        studyLogId: null,
        csId: this.csId,
        ctId: this.ctId,
        schemeId: this.schemeId,
        unitId: null,
        mgId: null,
        pstId: null,
        smType: '2',
        smId: null,
        studyMaterial: null,
        studyStartTime: this.format(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        studyEndTime: null,
        duration: 0,
        userId: this.user.userId,
        stuId: this.user.stuId,
        realName: this.user.realName,
        isFinished: false,
        studyScore: 0,
        lastPosition: 0,
        lastPages: 0
      }
    },
    // 查找学习记录，找不到就添加
    findStudyLog() {
      // var data = {
      //   userId: this.user.userId,
      //   csId: this.csId,
      //   ctId: this.ctId,
      //   schemeId: this.schemeId,
      //   stuId: this.user.stuId,
      //   realName: this.user.realName
      // }
      studyLogApi.getStudyLogById(this.studyLogId).then((result) => {
        if (result.data.studyLogId !== null) {
          this.courseStudyLog = result.data
          this.courseStudyLog.studyStartTime = this.courseStudyLog.studyEndTime
          // 将courseStudyLog转为chapter
          this.generChapter(this.courseStudyLog)
        } else {
          // 从0条记录到1条默认记录（默认第一个学习任务）
          this.initCourseStudyLog()
          studyLogApi.addDefaultStudyLog(this.courseStudyLog).then((result) => {
            if (result.code === 0) {
              this.courseStudyLog = result.data
              this.generChapter(this.courseStudyLog)
            }
          })
        }
      })
    },
    // 将courseStudyLog转为chapter
    generChapter(courseStudyLog) {
      const jmaterials = JSON.parse(courseStudyLog.studyMaterial)
      this.chapter.jmaterials = { ...jmaterials }
      this.chapter.csId = courseStudyLog.csId
      this.chapter.ctId = courseStudyLog.ctId
      this.chapter.schemeId = courseStudyLog.schemeId
      this.chapter.fileUrl = jmaterials.url
      this.chapter.chapterTitle = jmaterials.title
      this.chapter.chapterType = '2'
      this.chapter.fileType = jmaterials.type
      console.log('this.chapter.fileType = ', this.chapter.fileType)
      this.chapter.pstId = courseStudyLog.pstId
      this.chapter.sourceUnitId = courseStudyLog.unitId
      // this.chapter = { ...courseStudyLog }
      this.getPrepareStudyTask(this.chapter)
    },
    updateCourseStudyLog() {
      if (this.chapter.jmaterials.condition === '0' || this.chapter.jmaterials.condition === '学习到最后') {
        if (this.courseStudyLog.duration === this.myPlayer.duration() * 1000) {
          this.courseStudyLog.isFinished = true
          this.courseStudyLog.studyScore = this.chapter.jmaterials.score
          studyLogApi.updateStudyLog(this.courseStudyLog)
        } else {
          studyLogApi.updateStudyLog(this.courseStudyLog)
        }
      } else {
        if (this.formatSeconds(this.chapter.duration).toString() === this.courseStudyLog.jmaterials.finshTime) {
          this.courseStudyLog.isFinished = true
          this.courseStudyLog.studyScore = this.chapter.jmaterials.score
          studyLogApi.updateStudyLog(this.courseStudyLog)
        } else {
          studyLogApi.updateStudyLog(this.courseStudyLog)
        }
      }
    },
    showNote(index) {
      this.show = index
    },
    // 根据单元chapter获取预习，学习任务(预习，学习任务分别一个，不是分别多个)
    getPrepareStudyTask(chapter) {
      this.chapter = chapter
      console.log('getPrepareStudyTask-----chapter = ', chapter)
      if (chapter.fileType === 'video') {
        this.state = 'Video'
        this.playUrl = '/api/' + chapter.fileUrl
      } else if (chapter.fileType === 'audio') {
        this.state = 'Music'
        this.playUrl = '/file-server/' + chapter.fileUrl
        this.title = chapter.chapterTitle
        this.music.title = chapter.chapterTitle
        this.music.src = '/file-server/' + chapter.fileUrl
        const user = this.$store.getters.user
        this.artist = user.loginName
      } else {
        this.state = 'Pdf'
        this.playUrl = '/file-server/' + chapter.fileUrl
      }
      console.log('this.playUrl = ', this.playUrl)
    },
    closeModel(index) {
      this.closeRightComponents = index
    },
    // 获取视频资料的url
    getUrlByVideo(videoMaterials) {
      if (videoMaterials == null || videoMaterials === undefined) {
        this.$message({
          message: '该课时下无音频资料!',
          type: 'info'
        })
        return
      } else {
        videoMaterials.forEach((item) => {
          // 获取第一个视频
          console.log('this.videoMaterials------item = ', item)
          this.M3U8URL = '/api/' + item.url
          this.fileId = item.fileId
          console.log('this.M3U8URL = ', this.M3U8URL)
          return
        })
      }
    },
    // 判断是否已收藏课程
    isFavoriteCourse() {
      courseFavoriteApi.getCourseFavList(this.queryParams).then(response => {
        this.isCourseFav = response.data
      })
      if (this.isCourseFav.length === 1) {
        this.active = false
        // console.log(this.active)
      } else {
        this.active = true
        // console.log(this.active)
      }
    },
    // 收藏与取消收藏课程
    toFavoriteCourse() {
      if (this.isCourseFav.length !== 0) {
        courseFavoriteApi.delete(this.isCourseFav[0].favId).then(response => {
          if (response.code === 0) {
            this.active = !this.active
            this.isFavoriteCourse()
          } else {
            this.active
          }
        })
        // })
      } else {
        this.courseFavorite = {
          orgId: 100,
          csId: this.csId,
          ctId: parseInt(this.$route.params.ctId),
          schemeId: parseInt(this.$route.params.schemeId),
          userId: parseInt(this.$store.getters.user.userId)
        }
        courseFavoriteApi.add(this.courseFavorite)
          .then(result => {
            if (result.code === 0) {
              this.active = !this.active
              this.isFavoriteCourse()
            // this.$message({
            //   type: 'success',
            //   message: '添加成功'
            // })
            } else {
            // this.$message({
            //   type: 'error',
            //   message: '添加失败'
            // })
            }
          })
      }
    },
    // 回到课程主页
    backtoHome() {
      this.$router.push({  // 核心语句
        path: `/coursehome`   // 跳转的路径
      })
    },
    // 返回上级页面
    back() {
      this.$router.push({  // 核心语句
        path: `/courseSet/${this.csId}/term/${this.ctId}/scheme/${this.schemeId}`   // 跳转的路径
      })
    },
    getCourseInfo() {
      courseSetApi.getOneById(this.csId).then(resp => {
        this.coursedetail = resp.data
      })
    },
    // 视频左侧tab栏的选择展示
    seleted(i) {
      this.show = i
      this.isNavigation = i
      this.closeRightComponents = true
    },
    // 视频下面的问答、评论、同学笔记的选择展示
    showOne(index) {
      this.show = index
    }
  }
}
</script>
<style lang="scss" scoped>
.active > a {
	color: #e50112;
}
.bottomareaul {
	width: 100%;
	height: 68px;
	background: #fff;
	box-shadow: 0 4px 8px 0 rgba(28, 31, 33, 0.1);
	ul {
		width: 1152px;
		margin: 0 auto;
		padding: 12px 16px;
		line-height: 40px;
	}
}
.bottomareali {
	display: inline-block;
	font-size: 16px;
	color: #999;
	margin-left: 30px;
}
.bottomareali_active {
	border-bottom: 4px solid #e50012;
	color: #e50012;
}
.header_bg_area {
	padding: 15px 40px;
	height: 60px;
	background: #343434;
	line-height: 30px;
	font-size: 16px;
	.fz16 {
		font-size: 16px;
		font-weight: 700;
	}
}
.tab_fun_item {
	padding-top: 25px;
	.icon {
		width: 3em;
		height: 3em;
	}
}
.tab_fun_item:hover {
	.fun_icon,
	.fun_fz_sty {
		color: #e50012;
		font-weight: bold;
	}
}
.course-subcontainer {
	width: 1152px;
	margin: 0 auto;
	.course-left {
		float: left;
		position: relative;
		width: 800px;
		padding-top: 24px;
	}
}
.icon {
	width: 1em;
	height: 1em;
}
.collection_btn_styed {
	display: inline-block !important;
	padding: 0 15px !important;
	height: 36px;
	line-height: 30px !important;
	font-size: 14px !important;
	color: rgb(229, 0, 18) !important;
	border: 1px solid rgb(229, 0, 18) !important;
	border-radius: 20px !important;
}
.video_and_right {
	display: flex;
}
.video_son {
	order: 1;
	width: 100%;
	background-color: #333;
	position: relative;
}
.right_son {
	order: 2;
}
</style>
