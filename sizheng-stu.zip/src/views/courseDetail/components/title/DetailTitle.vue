<template>
  <div class="DetailTitle">
    <div class="bg_img_8" style="width:100%;">
      <div class="w1200 mar_auto" style="width:100%;  padding: 30px 8%;">
        <div class="fz17 cor_2 hidden-xs" style="width:100%;">
          <span>
            <router-link to="/" style="color: #fff">首页</router-link>
          </span>
          <em class="mar5">></em>
          <span>
            <router-link to="/coursehome" style="color: #fff">课程列表</router-link>
          </span>
          <em class="mar5">></em>
          <span class="cor_fff">课程详情</span>
        </div>
        <div class="mt30 cf" style="width:100%;">
          <el-row>
            <el-col :span="20">
              <div class="ov fl">
                <div class="cf">

                  <div class="ov" style="padding-right:25px;">
                    <div class style="width:100%;">
                      <span class="fz26 fwb cor_fff vm">{{ courseScheme.schemeTitle }}</span>
                      <!-- <span
                    class="ml15 label_sty_area_2"
                  >{{ getCourseStatus(courseScheme.schemeStatus) }}</span>-->
                    </div>
                    <!-- <p class="mt25 fz17 cor_fff">
                  学习进度
                  <span class="ml25">{{ studyRate }}</span>
                </p>-->
                  </div>

                  <div class="fr hidden-xs">
                    <div class="ml65 fl tac">
                      <p class="fz18 cor_fff">{{ courseScheme.hitCount }}</p>
                      <p class="mt15 fz15 cor_2">点击量</p>
                    </div>
                    <div v-if="courseScheme.isShowMemberCount" class="ml65 fl tac">
                      <p class="fz18 cor_fff">{{ courseScheme.buyCount }}</p>
                      <p class="mt15 fz15 cor_2">学习人数</p>
                    </div>
                    <div class="ml65 fl tac">
                      <p class="fz18 cor_fff">{{ getCourseTerm() }}</p>
                      <p class="mt15 fz15 cor_2">课程学期</p>
                    </div>
                    <div class="ml65 fl tac">
                      <p class="fz18 cor_fff">{{ getSchemeTitle() }}</p>
                      <p class="mt15 fz15 cor_2">授课计划</p>
                    </div>
                  </div>

                </div>
              </div>
            </el-col>
            <el-col :span="4" class="mt30">
              <div class="fr" @click="enterCourse()">
                <span class="btn_3">{{ learnStatus }}</span>
              </div>
            </el-col>
          </el-row>

          <!--进度条-->
          <!-- <div class="mt15 cf mt" style="width:100%;">
            <div class="fr">
              <span class="ml15 db fz16 cor_81e" style="margin-top: -8px;">55%</span>
            </div>
            <div class="ov">
              <div class="progress_bar_area_2">
                <span class="speed_progress_sty" :class="{rate}"></span>
              </div>
            </div>
          </div>-->
        </div>
        <center>
          <div class="visible-xs mt15" style="width:225px;">
            <div class="fl tac">
              <p class="fz18 cor_fff">{{ coursedetail.duration }}课</p>
              <p class="mt15 fz15 cor_2">课程</p>
            </div>
            <div class="ml65 fl tac">
              <p class="fz18 cor_fff">{{ coursedetail.hitCount }}</p>
              <p class="mt15 fz15 cor_2">点击量</p>
            </div>
            <div class="ml65 fl tac">
              <p class="fz18 cor_fff">{{ coursedetail.studentCount }}</p>
              <p class="mt15 fz15 cor_2">学习人数</p>
            </div>
          </div>
        </center>
      </div>
      <!--w1200-->
    </div>
    <!--bg_img_8-->
  </div>
</template>
<script>
import studyLogApi from '@/api/course/courseTask/studyLog'
import courseMemberApi from '@/api/course/courseManage/courseMember'
import courseTermApi from '@/api/course/courseManage/courseTerm'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import { mapGetters } from 'vuex'
export default {
  name: 'DetailTitle',
  props: {
    coursedetail: {
      type: Object,
      required: true
    },
    courseTerm: {
      type: Object,
      required: true
    },
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      studyRate: '第二节',
      rate: '',
      courseSchemes: [{ 'schemeId': 0, 'schemeTitle': '请先选择课程学期' }],
      dropdown: '课程学期',
      dropScheme: '授课计划',
      ctId: parseInt(this.$route.params.ctId),
      csId: parseInt(this.$route.params.csId),
      schemeId: parseInt(this.$route.params.schemeId),
      learnStatus: '课程已关闭'
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {
    if (this.courseTerm != null) {
      this.dropdown = this.courseTerm.courseTerm
    }
    const schemeId = this.$route.params.schemeId
    this.schemeId = schemeId
    if (this.courseSchemes != null && this.courseSchemes.length !== 0) {
      const course = this.courseSchemes.find(item => item.schemeId === schemeId)
      if (course != null) {
        this.dropScheme = course.schemeTitle
      }
    }
    // schemeId != null && schemeId !== '' && schemeId !== undefined
    this.getLearnStatus()
  },
  methods: {
    returnLearnStatus(status) {
      this.$emit('returnLearnStatus', status)
    },
    // 判断该用户是否加入了该课程计划
    getLearnStatus() {
      // console.log('getLearnStatus')
      // 判断授课计划的是否允许加入
      // 从分组分头学员中查找，根据userId,,schemeId
      const courseMember = {}
      courseMember.userId = this.$store.getters.user.userId
      courseMember.schemeId = parseInt(this.$route.params.schemeId)
      courseMemberApi.isJoinCourseScheme(courseMember).then(response => {
        const result = response.data
        console.log('result = ', result)
        if (response.msg === 'success') {
          if (!result) {
            // 为true，则表示没有加入计划
            this.learnStatus = '立即参加'
            this.returnLearnStatus('立即参加')
          } else {
            this.learnStatus = '进入学习'
            this.returnLearnStatus('进入学习')
          }
        } else {
          this.learnStatus = '课程已关闭'
          this.returnLearnStatus('课程已关闭')
          // this.$message({
          //   type: 'warning',
          //   message: response.msg
          // })
        }
      })
    },
    // 进入课程
    enterCourse() {
      if (this.learnStatus === '立即参加') {
        this.immediatelyJoin()
      } else if (this.learnStatus === '进入学习') {
        this.continueLearning()
      }
    },
    // 立即参加，需要先判断有无密码
    immediatelyJoin() {
      if (this.courseScheme.isAllowedJoin && this.learnStatus === '立即参加') {
        this.addDefaultCourseMember()
      } else {
        // 加入密码为空，和上面一样，否则输入密码
        if (this.courseScheme.joinPassword === '') {
          this.addDefaultCourseMember()
        } else {
          this.inputPassword()
        }
      }
    },
    /** 输入加入课程密码 */
    inputPassword() {
      this.$prompt('请输入加入课程的密码', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        // 验证计划下的课程密码
        const scheme = {}
        scheme.schemeId = this.courseScheme.schemeId
        scheme.joinPassword = value
        courseSchemeApi
          .validateJoinPassword()
          .then(response => {
            const result = response.data
            if (result) {
              this.$message({
                message: '密码正确',
                type: 'success'
              })
              // 输入密码后加入课程
              this.learnStatus === '进入学习'
              this.continueLearning()
            } else {
              this.$message({
                message: '密码不正确',
                type: 'error'
              })
            }
          }).catch(err => {
            console.log(err)
          })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消输入'
        })
      })
    },
    // 立即加入（计划的学员分组中加入该学员），无需密码
    addDefaultCourseMember() {
      const user = this.$store.getters.user
      // 根据userId,stuId,realName,schemeId,添加到默认分组里
      const courseMember = {}
      courseMember.userId = user.userId
      courseMember.stuId = user.stuId
      courseMember.realName = user.realName
      courseMember.orgId = user.orgId
      courseMember.schemeId = this.courseScheme.schemeId
      courseMemberApi
        .joinCourseMember(courseMember)
        .then(response => {
          const result = response.data
          if (result) {
            this.$message({
              message: '加入成功',
              type: 'success'
            })
            this.learnStatus = '进入学习'
            this.returnLearnStatus('进入学习')
            this.continueLearning()
          } else {
            this.$message({
              message: '加入失败',
              type: 'error'
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    getSchemeTitle() {
      return this.courseScheme.schemeTitle
    },
    getCourseTerm() {
      return this.courseTerm.courseTerm
    },
    // 获取dropScheme
    getDropScheme() {
      if (this.courseScheme != null) {
        return this.courseScheme.schemeTitle
      }
      return this.dropScheme
    },
    // 获取dropdown
    getDropdown() {
      if (this.courseTerm != null) {
        return this.courseTerm.courseTerm
      }
      return this.dropdown
    },
    // 点击继续学习跳转
    continueLearning() {
      var data = {
        userId: this.user.userId,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        stuId: this.user.stuId,
        realName: this.user.realName
      }
      studyLogApi.getStudyLogBySchemeIdUserId(data).then(result => {
        if (result.data.studyLogId !== null) {
          this.$router.push(`/ContinueLearning/cs/${this.courseScheme.csId}/term/${this.courseScheme.ctId}/scheme/${this.courseScheme.schemeId}/courseStudyLog/${result.data.studyLogId}`)
        }
      })
    },
    // 获取课程学期
    getDropdown2(dropdown) {
      if (dropdown !== '课程学期') {
        return dropdown
      }
      const ctId = this.$route.params.ctId
      this.ctId = ctId
      if (ctId != null && ctId !== '' && ctId !== undefined) {
        let arr = []
        courseTermApi.getCourseTermById(ctId).then(resp => {
          arr = resp.data
        })
        return arr.find(item => item.ctId === ctId)
      } else {
        return '课程学期'
      }
    },
    // 课程学期下拉菜单触发
    handleCommand(command) {
      // this.$message('click on item ' + command)
      this.dropdown = command.courseTerm
      this.ctId = command.ctId
      if (this.ctId === undefined) {
        return
      }
      // 根据ctId，获取授课方案
      courseSchemeApi.getCourseSchemeByCourseTermId(this.ctId).then(resp => {
        // console.log('resp.data = ', resp.data)
        if (resp.data === [] || resp.data.length === 0) {
          this.courseSchemes = [{ 'schemeId': 0, 'schemeTitle': '该课程学期下没有教学计划' }]
          return
        }
        this.courseSchemes = resp.data
      })
    },
    // 授课方案下拉菜单触发
    handleScheme(command) {
      if (command.schemeId === 0) {
        return
      }
      this.schemeId = command.schemeId
      // this.$message('click on item ' + command)
      this.dropScheme = command.schemeTitle
      // 根据schemeId，获取课程信息（目录，讨论等）
      // 路由跳转
      this.$router.push({  // 核心语句
        path: `/courseSet/${this.csId}/term/${this.ctId}/scheme/${command.schemeId}`   // 跳转的路径
      })
    },
    getCourseStatus(status) {
      console.log('stauts = ', status)
      switch (status) {
        case '0': return '未发布'
        case '1': return '已发布'
        case '2': return '已关闭'
      }
    },
    routeCourseManger(course) {
      this.$router.push({  // 核心语句
        path: `/coursedetail/${course.csId}`   // 跳转的路径
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.el-dropdown-link {
  cursor: pointer;
  color: #fff;
}
.el-icon-arrow-down {
  font-size: 12px;
}
.fr {
  // TODO： 触摸小手
  cursor: pointer;
}
.ml65 {
  display: inline-block;
  margin-left: 20px !important;
  margin-top: 30px;
  text-align: center;
}
@media screen and (max-width: 576px) {
  .fz26 {
    font-size: 14px;
  }
  .fz18 {
    font-size: 14px;
  }
  .fz15 {
    font-size: 12px;
  }
  .w80 {
    width: 70%;
  }
  .btn_3 {
    font-size: 14px;
    padding: 0 15px;
    height: 30px;
    line-height: 30px;
  }
  .label_sty_area_2 {
    padding: 0 10px;
    height: 18px;
    line-height: 18px;
    font-size: 12px;
  }
  .progress_bar_area_2 {
    height: 3px;
  }
  .fz17 {
    font-size: 12px;
  }
  .mt {
    margin-top: 60px;
  }
  .bg_img_8 {
    height: 200px;
  }
}
@media screen and (max-width: 768px) {
  .w80 {
    width: 70%;
  }
  .mt30 {
    margin-top: -25px;
  }
  .mt25 {
    margin-top: 10px;
  }
}
@media screen and (min-width: 576px) {
  .mt {
    margin-top: 85px;
  }
}
.DetailTitle {
  width: 100%;
}
.rate {
  width: 55%;
}
.ml65 {
  margin-left: 10%;
}
</style>
