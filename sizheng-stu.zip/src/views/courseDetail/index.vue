<!--
@description 课程详情页
@author cgy
-->
<template>
  <div id="courseDetail">
    <!-- 顶级导航 -->
    <Header />
    <!-- 首页>课程列表>课程详情 -->
    <Nav />
    <!-- 课程详情头部 -->
    <DetailTitle
      :coursedetail="coursedetail"
      :course-term="courseTerm"
      :course-scheme="courseScheme"
      @returnLearnStatus="returnLearnStatus"
    />
    <!-- 课程介绍，公告，目录，作业，测验，练习，考试，资料区，评价 -->
    <CourseContent
      :coursedetail="coursedetail"
      :course-term="courseTerm"
      :course-scheme="courseScheme"
      :course-terms="courseTerms"
      :status="status"
    />
  </div>
</template>
<script>
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import courseTermApi from '@/api/course/courseManage/courseTerm'
import courseSetApi from '@/api/course/courseManage/courseSet'
import Header from '@/components/header'
import Nav from '@/components/nav'
import CourseContent from './components/content/index'
import DetailTitle from './components/title/DetailTitle'
export default {
  name: 'CourseScheme',
  components: {
    DetailTitle,
    CourseContent,
    Header,
    Nav
  },
  data() {
    return {
      status: '',
      coursedetail: {},
      courseTerm: {},
      courseScheme: {},
      courseTerms: []
    }
  },
  created() {
    // 获取课程详情
    this.setRouteCourse()
  },
  methods: {
    // 获得子组件DetailTitle的学习状态
    returnLearnStatus(status) {
      console.log('returnLearnStatus(status) = ', status)
      this.status = status
    },
    setRouteCourse() {
      // 获取课程详情
      const csId = parseInt(this.$route.params.csId)
      console.log('csId = ', csId)
      courseSetApi.getOneById(csId).then(resp => {
        this.coursedetail = resp.data
      })
      courseTermApi.getTermPageByCId(csId, 1, 10).then(resp => {
        this.courseTerms = resp.data.list
      })
      const ctId = this.$route.params.ctId
      if (csId != null && csId !== undefined) {
        courseTermApi.getCourseTermById(ctId).then(resp => {
          this.courseTerm = resp.data
          // this.courseTerm = { 'ctId': this.courseTerms[0].ctId, 'courseTerm': this.courseTerms[0].courseTerm }
        })
      }
      const schemeId = this.$route.params.schemeId
      if (schemeId != null && schemeId !== undefined) {
        courseSchemeApi.getOneById(schemeId).then(resp => {
          this.courseScheme = resp.data
          // this.courseTerm = { 'ctId': this.courseTerms[0].ctId, 'courseTerm': this.courseTerms[0].courseTerm }
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.courseDetail {
  width: 100%;
}
</style>
