<template>
  <!-- 课程分类 -->
  <div id="AllCourses">
    <div class="box">
      <div class="bg_img_6">
        <div class="w1200 mar_auto">
          <div class="pt60 re">
            <!-- 头部，搜索 -->
            <div id="head">
              <div class="tac" style="text-align: center;">
                <p class="dian_title_area">全部课程</p>
              </div>
              <!--搜索-->
              <div class="search_area_pos">
                <div class="cf">
                  <div class="fr">
                    <a class="search_btn_sty_2" @click="search">搜索</a>
                  </div>
                  <div class="re ov">
                    <input
                      v-model="queryParams.courseTitle"
                      type="text"
                      placeholder="搜索感兴趣的课程"
                      class="search_ipt_sty_2"
                    />
                    <i class="ico_search_sty_2"></i>
                  </div>
                </div>
              </div>
            </div>
            <!-- 分类 -->
            <div id="class">
              <div class="filter_sup_area">
                <!-- 分类1 方向 -->
                <div class="pt15 pb15 cf bb1">
                  <p class="box_title">{{ className1 }}：</p>
                  <!-- <div class="fl w133">
          <a href="javascript:void(0);" class="type_btn" style="padding: 0 20px;">全部</a>
                  </div>-->
                  <div class="ov">
                    <ul class="fl_dib" style="text-align: left;">
                      <li v-for="(item, index) in categoryOptions" :key="index">
                        <a
                          class="box_item"
                          :class="{ active: num1 == index }"
                          @click="selected1(index)"
                        >{{ item.label }}</a>
                      </li>
                    </ul>
                  </div>
                </div>
                <!-- 分类2 分类 -->
                <div class="pt15 pb15 cf bb1">
                  <p class="box_title">{{ className2 }}：</p>
                  <!-- <div class="fl w133">
          <a href="javascript:void(0);" class="type_btn" style="padding: 0 20px;">全部</a>
                  </div>-->
                  <div class="ov">
                    <ul class="fl_dib" style="text-align: left;">
                      <li v-for="(item, index) in categoryOthers" :key="index">
                        <a
                          class="box_item"
                          :class="{ active: num2 == index }"
                          @click="selected2(index)"
                        >{{ item.label }}</a>
                      </li>
                    </ul>
                  </div>
                </div>
                <!-- 分类3 学校 -->
                <div class="pt15 pb15 cf bb1">
                  <p class="box_title">{{ className3 }}：</p>
                  <!-- <div class="fl w133">
          <a href="javascript:void(0);" class="type_btn" style="padding: 0 20px;">全部</a>
                  </div>-->
                  <div class="ov">
                    <ul class="fl_dib" style="text-align: left;">
                      <li v-for="(item, index) in orgOptions" :key="index">
                        <a
                          class="box_item"
                          :class="{ active: num3 == index }"
                          @click="selected3(index)"
                        >{{ item.orgName }}</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <!--filter_sup_area-->
            </div>
            <!-- 排序 -->
            <!-- <Sort /> -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import categoryApi from '@/api/course/cateTag/category'
import orgApi from '@/api/user/org'
export default {
  name: 'AllCourses',
  components: {
    // Head
    // Class,
    // Sort
  },
  props: {},
  data() {
    return {
      num1: 0,
      num2: 0,
      num3: 0,
      className1: '方向',
      className2: '分类',
      className3: '学校',
      categoryOthers: [],
      categoryOptions: [],
      orgOptions: [],
      categoryTree: [],
      queryParams: {
        orgId: null,
        cateId: null,
        courseTitle: ''
      }
    }
  },
  computed: {
    // eslint-disable-next-line vue/no-dupe-keys
    acticeClass() {
      return this.num
    }
  },
  created() {
    this.setCate(this.categoryOthers)
    const all = { cateId: 0, label: '全部' }
    // 获取学校
    orgApi.getNextOrgList().then(result => {
      this.orgOptions = result.data
      this.orgOptions[0].orgName = '全部'
    })
    // 根据查询条件查询文章类别树形列表
    categoryApi.getTree().then(result => {
      this.categoryTree = result.data
    })
    // 一级课程分类
    categoryApi.getCateNameList().then(result => {
      this.categoryOptions = [all, ...result.data]
    })
    // 非一级课程分类
    categoryApi.getCateNameOthersList().then(result => {
      this.categoryOthers = [all, ...result.data]
    })
  },
  methods: {
    search() {
      this.$emit('getList', this.queryParams)
    },
    selected1: function(index) {
      // console.log('index = ', index)
      this.num1 = parseInt(index)
      const all = { cateId: 0, label: '全部' }
      const i = parseInt(index)
      const categoryOthers = this.categoryTree[this.num1 - 1].children
      this.queryParams.cateId = this.categoryOptions[i].cateId
      if (categoryOthers === undefined) {
        this.categoryOthers = [all]
      } else {
        this.categoryOthers = [all, ...categoryOthers]
      }
      this.$emit('getList', this.queryParams)
    },
    selected2: function(index) {
      this.num2 = parseInt(index)
      const i = parseInt(index)
      this.queryParams.cateId = this.categoryOthers[i].id
      this.$emit('getList', this.queryParams)
    },
    selected3: function(index) {
      this.num3 = parseInt(index)
      const i = parseInt(index)
      this.queryParams.orgId = this.orgOptions[i].orgId
      this.$emit('getList', this.queryParams)
    },
    setCate(array) {
      this.categoryOthers = array
    }
  }
}
</script>
<style lang="scss" scoped>
a {
  cursor: pointer;
}

@media screen and (max-width: 1200px) {
  .w1200 {
    width: 100%;
  }
}
@media screen and (min-width: 1200px) {
  .w1200 {
    width: 1200px;
  }
}
@media screen and (min-width: 950px) {
  .search_area_pos {
    position: absolute;
  }
}
@media screen and (max-width: 950px) {
  .search_area_pos {
    width: 297px;
    margin-top: 13px;
    margin-left: 28%;
  }
  .search_btn_sty_2 {
    width: 70px;
  }
  .dian_title_area {
    margin-left: 80%;
  }
  .w1200 {
    width: 297px;
  }
}
.active {
  color: #d30027;
  border: 1px solid #f47681;
  border-radius: 13px;
  background: #fff;
}
@media screen and (max-width: 768px) {
  .pt15 {
    margin-top: 10px;
  }
  .pb15 {
    margin-bottom: 10px;
  }
  .cf {
    zoom: 0;
    display: -webkit-box;
    display: -moz-box;
    display: -o-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    width: 100%;
  }
  .bb1 {
    border-bottom: 0;
  }
  .box_title {
    display: block;
    -moz-box-flex: 1;
    -o-box-flex: 1;
    -webkit-box-flex: 1;
    -ms-flex: 1;
    -webkit-flex: 1;
    -flex-flex: 1;
    flex: 1;
  }
}
@media screen and (max-width: 1200px) {
  .w1200 {
    width: 100%;
  }
}
@media screen and (min-width: 1200px) {
  .w1200 {
    width: 1200px;
  }
}
</style>
