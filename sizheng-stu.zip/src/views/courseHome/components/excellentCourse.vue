<template>
  <!--精品课程-->
  <div class="exelentCourse">
    <div class="w1200 mar_auto">
      <li
        v-for="(course, index) of courseSetData.slice(
          (pageNum - 1) * pageSize,
          pageNum * pageSize
        )"
        :key="index"
      >
        <el-row v-loading="loading" :gutter="50">
          <div class="mt30 cf">
            <el-col
              :xs="{ span: 6, offset: 1 }"
              :sm="{ span: 6, offset: 1 }"
              :md="{ span: 6, offset: 1 }"
              :lg="{ span: 6, offset: 0.5 }"
              :xl="{ span: 6, offset: 0.5 }"
            >
              <div class="fl">
                <div class="re">
                  <img
                    v-if="course.courseCover != null && course.courseCover!= ''"
                    :src="'http://fileserver:8888/' + course.courseCover"
                    class="img22"
                    alt
                    onerror="this.src='http://fileserver:8888/group1/M00/00/00/J2Ouul7sNO6AGINfAAAKhBa2VH8659.png';this.onerror = null"
                  />
                  <img v-else class="img22" src="@/assets/images/course.png" />
                </div>
              </div>
            </el-col>
            <el-col
              :xs="8"
              :sm="{ span: 11, offset: 0 }"
              :md="{ span: 13, offset: 0 }"
              :lg="{ span: 15, offset: 0 }"
              :xl="{ span: 16, offset: 0 }"
            >
              <div class="dit">
                <div class="course_study_sel_2">
                  <p class="fz20 fwb cor_3">
                    <span class="vm">{{ course.schemeTitle }}</span>
                    <span class="ml15 label_sty_area">精品课程</span>
                  </p>
                  <p
                    class="mt10 fz15 lh24 cor_2 clamp_2"
                    style="text-align: left;overflow:hidden"
                    v-html="course.briefIntroduction"
                  >{{ course.briefIntroduction }}</p>
                  <div class="mt25 cf">
                    <div class="fr">
                      <div
                        class="look_btn_sty"
                        style="cursor:pointer;"
                        @click="getRouteCourse(course)"
                      >立即查看</div>
                    </div>
                    <div class="ov">
                      <p class="fz16 cor_bdb lh40">
                        <span class="ml5">{{ course.orgName }}</span>
                        <!-- <span class="ml15">共{{ course.duration }}课</span> -->
                      </p>
                      <p class="fz16 cor_bdb lh40">
                        <span class="ml20 mr10">
                          <i class="mr10 ico_people_sty"></i>
                          {{ course.studentCount == null ? 0 : course.studentCount }}报名
                        </span>
                        <span class="ml15 mr10">
                          {{ course.hitCount == null ? 0 : course.hitCount }}
                          <i class="mr10 ico_cai_sty"></i>
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </el-col>
          </div>
        </el-row>
      </li>
    </div>
    <!--w1200-->
    <!--分页-->
    <div class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageNum"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total"
        prev-text="上一页"
        next-text="下一页"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
    <!-- <div class="page_box mt30 pt25 mb10 tac">
      <a class="page_item_prev" href="#">上一页</a>
      <a class="page_item page_num page_current" title="" href="#">1</a>
      <a class="page_item page_num" title="" href="#">2</a>
      <a class="page_item page_num" title="" href="#">3</a>
      <a class="page_item page_num" title="" href="#">4</a>
      <a class="page_item page_num" title="" href="#">5</a>
      <a class="page_item_next" href="#">下一页</a>
    </div>-->
  </div>
  <!--精品课程-->
</template>
<script>
// import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import COURSE_CONST from '@/constant/course-const'
// import Videos from '@/views/videos/index'
export default {
  components: {
    // Videos
  },
  props: {
    courseSetData: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      pageNum: 1,
      pageSize: COURSE_CONST.PAGESIZE,
      loading: false,
      total: 1
    }
  },
  methods: {
    handleCurrentChange(val) {
      this.loading = false
      this.$emit('getList', null, val, this.pageSize)
    },
    // 打开详情
    getRouteCourse(course) {
      // console.log('course = ', course)
      // 根据默认计划ID获取默认计划
      // let courseScheme = null
      // const schemeId = course.defaultCourseScheme
      // 获取默认计划ID
      this.$router.push({  // 核心语句
        path: `/courseSet/${course.csId}/term/${course.ctId}/scheme/${course.schemeId}`   // 跳转的路径
      })
    }
  }
}
</script>
<style scoped>
/* 分页 */
.el-pager li.active {
  color: #e50112;
}
.el-pager li:hover {
  color: #e50112;
}
.el-pagination button,
.el-pagination span:hover {
  color: #e50112;
}
</style>

<style lang="scss" scoped>
/* 分页 */
.el-pager li.active {
  color: #e50112;
}
.el-pager li:hover {
  color: #e50112;
}
.el-pagination button,
.el-pagination span:hover {
  color: #e50112;
}
@media screen and (max-width: 689px) {
  .el-col-xs-6 {
    width: 100%;
  }
  .el-col-xs-8 {
    width: 100%;
  }
  .w1200 {
    width: 100%;
  }
}
@media screen and (max-width: 1200px) {
  .look_btn_sty {
    padding: 0 15px;
    height: 40px;
    line-height: 40px;
    font-size: 13px;
  }
}
@media screen and (max-width: 992px) {
  .look_btn_sty {
    padding: 0 12px;
    height: 40px;
    line-height: 40px;
    font-size: 10px;
  }
  .lh40 {
    line-height: 20px;
  }
}
@media screen and (min-width: 992px) {
  .ov {
    p {
      display: inline;
    }
  }
}
</style>
