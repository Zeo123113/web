<template>
  <!--高校共建共享联盟-->
  <div class="bg_img_4">
    <div class="w1200 mar_auto">
      <!-- w1200 -->
      <div class="pt60 re">
        <div class="tac" style="text-align: center">
          <span class="dian_title_area_3">高校共建共享联盟</span>
        </div>
      </div>
      <div class="mt30 pt60">
        <ul class="university_list fl_dib">
          <li v-for="(school, index) in schools" :key="index">
            <img :src="school.schoolPic" class="img_logo" alt="" />
          </li>
        </ul>
      </div>
    </div>
    <!--w1200-->
  </div>
  <!--高校共建共享联盟-->
</template>
<script>
export default {
  data() {
    return {
      /* currentPage: 1, // 初始页
      pageSize: 4, // 每页的数据 */
      schools: [
        {
          schoolPic: require('@/assets/images/ico_university_1.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_2.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_3.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_4.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_5.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_6.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_7.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_8.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_9.png') // 高校联盟图片
        },
        {
          schoolPic: require('@/assets/images/ico_university_10.png') // 高校联盟图片
        }
      ]
    }
  }
}
</script>
<style lang="scss" scoped>
@media screen and (max-width: 1200px) {
  .w1200 {
    width: 100%;
  }
}
@media screen and (min-width: 1200px) {
  .w1200 {
    width: 1200px;
  }
}
</style>
