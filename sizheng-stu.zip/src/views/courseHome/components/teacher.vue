<template>
  <div>
    <!--名师风采-->
    <el-col class="mt20">
      <el-col class="mar_auto">
        <!-- w1200删了 -->
        <el-row>
          <el-col class="pb10 cf lh38 cor_e10">
            <el-col>
              <div>
                <span class="fz30 fwb fl" style="margin-left: 8%;">名师风采</span>
                <!-- <div class="ov fr" style="margin-right: 8%;">
                  <a href="#" class="fz20 cor_e10">更多名师</a>
                </div>-->
              </div>
            </el-col>
          </el-col>
        </el-row>
      </el-col>
    </el-col>
    <ul class="mt45 famous_teacher_list_2 fl_dib">
      <el-row>
        <li v-for="(teacher, index) in teachers" :key="index">
          <a href="#" class="db">
            <div class="teacher_introduce">
              <el-col
                :xs="{ span: 24, offset: 1 }"
                :sm="{ span: 22, offset: 1 }"
                :md="{ span: 18, offset: 0 }"
                :lg="{ span: 16, offset: 0.5 }"
                :xl="{ span: 22, offset: 1 }"
              >
                <img v-if="teacher.avatar != null && teacher.avatar != ''" :src="'http://fileserver:8888/' + teacher.avatar" class="img23" alt />
                <img v-else class="img23" src="@/assets/images/course.png">
              </el-col>
              <el-col
                :xs="{ span: 24, offset: 1 }"
                :sm="{ span: 22, offset: 1 }"
                :md="{ span: 18, offset: 0 }"
                :lg="{ span: 16, offset: 0.5 }"
                :xl="{ span: 22, offset: 1 }"
              >
                <div class="pl20 pr20">
                  <p class="mt45 pb10 cor_3">
                    <span class="fz22">{{ teacher.teacherName }}</span>
                  </p>
                  <p class="fz12 cor_2">{{ teacher.jobTitle }}</p>
                  <p class="mt5 fz12 lh22 cor_2 clamp_2 introduce">{{ teacher.introduction }}</p>
                </div>
              </el-col>
            </div>
          </a>
        </li>
      </el-row>
    </ul>
  </div>
  <!--名师风采-->
</template>
<script>
import teacherTeamApi from '@/api/course/courseManage/teacherTeam'
export default {
  data() {
    return {
      /* currentPage: 1, // 初始页
      pageSize: 4, // 每页的数据 */
      teachers: [],
      topCount: 5
    }
  },
  created() {
    // 获取前topCount名的教师信息
    teacherTeamApi.getBySeqDesByTopCount(this.topCount).then(response => {
      this.teachers = response.data
    })
  }
}
</script>
<style lang="scss" scoped>
.introduce {
  text-indent: 1.4em;
  width: 100%;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
  line-height: 2rem;
  overflow: hidden;
  // height: 10rem;
  // text-overflow: ellipsis;
}
</style>

