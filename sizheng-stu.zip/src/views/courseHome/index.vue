<!--
@description 全部课程
@author cgy
-->
<template>
  <div id="courseHome">
    <Header />
    <Nav />
    <div class="box">
      <!-- <Banner /> -->
      <AllCourses @getList="getList" />
      <!-- 课程列表 -->
      <ExcellentCourses :course-set-data="courseSetData" @getList="getList" />
      <center>
        <!--名师风采-->
        <Teacher />
      </center>
      <SchoolShare />
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import COURSE_CONST from '@/constant/course-const'
// import Banner from '../main/components/banner'
import AllCourses from './components/allCourses/index'
import Teacher from './components/teacher'
import ExcellentCourses from './components/excellentCourse'
import SchoolShare from './components/schoolShare'
import Header from '@/components/header'
import Nav from '@/components/nav'
export default {
  name: 'CourseHome',
  components: {
    // Banner,
    AllCourses,
    ExcellentCourses,
    Teacher,
    SchoolShare,
    Header,
    Nav
  },
  data() {
    return {
      courseSetData: [],
      pageNum: 1,
      pageSize: COURSE_CONST.PAGESIZE,
      queryParams: {
        orgId: null,
        cateId: null,
        courseTitle: ''
      },
      total: 1,
      loading: true
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {
    // 页面初始化获取列表
    // this.queryParams.orgId = this.user.orgId
    this.getList(this.queryParams, this.pageNum, this.pageSize)
  },
  methods: {
    // 获取课程列表
    getList(queryParams, pageNum, pageSize) {
      if (queryParams == null) {
        queryParams = this.queryParams
      }
      if (pageNum == null || pageNum === undefined) {
        pageNum = 1
      }
      if (pageSize == null || pageSize === undefined) {
        pageSize = 5
      }
      courseSchemeApi.getCourseSchemeFrontList(queryParams, pageNum, pageSize).then(response => {
        this.courseSetData = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    }
  }
}
</script>
<style lang="scss" scoped>

</style>
