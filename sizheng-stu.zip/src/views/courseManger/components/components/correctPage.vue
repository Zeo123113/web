<template>
  <div class="js-testpaper-container container mt20">
    <div class="row">
      <div class="col-md-9 prevent-copy">
        <div class="testpaper-body js-testpaper-body" data-copy="0">
          <div class="es-section js-testpaper-heading">
            <div class="testpaper-titlebar clearfix">
              <h1 class="testpaper-title">
                <p class="testpaper-title__content" title="ewrweq" v-html="homeworkRecord.hwtitle"></p>
                <small class="text-sm">
                  答题人：{{ homeworkRecord.realName }}
                  交卷时间：{{ homeworkRecord.hwSubtime }}
                  是否已批阅：{{ homeworkRecord.isGrading? '是':'否' }}
                </small>
              </h1>
              <div class="testpaper-status">
                <div class="label label-info">{{ homeworkRecord.isGrading? '已批阅':'批阅中' }}</div>
              </div>
            </div>

            <div class="testpaper-description cke_editable cke_contents_ltr">
              <p>学号:{{ homeworkRecord.stuId }}</p>
            </div>
          </div>

          <form id="teacherCheckForm" autocomplete="off" novalidate="novalidate">
            <div class="panel panel-default">
              <div class="panel-heading">
                待批阅题目
                <small class="color-gray">共{{ recordList.length }}题</small>
              </div>

              <div class="panel-body">
                <div v-for="(item, index) in recordList" :key="index" class="question-set-items">
                  <div v-if="item.tqTypeId.toString() === material" class="material">
                    <div
                      id="question8"
                      class="well testpaper-question-stem-material js-testpaper-question-stem-material"
                      v-html="item.content"
                    ></div>
                    <div class="mbm">
                      <div
                        class="testpaper-question-analysis js-testpaper-question-analysis"
                        style="display: none;"
                      >
                        <div class="well mb0">无解析</div>
                      </div>
                    </div>

                    <div
                      v-for="(materialItem, materialIndex) in item.materialQuestions"
                      id="question9"
                      :key="materialIndex"
                      class="testpaper-question testpaper-question-essay js-testpaper-question"
                      data-watermark-url="/cloud/testpaper_watermark"
                    >
                      <div class="testpaper-question-body">
                        <div class="clearfix">
                          <div class="testpaper-question-seq-wrap">
                            <div class="testpaper-question-seq">{{ item.tqSeq }}.{{ materialItem.tqSeq }}</div>
                          </div>
                          <div class="testpaper-question-stem" v-html="materialItem.content"></div>
                          （{{ materialItem.value }}分）
                        </div>
                      </div>

                      <div class="testpaper-question-footer clearfix">
                        <div class="testpaper-question-result">
                          <ul class="nav nav-pills nav-mini mbm">
                            <li class="active">
                              <a href="#studentAnswer9" data-toggle="tab" @click="materialItem.lookAnswer = false">学员回答</a>
                            </li>
                            <li>
                              <a href="#teacherAnswer9" data-toggle="tab" @click="materialItem.lookAnswer = true">参考答案</a>
                            </li>
                          </ul>
                          <div class="tab-content mbl">
                            <div v-if="!materialItem.lookAnswer" id="studentAnswer9" class="tab-pane active">
                              <p v-html="materialItem.userAnswer"></p>
                            </div>
                            <div v-else id="teacherAnswer9" class="tab-pane">{{ materialItem.answer }}</div>
                          </div>

                          <div class="form-horizontal">
                            <div class="form-group">
                              <label class="col-sm-2 control-label">得分</label>
                              <div class="col-sm-8 controls">
                                <!-- <el-input
                                  v-model="materialItem.score"
                                  type="number"
                                  max="100"
                                  min="0"
                                  class="form-control width-150"
                                  placeholder="得分"
                                  name="score_9"
                                  data-score="0.0"
                                  data-type="essay"
                                  data-id="9"
                                  value
                                /> -->
                                <el-input-number v-model="materialItem.score" controls-position="right" :min="0" :max="materialItem.value" :step="0.5" @change="toGrade(item)"></el-input-number>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    v-if="item.tqTypeId.toString() !== material"
                    id="question4"
                    class="testpaper-question testpaper-question-essay js-testpaper-question"
                    data-watermark-url="/cloud/testpaper_watermark"
                  >
                    <div class="testpaper-question-body">
                      <div class="clearfix">
                        <div class="testpaper-question-seq-wrap">
                          <div class="testpaper-question-seq">{{ item.tqSeq }}</div>
                        </div>
                        <div class="testpaper-question-stem" v-html="item.content"></div>
                        （{{ item.value }}分）
                      </div>
                    </div>

                    <div class="testpaper-question-footer clearfix">
                      <div class="testpaper-question-result">
                        <ul class="nav nav-pills nav-mini mbm">
                          <li class="active">
                            <a href="#studentAnswer4" data-toggle="tab" @click="item.lookAnswer = false">学员回答</a>
                          </li>
                          <li>
                            <a href="#teacherAnswer4" data-toggle="tab" @click="item.lookAnswer = true">参考答案</a>
                          </li>
                        </ul>
                        <div class="tab-content mbl">
                          <div v-if="!item.lookAnswer" id="studentAnswer4" class="tab-pane active">
                            <p v-html="item.userAnswer"></p>
                          </div>
                          <div v-if="item.lookAnswer" id="teacherAnswer4" class="tab-pane" v-html="item.answer"></div>
                        </div>

                        <div class="form-horizontal">
                          <div class="form-group">
                            <label class="col-sm-2 control-label">得分</label>
                            <div class="col-sm-8 controls">
                              <!-- <input
                                v-model="item.score"
                                type="text"
                                class="form-control width-150"
                                placeholder="得分"
                                name="score_4"
                                data-score="0.0"
                                data-type="essay"
                                data-id="4"
                                value
                              /> -->
                              <el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.5" @change="toGrade(item)"></el-input-number>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="col-md-3">
        <input type="hidden" value="25" class="js-used-time" />
        <div class="testpaper-card js-testpaper-card">
          <div class="panel panel-default">
            <div class="panel-heading">答题卡</div>
            <div class="panel-body">
              <div class="js-panel-card panel-card">
                <span
                  v-for="(item, index) in recordList"
                  :key="index"
                  href="javascript:;"
                  data-anchor="#question4"
                  class="js-btn-index color-lump mrm mbm js-answer-notwrong"
                  :class="item.grader != null? 'bg-success':'bg-warning'"
                >
                  <i
                    class="text-12 glyphicon glyphicon-bookmark marking-card js-marking-card hidden"
                  ></i>
                  {{ item.tqSeq }}
                </span>
                <div class="testpaper-card-explain clearfix">
                  <a href="javascript:;" class="color-lump lump-xs bg-success"></a>
                  <small class="color-gray mls">已批阅</small>
                  <a href="javascript:;" class="color-lump lump-xs bg-warning"></a>
                  <small class="color-gray mls">待批阅</small>
                </div>
              </div>
            </div>

            <div class="panel-footer text-right">
              <a class="btn btn-success" data-role="check-submit" @click="submit()">完成批阅</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div
      id="time-pause-dialog"
      class="modal fade"
      data-backdrop="static"
      tabindex="-1"
      role="dialog"
      aria-hidden="true"
    >
      <!-- <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-body task-state-modal">
            <div class="title font-blod">
              <i class="es-icon es-icon-zanting1 color-warning"></i>暂停
            </div>
            <div class="content">
              <div class="text-16">考试已暂停，请尽快回来哦！</div>
            </div>
            <div class="text-right mt20">
              <a class="btn btn-primary js-btn-resume" href="javascript:;">继续考试</a>
            </div>
          </div>
        </div>
      </div>-->
    </div>
  </div>
</template>
<script>
import assignApi from '@/api/exambank/homework-arrange'
import EXAMBANK_CONST from '@/constant/exambank-const'
import homeworkRecordApi from '@/api/exambank/homework-record'
export default {
  data() {
    return {
      recordList: [],
      material: EXAMBANK_CONST.MATERIAL,
      homeworkRecord: {}
    }
  },
  created() {
    const hwId = this.$route.params.hwId
    const stuUserId = this.$route.params.stuUserId
    assignApi.selectListBeforeCorrect(hwId).then(resp => {
      this.recordList = resp.data
    })
    this.homeworkRecord = {
      stuUserId: stuUserId,
      hwId: this.$route.params.hwId
    }
    homeworkRecordApi.selectHomeworkRecordListByUserId(this.homeworkRecord).then(resp => {
      this.homeworkRecord = resp.data[0]
      console.log(this.homeworkRecord)
    })
  },
  methods: {
    submit() {
      this.$confirm('是否提交批阅结果?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        assignApi.saveCorrect(this.recordList, this.homeworkRecord.hwrId).then(resp => {
          if (resp.code === 0) {
            this.$message({
              type: 'success',
              message: '提交成功!'
            })
            this.$router.back(-1)
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消提交'
        })
      })
    },
    // 为试题赋值评分者
    toGrade(questiton) {
      questiton.grader = this.user.realName
    }
  }
}
</script>
<style lang="scss" scoped>
.mt20 {
  margin-top: 20px !important;
}
@media screen and (min-width: 1200px) {
  .container {
    width: 1160px;
  }
}

// @media (min-width: 992px) {
//   .container {
//     width: 960px;
//   }
// }
// @media (min-width: 768px) {
//   .container {
//     width: 740px;
//   }
// }
.js-testpaper-body {
  line-height: 22px;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.56);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  font-family: Helvetica Neue, Helvetica, Arial, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, sans-serif;
  .es-section {
    background: #fff;
    padding: 15px;
    margin-bottom: 20px;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    border: 1px solid #e4ecf3;
    .testpaper-titlebar {
      border-bottom: 1px solid #ddd;
      margin-bottom: 20px;
      .testpaper-title {
        width: 85%;
      }
      .testpaper-status {
        margin-top: 20px;
        float: right;
      }
      .text-sm {
        font-size: 12px !important;
      }
      .testpaper-title {
        float: left;
        font-size: 24px;
        font-weight: 700;
        color: #444;
      }
    }
    .testpaper-description {
      color: #444;
      font-size: 14px;
    }
    .cke_editable {
      font-size: 13px;
      line-height: 1.6;
      word-wrap: break-word;
    }
  }
  .panel-default {
    padding: 0 15px;
    border-color: #e4ecf3;
    .panel-heading {
      position: relative;
      font-size: 16px;
      padding: 10px 0;
      line-height: 30px;
      background: #fff;
      border-bottom: 1px solid #f5f5f5;
    }
    .panel-heading {
      color: #616161;
      border-color: #e1e1e1;
    }
    .panel-heading {
      padding: 10px 15px;
      border-bottom: 1px solid transparent;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
    .panel-body {
      position: relative;
      padding: 15px 0;
      .testpaper-card .panel-card {
        position: relative;
        max-height: 270px;
        overflow: hidden;
        .color-lump {
          position: relative;
          display: inline-block;
          -webkit-border-radius: 4px;
          -moz-border-radius: 4px;
          border-radius: 4px;
          width: 30px;
          height: 30px;
          line-height: 30px;
          text-align: center;
          color: #fff;
          background-color: #e1e1e1;
        }
        .mbm {
          margin-bottom: 10px !important;
        }
        .mrm {
          margin-right: 10px !important;
        }
        .bg-warning {
          background-color: #ffa51f !important;
        }
      }
    }
    .panel-footer {
      padding: 15px 0;
      background: none;
      background-color: #fff;
    }
    .text-right {
      text-align: right !important;
    }
  }
  .panel-default {
    border-color: #e1e1e1;
  }
  .panel {
    margin-bottom: 20px;
    background-color: #fff;
    border: 1px solid transparent;
    border-radius: 4px;
  }
  .panel-default {
    padding: 0 15px;
    border-color: #e4ecf3;
    .panel-heading {
      position: relative;
      font-size: 16px;
      padding: 10px 0;
      line-height: 30px;
      background: #fff;
      border-bottom: 1px solid #f5f5f5;
      color: #616161;
      border-color: #e1e1e1;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
      .color-gray {
        color: #919191 !important;
      }
    }
    .panel-body {
      position: relative;
      padding: 15px 0;
      .testpaper-question:first-child {
        border-top: none;
      }
      .testpaper-question {
        position: relative;
        margin-bottom: 50px;
        font-size: 14px;
        border-top: 1px solid #ccc;
        padding-top: 20px;
        .testpaper-question-seq-wrap {
          float: left;
          width: 40px;
          margin-right: 10px;
          text-align: center;
          .testpaper-question-seq {
            font-size: 20px;
            color: #3a87ad;
          }
        }
        .testpaper-question-stem {
          margin-bottom: 10px;
          border-bottom: 1px dashed #ddd;
          overflow: hidden;
          zoom: 1;
        }
        .testpaper-question-footer {
          padding-left: 50px;
          .testpaper-question-essay .testpaper-question-result {
            float: none;
            .mbm {
              margin-bottom: 10px !important;
            }
            .nav {
              margin-bottom: 0;
              padding-left: 0;
              list-style: none;
            }
            .mbl {
              margin-bottom: 20px !important;
              .tab-content > .active {
                display: block;
              }
              .tab-content > .tab-pane {
                display: none;
              }
              p {
                margin: 0 0 10px !important;
              }
            }
            .form-horizontal .form-group {
              margin-bottom: 30px;
            }
            .form-horizontal .form-group {
              margin-left: -10px;
              margin-right: -10px;
            }
            .form-horizontal .control-label {
              text-align: right;
              margin-bottom: 0;
              padding-top: 7px;
            }
            .col-sm-2 {
              float: left;
              width: 16.66666667%;
            }
            .col-sm-9 {
              float: left;
              width: 75%;
            }
          }
        }
      }
    }
  }
  .panel {
    margin-bottom: 20px;
    background-color: #fff;
    border: 1px solid transparent;
    border-radius: 4px;
  }
}
.mbl {
  margin-top: 10px;
  margin-bottom: 20px !important;
}
.well {
  background-color: #fff !important;
}
.color-lump {
  position: relative;
  display: inline-block;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  width: 30px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  color: #fff;
  background-color: #e1e1e1;
}
.mbm {
  margin-bottom: 10px !important;
}
.mrm {
  margin-right: 10px !important;
}
.bg-warning {
  background-color: #ffa51f !important;
}
.bg-primary,
.bg-primary-hover:hover,
.bg-success {
  background-color: #5CB85C !important;
}
.color-lump.lump-card {
  color: #616161;
  border: 1px solid #e4ecf3;
  background-color: #fff;
}
.bg-danger {
  background-color: #ed3e3e !important;
}
.color-lump.lump-xs {
  width: 10px;
  height: 10px;
}
.testpaper-card-explain small {
  margin-right: 8px;
}
.mls {
  margin-left: 5px !important;
}
</style>
