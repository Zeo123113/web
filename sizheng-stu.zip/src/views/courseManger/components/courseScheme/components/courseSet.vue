<!--
@description 课时设置
@author cgy
-->
<template>
  <div class="courseSet">
    <div class="courseset-header-section">
      <div class="container cd-container">
        <!-- 顶部导航栏 -->
        <ol class="breadcrumb breadcrumb-o">
          <li class="text-overflow">
            <a @click="getRouteCourse">在教课程</a>
          </li>
          <li class="text-overflow courseset-header-section__breadcrumb">
            <a class="active">{{ coursedetail.courseTitle }}</a>
          </li>
        </ol>
        <!-- 课程展示栏 -->
        <div class="courseset-manage-header js-origin-header clearfix">
          <div class="clearfix js-origin-header-content">
            <img
              class="courseset-manage-header__img"
              :src="'http://fileserver:8888/' + coursedetail.courseCover"
              onerror="this.src='http://fileserver:8888/group1/M00/00/00/J2Ouul7sNO6AGINfAAAKhBa2VH8659.png';this.onerror = null"
            />
            <span
              class="course-publish-status"
              :class="{'course-publish-status--published': coursedetail.courseStatus === '1', 'course-publish-status--unpublished': coursedetail.courseStatus === '0'}"
            >{{ getCourseStatus(coursedetail.courseStatus) }}</span>

            <div class="courseset-manage-header-info">
              <div class="courseset-manage-header-info__title text-overflow">
                <span class="cd-dark-major">{{ coursedetail.courseTitle }}</span>
              </div>
              <div class="courseset-manage-header-info__price color-danger">
                <span class="money-symbol cd-text-sm">¥</span>
                <span
                  class="pure-price"
                >{{ coursedetail.originPrice == null ? '0' : coursedetail.originPrice }}</span>
              </div>
            </div>

            <div class="courseset-manage-header-btn">
              <!-- <a
                v-if="coursedetail.courseStatus == '0'"
                class="cd-btn cd-btn-default"
                target="_blank"
                @click="routeCourseDetail(coursedetail)"
              >预览课程</a>
              <button
                v-if="coursedetail.courseStatus == '0'"
                id="step-4"
                class="cd-btn cd-btn-primary cd-ml16 js-courseset-publish-btn"
                @click="publishCourse('0')"
              >发布课程</button> -->
              <!-- <button
                v-if="coursedetail.courseStatus == '1'"
                id="step-5"
                class="cd-btn cd-btn-primary cd-ml16 js-courseset-publish-btn"
                @click="routeCourseDetail(coursedetail)"
              >查看课程</button> -->
            </div>

            <div class="courseset-manage-header-data hidden-xs">
              <span class="cd-text-medium">课程学员</span>
              <div class="cd-mt16 cd-dark-major">
                <span
                  class="courseset-manage-header-data__num"
                >{{ coursedetail.studentCount == null ? 0 : coursedetail.studentCount }}</span>
              </div>
            </div>

            <div class="courseset-manage-header-data hidden-xs">
              <span class="cd-text-medium">课程计划</span>
              <div class="cd-mt16 cd-dark-major">
                <span class="courseset-manage-header-data__num">{{ coursedetail.schemes }}</span>
              </div>
            </div>
          </div>
        </div>
        <!-- 中部设置导航栏 -->
        <ul class="nav nav-tabs nav-header-section cd-mt24 clearfix">
          <div id="step-1" class="pull-left nav-header-section-step">
            <li class="nav-header-section__item" :class="{'nav_active': active == 'CourseNav'}">
              <a class="nav-header-section__link" @click="clickState('CourseNav')">课程信息</a>
            </li>
          </div>
          <div id="step-4" class="pull-left nav-header-section-step">
            <li class="nav-header-section__item" :class="{'nav_active': active == 'AllTerm'}">
              <a class="nav-header-section__link" @click="clickState('AllTerm')">全部学期</a>
            </li>
          </div>
          <div id="step-5" class="pull-left nav-header-section-step">
            <li class="nav-header-section__item" :class="{'nav_active': active == 'AllScheme'}">
              <a class="nav-header-section__link" @click="clickState('AllScheme')">全部计划</a>
            </li>
          </div>

          <div class="clearfix nav-header-section-step">
            <li
              class="nav-header-section__item pull-right cd-mr32"
              :class="{'nav_active': active == 'QuestionBank'}"
            >
              <a @click="clickState('QuestionBank')">课程题库</a>
            </li>

            <li
              class="nav-header-section__item pull-right"
              data-intro-group="odd"
              :class="{'nav_active': active == 'coursePaperManger'}"
            >
              <a @click="clickState('coursePaperManger')">课程试卷</a>
            </li>

            <li
              id="step-5"
              class="nav-header-section__item pull-right cd-ml24"
              data-intro-group="odd"
              :class="{'nav_active': active == 'CourseMaterial'}"
            >
              <a @click="clickState('CourseMaterial')">文件管理</a>
            </li>
          </div>
        </ul>
        <!-- 下面内容区(左侧导航栏) -->
        <!-- main内容 -->
        <component
          :is="state"
          :coursedetail="coursedetail"
          :course-term="courseTerm"
          @getSchemeByTerm="getSchemeByTerm"
        />
      </div>
    </div>
  </div>
</template>
<script>
import CourseMaterial from './topNav/courseMaterial/index'
import coursePaperManger from './topNav/coursePaperManger/index'
import AllTerm from './topNav/allTerm'
import AllScheme from './topNav/allScheme'
import courseSetApi from '@/api/course/courseManage/courseSet'
import SchemeSetting from './topNav/SchemeSetting'
import CourseNav from './topNav/courseNav'
import CourseTerm from './leftNav/TermSetting'
import QuestionBank from './topNav/question_bank/index'
export default {
  name: 'CourseSet',
  components: {
    SchemeSetting,
    CourseNav,
    CourseTerm,
    AllTerm,
    AllScheme,
    CourseMaterial,
    coursePaperManger,
    QuestionBank
  },
  props: {
    courseState: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      // 绿色下划线
      active: 'CourseNav',
      state: 'CourseNav',
      coursedetail: {},
      courseStatusOptions: [],
      courseTerm: {}
    }
  },
  created() {
    // 获取课程详情
    this.setRouteCourse()
    this.getState()
  },
  methods: {
    // allTerm中的查询计划,组件切换到AllScheme，并传递courseTerm
    getSchemeByTerm(courseTerm) {
      // 获取该学期下的授课计划
      this.courseTerm = { ...courseTerm }
      this.clickState('AllScheme')
    },
    getCourseState() {
      // 获取课程组件
      const setstate = this.$route.params.setstate
      // console.log('state = ', state)
      if (setstate != null && setstate !== undefined && setstate !== '') {
        this.state = setstate
      }
    },
    // 获取组件
    getState() {
      // this.state = this.courseState
      if (this.courseState === 'AllTerm') {
        this.clickState('AllTerm')
      } else if (this.courseState === 'AllScheme') {
        this.clickState('AllScheme')
      }
    },
    getCourseStatus(status) {
      switch (status) {
        case '0': return '未发布'
        case '1': return '已发布'
        case '2': return '已关闭'
      }
    },
    // 课程发布状态转成中文
    getStatus() {
      this.coursedetail.courseStatus = this.selectDictLabel(this.courseStatusOptions, this.coursedetail.courseStatus)
      // console.log('this.coursedetail.courseStatus = ', this.coursedetail.courseStatus)
    },
    // 发布课程
    publishCourse(courseStatus) {
      this.$confirm('是否确定发布该课程?', '发布课程', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info'
      }).then(() => {
        // 数据库修改课程发布状态
        this.coursedetail.courseStatus = courseStatus
        courseSetApi.updateCourseSet(this.coursedetail).then(result => {
          if (result.code === 0) {
            this.$message({
              type: 'success',
              message: '课程发布成功'
            })
          } else {
            this.$message({
              type: 'error',
              message: '课程发布失败'
            })
          }
          this.setRouteCourse()
        })
      }).catch(() => {
        this.$message({
          type: 'error',
          message: '课程发布失败'
        })
      })
    },
    // 打开详情
    getRouteCourse() {
      this.$router.push({  // 核心语句
        path: `/courseManger`   // 跳转的路径
      })
    },
    // 点击文件管理
    clickState(state) {
      this.active = state
      this.state = state
    },
    setRouteCourse() {
      // 获取课程设置详情
      const csId = this.$route.params.csId
      if (csId === undefined || csId == null) {
        return
      }
      courseSetApi.getOneById(csId).then(resp => {
        this.coursedetail = resp.data
      })
    },
    routeCourseDetail(course) {
      const csId = this.$route.params.csId
      this.$router.push({  // 核心语句
        path: `/coursedetail/${csId}`   // 跳转的路径
      })
    }
  }
}
</script>
<style lang="scss" scoped>
// TODO: 头部
.course-publish-status--unpublished {
  background-color: #707070;
}
.courseset-header-section .breadcrumb .active {
  color: rgba(0, 0, 0, 0.88);
}
.breadcrumb a,
.breadcrumb a:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

.breadcrumb a {
  color: #919191;
}
.courseset-header-section .breadcrumb {
  padding: 4px 0;
  line-height: 1;
  font-size: 14px;
}
.text-overflow {
  font-size: 14px;
}
.breadcrumb.breadcrumb-o {
  background: none;
  margin: 12px auto;
  padding: 8px 0;
}
.breadcrumb.breadcrumb-o > li,
.breadcrumb > li {
  max-width: 100%;
}

.breadcrumb > li {
  display: inline-block;
}
.courseset-manage-header-data__num {
  font-size: 18px;
  line-height: 1;
  margin-right: 4px;
}
.cd-mt16 {
  margin-top: 16px !important;
}

.cd-dark-major {
  color: rgba(0, 0, 0, 0.88);
  font-size: 16px;
}
.cd-text-medium {
  font-weight: 500 !important;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.56);
}
.cd-btn.cd-btn-primary {
  color: #fff;
  background: #e50112;
  border-color: #e50112;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.cd-ml16 {
  margin-left: 16px !important;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
a {
  text-decoration: none;
}
.cd-btn.cd-btn-default {
  color: rgba(0, 0, 0, 0.88);
  background: #ececec;
  border-color: #ececec;
}
.courseset-manage-header-info__price {
  margin-top: 16px;
  font-size: 18px;
  line-height: 1;
}

.color-danger {
  color: #ed3e3e !important;
}
.courseset-manage-header-info__title {
  margin: 8px 0;
  font-size: 16px;
  line-height: 1;
  font-weight: 500;
  max-width: 350px;
}

.ellipsis,
.text-overflow {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}
a {
  cursor: pointer;
}
// TODO: 绿色下划线
.nav_active {
  border-bottom: 2px solid #e50112;
}
.nav-header-section.nav .nav-header-section__item.active > a {
  color: rgba(0, 0, 0, 0.88);
}
.nav-header-section.nav .nav-header-section__item > a {
  font-size: 16px;
  font-weight: 500;
  padding: 16px 0;
  display: block;
  line-height: 1;
  color: rgba(0, 0, 0, 0.56);
}
a {
  text-decoration: none;
}
.courseset-header-section .nav-header-section.nav .nav-header-section__item {
  margin: 0 32px;
}
.nav.nav-tabs .highlight {
  position: absolute;
  bottom: -1px;
  border-bottom: 2px solid #e50112;
}

.nav.nav-tabs > li {
  margin-bottom: 0;
}
.nav-header-section-step {
  float: right;
  height: 43px;
}
.pull-left {
  float: left !important;
}
.nav > li,
.nav > li > a {
  position: relative;
  display: block;
}
.cd-ml32 {
  margin-left: 32px !important;
}
.courseset-header-section .nav-header-section.nav .nav-header-section__item {
  margin: 0 32px;
}
.cd-mt24 {
  margin-top: 24px !important;
}
.courseset-header-section .nav-header-section.nav {
  margin-bottom: 0;
  border: none;
}
.courseset-manage-header-data {
  float: right;
  margin-top: 20px;
  padding-left: 32px;
  padding-right: 32px;
  text-align: center;
  line-height: 1;
}
.courseset-manage-header-btn {
  float: right;
  margin-top: 28px;
  margin-left: 24px;
  font-size: 0;
}
.courseset-manage-header-info {
  float: left;
}
.courseset-manage-header .course-publish-status {
  top: 8px;
}
.course-publish-status--published {
  background-color: #e50112;
}
.course-publish-status {
  position: absolute;
  left: -6px;
  top: 28px;
  padding: 9px 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
}
.courseset-manage-header__img {
  float: left;
  width: 160px;
  height: 90px;
  margin-right: 16px;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
}
img {
  vertical-align: middle;
}
img {
  border: 0;
}
.courseset-manage-header {
  overflow: hidden;
  position: relative;
  padding: 16px 32px 16px 16px;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.02),
    0 0 4px 0 rgba(0, 0, 0, 0.04), 0 4px 4px 0 rgba(0, 0, 0, 0.06);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.02), 0 0 4px 0 rgba(0, 0, 0, 0.04),
    0 4px 4px 0 rgba(0, 0, 0, 0.06);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.02), 0 0 4px 0 rgba(0, 0, 0, 0.04),
    0 4px 4px 0 rgba(0, 0, 0, 0.06);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  background-color: #fff;
}
.cd-container {
  padding-left: 12px;
  padding-right: 12px;
  margin: 0 auto;
}
.courseset-header-section .breadcrumb {
  padding: 4px 0;
  line-height: 1;
  font-size: 12px;
}
.breadcrumb.breadcrumb-o {
  background: none;
  margin: 12px auto;
  padding: 8px 0;
}
.breadcrumb {
  background-color: #f5f5f5;
}
.breadcrumb {
  padding: 8px 15px;
  margin-bottom: 20px;
  list-style: none;
  border-radius: 4px;
}
ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
*,
:after,
:before {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
*,
:after,
:before {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
ol {
  display: block;
  list-style-type: decimal;
  -webkit-margin-before: 1em;
  -webkit-margin-after: 1em;
  -webkit-margin-start: 0px;
  -webkit-margin-end: 0px;
  -webkit-padding-start: 40px;
}
</style>
