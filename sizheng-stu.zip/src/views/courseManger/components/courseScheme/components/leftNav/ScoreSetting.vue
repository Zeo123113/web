<!--
@description 课程计划---课程成绩设置
@author cgy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">课程成绩设置</div>
    </div>
    <div class="cd-main__body">
      <el-form ref="form" :model="scoreSetting" :rules="rules" class="form-horizontal">
        <div class="course-manage-subltitle cd-mb40">成绩设置</div>
        <div role="course-marketing-info">
          <div class="form-group">
            <el-col :span="12">
              <el-form-item label="达标分数" prop="standardScore" :label-width="formLabelWidth">
                <el-input
                  v-model.number="scoreSetting.standardScore"
                  placeholder="请输入达标分数"
                  autocomplete="off"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="发布类型" prop="publishType" :label-width="formLabelWidth">
                <el-radio-group v-model="scoreSetting.publishType">
                  <el-radio
                    v-for="dict in publishTypeDict"
                    :key="dict.dictValue"
                    :label="dict.dictValue"
                  >{{ dict.dictLabel }}</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                v-if="scoreSetting.publishType === '1'"
                label="发布时间"
                prop="publishTime"
                :label-width="formLabelWidth"
              >
                <el-date-picker
                  v-model="scoreSetting.publishTime"
                  type="datetime"
                  placeholder="选择日期时间"
                  align="right"
                  :picker-options="pickerOptions"
                  style="width:217px;"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="成绩权重" :label-width="formLabelWidth">
                <table>
                  <thead>
                    <tr>
                      <th>序号</th>
                      <th>名称</th>
                      <th>权重</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="data in weightData" :key="data.id">
                      <td>{{ data.id }}</td>
                      <td>{{ data.name }}</td>
                      <td style="width: 30rem;">
                        <!-- <span>{{ data.weight }}</span> -->
                        <el-slider v-model="data.weight" :step="10" show-stops></el-slider>
                      </td>
                      <td>{{ data.weight }}%</td>
                    </tr>
                  </tbody>
                </table>
                <el-alert v-show="isError" :marks="50" title="成绩权重之和必须等于100" type="error" />
              </el-form-item>
            </el-col>
          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-8">
            <el-button
              v-if="!hold"
              type="primary"
              class="course-btn-submit"
              size="small"
              @click="submit"
            >保 存</el-button>
            <el-button
              v-if="hold"
              type="primary"
              class="course-btn-submit"
              size="small"
              disabled
            >正 在 保 存 ...</el-button>
          </div>
        </div>
      </el-form>
    </div>
  </div>
</template>
<script>
import scoreSettingApi from '@/api/course/courseManage/scoreSetting'
// import courseSchemeApi from '@/api/course/courseManage/courseScheme'
export default {
  name: 'ScoreSetting',
  components: {
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    var checkAge = (rule, value, callback) => {
      // console.log('value = ', value)
      const standardScore = this.scoreSetting.standardScore
      if (!standardScore) {
        return callback(new Error('达标分数不能为空'))
      }
      setTimeout(() => {
        if (!Number.isInteger(standardScore)) {
          callback(new Error('请输入数字值'))
        } else {
          if (standardScore < 0 || standardScore > 80) {
            callback(new Error('达标分数必须在0~80之间'))
          } else {
            callback()
          }
        }
      }, 1000)
    }
    return {
      publishTypeDict: [],
      weight: [],
      isError: false,
      // 表单属性宽度
      formLabelWidth: '150px',
      // 正在保存
      hold: false,
      rules: {
        standardScore: [{ validator: checkAge, trigger: 'blur' }]
      },
      scoreStatusDict: [],
      weightData: [
        { 'id': 1, 'name': '作业权重', 'weight': 0 },
        { 'id': 2, 'name': '考试权重', 'weight': 0 },
        { 'id': 3, 'name': '实验权重', 'weight': 0 },
        { 'id': 4, 'name': '考勤权重', 'weight': 0 },
        { 'id': 5, 'name': '平时权重', 'weight': 0 }
      ],
      scoreSetting: {
        cssId: null,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        attainedScore: this.courseScheme.giveCredit,
        examWeight: null,
        homeworkWeight: null,
        experWeight: null,
        regularWeight: null,
        checkinWeight: null,
        standardScore: null,
        publishType: '0',
        scoreStatus: null,
        publishTime: null,
        delFlag: null,
        orgId: this.courseScheme.orgId,
        createOrgId: null,
        createBy: null,
        updateBy: null
      },
      // 日期时间选择器
      pickerOptions: {
        shortcuts: [
          {
            text: '今天',
            onClick(picker) {
              picker.$emit('pick', new Date())
            }
          },
          {
            text: '昨天',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24)
              picker.$emit('pick', date)
            }
          },
          {
            text: '一周前',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', date)
            }
          }
        ]
      }
    }
  },
  created() {
    this.getDataByType('course_score_status').then(response => {
      this.scoreStatusDict = response.data
    })
    // 发布类型数据字典
    this.getDataByType('course_scoreSetting_publish').then(response => {
      this.publishTypeDict = response.data
    })
    // 初始化获取数据
    this.getScoreSetting()
  },
  methods: {
    // 初始化获取数据
    getScoreSetting() {
      if (this.courseScheme.schemeId != null) {
        scoreSettingApi.getScoreSettingBySchemeId(this.courseScheme.schemeId).then(response => {
          if (response.data.length > 0) {
            this.scoreSetting = response.data[0]
            this.setWeightData(this.scoreSetting)
          }
        })
      }
    },
    // 拖动 Slider 滑块
    change(value) {
      console.log('value = ', value)
    },
    // 权重表格赋值
    setWeightData(scoreSetting) {
      this.weightData[0].weight = scoreSetting.homeworkWeight  * 100
      this.weightData[1].weight = scoreSetting.examWeight * 100
      this.weightData[2].weight = scoreSetting.experWeight  * 100
      this.weightData[3].weight = scoreSetting.checkinWeight * 100
      this.weightData[4].weight = scoreSetting.regularWeight  * 100
    },
    // 权重表格赋值
    getWeightData(weightData) {
      this.scoreSetting.homeworkWeight = (isNaN(this.weightData[0].weight) ? 0 : this.weightData[0].weight) / 100
      this.scoreSetting.examWeight = (isNaN(this.weightData[1].weight) ? 0 : this.weightData[1].weight) / 100
      this.scoreSetting.experWeight = (isNaN(this.weightData[2].weight) ? 0 : this.weightData[2].weight) / 100
      this.scoreSetting.checkinWeight = (isNaN(this.weightData[3].weight) ? 0 : this.weightData[3].weight) / 100
      this.scoreSetting.regularWeight = (isNaN(this.weightData[4].weight) ? 0 : this.weightData[4].weight) / 100
    },
    // 提交
    submit() {
      // this.hold = !this.hold
      // 校验成绩的权重
      const weight0 = isNaN(this.weightData[0].weight) ? 0 : this.weightData[0].weight
      const weight1 = isNaN(this.weightData[1].weight) ? 0 : this.weightData[1].weight
      const weight2 = isNaN(this.weightData[2].weight) ? 0 : this.weightData[2].weight
      const weight3 = isNaN(this.weightData[3].weight) ? 0 : this.weightData[3].weight
      const weight4 = isNaN(this.weightData[4].weight) ? 0 : this.weightData[4].weight
      const weightTotal = weight0 + weight1 + weight2 + weight3 + weight4
      console.log('weightTotal = ', weightTotal)
      if (weightTotal !== 100) {
        console.log('weightTotal = ', weightTotal)
        console.log('weightData = ', this.weightData)
        this.$message({
          message: '成绩权重之和必须等于100',
          type: 'error'
        })
        this.isError = true
        return
      }
      // 获取权限
      this.getWeightData()
      // 更新课程的成绩设置
      this.saveScoreSetting()
    },
    // 保存表单
    saveScoreSetting() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.hold = !this.hold
          // 添加或编辑课程的成绩设置
          if (!this.scoreSetting.cssId) {
            this.scoreSetting.createOrgId = this.$store.getters.user.org.orgId
            this.scoreSetting.createBy = this.$store.getters.user.loginName
            scoreSettingApi.add(this.scoreSetting).then(resp => {
              // this.resetForm('scoreSetting')
              if (resp.code === 0) {
                this.$message({
                  type: 'success',
                  message: '保存成功'
                })
              } else {
                this.$message({
                  message: resp.msg,
                  type: 'error'
                })
              }
              this.hold = !this.hold
            })
          } else {
            this.scoreSetting.updateBy = this.$store.getters.user.loginName
            scoreSettingApi.edit(this.scoreSetting).then(resp => {
              // this.resetForm('scoreSetting')
              if (resp.code === 0) {
                this.$message({
                  type: 'success',
                  message: '修改成功'
                })
              } else {
                this.$message({
                  message: resp.msg,
                  type: 'error'
                })
              }
              this.hold = !this.hold
            })
          }
        }
      })
    }
  }
}
</script>
<style scoped>
.course-btn-submit {
  color: #fff;
  background: #e50112;
  border-color: #e50112;
}
</style>
<style lang="scss" scoped>
table {
  border-collapse: collapse;

  font-family: Futura, Arial, sans-serif;
}

caption {
  font-size: larger;

  margin: 1em auto;
}

th,
td {
  padding: 0.65em;
}

th,
td {
  border-bottom: 1px solid #ddd;

  border-top: 1px solid #ddd;

  text-align: center;
}
.form-control-static {
  min-height: 34px;
  padding-top: 11px;
  padding-bottom: 7px;
  margin-bottom: 0;
}
.list-group {
  padding-left: 0;
  margin-bottom: 10px;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.col-sm-8 {
  float: left;
  width: 66.66666667%;
}
label + .cd-radio-group .cd-radio {
  margin-top: 12px;
  margin-bottom: 4px;
}
.course-manage-info .cd-radio {
  min-width: 76px;
  color: rgba(0, 0, 0, 0.88);
  font-weight: 400;
}
.cd-radio {
  position: relative;
  padding-right: 20px;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  display: inline-block;
  margin-bottom: 0;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.ml5 {
  margin-left: 5px;
  font-size: 14px;
}
.course-mangae-info__input {
  width: 128px;
  display: inline-block;
}
.form-control {
  color: #616161;
  border-color: #e1e1e1;
}
.mrs {
  margin-right: 5px !important;
}
.form-control {
  //   width: 100%;
  height: 34px;
  padding: 6px 12px;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-transition: border-color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.form-control,
output {
  //   display: block;
  font-size: 14px;
  line-height: 1.42857143;
  color: #919191;
}
.control-label-required {
  position: relative;
}

label {
  display: inline-block;
  max-width: 100%;
  margin-bottom: 5px;
  font-weight: 700;
  //   font-size: 15px;
}
.form-horizontal .control-label {
  text-align: right;
  margin-bottom: 0;
  padding-top: 11px;
}

.col-sm-2 {
  float: left;
  width: 16.66666667%;
}
.course-manage-intro i {
  line-height: 42px;
  font-size: 16px;
}

.es-icon {
  line-height: 1;
}
.es-icon {
  font-family: es-icon !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.course-manage-intro .course-manage-intro__inner {
  width: 42px;
  height: 42px;
  text-align: center;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  color: #fff;
  background-color: #e50112;
}
.course-manage-intro .course-manage-intro__tip {
  font-size: 12px;
  line-height: 1;
  color: #adadad;
}

.mtm {
  margin-top: 10px !important;
}
.course-manage-intro .course-manage-intro__outer {
  padding: 0 15px;
  width: 72px;
}
.cd-mt24 {
  margin-top: 24px !important;
}

.form-group {
  margin-bottom: 15px;
}
.course-manage-info .form-group {
  margin-bottom: 24px;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.course-manage-info .course-manage-info__title {
  box-shadow: none;
}

.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.course-manage-info .course-manage-info__title + div {
  padding-top: 0;
}

.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
form {
  display: block;
  margin-top: 0em;
}
.course-manage-subltitle {
  padding: 9px 0 9px 32px;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  color: rgba(0, 0, 0, 0.8);
  background-color: rgba(0, 0, 0, 0.04);
}

.cd-mb40 {
  margin-bottom: 40px !important;
}
.course-manage-subltitle {
  padding: 9px 0 9px 32px;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  color: rgba(0, 0, 0, 0.8);
  background-color: rgba(0, 0, 0, 0.04);
}
.cd-mb40 {
  margin-bottom: 40px !important;
}
.course-manage-info .form-group {
  margin-bottom: 24px;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
.course-manage-intro {
  position: fixed;
  bottom: 30px;
  z-index: 1000;
}
input {
  line-height: normal;
}

input,
optgroup,
select,
textarea {
  color: inherit;
  font: inherit;
  margin: 0;
}
</style>
