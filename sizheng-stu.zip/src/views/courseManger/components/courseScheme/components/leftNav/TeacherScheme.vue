<!--
@description 教师管理
@author cgy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">教师管理</div>
    </div>
    <div class="cd-main__body">
      <div>
        <form id="teachers-form" class="form-horizontal" method="post">
          <div id="teachers-form-group" class="form-group">
            <div class="col-md-2 control-label">
              <label>已添加教师</label>
            </div>
            <div class="col-md-8 controls">
              <div id="course-teachers">
                <div data-reactroot class="multi-group">
                  <ul class="multi-list sortable-list list-group">
                    <li
                      v-for="(teacher,index) of teachers"
                      :key="index"
                      class="list-group-item"
                      data-seq="1"
                    >
                      <img
                        :src="avatarHttp + teacher.avatar"
                        class="avatar-sm avatar-sm-square mrm"
                        alt
                        onerror="this.src='http://fileserver:8888/group1/M00/00/00/J2Ouul7sNO6AGINfAAAKhBa2VH8659.png';this.onerror = null"
                      />
                      <span
                        class="label-name text-overflow inline-block vertical-middle"
                      >{{ teacher.loginName }}</span>
                      <a class="pull-right link-gray mtm" @click="fakeDelete(teacher.value)">
                        <svg class="icon icon-graphic" aria-hidden="true">
                          <use xlink:href="#icon-cross8" />
                        </svg>
                      </a>
                    </li>
                  </ul>
                  <div class="input-group">
                    <el-select
                      v-model="courseScheme.teacherIds"
                      multiple
                      filterable
                      remote
                      default-first-option
                      placeholder="请授课选择教师"
                      style="width:45rem"
                      :remote-method="remoteMethod"
                      :loading="loading"
                    >
                      <el-option
                        v-for="item in leaders"
                        :key="item.teacherId"
                        :label="item.teacherName"
                        :value="item.teacherId"
                      ></el-option>
                    </el-select>
                  </div>
                </div>
              </div>
              <div class="help-block">只能添加有教师权限的用户</div>
            </div>
          </div>
          <div class="form-group">
            <div class="col-md-offset-2 col-md-8 controls">
              <button type="button" class="cd-btn cd-btn-primary js-btn-save" @click="submit">保存</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
<script>
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import { mapGetters } from 'vuex'
import userApi from '@/api/user/user'
import teacherTeamApi from '@/api/course/courseManage/teacherTeam'
import USER_CONST from '@/constant/user-const'
export default {
  name: 'TeacherScheme',
  components: {
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 头像前缀
      avatarHttp: USER_CONST.AVATARHTTP,
      // 该组织的教师列表
      leaders: [],
      // 查询教师的变量
      teacherParam: {
        orgId: null,
        csId: null,
        ctId: null,
        teacherName: null
      },
      loading: false,
      // 教师团队的教师用户
      teachers: [],
      avatarUrl:
        process.env.NODE_ENV === 'development'
          ? 'http://fileserver:8888' + '/'
          : '/'
    }
  },
  /**
   *从状态管理器获取按钮权限数组button
   */
  computed: {
    ...mapGetters({
      button: 'button',
      user: 'user'
    })
  },
  created() {
    if (!(this.courseScheme.teacherIds instanceof Array) && this.courseScheme.teacherIds !== null) {
      this.courseScheme.teacherIds = JSON.parse(this.courseScheme.teacherIds)
    }
    console.log('this.courseScheme.teacherIds = ', this.courseScheme.teacherIds)
    this.getTeacherTeamByCsId()
    // 根据教师名称查询相关教师
    this.getTeachers()
  },
  methods: {
    // 删除某教师
    fakeDelete(userId) {
      const teacherIds = this.courseScheme.teacherIds
      setTimeout(() => {
        this.teachers = teacherIds.filter((val) => {
          if (val !== userId) {
            return val
          }
        })
      }, 200)
    },
    // 保存
    submit() {
      // this.courseScheme.teacherIds = this.courseScheme.teacherIds.join(',')
      this.courseScheme.teacherIds = JSON.stringify(this.courseScheme.teacherIds)
      // console.log('this.courseScheme.teacherIds = ', this.courseScheme.teacherIds)
      courseSchemeApi.update(this.courseScheme)
        .then(result => {
          if (result.code === 0) {
            this.$message({
              type: 'success',
              message: '保存成功'
            })
          } else {
            this.$message({
              type: 'error',
              message: '保存失败'
            })
          }
        })
    },
    // 选择器变化
    remoteMethod(query) {
      // const teacherIds = this.courseScheme.teacherIds
      // console.log('teacherIds = ', teacherIds)
      // console.log('this.leaders = ', this.leaders)
      // setTimeout(() => {
      //   this.teachers = this.leaders.filter((val) => {
      //     if (teacherIds.indexOf(val.value) > -1) {
      //       return val
      //     }
      //   })
      // }, 200)
      // console.log('teacherIds = ', teacherIds)
      // console.log('this.teachers = ', this.teachers)
      console.log('query = ', query)
      if (query !== '') {
        this.loading = true
        setTimeout(() => {
          this.loading = false
          this.getTeachers(query)
        }, 200)
      } else {
        this.getTeachers(null)
      }
    },
    // 获取课程学期下的教师团队的教师
    getTeachers(query) {
      this.teacherParam.orgId = this.courseScheme.orgId
      this.teacherParam.csId = this.courseScheme.csId
      this.teacherParam.ctId = this.courseScheme.ctId
      this.teacherParam.teacherName = query
      teacherTeamApi.listTeacherTeam(this.teacherParam, 1, 5).then(response => {
        this.leaders = response.data.list
        // this.total = response.data.total
      })
    },
    // 获取该课程的教师团队
    getTeacherTeamByCsId() {
      if (this.courseScheme.teacherIds.length < 1) {
        return
      }
      teacherTeamApi.getTeaUserIdsByIds(this.courseScheme.teacherIds).then(response => {
        const teaUserIds = response.data
        this.getTeacherList(teaUserIds)
      })
    },
    // 根据用户Id列表查询用户登录名,头像列表
    getTeacherList(teaUserIds) {
      userApi.getUsersByIds(teaUserIds).then(response => {
        this.teachers = response.data
      })
    }
  }
}
</script>
<style lang="scss" scoped>
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.input-group-btn {
  border: 1px solid #ccc;
}
.btn-default,
.btn-default.disabled:hover,
.btn-default[disabled]:hover {
  color: #616161;
  background-color: #f5f5f5;
  border-color: #616161;
}
.btn {
  display: inline-block;
  margin-bottom: 0;
  font-weight: 400;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  background-image: none;
  border: 1px solid transparent;
  white-space: nowrap;
  padding: 6px 12px;
  font-size: 14px;
  line-height: 1.42857143;
  border-radius: 4px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
a {
  text-decoration: none;
}
.ellipsis,
.text-overflow {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}
.multi-group .list-group .label-name {
  font-size: 1rem;
  width: 160px;
}
.vertical-middle {
  vertical-align: middle !important;
}
.inline-block {
  display: inline-block !important;
}
.avatar-sm,
.avatar-small {
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  width: 40px !important;
  height: 40px !important;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

.cd-btn.cd-btn-primary {
  color: #fff;
  background: #e50112;
  border-color: #e50112;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.multi-group {
  position: relative;
}
button,
input,
select,
textarea {
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}
.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
.help-block {
  margin-bottom: 0;
}

.help-block {
  display: block;
  margin-top: 5px;
  margin-bottom: 10px;
  color: #a1a1a1;
}
label {
  display: inline-block;
  max-width: 100%;
  margin-bottom: 5px;
  font-weight: 700;
}
.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
</style>
