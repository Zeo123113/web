<!--
@description 教师团队管理
@author zhaoshibin
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">教师团队</div>
    </div>
    <div class="cd-main__body">
      <!-- 下面是查询模块 -->
      <el-form :model="queryParams" :inline="true" class="form-inline">
        <el-form-item label="教师姓名">
          <el-input v-model="queryParams.teacherName" placeholder="请输入教师姓名" size="medium" clearable></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" size="small" @click="handleQuery">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" size="small" @click="handleAdd">新增</el-button>
        </el-form-item>
      </el-form>
      <!-- 下面是数据展示 -->
      <el-table :data="tableData" tooltip-effect="dark" style="width: 100%">
        <el-table-column label="编号" prop="teacherId" align="center" min-width="55" />
        <el-table-column label="教师姓名" prop="teacherName" align="center" min-width="100" />
        <el-table-column label="是否团队负责人" prop="isLeader" align="center" min-width="150" :formatter="isLeaderTypeFormat" />
        <el-table-column label="职称头衔" prop="jobTitle" align="center" min-width="80" />
        <el-table-column label="个人介绍" prop="introduction" align="center" min-width="80" show-overflow-tooltip />
        <el-table-column label="教师所属机构名称" prop="teaOrgName" align="center" min-width="200" />
        <el-table-column label="创建时间" prop="createTime" align="center" min-width="160" />
        <el-table-column label="更新时间" prop="updateTime" align="center" min-width="160" />
        <el-table-column label="操作" fixed="right" align="center" min-width="200">
          <template slot-scope="scope">
            <el-button type="success" size="mini" @click="handleUpdate(scope.row)">编辑</el-button>
            <el-button type="danger" size="mini" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 下面是分页插件 -->
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      ></pagination>
      <!-- 下面是新增修改教师团队信息弹出框 -->
      <el-dialog :title="title" :visible.sync="open" width="46%">
        <el-form ref="form" :model="form" :rules="rules" label-width="115px">
          <el-row>
            <el-col :span="12">
              <el-form-item label="教师姓名" prop="teacherName">
                <el-select
                  v-model="form.teacherName"
                  placeholder="请选择教师"
                  value-key="userId"
                  filterable
                  @change="teacherNameChange"
                >
                  <el-option
                    v-for="userList in userListOptions"
                    :key="userList.userId"
                    :label="userList.realName"
                    :value="userList.realName"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="团队负责人" prop="isLeader">
                <el-radio-group v-model="form.isLeader">
                  <el-radio :label="false">否</el-radio>
                  <el-radio :label="true">是</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="职称头衔" prop="jobTitle">
            <el-input v-model="form.jobTitle" placeholder="请输入职称头衔"></el-input>
          </el-form-item>
          <el-form-item label="个人介绍" prop="introduction">
            <el-input v-model="form.introduction" placeholder="请输入个人介绍"></el-input>
          </el-form-item>
          <el-form-item label="备注" prop="remark">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入内容"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" size="small" @click="submitForm">保存</el-button>
          <el-button size="small" @click="cancel">取消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import teacherTeamApi from '@/api/course/courseManage/teacherTeam'
import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
import userApi from '@/api/user/user'
export default {
  components: { pagination },
  props: {
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 分页记录总条数默认是1
      total: 1,
      // 默认从第一页开始
      pageNum: 1,
      // 默认每页显示的记录条数
      pageSize: USER_CONST.PAGESIZE,
      queryParams: {
        orgId: this.courseTerm.orgId,
        csId: this.courseTerm.csId,
        ctId: this.courseTerm.ctId,
        teacherName: undefined
      },
      // 数据表格展示数据
      tableData: [],
      // 弹出框的标题
      title: '',
      // 弹出框默认关闭
      open: false,
      // 新增修改的弹框表单
      form: {},
      rules: {
        // 表单校验
        teacherName: [{ required: true, message: '教师姓名不能为空', trigger: 'blur' }],
        isLeader: [{ required: true, message: '是否团队负责人不能为空', trigger: 'blur' }]
      },
      // 当前用户所在二级组织机构及以下的所有教师用户
      userListOptions: []
    }
  },
  // 钩子函数页面加载时调用数据
  created() {
    // 根据当前用户orgId获取当前用户所在二级组织机构及以下所有的教师用户
    userApi.getUserListByCurrentUserOrgId(this.$store.getters.user.orgId).then(response => {
      this.userListOptions = response.data
    })
    this.fetchData(this.queryParams, this.pageNum, this.pageSize)
  },
  methods: {
    // 是否教师团队数据字典翻译
    isLeaderTypeFormat(row) {
      return row.isLeader === true ? '是' : '否'
    },
    // 教师姓名改变时触发
    teacherNameChange(value) {
      let obj = {}
      obj = this.userListOptions.find((userList) => {
        return userList.realName === value
      })
      this.form.teaUserId = obj.userId
      this.form.teaOrgName = obj.org.orgName
      this.form.jobTitle = obj.title
      this.form.introduction = obj.introduction
    },
    // 获得tableData,带有分页
    fetchData(queryParams, pageNum, pageSize) {
      teacherTeamApi.listTeacherTeam(queryParams, pageNum, pageSize).then(response => {
        this.tableData = response.data.list
        this.total = response.data.total
      })
    },
    // 根据查询条件查询按钮
    handleQuery() {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    // 处理分页组件上面的操作
    pageQuery() {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    // 新增编辑表单重置
    reset() {
      this.form = {
        orgId: this.courseTerm.orgId,
        ctId: this.courseTerm.ctId,
        csId: this.courseTerm.csId,
        teacherId: undefined,
        teacherName: undefined,
        teaUserId: undefined,
        teaOrgName: undefined,
        isLeader: false,
        jobTitle: undefined,
        introduction: undefined
      }
      this.resetForm('form')
    },
    // 表单重置调用elementui函数
    resetForm(refName) {
      if (this.$refs[refName] !== undefined) {
        this.$refs[refName].resetFields()
      }
    },
    // 点击新增按钮
    handleAdd() {
      this.reset()
      this.open = true
      this.title = '添加教师团队'
    },
    // 点击编辑按钮
    handleUpdate(row) {
      this.form = row
      this.title = '修改教师团队'
      this.open = true
    },
    // 新增修改提交
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.form.teacherId !== undefined) {
            teacherTeamApi.updateTeacherTeam(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  type: 'success',
                  message: '修改成功'
                })
                this.open = false
                this.fetchData(this.queryParams, this.pageNum, this.pageSize)
              } else {
                this.$message({
                  message: response.msg,
                  type: 'error'
                })
              }
            })
          } else {
            teacherTeamApi.addTeacherTeam(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  type: 'success',
                  message: '新增成功'
                })
                this.open = false
                this.fetchData(this.queryParams, this.pageNum, this.pageSize)
              } else {
                this.$message({
                  message: response.msg,
                  type: 'error'
                })
              }
            })
          }
        }
      })
    },
    // 单条删除按钮
    handleDelete(row) {
      this.$confirm('是否确认删除教师姓名为 "' + row.teacherName + '" 的数据项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return teacherTeamApi.delTeacherTeam(row.teacherId)
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '教师信息删除成功'
          })
          this.fetchData(this.queryParams, this.pageNum, this.pageSize)
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 点击取消保存按钮
    cancel() {
      this.open = false
    }
  }
}
</script>
<style scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.btn-group {
  margin-bottom: 20px;
}
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
