<!--
@description 课程学期设置
@author cgy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">基础设置</div>
    </div>
    <div class="cd-main__body">
      <el-form ref="form" :model="courseTerm" :rules="rules" class="form-horizontal">
        <el-row>
          <el-col :span="24">
            <el-form-item label="开课类型" prop="termType" :label-width="formLabelWidth">
              <el-radio-group v-model="courseTerm.termType" :disabled="courseTerm.ctId > 0">
                <el-radio
                  v-for="item in termTypeOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                  @change="changeRadio"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item
              v-if="!showTermTitle && courseTerm.termType === '0'"
              :label-width="formLabelWidth"
            >
              <el-select
                v-model="courseTermLabel"
                placeholder="请选择课程学期"
                clearable
                style="width:270px;"
              >
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.label"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item v-if="courseTerm.termType === '1'" :label-width="formLabelWidth">
              <span v-if="!showStartEndTime">{{ getStartEndTime() }}</span>
              <svg
                v-if="!showStartEndTime"
                class="icon"
                aria-hidden="true"
                style="margin-left: 1rem;"
                @click="updateShowStartEndTime()"
              >
                <use xlink:href="#icon-bianji" />
              </svg>
              <svg
                v-if="courseTerm.ctId > 0 && showStartEndTime"
                class="icon"
                aria-hidden="true"
                style="margin-left: 1rem;"
                @click="updateShowStartEndTime()"
              >
                <use xlink:href="#icon-fanhui-xianxing" />
              </svg>
              <el-date-picker
                v-show="showStartEndTime"
                v-model="startEndTime"
                value-format="yyyy-MM-dd HH:mm:ss"
                type="datetimerange"
                align="right"
                unlink-panels
                range-separator="至"
                start-placeholder="开课时间"
                end-placeholder="结课时间"
                :picker-options="pickerOptions"
                @change="timeChange"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="学期名称" prop="termTitle" :label-width="formLabelWidth">
              <el-input
                v-model="courseTerm.termTitle"
                :disabled="showTermTitle"
                placeholder="请输入学期描述"
                clearable
                style="width:300px;"
              />
              <svg
                v-if="showTermTitle"
                class="icon"
                aria-hidden="true"
                style="margin-left: 1rem"
                @click="updateTermTitle()"
              >
                <use xlink:href="#icon-bianji" />
              </svg>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="课程封面" prop="courseCover" :label-width="formLabelWidth">
              <el-upload
                ref="inputFileUpload"
                class="avatar-uploader"
                :action="inputFileUploadUrl"
                :data="fileTag"
                accept=".jpg, .png, .gif"
                :before-upload="inputFileBeforeUpload"
                :on-success="inputFileUploadSuccess"
                :on-error="inputFileUploadError"
                :headers="headers"
                :show-file-list="false"
              >
                <div class="itemInWorks">
                  <img
                    v-if="courseTerm.courseCover"
                    :src="'http://fileserver:8888/' + courseTerm.courseCover"
                    onerror="this.src='http://fileserver:8888/group1/M00/00/00/J2Ouul7sNO6AGINfAAAKhBa2VH8659.png';this.onerror = null"
                    class="avatar"
                  />
                  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                  <div class="mask">点击更换标题图片</div>
                </div>
              </el-upload>
              <span
                style="color:#aaa;font-size:12px;"
              >请上传jpg、png、gif格式的图片，建议图片尺寸为480×270px。建议图片大小不超过2MB。</span>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="授课模式" prop="teachingMode" :label-width="formLabelWidth">
              <el-radio-group v-model="courseTerm.teachingMode" :disabled="courseTerm.ctId > 0">
                <el-radio
                  v-for="item in teachingModeOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item
              v-if="courseTerm.teachingMode === '1'"
              label="教学方案类型"
              prop="schemeType"
              :label-width="formLabelWidth"
            >
              <el-radio-group v-model="courseTerm.schemeType" :disabled="courseTerm.ctId > 0">
                <el-radio
                  v-for="item in schemeTypeOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="考试模式" prop="examMode" :label-width="formLabelWidth">
              <el-radio-group v-model="courseTerm.examMode" :disabled="courseTerm.ctId > 0">
                <el-radio
                  v-for="item in examModeOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="阅卷模式" prop="markingMode" :label-width="formLabelWidth">
              <el-radio-group v-model="courseTerm.markingMode" :disabled="courseTerm.ctId > 0">
                <el-radio
                  v-for="item in markingModeOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="课程目标" prop="goals" :label-width="formLabelWidth">
              <tinymce ref="goals" v-model="courseTerm.goals" :save-flag="saveFlag" :height="250" />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="课程受众" prop="audiences" :label-width="formLabelWidth">
              <tinymce
                ref="audiences"
                v-model="courseTerm.audiences"
                :save-flag="saveFlag"
                :height="250"
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="课程推介" prop="recomIntro" :label-width="formLabelWidth">
              <tinymce
                ref="recomIntro"
                v-model="courseTerm.recomIntro"
                :save-flag="saveFlag"
                :height="250"
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="预备知识" prop="propaedeutics" :label-width="formLabelWidth">
              <tinymce
                ref="propaedeutics"
                v-model="courseTerm.propaedeutics"
                :save-flag="saveFlag"
                :height="250"
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="参考资料" prop="courseRefMaterials" :label-width="formLabelWidth">
              <tinymce
                ref="courseRefMaterials"
                v-model="courseTerm.courseRefMaterials"
                :save-flag="saveFlag"
                :height="250"
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="证书学分要求" prop="requirements" :label-width="formLabelWidth">
              <el-input v-model="courseTerm.requirements" placeholder="请输入证书或学分要求" clearable />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="建议周学时" prop="hoursPerWeek" :label-width="formLabelWidth">
              <el-input v-model="courseTerm.hoursPerWeek" placeholder="请输入建议周学时" clearable />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="常见问题" prop="commonQuestions" :label-width="formLabelWidth">
              <tinymce
                ref="courseRefMaterials"
                v-model="courseTerm.commonQuestions"
                :save-flag="saveFlag"
                :height="250"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" style="margin-left: 12rem">
        <el-button
          v-if="!hold"
          type="primary"
          style="background-color: #E50112;border-color: #E50112;"
          class="course-btn-submit"
          size="small"
          @click="submit"
        >保 存</el-button>
        <el-button
          v-if="hold"
          type="primary"
          class="course-btn-submit"
          size="small"
          disabled
        >正 在 保 存 ...</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import Tinymce from '@/components/Tinymce'
import { getToken } from '@/utils/auth'
import courseTermApi from '@/api/course/courseManage/courseTerm'
export default {
  name: 'CourseSetting',
  components: {
    Tinymce
  },
  props: {
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    // 验证开课学期是否唯一
    const validateCourseTerm = (rule, value, callback) => {
      console.log('value = ', value)
      if (value === null || value === '' || value === undefined) {
        return callback(new Error('学期名称不能为空'))
      } else if (value.length < 3 || value.length > 20) {
        return callback(new Error('字符长度在 3 到 20 个字符'))
      }
      const courseTerm = { ...this.courseTerm }
      courseTerm.courseTerm = value
      courseTermApi
        .validateCourseTerm(courseTerm)
        .then(function(resp) {
          console.log('resp = ', resp)
          if (resp.data < 1) {
            callback()
          } else {
            callback(new Error('学期名已存在,请重新输入'))
          }
        })
    }
    return {
      // 正在保存
      hold: false,
      // 开课，结课时间
      startEndTime: '',
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      rules: {
        termTitle: [{ validator: validateCourseTerm, trigger: 'blur' }],
        termType: [
          { required: true, message: '开课学期类型不能为空', trigger: 'blur' }
        ],
        briefIntroduction: [
          { required: true, message: '课程简介不能为空', trigger: 'blur' },
          { min: 3, max: 800, message: '长度在 3 到 800 个字符', trigger: 'blur' }
        ],
        requirements: [
          { pattern: /^[0-9]+(.[0-9]{0,1})?$/, message: '请输入0-1位小数的正实数', trigger: 'change' }
        ],
        hoursPerWeek: [
          { max: 100, message: '长度不能超过100 个字符', trigger: 'blur' }
        ]
      },
      // 表单属性宽度
      formLabelWidth: '120px',
      termTypeOptions: [],
      schemeTypeOptions: [],
      examModeOptions: [],
      markingModeOptions: [],
      teachingModeOptions: [],
      // 上传文件时文件标签
      fileTag: { fileTag: '课程学期封面' },
      inputFileUploadUrl: process.env.VUE_APP_BASE_API + '/course/course-term/inputFileUpload',
      headers: {
        token: getToken()
      },
      options: [],
      courseTermLabel: '',
      // 富文本开启标志
      saveFlag: false,
      // 显示学期描述
      showTermTitle: false,
      // 显示时间选择器
      showStartEndTime: false
    }
  },
  watch: {
    startEndTime: function(val) {
      console.log('val = ', val)
      if (val != null) {
        this.courseTerm.courseStartTime = val[0]
        this.courseTerm.courseEndTime = val[1]
      } else {
        this.startEndTime = ''
      }
    },
    courseTermLabel: function(val) {
      console.log('courseTermLabel---------val = ', val)
      if (val != null) {
        this.courseTerm.termTitle = val
      }
      console.log('this.courseTerm.termTitle = ', this.courseTerm.termTitle)
    }
  },
  created() {
    // 课程学期类型字典获取
    this.getDataByType('course_term_termtype').then(response => {
      this.termTypeOptions = response.data
    })
    // 教学方案类型字典获取
    this.getDataByType('course_term_schemeType').then(response => {
      this.schemeTypeOptions = response.data
    })
    // 授课模式类型字典获取
    this.getDataByType('course_term_teachingmode').then(response => {
      this.teachingModeOptions = response.data
    })
    // 考试模式字典获取
    this.getDataByType('course_term_examMode').then(response => {
      this.examModeOptions = response.data
    })
    // 阅卷模式字典获取
    this.getDataByType('course_term_markingMode').then(response => {
      this.markingModeOptions = response.data
    })
    this.getTermName()
    this.setPickerOptions()
  },
  // beforeUpdate() {
  //   this.setPickerOptions()
  // },
  methods: {
    getStartEndTime() {
      if (this.courseTerm.courseStartTime != null && this.courseTerm.courseEndTime != null) {
        return this.courseTerm.courseStartTime + ' 至 ' + this.courseTerm.courseEndTime
      }
    },
    updateShowStartEndTime() {
      // console.log('updateShowStartEndTime============')
      this.showStartEndTime = !this.showStartEndTime
    },
    updateTermTitle() {
      this.showTermTitle = false
    },
    // 赋值开课时间
    setPickerOptions() {
      console.log('this.courseTerm.ctId = ', this.courseTerm.ctId)
      if (this.courseTerm.ctId > 0) {
        this.showTermTitle = true
        this.showStartEndTime = false
      } else {
        this.showTermTitle = false
        this.showStartEndTime = true
      }
      // if (this.courseTerm.courseStartTime !== '') {
      //   this.startEndTime[0] = this.courseTerm.courseStartTime
      // }
      // if (this.courseTerm.courseEndTime !== '') {
      //   this.startEndTime[1] = this.courseTerm.courseEndTime
      // }
    },
    changeRadio(val) {
      // 0:按学期开课；1：按时间段开课
      if (val === '0') {
        this.courseTerm.termTitle = this.courseTermLabel
      } else {
        if (this.courseTerm.ctId < 1) {
          this.courseTerm.termTitle = ''
        }
      }
    },
    timeChange() {
      if (this.courseTerm.ctId < 1) {
        this.courseTerm.termTitle = ''
      }
    },
    /** 打开弹窗放入富文本内容 */
    open() {
      this.saveFlag = true
      this.editsaveFlag()
    },
    editsaveFlag() {
      setTimeout(() => {
        this.saveFlag = !this.saveFlag
      }, 500)
    },
    // 生成学期
    getTermName() {
      var date = new Date() // 当前时间
      var year = date.getFullYear() // 现在年份
      var month = date.getMonth() + 1 // getMonth()获取当前月份(0-11,0代表1月)
      // 自动生成近五年的学期
      var oldYer = year
      // console.log(oldYer)
      do {
        this.options.push({
          value: oldYer + '春',
          label: oldYer + '-' + (oldYer + 1) + '学年(春)'
        })
        this.options.push({
          value: oldYer + '秋',
          label: oldYer + '-' + (oldYer + 1) + '学年(秋)'
        })
        oldYer = oldYer + 1
      } while (oldYer < year)
      if (month >= 2 && month <= 8) {
        this.options.push({
          value: oldYer + '春',
          label: oldYer + '-' + (oldYer + 1) + '学年(春)'
        })
      } else {
        this.options.push({
          value: oldYer + '春',
          label: oldYer + '-' + (oldYer + 1) + '学年(春)'
        })
        this.options.push({
          value: oldYer + '秋',
          label: oldYer + '-' + (oldYer + 1) + '学年(秋)'
        })
      }
      this.courseTerm.termTitle = this.courseTerm.courseTerm
      // console.log('this.options = ', this.options)
      // this.courseTermLabel = this.options[0].label
      // this.courseTerm.termTitle = this.options[0].label
    },
    // 表单提交
    submit() {
      this.hold = !this.hold
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.courseTerm.ctId === -1) {
            this.courseTerm.courseTerm = this.courseTerm.termTitle
            courseTermApi.addEntry(this.courseTerm).then(result => {
              if (result.code === 0) {
                this.$message({
                  type: 'success',
                  message: '保存成功'
                })
                // this.$emit('getList')
              } else {
                this.$message({
                  type: 'error',
                  message: '保存失败'
                })
              }
              this.hold = !this.hold
              this.$emit('getList')
            })
          } else {
            this.courseTerm.courseTerm = null
            courseTermApi.updateEntry(this.courseTerm).then(result => {
              if (result.code === 0) {
                this.$message({
                  type: 'success',
                  message: '修改成功'
                })
                // this.$emit('getList')
              } else {
                this.$message({
                  type: 'error',
                  message: '修改失败'
                })
              }
              this.hold = !this.hold
              this.$emit('getList')
            })
          }
        } else {
          this.$message({
            type: 'error',
            message: '表单校验不合法, 请检查表单重新提交'
          })
          this.hold = !this.hold
        }
      })
    },
    // 打开课程设置
    routeCourseTerm(courseTerm) {
      this.$router.push({  // 核心语句
        path: `/courseManger/${courseTerm.csId}/${'AllTerm'}`
      })
    },
    /** 上传之前检测文件类型及大小 */
    inputFileBeforeUpload: function(file) {
      this.fileTag.inputFile = this.courseTerm.courseCover
      const FileExt = file.name.replace(/.+\./, '')
      if (['jpg', 'png', 'gif'].indexOf(FileExt.toLowerCase()) === -1) {
        this.$message({
          type: 'warning',
          message: '请上传后缀名为jpg、png、gif的附件！'
        })
        return false
      }
      this.isLt2k = file.size / 1024 / 1024 <= 2 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过2Mb!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 文件上传成功时的勾子 */
    inputFileUploadSuccess: function(response, file, fileList) {
      this.$refs.inputFileUpload.clearFiles()
      this.courseTerm.courseCover = response.data
      if (response.code === 0) {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件成功！',
          type: 'info'
        })
      } else {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件失败!' + response.msg,
          type: 'error'
        })
      }
    },
    /** 上传失败时的勾子 */
    inputFileUploadError: function(err, file, fileList) {
      this.$refs.inputFileUpload.clearFiles()
      this.$message({
        message: '上传文件失败!',
        type: 'error'
      })
      console.log(err)
    },
    /** 提交上传文件 */
    inputFileSubmitUpload() {
      this.$refs.inputFileUpload.submit()
    }
  }
}
</script>
<style lang="scss" scoped>
.icon {
  cursor: pointer;
}
.p_upload >>> .el-upload__input {
  display: none;
}
.p_upload >>> .el-upload >>> input {
  display: none;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.course_content {
  padding-left: 0;
  padding-right: 0;
  // padding-right: 12px;
  margin: 0 auto;
  position: relative;
  border-radius: 4px;
  margin-top: 10px;
  margin-bottom: 24px;
}
.width-full {
  width: 100%;
}
.select2-container {
  margin-left: 0;
  margin-right: 0;
  border: 0;
  padding: 0;
  float: none;
}
.select2-container {
  margin: 0;
  padding: 0;
  border: none;
  position: relative;
  display: inline-block;
  zoom: 1;
  *display: inline;
  vertical-align: middle;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn.cd-btn-primary {
  color: #fff;
  background: #e50112;
  border-color: #e50112;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
img {
  vertical-align: top;
  border: none;
}
@media (min-width: 992px) {
  .col-md-8 {
    width: 66.66666667%;
  }

  .col-md-1,
  .col-md-10,
  .col-md-11,
  .col-md-12,
  .col-md-2,
  .col-md-3,
  .col-md-4,
  .col-md-5,
  .col-md-6,
  .col-md-7,
  .col-md-8,
  .col-md-9 {
    float: left;
  }
}
label + .cd-radio-group .cd-radio {
  margin-top: 12px;
  margin-bottom: 4px;
}

.course-manage-info .cd-radio {
  min-width: 76px;
  color: rgba(0, 0, 0, 0.88);
  font-weight: 400;
}
.cd-radio {
  position: relative;
  padding-left: 20px;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  display: inline-block;
  margin-bottom: 0;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-radio-group {
  margin-bottom: 16px;
}
@media (min-width: 992px) {
  .col-md-8 {
    float: left;
    width: 66.66666667%;
  }
}
.width-full {
  width: 100%;
}
.select2-container {
  margin-left: 0;
  margin-right: 0;
  border: 0;
  padding: 0;
  float: none;
}
.select2-container,
.select2-drop,
.select2-search,
.select2-search input {
  -webkit-box-sizing: border-box;
  -khtml-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -ms-box-sizing: border-box;
  box-sizing: border-box;
}
.select2-container {
  margin: 0;
  padding: 0;
  border: none;
  position: relative;
  display: inline-block;
  zoom: 1;
  *display: inline;
  vertical-align: middle;
}
.course-manage-info .form-group {
  margin-bottom: 24px;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.cd-mt40 {
  margin-top: 40px !important;
}
.form-group {
  margin-bottom: 15px;
}
.course-manage-info .form-group {
  margin-bottom: 24px;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
@media screen and (min-width: 1200px) {
  .cd-container {
    width: 1200px;
  }
  .cd-container {
    padding-left: 12px;
    padding-right: 12px;
    margin: 0 auto;
  }
  .container {
    width: 1160px;
  }
}
.course-manage-info {
  position: relative;
}

.courseset-manage-padding {
  padding: 32px 0;
}
.courseset-manage-body {
  margin-top: 1px !important;
  min-height: 550px;
  background-color: #fff;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-content {
  position: relative;
  border-radius: 4px;
  margin-top: 24px;
  margin-bottom: 24px;
}
.courseset-manage-body__title {
  padding-bottom: 24px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.06);
  font-size: 16px;
  line-height: 1;
  color: rgba(0, 0, 0, 0.56);
  font-weight: 500;
}
.cd-mt32 {
  margin-top: 32px !important;
}
@media screen and (max-width: 992px) {
  .control-label-required {
    float: left;
  }
}
.w50 {
  width: 227px;
}
.itemInWorks {
  border-radius: 5px; /*圆角*/
  font-size: 18px;
  font-weight: 600;
  color: dimgrey;
  text-align: center; /*文字“婚礼策划”水平居中*/
  line-height: 50px; /*文字“婚礼策划”垂直居中*/
  box-shadow: #909090 0px 0px 10px; /*周围阴影*/
  overflow: hidden;
  position: relative;
}

/*半透明部分*/
.itemInWorks .mask {
  height: 100%;
  width: 100%;
  color: #f5f1e5;
  line-height: 178px;
  padding-left: 8px;
  border-radius: 2px 2px 5px 5px;
  font-size: 14px;
  font-weight: 300;
  text-align: center;
  font-weight: bold;
  /*以上根据个人的效果自定义*/

  position: absolute;
  top: 178px; /*鼠标不放时，半透明部分最高处离外层div顶端的距离*/
  background-color: rgba(0, 0, 0, 0.5); /*透明度*/
  transition: top 0.5s ease-in-out; /*改变top属性，0.5秒完成，慢开始慢结束*/
}

.itemInWorks:hover .mask {
  top: 0; /*鼠标放上时，滑动到的最高处离外层div顶端的距离*/
}
</style>
