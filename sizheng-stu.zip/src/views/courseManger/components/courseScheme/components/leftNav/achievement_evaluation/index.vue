<!--
    学员成绩
    @author:cpy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading">
      <div class="cd-main__title">成绩评定</div>
    </div>
    <div class="cd-main__body">
      <div class="course-statictics">
        <!-- 概览 -->
        <div class="dashboard row">
          <div class="col-xs-4 item bottom-border" @click="gotoHomeworkInfo()">
            <span class="number">作业</span>
            <!-- <div
              class="title"
            >共 {{ homeworkStatistical.submitNum }} 次 平均 {{ homeworkStatistical.average }} 分</div> -->
          </div>
          <div class="col-xs-4 item bottom-border" @click="gotoTestInfo()">
            <span class="number">测试</span>
            <!-- <div
              class="title"
            >共 {{ testStatistical.submitNum }} 次 平均 {{ testStatistical.average }} 分</div> -->
          </div>
          <div class="col-xs-4 item bottom-border no-right-border" @click="gotoExamInfo()">
            <span class="number">考试</span>
            <!-- <div class="title">
              共 {{ examStatistical.submitNum }} 次 平均 {{ examStatistical.average }} 分
              <span
                class="link-medium es-icon es-icon-help ml5"
                data-container="body"
                data-toggle="popover"
                data-trigger="hover"
                data-placement="top"
                data-content="观看免费任务和试看视频的总次数"
                data-original-title
                title
              ></span>
            </div> -->
          </div>
          <div class="col-xs-4 item">
            <span class="number">实验</span>
            <!-- <div class="title">共 0 次 平均 0 分</div> -->
          </div>
          <div class="col-xs-4 item">
            <span class="number">考勤</span>
            <!-- <div class="title">共 0 次 平均 0 分</div> -->
          </div>
          <div class="col-xs-4 item no-right-border">
            <span class="number">平时</span>
            <!-- <div class="title">共 0 次 平均 0 分</div> -->
          </div>
        </div>
        <div v-if="current" class="course-manage-subltitle cd-mb40">成绩详情</div>

        <!-- 学员趋势 -->
        <!-- <div id="js-student-trendency" class="statictic-body" data-course-id="41">
          <div class="statictic-header">学员趋势</div>
          <div id="date-range-picker">
            <span class="select-content">
              <input
                class="select-time-input js-date-range-input"
                type="text"
                name="course-datetime"
                value="2020/06/13-2020/06/19"
              />
              <i class="es-icon es-icon-arrowdropdown"></i>
            </span>
            <a
              href="javascript:;"
              class="date-change is-date-change js-quick-day-pick week"
              data-days="7"
            >7天</a>
            <a
              href="javascript:;"
              class="date-change is-date-change js-quick-day-pick month"
              data-days="30"
            >30天</a>
          </div>
          <div
            id="js-student-trendency-chart"
            class="stu-chart-container chart-container mtl"
            style="-webkit-tap-highlight-color: transparent; user-select: none; position: relative; background-color: transparent;"
            _echarts_instance_="ec_1592567146261"
          >
            <div
              style="position: relative; overflow: hidden; width: 892px; height: 250px; cursor: default;"
            >
              <canvas
                width="892"
                height="250"
                data-zr-dom-id="zr_0"
                style="position: absolute; left: 0px; top: 0px; width: 892px; height: 250px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"
              ></canvas>
            </div>
            <div
              style="position: absolute; display: none; border-style: solid; white-space: nowrap; z-index: 9999999; transition: left 0.4s cubic-bezier(0.23, 1, 0.32, 1) 0s, top 0.4s cubic-bezier(0.23, 1, 0.32, 1) 0s; background-color: rgb(255, 255, 255); border-width: 1px; border-color: rgb(245, 245, 245); border-radius: 4px; color: rgb(155, 155, 155); font: 14px/21px &quot;Microsoft YaHei&quot;; padding: 15px; left: 474.519px; top: 110px;"
            >
              2020-06-16
              <br />
              <span
                style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#FD7C82"
              ></span>新增学员 0
              <br />
              <span
                style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#6A94FD"
              ></span>免费试看数 0
              <br />
            </div>
          </div>
        </div>-->
        <!-- 完课率 -->
        <!-- <div id="finished-rate-trend" class="statictic-body" data-course-id="41">
          <div class="statictic-header">
            完课率
            <span
              class="link-medium es-icon es-icon-help ml5"
              data-container="body"
              data-toggle="popover"
              data-trigger="hover"
              data-placement="top"
              data-content="学完整个教学计划的人数 ÷ 该教学计划学员总数"
              data-original-title
              title
            ></span>
          </div>

          <div id="date-range-picker">
            <span class="select-content">
              <input
                class="select-time-input js-date-range-input"
                type="text"
                name="course-datetime"
                value="2020/06/13-2020/06/19"
              />
              <i class="es-icon es-icon-arrowdropdown"></i>
            </span>
            <a
              href="javascript:;"
              class="date-change is-date-change js-quick-day-pick week"
              data-days="7"
            >7天</a>
            <a
              href="javascript:;"
              class="date-change is-date-change js-quick-day-pick month"
              data-days="30"
            >30天</a>
          </div>
          <div
            id="finished-rate-chart"
            class="course-chart-container chart-container mtl"
            _echarts_instance_="ec_1592567146262"
            style="-webkit-tap-highlight-color: transparent; user-select: none; position: relative; background-color: transparent;"
          >
            <div
              style="position: relative; overflow: hidden; width: 892px; height: 250px; cursor: default;"
            >
              <canvas
                width="892"
                height="250"
                data-zr-dom-id="zr_0"
                style="position: absolute; left: 0px; top: 0px; width: 892px; height: 250px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"
              ></canvas>
            </div>
            <div
              style="position: absolute; display: none; border-style: solid; white-space: nowrap; z-index: 9999999; transition: left 0.4s cubic-bezier(0.23, 1, 0.32, 1) 0s, top 0.4s cubic-bezier(0.23, 1, 0.32, 1) 0s; background-color: rgb(255, 255, 255); border-width: 1px; border-color: rgb(245, 245, 245); border-radius: 4px; color: rgb(155, 155, 155); font: 14px/21px &quot;Microsoft YaHei&quot;; padding: 15px; left: 458.625px; top: 130px;"
            >
              2020-06-16
              <br />
              <span
                style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#92D178"
              ></span>完课人数 0
              <br />
              <span
                style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#FECF7D"
              ></span>完课率 0%
              <br />
            </div>
          </div>
        </div>
        <div class="statictic-body">
          <div class="statictic-header">
            <ul class="nav nav-tabs" role="tablist">
              <li class="active">
                <a href="#student-data-detail" data-toggle="tab" aria-expanded="true">学员详情</a>
              </li>
              <li class>
                <a href="#task-data-detail" data-toggle="tab" aria-expanded="false">任务详情</a>
              </li>
              <li class="highlight" style="left: 0.0215951px; width: 56px;"></li>
            </ul>
          </div>
          <div class="tab-content">
            <div id="student-data-detail" class="tab-pane fade active in">
              <form id="overview-student-detail" class="js-student-from">
                <span class="select-content bottom-border">
                  <select name="orderBy" class="select-time-select">
                    <option value="createdTimeDesc">加入时间 ↓</option>
                    <option value="createdTimeAsc">加入时间 ↑</option>
                    <option value="learnedCompulsoryTaskNumDesc">完成率 ↓</option>
                    <option value="learnedCompulsoryTaskNumAsc">完成率 ↑</option>
                  </select>
                  <i class="es-icon es-icon-arrowdropdown"></i>
                </span>
                <span class="select-content bottom-border">
                  <select class="select-time-select" name="range">
                    <option value>全部</option>
                    <option value="unFinished">未完成</option>
                    <option value="unLearnedSevenDays">7天未学</option>
                  </select>
                  <i class="es-icon es-icon-arrowdropdown"></i>
                </span>
                <span class="select-content">
                  <input
                    class="select-time-input js-name-search"
                    type="text"
                    name="nameOrMobile"
                    placeholder="用户名/手机号"
                  />
                  <i class="es-icon es-icon-search"></i>
                </span>
                <input type="hidden" name="courseId" value="41" />
                <a
                  class="cd-btn mhs cd-btn-sm pull-right cd-btn-primary js-export-btn"
                  href="javascript:;"
                  data-try-url="/try/export/course-overview-student-list"
                  data-url="/export/course-overview-student-list"
                  data-pre-url="/pre/export/course-overview-student-list"
                  data-loading-text="正在导出..."
                  data-target-form="#overview-student-detail"
                >
                  <i class="es-icon es-icon-filedownload cd-text-sm"></i>
                  导出
                </a>

                <div id="export-modal" class="hide">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button
                          type="button"
                          class="close"
                          data-dismiss="modal"
                          aria-hidden="true"
                        >×</button>
                        <h4 class="modal-title" data-success="文件下载完成">文件下载中</h4>
                      </div>
                      <div class="modal-body">
                        <div class="progress progress-striped active">
                          <div
                            id="progress-bar"
                            class="progress-bar progress-bar-success"
                            style="width: 0%"
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
              <button class="btn btn-primary pull-right hide">导出</button>
              <div
                id="student-detail-chart"
                data-form=".js-student-from"
                class="detail-chart-container chart-container mtl text-sm clearfix"
                data-url="/course/41/student/detail"
              >
                <div class="legend clearfix">
                  <div class="col-10">学员</div>
                  <div class="col-80">
                    任务进度
                    <span
                      class="legend-icon mll finish js-legend-btn"
                      data-bar-class=".finish-color"
                    >已学完</span>
                    <span
                      class="legend-icon mll start js-legend-btn"
                      data-bar-class=".start-color"
                    >学习中</span>
                    <span
                      class="legend-icon mll learn js-legend-btn"
                      data-bar-class=".learn-color"
                    >未学</span>
                  </div>
                  <div class="col-10">完成率</div>
                </div>
                <div class="empty">暂无记录</div>
              </div>
            </div>
            <div id="task-data-detail" class="tab-pane fade clearfix">
              <span class="select-content">
                <form id="overview-task-list" class="js-task-detail">
                  <input class="select-time-input" type="text" name="titleLike" placeholder="任务名" />
                  <i class="es-icon es-icon-search cursor-pointer js-task-detail-search"></i>
                  <input type="hidden" name="courseId" value="41" />
                </form>
              </span>
              <a
                class="cd-btn mhs cd-btn-sm pull-right cd-btn-primary js-export-btn"
                href="javascript:;"
                data-try-url="/try/export/course-overview-task-list"
                data-url="/export/course-overview-task-list"
                data-pre-url="/pre/export/course-overview-task-list"
                data-loading-text="正在导出..."
                data-target-form="#overview-task-list"
              >
                <i class="es-icon es-icon-filedownload cd-text-sm"></i>
                导出
              </a>

              <div id="export-modal" class="hide">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <h4 class="modal-title" data-success="文件下载完成">文件下载中</h4>
                    </div>
                    <div class="modal-body">
                      <div class="progress progress-striped active">
                        <div
                          id="progress-bar"
                          class="progress-bar progress-bar-success"
                          style="width: 0%"
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div
                id="task-data-chart"
                data-url="/course/41/task/detail"
                data-form=".js-task-detail"
                class="mtl detail-chart-container chart-container text-sm"
              >
                <div class="row">
                  <div class="legend clearfix">
                    <div class="col-10">任务</div>
                    <div class="col-80">
                      任务进度
                      <span
                        class="legend-icon mll finish js-legend-btn"
                        data-bar-class=".finish-color"
                      >已学完</span>
                      <span
                        class="legend-icon mll start js-legend-btn"
                        data-bar-class=".start-color"
                      >学习中</span>
                      <span
                        class="legend-icon mll learn js-legend-btn"
                        data-bar-class=".learn-color"
                      >未学</span>
                    </div>
                    <div class="col-10">完成率</div>
                  </div>
                  <div class="empty">暂无记录</div>
                </div>
                <div class="pull-right mtm"></div>
              </div>
            </div>
          </div>
        </div>-->
      </div>
    </div>
  </div>
</template>
<script>
import assignApi from '@/api/exambank/homework-arrange'
import examArrangeApi from '@/api/exambank/examArrange'
import EXAMBANKCONST from '@/constant/exambank-const'
import stuAnswerApi from '@/api/exambank/stu-answer'
import homeworkRecordApi from '@/api/exambank/homework-record'
// import ExamTestTable from './components/ExamTestTable'
// import TestTable from './components/TestTable'
// import HomeworkTable from './components/HomeworkTable'
export default {
  // components: {
  //   ExamTestTable,
  //   TestTable,
  //   HomeworkTable
  // },
  props: {
    courseScheme: {
      type: Object,
      default: () => { return {} }
    }
  },
  data() {
    return {
      // 作业统计对象
      homeworkStatistical: {},
      // 考试的查询参数对象
      examSelect: {},
      // 测试的查询参数对象
      testSelect: {},
      // 考试统计对象
      examStatistical: {},
      // 测试统计对象
      testStatistical: {},
      // 考试详情对象列表
      examInfoList: [],
      // 测试详情对象列表
      testInfoList: [],
      // 作业详情对象列表
      homeworkInfoList: [],
      // 当前显示哪部分成绩
      current: null
    }
  },
  mounted() {
    // this.getHomework()
    // this.getExam()
    // this.getTest()
  },
  methods: {
    /** 获取作业统计结果 */
    getHomework() {
      assignApi.statistics(this.courseScheme.schemeId).then(resp => {
        this.homeworkStatistical = resp.data
      })
    },
    /** 获取考试统计结果 */
    getExam() {
      this.examSelect.courseId = this.courseScheme.csId
      this.examSelect.termId = this.courseScheme.ctId
      this.examSelect.examType = EXAMBANKCONST.EXAM
      examArrangeApi.statistics(this.examSelect).then(resp => {
        this.examStatistical = resp.data
      })
    },
    /** 获取测试统计结果 */
    getTest() {
      this.testSelect.courseId = this.courseScheme.csId
      this.testSelect.termId = this.courseScheme.ctId
      this.testSelect.examType = EXAMBANKCONST.TEST
      examArrangeApi.statistics(this.testSelect).then(resp => {
        this.testStatistical = resp.data
      })
    },
    // 打开作业统计详情
    gotoHomeworkInfo() {
      if (this.homeworkStatistical.ids && this.homeworkStatistical.ids.length > 0) {
        this.current = 'homeworkStatistical'
        homeworkRecordApi.statisticsInfo(this.homeworkStatistical.ids).then(resp => {
          this.homeworkInfoList = resp.data
        })
      } else {
        this.$message({
          type: 'error',
          message: '抱歉，还没有学生作业记录!'
        })
      }
    },
    // 打开考试统计详情
    gotoExamInfo() {
      if (this.examStatistical.ids && this.examStatistical.ids.length > 0) {
        this.current = 'examStatistical'
        stuAnswerApi.statisticsInfo(this.examStatistical.ids).then(resp => {
          this.examInfoList = resp.data
        })
      } else {
        this.$message({
          type: 'error',
          message: '抱歉，还没有学生考试记录!'
        })
      }
    },
    // 打开测试统计详情
    gotoTestInfo() {
      if (this.testStatistical.ids && this.testStatistical.ids.length > 0) {
        this.current = 'testStatistical'
        stuAnswerApi.statisticsInfo(this.testStatistical.ids).then(resp => {
          this.testInfoList = resp.data
        })
      } else {
        this.$message({
          type: 'error',
          message: '抱歉，还没有学生测试记录!'
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
  .cd-main__heading {
    padding: 24px 32px;
    box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
    .cd-main__title {
      font-size: 16px;
      color: rgba(0, 0, 0, 0.88);
      line-height: 1;
      margin: 0 auto;
      font-weight: 500;
    }
  }
  .cd-main__body {
    padding: 32px;
    min-height: 900px;
    .course-manage-subltitle {
      padding: 9px 0 9px 32px;
      font-size: 14px;
      font-weight: 500;
      line-height: 1;
      color: rgba(0, 0, 0, 0.8);
      background-color: rgba(0, 0, 0, 0.04);
    }

    .cd-mb40 {
      margin-bottom: 40px !important;
    }
    .course-statictics {
      .dashboard {
        background: #fff;
        box-shadow: 0 0 30px 0 rgba(0, 0, 0, 0.03);
        border-radius: 4px;
        margin: 10px;
        text-align: center;
        margin-bottom: 20px;
        .item {
          padding-top: 30px;
          height: 120px;
          border-right: 1px solid rgba(0, 0, 0, 0.06);
          cursor: pointer;
          .number {
            position: relative;
            opacity: 0.88;
            font-size: 32px;
            color: #000;
            letter-spacing: 1px;
            line-height: 32px;
          }
          .title {
            opacity: 0.56;
            font-size: 12px;
            color: #000;
            letter-spacing: 0;
            line-height: 12px;
            padding-top: 10px;
          }
        }
        .bottom-border {
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
        }
        .no-right-border {
          border-right: none;
        }
      }
    }

    .statictic-body {
      margin: 0 10px 20px;
    }
  }
}
</style>
