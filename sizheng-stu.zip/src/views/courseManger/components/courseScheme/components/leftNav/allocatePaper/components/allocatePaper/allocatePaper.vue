<template>
  <div v-loading="loading" class="re" style="border-top: 15px solid #f8f8f8;">
    <div class="re" style="border-top: 15px solid #f8f8f8;">
      <div style="margin-left: 360px; margin-right: 360px;">
        <div class="tac">
          <img src="images/ico_title_1.jpg" alt />
        </div>
        <div class="re pt15 pb15">
          <p class="tac lh40">
            <span class="fz24 fwb vm">{{ paper.paperTitle }}</span>
          </p>
          <!-- <div class="mt25 subject_area_sty_2">
            <div class="tac">
              <div class="mt15 re dib">
                <div class="achievement_score_bg">
                  <span class="fwb">{{ stuAnswer.score }}</span>
                  <span class="fz24">分</span>
                </div>
              </div>
            </div>
          </div> -->
        </div>
        <div v-for="(item,index) of questionList" :key="index" style="margin-bottom:20px">
          <div v-if="item.tqTypeId.toString()===SINGLE || item.tqTypeId.toString()===MULTIPLE || item.tqTypeId.toString()===JUDGEMENT" :style="{display: currentIndex== index? 'block':'none'}">
            <div
              :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
              style="padding: 0; "
            >
              <div class="pa25">
                <div class="cf">
                  <div class="mr25 fl">
                    <div class>
                      <i class="ico_subject_num">{{ index+1 }}</i>
                    </div>
                    <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                  </div>
                  <div class="ov">
                    <p class="mt5 lh24">
                      <span class="fz16 fwb">{{ item.content }}</span>
                    </p>
                    <!--选项-->
                    <div class="mt10">
                      <div v-for="(item1,index1) of item.options" :key="index1">
                        <p class="fz15 lh38 cor_2">{{ item1.value }}:{{ item1.label }}</p>
                      </div>
                    </div>
                    <!--正确答案-->
                    <div class="mt20 re cf" style="padding-right: 105px;">
                      <div v-if="item.pdId!==null" class="fz15 cor_2">
                        <span class>
                          正确答案是
                          <em class="cor_00c">{{ item.answer }}</em>
                        </span>
                        <span class="ml15">
                          学生答案是
                          <em
                            class="cor_00c"
                            :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                          >{{ item.userAnswer }}</em>
                        </span>
                        <span class="ml15">
                          学生得分
                          <em
                            class="cor_00c"
                          >{{ item.score }} </em>分
                        </span>
                        <span class="ml15">
                          评分者
                          <em>{{ item.grader }}</em>
                        </span>
                      </div>
                      <div v-else class="fz15 cor_2">
                        <span class>
                          <em class="cor_00c" style="color:#E20312">学生未提交</em>
                        </span>
                      </div>
                      <div v-if="item.pdId!==null" class="fz15 cor_2 mt20">
                        教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                        <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">修改</el-button>
                      </div>
                      <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                        <span
                          class="analysis_fz_sty fz15 cor_2 vm"
                        >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                        <i class="ml10 ico_arrow_rotate"></i>
                      </a>
                    </div>
                  <!--正确答案-->
                  </div>
                </div>
              </div>
              <!--pa25-->
              <!--解析-->
              <div class="analysis_area_b">
                <div class="mr25 fl vh">
                  <div class>
                    <i class="ico_subject_num">{{ index+1 }}</i>
                  </div>
                  <p class="mt10 cor_e10 tac">共2分</p>
                </div>
                <div class="ov">
                  <p class="fz16 fwb">解析：</p>
                  <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                </div>
              </div>
            <!--解析-->
            </div>
          </div>
          <div v-if="item.tqTypeId.toString()===FILLBLANK" :style="{display: currentIndex== index? 'block':'none'}">
            <div
              :id="'bank'+item.pdId"
              :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
              style="padding: 0;"
            >
              <div class="pa25">
                <div class="cf">
                  <div class="mr25 fl">
                    <div class>
                      <i class="ico_subject_num">{{ index+1 }}</i>
                    </div>
                    <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                  </div>
                  <div class="ov">
                    <p class="mt5 lh24"><span class="fz16 fwb" v-html="item.prveContent"><span class="dib h20 lh20 bb4" style="width: 70px;"></span><span class="dib h20 lh20 bb4" style="width: 70px;"></span></span></p>

                    <!--正确答案-->
                    <div class="mt20 re cf" style="padding-right: 105px;">
                      <div v-if="item.pdId!==null" class="fz15 cor_2">
                        <span class>
                          正确答案是
                          <em class="cor_00c">{{ item.answer }}</em>
                        </span>
                        <span class="ml15">
                          学生答案是
                          <em
                            class="cor_00c"
                            :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                          >{{ item.userAnswer }}</em>
                        </span>
                        <span class="ml15">
                          学生得分
                          <em
                            class="cor_00c"
                          >{{ item.score }} </em>分
                        </span>
                        <span class="ml15">
                          评分者
                          <em>{{ item.grader }}</em>
                        </span>
                      </div>
                      <div v-else class="fz15 cor_2">
                        <span class>
                          <em class="cor_00c" style="color:#E20312">学生未提交</em>
                        </span>
                      </div>
                      <div v-if="item.pdId!==null" class="fz15 cor_2 mt20">
                        教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                        <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">修改</el-button>
                      </div>
                      <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                        <span
                          class="analysis_fz_sty fz15 cor_2 vm"
                        >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                        <i class="ml10 ico_arrow_rotate"></i>
                      </a>
                    </div>
                    <!--正确答案-->
                  </div>
                </div>
              </div>
              <!--解析-->
              <div class="analysis_area_b cf">
                <div class="mr25 fl vh">
                  <div class>
                    <i class="ico_subject_num">1</i>
                  </div>
                  <p class="mt10 cor_e10 tac">共2分</p>
                </div>
                <div class="ov">
                  <p class="fz16 fwb">解析：</p>
                  <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                </div>
              </div>
              <!--解析-->
            </div>
          </div>
          <div v-if="item.tqTypeId.toString()===MATERIAL" :style="{display: currentIndex== index? 'block':'none'}">
            <div class="pl25 bl1">
              <div :id="'item'+item.pdId" class="subject_area_sty_2">
                <div class="cf">
                  <p class="mr35 pl30 fl fz20 fwb lh40">材料</p>
                  <div class="ov">
                    <p class="fz18 lh40 ti" v-html="item.content"></p>
                  </div>
                </div>
                <i class="dot_sty_pos"></i>
              </div>
              <!-- 单选题 -->
              <div v-if="item.mselectBankList.length>0">
                <div class="pt15 pb15">
                  <i class="ml15 ico_subject_type_3"></i>
                  <span class="ml20 fz20 fwb vm">材料单选题</span>
                  <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                </div>
                <div v-for="(item1,index1) of item.mselectBankList" :key="index1">
                  <div
                    :class="[item1.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                    style="padding: 0;"
                  >
                    <div class="pa25">
                      <div class="cf">
                        <div class="mr25 fl">
                          <div class>
                            <i class="ico_subject_num">{{ index1+1 }}</i>
                          </div>
                          <p class="mt10 cor_e10 tac">共{{ item1.value }}分</p>
                        </div>
                        <div class="ov">
                          <p class="mt5 lh24">
                            <span class="fz16 fwb">{{ item1.content }}</span>
                            <!-- <span class="ml15 state_bg_sty_2">待查</span> -->
                          </p>
                          <!--选项-->
                          <div class="mt10">
                            <div v-for="(item12,index12) of item1.options" :key="index12">
                              <p class="fz15 lh38 cor_2">{{ item12.value }}:{{ item12.label }}</p>
                            </div>
                          </div>
                          <!--正确答案-->
                          <div class="mt20 re cf" style="padding-right: 105px;">
                            <div v-if="item1.pdId!==null" class="fz15 cor_2">
                              <span class>
                                正确答案是
                                <em class="cor_00c">{{ item1.answer }}</em>
                              </span>
                              <span class="ml15">
                                学生答案是
                                <em
                                  class="cor_00c"
                                  :style="{color: item1.isCorrect? '#00CC56' : '#E20312'}"
                                >{{ item1.userAnswer }}</em>
                              </span>
                              <span class="ml15">
                                学生得分
                                <em
                                  class="cor_00c"
                                >{{ item1.score }} </em>分
                              </span>
                              <span class="ml15">
                                评分者
                                <em>{{ item1.grader }}</em>
                              </span>
                            </div>
                            <div v-else class="fz15 cor_2">
                              <span class>
                                <em class="cor_00c" style="color:#E20312">学生未提交</em>
                              </span>
                            </div>
                            <div v-if="item1.pdId!==null" class="fz15 cor_2 mt20">
                              教师评分：<el-input-number v-model="item1.score" controls-position="right" :min="0" :max="item1.value" :step="0.1"></el-input-number>
                              <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item1)">修改</el-button>
                            </div>
                            <a class="analysis_weizhi_pos click" @click="changeShow(item1)">
                              <span
                                class="analysis_fz_sty fz15 cor_2 vm"
                              >{{ item1.showFlag? '收起解析': '展开解析' }}</span>
                              <i class="ml10 ico_arrow_rotate"></i>
                            </a>
                          </div>
                          <!--正确答案-->
                        </div>
                      </div>
                    </div>

                    <!--解析-->
                    <div class="analysis_area_b cf">
                      <div class="mr25 fl vh">
                        <div class>
                          <i class="ico_subject_num">1</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共2分</p>
                      </div>
                      <div class="ov">
                        <p class="fz16 fwb">解析：</p>
                        <p class="fz15 lh28" v-html="item1.ideas">{{ item1.ideas }}</p>
                      </div>
                    </div>
                    <!--解析-->

                    <i class="dot_sty_pos"></i>
                  </div>
                </div>
              </div>
              <!-- 单选题 -->
              <!-- 多选题 -->
              <div v-if="item.mmultselectBankList.length>0">
                <div class="pt15 pb15">
                  <i class="ml15 ico_subject_type_3"></i>
                  <span class="ml20 fz20 fwb vm">材料多选题</span>
                  <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                </div>
                <div v-for="(item1,index1) of item.mmultselectBankList" :key="index1">
                  <div
                    :class="[item1.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                    style="padding: 0;"
                  >
                    <div class="pa25">
                      <div class="cf">
                        <div class="mr25 fl">
                          <div class>
                            <i class="ico_subject_num">{{ index1+1 }}</i>
                          </div>
                          <p class="mt10 cor_e10 tac">共{{ item1.value }}分</p>
                        </div>
                        <div class="ov">
                          <p class="mt5 lh24">
                            <span class="fz16 fwb">{{ item1.content }}</span>
                            <!-- <span class="ml15 state_bg_sty_2">待查</span> -->
                          </p>
                          <!--选项-->
                          <div class="mt10">
                            <div v-for="(item12,index12) of item1.options" :key="index12">
                              <p class="fz15 lh38 cor_2">{{ item12.value }}:{{ item12.label }}</p>
                            </div>
                          </div>
                          <!--正确答案-->
                          <div class="mt20 re cf" style="padding-right: 105px;">
                            <div v-if="item1.pdId!==null" class="fz15 cor_2">
                              <span class>
                                正确答案是
                                <em class="cor_00c">{{ item1.answer }}</em>
                              </span>
                              <span class="ml15">
                                学生答案是
                                <em
                                  class="cor_00c"
                                  :style="{color: item1.isCorrect? '#00CC56' : '#E20312'}"
                                >{{ item1.userAnswer }}</em>
                              </span>
                              <span class="ml15">
                                学生得分
                                <em
                                  class="cor_00c"
                                >{{ item1.score }} </em>分
                              </span>
                              <span class="ml15">
                                评分者
                                <em>{{ item1.grader }}</em>
                              </span>
                            </div>
                            <div v-else class="fz15 cor_2">
                              <span class>
                                <em class="cor_00c" style="color:#E20312">学生未提交</em>
                              </span>
                            </div>
                            <div v-if="item1.pdId!==null" class="fz15 cor_2 mt20">
                              教师评分：<el-input-number v-model="item1.score" controls-position="right" :min="0" :max="item1.value" :step="0.1"></el-input-number>
                              <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item1)">修改</el-button>
                            </div>
                            <a class="analysis_weizhi_pos click" @click="changeShow(item1)">
                              <span
                                class="analysis_fz_sty fz15 cor_2 vm"
                              >{{ item1.showFlag? '收起解析': '展开解析' }}</span>
                              <i class="ml10 ico_arrow_rotate"></i>
                            </a>
                          </div>
                          <!--正确答案-->
                        </div>
                      </div>
                    </div>

                    <!--解析-->
                    <div class="analysis_area_b cf">
                      <div class="mr25 fl vh">
                        <div class>
                          <i class="ico_subject_num">1</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共2分</p>
                      </div>
                      <div class="ov">
                        <p class="fz16 fwb">解析：</p>
                        <p class="fz15 lh28" v-html="item1.ideas">{{ item1.ideas }}</p>
                      </div>
                    </div>
                    <!--解析-->

                    <i class="dot_sty_pos"></i>
                  </div>
                </div>
              </div>
              <!-- 多选题 -->

              <!--问答题-->
              <div v-if="item.mquestanswerBankList.length>0" class="mt15">
                <div class="pt15 pb15">
                  <i class="ml15 ico_subject_type_3"></i>
                  <span class="ml20 fz20 fwb vm">材料问答题</span>
                  <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                </div>
                <!--题目-->
                <div v-for="(item1,index1) of item.mquestanswerBankList" :key="index1">
                  <div :class="[item1.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']">
                    <div class="cf">
                      <div class="mr25 fl">
                        <div class>
                          <i class="ico_subject_num">{{ index1+1 }}</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共{{ item1.value }}分</p>
                      </div>
                      <div class="ov">
                        <p class="mt5 lh24">
                          <span class="fz16 fwb" v-html="item1.content">{{ item1.content }}</span>
                          <!-- <span class="ml15 state_bg_sty_1">待查</span> -->
                        </p>

                        <!--内容-->
                        <div class="mt20 re cf" style="padding-right: 105px;">
                          <div class="cor_1 fz16 mt25">正确答案：</div>
                          <div class=" b2 pa20">
                            <p class="fz16 lh24 cor_1"> {{ item1.answer }}</p>
                          </div>
                          <div class="cor_1 fz16 mt25">学生答案：</div>
                          <div class=" b2 pa20">
                            <p class="fz16 lh24 cor_1" v-html="item1.userAnswer"></p>
                          </div>
                          <div v-if="item1.pdId!==null" class="fz15 cor_2 mt20">
                            <span class="">
                              学生得分
                              <em
                                class="cor_00c"
                              >{{ item1.score }} </em>分
                            </span>
                            <span class="ml15">
                              评分者
                              <em>{{ item1.grader }}</em>
                            </span>
                          </div>
                          <div v-else class="fz15 cor_2 mt20">
                            <span class>
                              <em class="cor_00c" style="color:#E20312">学生未提交</em>
                            </span>
                          </div>
                          <div v-if="item1.pdId!==null" class="fz15 cor_2 mt20">
                            教师评分：<el-input-number v-model="item1.score" controls-position="right" :min="0" :max="item1.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item1)">修改</el-button>
                          </div>
                          <a class="analysis_weizhi_pos click" @click="changeShow(item1)">
                            <span
                              class="analysis_fz_sty fz15 cor_2 vm"
                            >{{ item1.showFlag ? '收起解析': '展开解析' }}</span>
                            <i class="ml10 ico_arrow_rotate"></i>
                          </a>
                        </div>
                      </div>
                      <!--解析-->
                      <div class="analysis_area_b cf mt20">
                        <div class="mr25 fl vh">
                          <div class>
                            <i class="ico_subject_num">{{ index1+1 }}</i>
                          </div>
                          <p class="mt10 cor_e10 tac">共{{ item1.value }}分</p>
                        </div>
                        <div class="ov">
                          <p class="fz16 fwb">解析：</p>
                          <p class="fz15 lh28" v-html="item1.ideas"></p>
                        </div>
                      </div>
                      <!--解析-->
                    </div>
                  </div>
                </div>
              </div>
              <!--问答题-->

              <!--判断题-->
              <div v-if="item.mjudgeBnakList.length>0" class="mt15">
                <div class="pt15 pb15">
                  <i class="ml15 ico_subject_type_4"></i>
                  <span class="ml20 fz20 fwb vm">材料判断题</span>
                  <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                </div>
                <!--题目-->
                <div v-for="(item1,index1) of item.mjudgeBnakList" :key="index1">
                  <div
                    :class="[item1.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                    style="padding: 0;"
                  >
                    <div class="pa25">
                      <div class="cf">
                        <div class="mr25 fl">
                          <div class>
                            <i class="ico_subject_num">{{ index1+1 }}</i>
                          </div>
                          <p class="mt10 cor_e10 tac">共{{ item1.value }}分</p>
                        </div>
                        <div class="ov">
                          <p class="mt5 lh24">
                            <span class="fz16 fwb">{{ item1.content }}</span>
                            <!-- <span class="ml15 state_bg_sty_1">待查</span> -->
                          </p>
                          <!--正确答案-->
                          <div class="mt20 re cf" style="padding-right: 105px;">
                            <div v-if="item1.pdId!==null" class="fz15 cor_2">
                              <span class>
                                正确答案是
                                <em class="cor_00c">{{ item1.answer }}</em>
                              </span>
                              <span class="ml15">
                                学生答案是
                                <em
                                  class="cor_00c"
                                  :style="{color: item1.isCorrect? '#00CC56' : '#E20312'}"
                                >{{ item1.userAnswer }}</em>
                              </span>
                              <span class="ml15">
                                学生得分
                                <em
                                  class="cor_00c"
                                >{{ item1.score }} </em>分
                              </span>
                              <span class="ml15">
                                评分者
                                <em>{{ item1.grader }}</em>
                              </span>
                            </div>
                            <div v-else class="fz15 cor_2">
                              <span class>
                                <em class="cor_00c" style="color:#E20312">学生未提交</em>
                              </span>
                            </div>
                            <div v-if="item1.pdId!==null" class="fz15 cor_2 mt20">
                              教师评分：<el-input-number v-model="item1.score" controls-position="right" :min="0" :max="item1.value" :step="0.1"></el-input-number>
                              <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item1)">修改</el-button>
                            </div>
                            <a class="analysis_weizhi_pos click" @click="changeShow(item1)">
                              <span
                                class="analysis_fz_sty fz15 cor_2 vm"
                              >{{ item1.showFlag? '收起解析': '展开解析' }}</span>
                              <i class="ml10 ico_arrow_rotate"></i>
                            </a>
                          </div>
                          <!--正确答案-->
                        </div>
                      </div>
                    </div>

                    <!--解析-->
                    <div class="analysis_area_b cf">
                      <div class="mr25 fl vh">
                        <div class>
                          <i class="ico_subject_num">1</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共2分</p>
                      </div>
                      <div class="ov">
                        <p class="fz16 fwb">解析：</p>
                        <p class="fz15 lh28" v-html="item1.ideas">{{ item1.ideas }}</p>
                      </div>
                    </div>
                    <!--解析-->
                  </div>
                </div>
              </div>
              <!--判断题-->

              <!--填空题-->
              <div v-if="item.mblankBankList.length>0" class="mt15">
                <div class="pt15 pb15">
                  <i class="ml15 ico_subject_type_3"></i>
                  <span class="ml20 fz20 fwb vm">材料填空题</span>
                  <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                </div>
                <!--题目-->
                <div v-for="(item1,index1) of item.mblankBankList" :key="index1">
                  <div
                    :class="[item1.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                    style="padding: 0;"
                  >
                    <div class="pa25">
                      <div class="cf">
                        <div class="mr25 fl">
                          <div class>
                            <i class="ico_subject_num">1</i>
                          </div>
                          <p class="mt10 cor_e10 tac">共2分</p>
                        </div>
                        <div class="ov">
                          <p class="mt5 lh24"><span class="fz16 fwb" v-html="item1.prveContent"><span class="dib h20 lh20 bb4" style="width: 70px;"></span><span class="dib h20 lh20 bb4" style="width: 70px;"></span></span></p>
                          <!--正确答案-->
                          <div class="mt20 re cf" style="padding-right: 105px;">
                            <div v-if="item1.pdId!==null" class="fz15 cor_2">
                              <span class>
                                正确答案是
                                <em class="cor_00c">{{ item1.answer }}</em>
                              </span>
                              <span class="ml15">
                                学生答案是
                                <em
                                  class="cor_00c"
                                  :style="{color: item1.isCorrect? '#00CC56' : '#E20312'}"
                                >{{ item1.userAnswer }}</em>
                              </span>
                              <span class="ml15">
                                学生得分
                                <em
                                  class="cor_00c"
                                >{{ item1.score }} </em>分
                              </span>
                              <span class="ml15">
                                评分者
                                <em>{{ item1.grader }}</em>
                              </span>
                            </div>
                            <div v-else class="fz15 cor_2">
                              <span class>
                                <em class="cor_00c" style="color:#E20312">学生未提交</em>
                              </span>
                            </div>
                            <div v-if="item1.pdId!==null" class="fz15 cor_2 mt20">
                              教师评分：<el-input-number v-model="item1.score" controls-position="right" :min="0" :max="item1.value" :step="0.1"></el-input-number>
                              <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item1)">修改</el-button>
                            </div>
                            <a class="analysis_weizhi_pos click" @click="changeShow(item1)">
                              <span
                                class="analysis_fz_sty fz15 cor_2 vm"
                              >{{ item1.showFlag? '收起解析': '展开解析' }}</span>
                              <i class="ml10 ico_arrow_rotate"></i>
                            </a>
                          </div>
                          <!--正确答案-->
                        </div>
                      </div>
                    </div>
                    <!--解析-->
                    <div class="analysis_area_b cf">
                      <div class="mr25 fl vh">
                        <div class>
                          <i class="ico_subject_num">1</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共2分</p>
                      </div>
                      <div class="ov">
                        <p class="fz16 fwb">解析：</p>
                        <p class="fz15 lh28" v-html="item1.ideas">{{ item1.ideas }}</p>
                      </div>
                    </div>
                    <!--解析-->
                  </div>
                </div>
              </div>
              <!--填空题-->
            </div>

          </div>
          <div v-if="item.tqTypeId.toString()===ESSAY_QUESTION" :style="{display: currentIndex== index? 'block':'none'}">
            <div :id="'bank'+item.pdId" :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']">
              <div class="cf">
                <div class="mr25 fl">
                  <div class>
                    <i class="ico_subject_num">{{ index+1 }}</i>
                  </div>
                  <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                </div>
                <div class="ov">
                  <p class="mt5 lh24">
                    <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                    <!-- <span class="ml15 state_bg_sty_2">待查</span> -->
                  </p>
                  <!--内容-->
                  <div class="mt20 re cf" style="padding-right: 105px;">
                    <div class="cor_1 fz16 mt25">正确答案：</div>
                    <div class=" b2 pa20">
                      <p class="fz16 lh24 cor_1"> {{ item.answer }}</p>
                    </div>
                    <div class="cor_1 fz16 mt25">学生答案：</div>
                    <div class=" b2 pa20">
                      <p class="fz16 lh24 cor_1" v-html="item.userAnswer"></p>
                    </div>
                    <div v-if="item.pdId!==null" class="fz15 cor_2 mt20">
                      <span class="">
                        学生得分
                        <em
                          class="cor_00c"
                        >{{ item.score }} </em>分
                      </span>
                      <span class="ml15">
                        评分者
                        <em>{{ item.grader }}</em>
                      </span>
                    </div>
                    <div v-else class="fz15 cor_2 mt20">
                      <span class>
                        <em class="cor_00c" style="color:#E20312">学生未提交</em>
                      </span>
                    </div>
                    <div v-if="item.pdId!==null" class="fz15 cor_2 mt20">
                      教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                      <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">修改</el-button>
                    </div>
                    <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                      <span
                        class="analysis_fz_sty fz15 cor_2 vm"
                      >{{ item.showFlag ? '收起解析': '展开解析' }}</span>
                      <i class="ml10 ico_arrow_rotate"></i>
                    </a>
                  </div>
                  <!--内容-->
                  <!-- <p class="mt20 pl20 fz16 cor_1">
                      得分：
                      <span class="fz20 cor_e10">2分</span>
                    </p> -->

                </div>
              </div>
              <!--解析-->
              <div class="analysis_area_b cf mt20">
                <div class="mr25 fl vh">
                  <div class>
                    <i class="ico_subject_num">{{ index+1 }}</i>
                  </div>
                  <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                </div>
                <div class="ov">
                  <p class="fz16 fwb">解析：</p>
                  <p class="fz15 lh28" v-html="item.ideas"></p>
                </div>
              </div>
              <!--解析-->
            </div>
          </div>
          <div v-if="item.tqTypeId.toString()===PROGRAMME" :style="{display: currentIndex== index? 'block':'none'}">
            <div
              :id="'bank'+item.pdId"
              :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
            >
              <div class="cf">
                <div class="mr25 fl">
                  <div class>
                    <i class="ico_subject_num">{{ index+1 }}</i>
                  </div>
                  <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                </div>
                <div class="ov">
                  <p class="mt5 lh24">
                    <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                  </p>
                  <!--富文本编辑器-->
                  <tinymce
                    ref="topicContent"
                    v-model="item.answer"
                    :save-flag="saveFlag"
                    class="mt25"
                  />
                  <!--正确答案-->
                  <div class="mt20 mb20 re cf" style="padding-right: 105px;">
                    <div v-if="item.pdId!==null" class="fz15 cor_2">
                      <span class="">
                        下载学生答案
                        <em class="cor_00c">
                          <el-button
                            size="small"
                            style="margin-left:20px"
                            type="success"
                            @click="downLoad(item.userAnswer,index)"
                          >下载</el-button>
                        </em>
                      </span>
                      <span class="ml15">
                        学生得分是
                        <em
                          class="cor_00c"
                        >{{ item.score }} </em>分
                      </span>
                      <span class="ml15">
                        评分者
                        <em>{{ item.grader }}</em>
                      </span>
                    </div>
                    <div v-else class="fz15 cor_2">
                      <span class>
                        <em class="cor_00c" style="color:#E20312">学生未提交</em>
                      </span>
                    </div>
                    <div v-if="item.pdId!==null" class="fz15 cor_2 mt20 ">
                      <span class="">
                        评分结果：<br>
                        <span style="letter-spacing:1pt;line-height:25px;" v-html="item.gradeResult"></span>
                      </span>
                    </div>
                    <div v-if="item.pdId!==null" class="fz15 cor_2 mt20 ">
                      教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                      <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">修改</el-button>
                    </div>
                    <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                      <span
                        class="analysis_fz_sty fz15 cor_2 vm"
                      >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                      <i class="ml10 ico_arrow_rotate"></i>
                    </a>
                  </div>
                  <!--正确答案-->
                </div>
                <!--解析-->
                <div class="analysis_area_b cf">
                  <div class="mr25 fl vh">
                    <div class>
                      <i class="ico_subject_num">1</i>
                    </div>
                    <p class="mt10 cor_e10 tac">共2分</p>
                  </div>
                  <div class="ov">
                    <p class="fz16 fwb">解析：</p>
                    <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                  </div>
                </div>
                <!--解析-->
              </div>
            </div>
          </div>
          <div v-if="item.tqTypeId.toString()===PROG_FILLBLANK" :style="{display: currentIndex== index? 'block':'none'}">
            <div
              :id="'bank'+item.pdId"
              :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
            >
              <div class="cf">
                <div class="mr25 fl">
                  <div class>
                    <i class="ico_subject_num">{{ index+1 }}</i>
                  </div>
                  <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                </div>
                <div class="ov">
                  <p class="mt5 lh24">
                    <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                  </p>
                  <tinymce
                    v-model="item.code"
                    plugins="codesample"
                    toolbar="false"
                    menubar="false"
                    inline="true"
                    :height="400"
                  />
                  <!--正确答案-->
                  <div class="mt20 re cf" style="padding-right: 105px;">
                    <div v-if="item.pdId!==null" class="fz15 cor_2">
                      <span class="">
                        下载学生答案
                        <em class="cor_00c">
                          <el-button
                            size="small"
                            style="margin-left:20px"
                            type="success"
                            @click="downLoad(item.attachment,index)"
                          >下载</el-button>
                        </em>
                      </span>
                      <span class="ml15">
                        学生得分是
                        <em
                          class="cor_00c"
                        >{{ item.score }} </em>分
                      </span>
                      <span class="ml15">
                        评分者
                        <em>{{ item.grader }}</em>
                      </span>
                    </div>
                    <div v-else class="fz15 cor_2">
                      <span class>
                        <em class="cor_00c" style="color:#E20312">学生未提交</em>
                      </span>
                    </div>
                    <div v-if="item.pdId!==null" class="fz15 cor_2 mt20 ">
                      <span class="">
                        评分结果：<br>
                        <span style="letter-spacing:1pt;line-height:25px;" v-html="item.gradeResult"></span>
                      </span>
                    </div>
                    <div v-if="item.pdId!==null" class="fz15 cor_2 mt20 ">
                      教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                      <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">修改</el-button>
                    </div>
                    <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                      <span
                        class="analysis_fz_sty fz15 cor_2 vm"
                      >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                      <i class="ml10 ico_arrow_rotate"></i>
                    </a>
                  </div>
                  <!--正确答案-->
                </div>

                <div class="analysis_area_b cf">
                  <div class="mr25 fl vh">
                    <div class>
                      <i class="ico_subject_num">1</i>
                    </div>
                    <p class="mt10 cor_e10 tac">共2分</p>
                  </div>
                  <div class="ov">
                    <p class="fz16 fwb">解析：</p>
                    <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                  </div>
                </div>
                <!--解析-->
              </div>
            </div>
          </div>
          <div v-if="item.tqTypeId.toString()===FILE_UPLOAD" :style="{display: currentIndex== index? 'block':'none'}">
            <div :id="'bank'+item.pdId" :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']">
              <div class="cf">
                <div class="mr25 fl">
                  <div class>
                    <i class="ico_subject_num">{{ index+1 }}</i>
                  </div>
                  <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                </div>
                <div class="ov">
                  <p class="mt5 lh30">
                    <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                  </p>
                </div>
                <div class="mt20 mb20 re cf" style="padding-right: 105px;">
                  <div v-if="item.pdId!==null" class="fz15 cor_2">
                    <span class="">
                      下载学生答案
                      <em class="cor_00c">
                        <el-button
                          size="small"
                          style="margin-left:10px"
                          type="success"
                          @click="downLoad(item.userAnswer,index)"
                        >下载</el-button>
                      </em>
                    </span>
                    <span class="ml15">
                      学生得分是
                      <em
                        class="cor_00c"
                      >{{ item.score }} </em>分
                    </span>
                    <span class="ml15">
                      评分者
                      <em>{{ item.grader }}</em>
                    </span>
                  </div>
                  <div v-else class="fz15 cor_2">
                    <span class>
                      <em class="cor_00c" style="color:#E20312">学生未提交</em>
                    </span>
                  </div>
                  <div v-if="item.pdId!==null" class="fz15 cor_2 mt20 " style="margin-left:73px">
                    教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                    <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">修改</el-button>
                  </div>
                  <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                    <span
                      class="analysis_fz_sty fz15 cor_2 vm"
                    >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                    <i class="ml10 ico_arrow_rotate"></i>
                  </a>
                </div>
                <div class="analysis_area_b cf">
                  <div class="mr25 fl vh">
                    <div class>
                      <i class="ico_subject_num">1</i>
                    </div>
                    <p class="mt10 cor_e10 tac">共2分</p>
                  </div>
                  <div class="ov">
                    <p class="fz16 fwb">解析：</p>
                    <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <el-row style="margin-bottom:20px">
        <el-col :span="18" style="text-align:right;" class="submit-buttons">
          <el-button
            v-show="currentIndex != 0"
            :style="{display:currentIndex == 0? 'none':'line-block' }"
            @click="currentPrevious()"
          >上一题</el-button>
          <el-button
            v-show="currentIndex != questionList.length-1"
            :style="{padding:currentIndex == 0 ? '10px 45px' :'10px 45px' }"
            type="primary"
            @click="currentNext()"
          >下一题</el-button>
          <el-button
            v-show="currentIndex == questionList.length-1"
            type="primary"
            @click="finishMarke()"
          >提 交</el-button>
        </el-col>
      </el-row>
      <div id="fixed_answer_card" ref="answercard" class="fixed_answer_card" style="top:0px">
        <div class="fixed_answer_card_info">
          <div class="answer_card_title_bg">
            <p class="fz26 fwb cor_e10">阅卷状态</p>
          </div>
          <div class="scroll_mcs_2 answer-card">
            <!--单选题-->
            <div v-if="questionList.length>0">
              <ul class="answer_card_num_list fl_dib">
                <li
                  v-for="(item,index) of questionList"
                  :key="index"
                  :class="[item.grader === null || item.grader === '' ? 'no_current ' : '']"
                  @click="goAnchor(index)"
                >
                  <span>{{ index+1 }}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Tinymce from '@/components/Tinymce'
import EXAMBANK_CONST from '@/constant/exambank-const'
import { mapGetters } from 'vuex'
// import stuAnswerApi from '@/api/exambank/stu-answer.js'
import { downloadByLink } from '@/utils/index'
import paperAllocateApi from '@/api/exambank/paper-allocate'
import answerScoreApi from '@/api/exambank/answer-score.js'
export default {
  name: 'AllocatePaper',
  components: {
    Tinymce
  },
  data() {
    return {
      stuAnswer: {},
      // 当前试题
      currentIndex: 0,
      questionList: [],
      // 单选题列表
      selectBankList: {
        list: [],
        value: 0
      },
      // 多选题列表
      multselectBankList: {
        list: [],
        value: 0
      },
      // 判断题列表
      judgeBnakList: {
        list: [],
        value: 0
      },
      // 填空题列表
      blankBankList: {
        list: [],
        value: 0
      },
      // 简答题列表
      questanswerBankList: {
        list: [],
        value: 0
      },
      // 材料题列表
      meteraBankList: {
        list: [],
        value: 0
      },
      // 编程题列表
      programBankList: {
        list: [],
        value: 0
      },
      // 程序填空题列表
      programblankBank: {
        list: [],
        value: 0
      },
      // 接口编程题列表
      programminterBank: {
        list: [],
        value: 0
      },
      // 文件上传提列表
      fileupload: {
        list: [],
        value: 0
      },
      // 试题类型常量定义
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      ESSAY_QUESTION: EXAMBANK_CONST.ESSAY_QUESTION,
      MATERIAL: EXAMBANK_CONST.MATERIAL,
      PROGRAMME: EXAMBANK_CONST.PROGRAMME,
      PROG_FILLBLANK: EXAMBANK_CONST.PROG_FILLBLANK,
      INTERFACE: EXAMBANK_CONST.INTERFACE,
      FILE_UPLOAD: EXAMBANK_CONST.FILE_UPLOAD,
      saveFlag: false,
      loading: false,
      searchBarFixed: false,
      paper: {},
      answerId: null,
      answerIdList: [],
      VUE_APP_FILE_SERVER: process.env.VUE_APP_FILE_SERVER
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {
    this.loading = true
    var teacherId = this.$route.params.teacherId
    var courseId = this.$route.params.courseId
    var termId  = this.$route.params.termId
    var allocatePaper = {
      teacherId: teacherId,
      courseId: courseId,
      termId: termId
    }
    paperAllocateApi.getPaperAllocateListByTeacherId(allocatePaper).then(resp => {
      resp.data.forEach(item => {
        if (item.tqTypeId.toString() === this.SINGLE) {
          this.selectBankList.list.push(item)
          this.selectBankList.value += item.value
        } else if (item.tqTypeId.toString() === this.MULTIPLE) {
          this.multselectBankList.list.push(item)
          this.multselectBankList.value += item.value
        } else  if (item.tqTypeId.toString() === this.JUDGEMENT) {
          this.judgeBnakList.list.push(item)
          this.judgeBnakList.value += item.value
        } else if (item.tqTypeId.toString() === this.FILLBLANK) {
          this.blankBankList.list.push(item)
          this.blankBankList.value += item.value
        } else if (item.tqTypeId.toString() === this.ESSAY_QUESTION) {
          this.$set(item, 'showFlag', false)
          this.questanswerBankList.list.push(item)
          this.questanswerBankList.value += item.value
        } else  if (item.tqTypeId.toString() === this.MATERIAL) {
          this.meteraBankList.value += item.value
          this.meteraBankList.list.push(this.meteraSmallBank(item))
        } else  if (item.tqTypeId.toString() === this.PROGRAMME) {
          this.$set(item, 'showFlag', false)
          this.programBankList.value += item.value
          this.programBankList.list.push(item)
        } else  if (item.tqTypeId.toString() === this.PROG_FILLBLANK) {
          this.$set(item, 'showFlag', false)
          this.programblankBank.list.push(item)
          this.programblankBank.value += item.value
        } else  if (item.tqTypeId.toString() === this.INTERFACE) {
          this.$set(item, 'showFlag', false)
          this.programminterBank.value += item.value
          this.programminterBank.list.push(item)
        } else {
          this.fileupload.value += item.value
          this.$set(item, 'showFlag', false)
          this.fileupload.list.push(item)
        }
      })
      setTimeout(() => {
        this.selectBankList.list = this.Rendering(this.selectBankList.list)
        this.multselectBankList.list = this.Rendering(this.multselectBankList.list)
        this.judgeBnakList.list = this.Rendering(this.judgeBnakList.list)
        this.blankBankList.list = this.Rendering(this.blankBankList.list)
        this.programblankBank.list = this.RenderProgramBlank(this.programblankBank.list)
        this.questionList = [
          ...this.selectBankList.list,
          ...this.multselectBankList.list,
          ...this.judgeBnakList.list,
          ...this.blankBankList.list,
          ...this.programBankList.list,
          ...this.questanswerBankList.list,
          ...this.programblankBank.list,
          ...this.meteraBankList.list,
          ...this.fileupload.list,
          ...this.programminterBank.list
        ]
        console.log(this.questionList)
        this.loading = false
      }, 2000)
    })
  },
  methods: {
    currentPrevious() {
      this.currentIndex = this.currentIndex - 1
    },
    currentNext() {
      this.currentIndex = this.currentIndex + 1
    },
    goAnchor(index) {
      this.currentIndex = index
    },
    // 教师点击修改
    dealMarking(item) {
      this.answerIdList.push(item.answerId)
      var answerScore = {
        pdId: item.pdId,
        tqId: item.tqId,
        teacherId: this.$route.params.teacherId,
        score: item.score
      }
      answerScoreApi.add(answerScore
      ).then(resp => {
        if (resp.code === 0) {
          this.$message({
            message: '保存成功',
            type: 'success'
          })
          item.grader = this.user.loginName
          paperAllocateApi.updateStatusById(item.allocateId)
        } else {
          this.$message({
            message: '保存失败',
            type: 'danger'
          })
        }
      })
    },
    dealMaterialAnswerMarking(item) {
      this.answerIdList.push(item.answerId)
      var answerScore = {
        pdId: item.pdId,
        tqId: item.materialId,
        teacherId: this.$route.params.teacherId,
        score: item.score
      }
      answerScoreApi.add(answerScore
      ).then(resp => {
        if (resp.code === 0) {
          this.$message({
            message: '保存成功',
            type: 'success'
          })
          item.grader = this.user.loginName
          paperAllocateApi.updateStatusById(item.allocateId)
        } else {
          this.$message({
            message: '保存失败',
            type: 'danger'
          })
        }
      })
    },
    /**
     * 完成阅卷
     */
    finishMarke() {
      this.answerIdList = this.unique(this.answerIdList)
      this.$confirm('是否提交', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          paperAllocateApi.dealSubmitAllocate(this.answerIdList).then(resp => {
            if (resp.code === 0) {
              this.$message({
                type: 'success',
                message: '阅卷完成'
              })
              this.$router.go(-1)
            }
          })
        })
    },
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    },
    changeShow(item) {
      item.showFlag = !item.showFlag
      console.log(item)
    },
    // 处理材料小题
    meteraSmallBank(list) {
      list = { ...list, mselectBankList: [], mmultselectBankList: [], mjudgeBnakList: [], mblankBankList: [], mquestanswerBankList: [] }
      console.log(list)
      list.materialQuestions.forEach(item => {
        if (item.tqTypeId.toString() === this.SINGLE) {
          list.mselectBankList.push(item)
        } else if (item.tqTypeId.toString() === this.MULTIPLE) {
          list.mmultselectBankList.push(item)
        } else  if (item.tqTypeId.toString() === this.JUDGEMENT) {
          list.mjudgeBnakList.push(item)
        } else if (item.tqTypeId.toString() === this.FILLBLANK) {
          list.mblankBankList.push(item)
        } else  {
          this.$set(item, 'showFlag', false)
          list.mquestanswerBankList.push(item)
        }
      })
      list.mselectBankList = this.Rendering(list.mselectBankList)
      list.mmultselectBankList = this.Rendering(list.mmultselectBankList)
      list.mjudgeBnakList = this.Rendering(list.mjudgeBnakList)
      list.mblankBankList = this.Rendering(list.mblankBankList)
      return list
    },
    // 渲染选择多选判断题
    Rendering(list) {
      var bankList = []
      list.forEach(bank => {
        var options = []
        const dom = this.collectionToArray(this.parseDom(bank.content))
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text' || (dom[i].nodeName === 'P' && dom[i].innerText.trim() === '')) {
            dom.splice(i, 1)
            i--
          }
        }
        if (
          bank.tqTypeId.toString() === this.SINGLE ||
        bank.tqTypeId.toString() === this.JUDGEMENT ||
        bank.tqTypeId.toString() === this.MULTIPLE
        ) {
          let ol_pos = -1
          for (let i = 0; i < dom.length; i++) {
            if (dom[i].nodeName === 'OL') {
              ol_pos = i
            }
          }
          if (ol_pos > 0) {
            const ol = dom[ol_pos]
            dom.splice(ol_pos, 1)
            let str = ''
            for (let i = 0; i < dom.length; i++) {
              str += dom[i].innerHTML
            }
            bank.content = str
            str = ''
            for (let i = 0; i < ol.children.length; i++) {
              const index = String.fromCharCode(i + 65)
              const item = {}
              item.value = index
              item.label = ol.children[i].innerHTML
              options[i] = item
            }
          }
          bank = { ...bank, options: options, showFlag: false }
          bankList.push(bank)
        } else {
          console.log(bank)
          var content = []
          let k = 1
          for (let i = 0; i < dom.length; i++) {
            content[i] = dom[i].innerHTML
            content[i] = content[i].replace(/<input.*?>/g, '&lt;blank&gt;')
            let index = content[i].indexOf('&lt;blank&gt;', 0)
            console.log(index)
            while (index >= 0) {
              const str = ' ( ' + k + ' ) '
              k++
              content[i] = content[i].replace('&lt;blank&gt;', str)
              index = content[i].indexOf('&lt;blank&gt;', index + 7)
            }
            var objE = document.createElement('p')
            objE.innerHTML = content[i]
            content[i] = objE.outerHTML
          }
          let str = ''
          for (let i = 0; i < content.length; i++) {
            str += content[i]
          }
          content = str
          for (let i = 0; i < k - 1; i++) {
            options[i] = i + 1
          }
          bank = { ...bank, prveContent: content, options: options, showFlag: false }
          bankList.push(bank)
          console.log(bank)
        }
      })
      return bankList
    },
    // 渲染程序填空题
    RenderProgramBlank(list) {
      var bankList = []
      list.forEach(bank => {
        var code = []
        var options = []
        // 题目内容处理
        let dom = this.collectionToArray(this.parseDom(bank.content))
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text' || (dom[i].nodeName === 'P' && dom[i].innerText.trim() === '')) {
            dom.splice(i, 1)
            i--
          }
        }
        let str = ''
        for (let i = 0; i < dom.length; i++) {
          str += dom[i].innerHTML + '<br/>'
        }
        bank.content = str
        // 程序体处理
        dom = this.collectionToArray(this.parseDom(bank.code))
        let k = 1
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text') {
            this.code[i] = dom[i].nodeValue
            continue
          }
          code[i] = dom[i].outerHTML

          let index = code[i].indexOf('&lt;blank&gt;', 0)
          while (index >= 0) {
            const str = ' ( ' + k + ' ) '
            k++
            code[i] = code[i].replace('&lt;blank&gt;', str)
            index = code[i].indexOf('&lt;blank&gt;', index + 7)
          }
        }
        str = ''
        for (let i = 0; i < code.length; i++) {
          str += code[i]
        }
        code = str
        // 保存填空数，用于绘制答案文本框
        for (let i = 0; i < k - 1; i++) {
          options[i] = i + 1
        }
        bank = { ...bank, code: code, options: options }
        bankList.push(bank)
        console.log(bank)
      })
      return bankList
    },
    downLoad(url, index) {
      downloadByLink(this.VUE_APP_FILE_SERVER, url, 'StudentAnswer.c')
    },
    unique(arr) {
      if (!Array.isArray(arr)) {
        console.log('type error!')
        return
      }
      return [...new Set(arr)]
    }
  }
}
</script>
<style lang="scss" scpoed>
.click {
  cursor: pointer;
}
.fixed_answer_card {
    padding-bottom: 25px;
    top: 80px;
    z-index: 0;
    .answer_card_title_bg {
      height: 110px;
      padding-top: 50px;
    }
    .isFixed {
      position: fixed;
      top: 0;
      right: 20px;
      width: 323px;
      background: #fff;
      border: 1px solid #f6f6f6;
      -webkit-box-shadow: 0 5px 10px #eee;
      box-shadow: 0 5px 10px #eee;
      border-radius: 6px;
    }
  }
.mb30 {
  margin-bottom: 30px;
}
::-webkit-scrollbar {
  //滚动条整体样式
  width: 5px;
  height: 5px;
}
::-webkit-scrollbar-thumb {
  //滚动条小方块样式
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #ffb8be;
}
::-webkit-scrollbar-track {
  //滚动条滚动轴样式
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #fff;
}
.answer-card {
  overflow: scroll;
  height: 400px;
  overflow-x: hidden;
}
</style>
