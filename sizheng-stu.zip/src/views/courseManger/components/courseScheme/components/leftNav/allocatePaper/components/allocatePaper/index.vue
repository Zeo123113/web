<template>
  <div class="outer-container">
    <div v-if="!isLogin" class="mt20 pb">
      <el-form ref="scoreTeacherLogin" :model="scoreTeacherLogin" :rules="rules" label-width="240px">
        <el-form-item label="阅卷教师姓名" prop="teaName">
          <el-input
            v-model="scoreTeacherLogin.teaName"
            placeholder="请输入阅卷教师姓名"
            autocomplete="off"
            clearable
            style="width:300px"
          ></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="scoreTeacherLogin.password"
            placeholder="请输入密码"
            autocomplete="off"
            clearable
            show-password
            style="width:300px"
          ></el-input>
          <el-button type="primary" style="margin-left:25px" @click="onSubmit('scoreTeacherLogin')">登录</el-button>
        </el-form-item>
      </el-form>
      <div class="nodata">
        <p><svg class="icon icon-tishi" aria-hidden="true">
          <use xlink:href="#icon-tishi" />
        </svg></p>
        <p> 请使用阅卷教师账号登录，进行管理</p>
      </div>
    </div>
    <div v-else class="mt20 pb">
      <span class="tip ml">欢迎{{ scoreTeacher.teaName }},你的权限是{{ privilege }}</span>
      <el-button type="primary" style="margin-left:25px" @click="start()">开始阅卷</el-button>
    </div>
  </div>
</template>

<script>
import scoringTeacherApi from '@/api/exambank/scoring-teacher'
export default {
  props: {
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      scoreTeacherLogin: {
        teaName: '',
        password: '',
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        orgId: this.courseTerm.orgId
      },
      scoreTeacher: {},
      isLogin: false,
      privilege: '',
      // 教师权限数据字典
      privilegeDict: [],
      rules: {
        teaName: [{ required: true, message: '阅卷教师姓名不能为空', trigger: 'blur' }],
        password: [{ required: true, message: '密码不能为空', trigger: 'blur' }]
      }
    }
  },
  created() {
    // 教师权限数据字典获取
    this.getDataByType('exambank_teacher_privilege').then(response => {
      this.privilegeDict = response.data
    })
  },
  methods: {
    initScoreTeacher() {
      this.scoreTeacherLogin = {
        teaName: '',
        password: '',
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        orgId: this.courseTerm.orgId
      }
    },
    onSubmit(scoreTeacherLogin) {
      this.$refs[scoreTeacherLogin].validate((valid) => {
        if (valid) {
          scoringTeacherApi.scoreTeacherLogin(this.scoreTeacherLogin).then(resp => {
            if (resp.code === 0) {
              this.scoreTeacher = resp.data
              this.isLogin = true
              this.privilege = this.privilegeFormat(this.scoreTeacher)
              this.$emit('login', this.isLogin = true, this.scoreTeacher)
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    privilegeFormat(row) {
      return this.selectDictLabel(this.privilegeDict, row.privilege)
    },
    start() {
      this.$router.push({  // 核心语句
        path: `/allocatePaper/${this.scoreTeacher.teacherId}/${this.courseTerm.csId}/${this.courseTerm.ctId}`   // 跳转的路径
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.ml
{
    margin-left:20px
}
.pb
{
    padding-bottom:304px
}
.tip
{
    font-size:18px;
    color: #9199a1;
}
.nodata {
//   padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: left;
    line-height: 24px;
    margin-bottom: 4px;
    margin-left: 30px;
  }
}
</style>
