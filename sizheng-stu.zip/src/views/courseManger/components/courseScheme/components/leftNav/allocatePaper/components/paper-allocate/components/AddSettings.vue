<template>
  <el-dialog :title="dialog.title" :visible.sync="dialog.show" :width="dialogWidth" @close="close" @open="open">
    <el-form ref="form" :model="form" :rules="rules">
      <el-row>
        <!-- 选择试题 -->
        <el-col v-if="dialog.title === '选择试题'" :span="24">
          <div>
            <!-- <span>项目成员（9）</span>
            <el-input
              v-model="teacherName"
              placeholder="请输入教师姓名"
              clearable
              style="width:200px;"
              @change="change"
            />-->
            <el-button type="primary" style="float:right" @click="add">添加设置</el-button>
          </div>
          <el-table :data="settings" style="width:100%; margin-top:10px" tooltip-effect="dark">
            <el-table-column prop="paperId" align="center" label="试卷编号" min-width="100" />
            <el-table-column prop="teacherId" align="center" label="教师编号" min-width="100" />
            <el-table-column
              prop="paperTitle"
              align="center"
              label="试卷"
              show-overflow-tooltip
              min-width="120"
            />
            <el-table-column
              prop="tqTypeId"
              :formatter="typeFormat"
              align="center"
              label="题型"
              min-width="120"
            />
            <el-table-column prop="tearcherName" align="center" label="教师" min-width="120" />
            <el-table-column prop="overCount" align="center" label="已完成数量" min-width="100" />
            <el-table-column prop="doingCount" align="center" label="未完成数量" min-width="100" />
            <el-table-column label="操作" min-width="120" fixed="right" align="center">
              <template slot-scope="scope">
                <el-button size="mini" type="text" @click="edit(scope.row)">编辑</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-col>
        <!-- 添加设置 -->
        <el-alert
          v-if="dialog.title === '添加设置' && form.questionIds != null"
          type="warning"
          :description="note"
        />
        <el-col v-if="dialog.title === '添加设置'" :span="12">
          <el-form-item label="选择试卷" prop="paperIds" :label-width="labelWidth">
            <el-select v-model="form.paperIds" multiple filterable placeholder="请选择试卷" clearable>
              <el-option
                v-for="item in papers"
                :key="item.paperId"
                :label="item.paperTitle"
                :value="item.paperId"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.title === '添加设置'" :span="12">
          <el-form-item label="选择题型" prop="tqTypeIds" :label-width="labelWidth">
            <el-select v-model="form.tqTypeIds" multiple filterable placeholder="请选择题型" clearable>
              <el-option
                v-for="dict in typeValue"
                :key="dict.dictvalue"
                :label="dict.dictLabel"
                :value="dict.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.title === '添加设置'" :span="12">
          <el-form-item label="选择教师" prop="teacherIds" :label-width="labelWidth">
            <el-select
              v-model="form.teacherIds"
              multiple
              filterable
              placeholder="请选择阅卷教师"
              clearable
            >
              <el-option
                v-for="item in teachers"
                :key="item.teacherId"
                :label="item.teaName"
                :value="item.teacherId"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.title === '添加设置'" :span="12">
          <el-form-item label="试题数量" prop="tqCount" :label-width="labelWidth">
            <el-input-number
              v-model="form.tqCount"
              controls-position="right"
              :min="0"
              @focus="focus"
            />
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.title === '添加设置'" :span="22">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入保存的备注"></el-input>
          </el-form-item>
        </el-col>
        <!-- 修改设置 -->
        <el-col v-if="dialog.title === '修改设置'" :span="12">
          <el-form-item label="选择试卷" prop="paperId" :label-width="labelWidth">
            <el-select v-model="form.paperId" :disabled="true" clearable>
              <el-option
                v-for="item in papers"
                :key="item.paperId"
                :label="item.paperTitle"
                :value="item.paperId"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.title === '修改设置'" :span="12">
          <el-form-item label="选择题型" prop="tqTypeId" :label-width="labelWidth">
            <el-select v-model="form.tqTypeId" :disabled="true" clearable>
              <el-option
                v-for="dict in typeValue"
                :key="dict.dictvalue"
                :label="dict.dictLabel"
                :value="dict.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.title === '修改设置'" :span="12">
          <el-form-item label="选择教师" prop="teacherId" :label-width="labelWidth">
            <el-select v-model="form.teacherId" filterable placeholder="请选择阅卷教师" clearable>
              <el-option
                v-for="item in teachers"
                :key="item.teacherId"
                :label="item.teaName"
                :value="item.teacherId"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.title === '修改设置'" :span="12">
          <el-form-item label="试题数量" prop="tqCount" :label-width="labelWidth">
            <el-input-number v-model="form.tqCount" controls-position="right" :min="0" />
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.title === '修改设置'" :span="22">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入保存的备注"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button
        v-if="dialog.title === '添加设置' || dialog.title === '修改设置'"
        v-show="last"
        type="primary"
        size="small"
        @click="submit"
      >保 存</el-button>
      <el-button
        v-if="dialog.title === '添加设置' || dialog.title === '修改设置'"
        size="small"
        @click="closeAddSettings"
      >取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import courseSetApi from '@/api/course/courseManage/courseSet'
import courseTermApi from '@/api/course/courseManage/courseTerm'
import stuPaperDetailApi from '@/api/exambank/stu-paper-detail.js'
import scoringTeacherApi from '@/api/exambank/scoring-teacher'
import paperApi from '@/api/exambank/paper.js'
import paperAllocateApi from '@/api/exambank/paper-allocate'
export default {
  name: 'AddSettings',
  components: {
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      default: null
    },
    typeValue: {
      type: Array,
      default: null
    },
    orgOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    // 验证试题数量是否符合要求（不超过未分配的数量，不能为0）
    var existqCount = (rule, value, callback) => {
      // console.log('existqCount-value = ', value)
      if (this.dialog.title === '添加设置') {
        if (value == null || value === '' || value === undefined || value === 0 || this.form.questionIds == null) {
          return callback(new Error('试题数量不能为空或为0'))
        }
        if (value > this.form.questionIds.length) {
          return callback(new Error('不能超过未分配试题数量：' + this.form.questionIds.length))
        }
      } else if (this.dialog.title === '修改设置') {
        if (value === null || value === '' || value === undefined || value === 0 || this.doingCount == null) {
          return callback(new Error('试题数量不能为空或为0'))
        }
        if (value > this.doingCount) {
          return callback(new Error('不能超过未分配试题数量：' + this.doingCount))
        }
      }
      callback()
    }
    return {
      courseOptions: [],
      courseTermOptions: [],
      // 表单校验
      rules: {
        tqCount: [{ validator: existqCount, trigger: 'blur', required: true }],
        paperIds: [{ required: true, message: '试卷不能为空', trigger: 'blur' }],
        tqTypeIds: [{ required: true, message: '题型不能为空', trigger: 'blur' }],
        teacherIds: [{ required: true, message: '阅卷教师编号不能为空', trigger: 'blur' }]
      },
      labelWidth: '120px',
      // 课程，学期下的试卷
      papers: [],
      // 课程，学期封装的对象
      courseAndTerm: {
        courseId: null,
        termId: null
      },
      // 上一步是否显示
      previous: false,
      // 最后一步是否显示
      last: false,
      // 阅卷老师列表
      teachers: [],
      // 阅卷设置
      settings: [],
      // 本页面弹窗大小
      dialogWidth: '400px',
      // 搜索框内容
      teacherName: '',
      // 添加/编辑设置弹窗
      settingDialog: {
        title: '',
        show: false
      },
      // 所有试卷，题型下试题的列表
      tqIds: [],
      // 试卷，题型下的试题数量
      tqLength: null,
      note: '',
      // 已经分配的试题
      allocateIds: [],
      allocateLength: null,
      // 未分配试题的个数（编辑设置需要）
      doingCount: null
    }
  },
  methods: {
    // 展示所有已添加的阅卷设置（试卷，试题类型，教师，已完成数量，未完成数量）
    getSettings() {
      paperAllocateApi
        .getSettings()
        .then(response => {
          this.settings = response.data
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 在 Input 获得焦点时触发
    focus() {
      // 是否输入了试卷和试题类型
      if (
        this.form === null ||
        this.form.paperIds === null ||
        this.form.tqTypeIds === null ||
        this.form.paperIds.length === 0 ||
        this.form.tqTypeIds.length === 0
      ) {
        return
      } else {
        this.getIdsByTypeIds()
        // this.getIdsByQuestionType()
        // this.getQuestionIds()
        if (this.form.questionIds !== null) {
          this.note = '未分配的试题数量：' + this.form.questionIds.length
        }
      }
    },
    // 计算未分配的试题数量
    getQuestionIds() {
      // tqIds - allocateIds
      const tqSet = new Set(this.tqIds)
      const allocateSet = new Set(this.allocateIds)
      const ids = new Set([...tqSet].filter(x => !allocateSet.has(x)))
      // this.form.questionIds = [...ids]
      // this.form.questionIds = Array.from(ids)
      this.form.questionIds = Array.from(ids)
      console.log('this.form.questionIds = ', this.form.questionIds)
    },
    // 已经分配的试题
    getIdsByTypeIds() {
      paperAllocateApi
        .getIdsByTypeIds(this.form)
        .then(response => {
          this.allocateIds = response.data
          this.allocateLength = this.allocateIds.length
          this.getIdsByQuestionType()
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 根据课程-学期-试卷paperIds，题型typeIds，查询出所有要分配的试题ids,从答卷详情试题表
    getIdsByQuestionType() {
      stuPaperDetailApi
        .getIdsByQuestionType(this.form)
        .then(response => {
          this.tqIds = response.data
          this.tqLength = this.tqIds.length
          // this.getIdsByTypeIds()
          // console.log('this.tqIds = ', this.tqIds)
          // console.log('this.allocateIds = ', this.allocateIds)
          this.getQuestionIds()
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 根据课程和学期编号，来获取试卷
    getPapersByCourseAndTerm(form) {
      paperApi
        .getPapersByCourseAndTerm(form.courseId, form.termId)
        .then(response => {
          this.papers = response.data
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 添加设置弹窗
    add() {
      // this.$refs['form'].clearValidate()
      // 校验关闭,必填置为false
      // this.rules.teacherId.required = false
      // this.resetRules()

      this.tqLength = null
      this.note = ''
      // this.getSettings()
      this.getTeachers(this.courseAndTerm)
      this.getPapersByCourseAndTerm(this.form)
      this.form.paperIds = []
      this.form.tqTypeIds = []
      this.form.teacherIds = []
      this.form.tqCount = 0
      this.dialog.title = '添加设置'
    },
    // 修改设置弹窗
    edit(row) {
      this.form.paperId = row.paperId
      this.form.tqTypeId = row.tqTypeId
      this.form.teacherId = row.teacherId
      this.form.teacherName = row.teacherName
      this.form.tqCount = row.doingCount
      this.doingCount = row.doingCount
      this.form.stuUserId = row.teacherId
      this.form.remark = ''
      this.getTeachers(this.courseAndTerm)
      this.focus()
      this.dialog.title = '修改设置'
    },
    // 输入框失去焦点或用户按下回车时触发
    change() {
      console.log('change============>')
    },
    // 判断值为空
    isEmpty(value) {
      if (value === undefined || value === '' || value === null) {
        return true
      } else {
        return false
      }
    },
    /** 试题类型数据字典 */
    typeFormat(row) {
      return this.selectDictLabel(this.typeValue, row.tqTypeId.toString())
    },
    // 根据课程，学期编号，来获取阅卷老师
    getTeachers(scoringTeacher) {
      scoringTeacherApi
        .listByTerm(scoringTeacher)
        .then(response => {
          this.teachers = response.data
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 关闭添加/编辑设置弹窗
    closeAddSettings() {
      this.getSettings()
      this.dialog.title = '选择试题'
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialogWidth = '400px'
      this.previous = false
      this.last = false
      this.dialog.title = '选择试题'
      this.dialog.show = false
      this.$emit('getList')
    },
    open() {
      this.dialogWidth = '800px'
      this.last = true
      this.courseAndTerm.courseId = this.form.courseId
      this.courseAndTerm.termId = this.form.termId
      this.form.teacherId = ''
      this.getSettings()
      // this.getTeachers(this.courseAndTerm)
      this.getPapersByCourseAndTerm(this.form)
      this.dialog.title = '选择试题'
    },
    /** 提交按钮 */
    submit() {
      if (this.dialog.title === '添加设置') {
        this.$refs['form'].validate(valid => {
          if (valid) {
            // 获取提交的试题数量
            paperAllocateApi
              .addPaperAllocate(this.form)
              .then(result => {
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
              })
              .catch(err => {
                console.log(err)
              })
            this.close()
          }
        })
      } else if (this.dialog.title === '修改设置') {
        // 手动校验
        const form = { ...this.form }
        // console.log('手动校验--form = ', form)
        if (form.teacherId == null || form.teacherId === '' || form.tqCount == null || form.tqCount === 0) {
          return false
        }
        paperAllocateApi
          .updateSettings(this.form)
          .then(result => {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            this.next()
          })
          .catch(err => {
            console.log(err)
          })

        this.closeAddSettings()
      }
    },
    /** 组织机构选择发生变化时触发 */
    orgChange(value) {
      this.form.courseId = null
      this.form.termId = null
      this.courseOptions = []
      this.courseTermOptions = []
      if (value !== null && value !== '' && value !== undefined) {
        courseSetApi.getCourseListByOrgId(value).then(response => {
          this.courseOptions = response.data
        })
      }
    },
    /** 课程选择发生变化时触发 */
    courseChange(value) {
      this.form.termId = null
      this.courseTermOptions = []
      if (value !== null && value !== '' && value !== undefined) {
        courseTermApi.getCourseTermByCourseSetId(value).then(response => {
          this.courseTermOptions = response.data
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.el-input {
  width: 130px;
}
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
