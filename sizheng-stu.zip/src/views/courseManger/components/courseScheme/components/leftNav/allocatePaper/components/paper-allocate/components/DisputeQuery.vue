<template>
  <el-dialog
    :title="queryDialog.title"
    :visible.sync="queryDialog.show"
    width="800px"
    @close="close"
  >
    <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
      <el-form-item label="最大允许偏差">
        <el-input-number
          v-model="queryParams.score"
          :min="1"
          :max="5"
          style="margin-right:4px;margin-left:1px"
          controls-position="right"
          clearable
        />
      </el-form-item>
      <el-form-item label="评分时间">
        <el-date-picker
          v-model="dateRange"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          unlink-panels
          :picker-options="pickerOptions"
          style="width:200px;"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" @click="change">搜索</el-button>
        <!-- <el-button icon="el-icon-refresh" @click="resetQuery('searchForm')">重置</el-button> -->
      </el-form-item>
    </el-form>

    <el-table :data="answerScores" style="width:100%; margin-top:10px" tooltip-effect="dark">
      <el-table-column prop="pdId" align="center" label="试题编号" sortable min-width="100" />
      <el-table-column
        prop="questionBank.content"
        align="center"
        label="题目内容"
        show-overflow-tooltip
        min-width="200"
      />
      <el-table-column
        prop="scoringTeacher.teaName"
        align="center"
        label="阅卷教师"
        sortable
        min-width="100"
      />
      <el-table-column prop="score" align="center" label="得分" sortable min-width="100" />
      <el-table-column
        prop="gradeTime"
        align="center"
        label="评分时间"
        show-overflow-tooltip
        min-width="160"
      />
      <el-table-column prop="reviseScore" align="center" label="修正得分" min-width="100" />
      <el-table-column prop="reviseTime" align="center" label="修正时间" min-width="100" />
      <el-table-column prop="reviseReason" align="center" label="修正原因" min-width="200" />
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="getList"
    />
  </el-dialog>
</template>

<script>
import pagination from '@/components/Pagination/index'
import answerScoreApi from '@/api/exambank/answer-score'
import USER_CONST from '@/constant/user-const'
export default {
  components: { pagination },
  props: {
    queryDialog: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      // 最大允许偏差值
      score: null,
      // 表格数据
      answerScores: [],
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // 是否显示加载遮罩层
      loading: false,
      total: 1,
      // 试题得分表
      answerScore: {
        pdId: null,
        teacherId: null,
        score: null,
        gradeTime: '',
        reviseScore: '',
        reviseTime: '',
        reviseReason: ''
      },
      queryParams: {
        beginTime: null,
        endTime: null,
        score: null
      },
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      dateRange: ''
    }
  },
  created() {
    this.getList()
  },
  methods: {
    /** 重置按钮操作 */
    resetQuery() {
      this.$refs['searchForm'].resetFields()
      this.dateRange = ''
      this.queryParams.beginTime = ''
      this.queryParams.endTime = ''
    },
    getList() {
      this.loading = true
      // this.answerScore.score = this.score
      answerScoreApi
        .getAnswerScoreList(this.queryParams, this.pageNum, this.pageSize)
        .then(response => {
          this.answerScores = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    },
    reset() {
      this.queryParams = {
        teacherId: null,
        beginTime: null,
        endTime: null,
        score: null
      }
    },
    close() {
      this.score = null
      this.queryDialog.show = false
    },
    // 输入框失去焦点或用户按下回车时触发
    change() {
      this.getList()
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
