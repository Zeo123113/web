<template>
  <el-dialog :title="editDialog.title" :visible.sync="editDialog.show" width="800px" @close="close">
    <el-form ref="form" :model="form" :rules="rules">
      <el-row>
        <el-col :span="12">
          <el-form-item label="试卷名称" prop="paperTitle" :label-width="labelWidth">
            <span>{{ form.paperTitle }}</span>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="答卷详情试题" prop="pdId" :label-width="labelWidth">
            <el-input-number v-model="form.pdId" :min="1" controls-position="right" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="教师编号" prop="teacherId" :label-width="labelWidth">
            <el-input-number v-model="form.teacherId" :min="1" controls-position="right" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="阅卷状态" prop="paperStatus" :label-width="labelWidth">
            <el-select v-model="form.paperStatus" placeholder="请选择阅卷状态" clearable>
              <el-option
                v-for="item in paperStatusDict"
                :key="item.value"
                :label="item.dictLabel"
                :value="item.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="22">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入保存的备注"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit">保 存</el-button>
      <el-button size="small" @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import paperAllocateApi from '@/api/exambank/paper-allocate'
export default {
  components: {},
  props: {
    editDialog: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      default: null
    },
    typeValue: {
      type: Array,
      default: null
    },
    paperStatusDict: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      // 表单校验
      rules: {
        paperId: [{ required: true, message: '试卷编号不能为空', trigger: 'blur' }],
        tqTypeId: [{ required: true, message: '试题类型不能为空', trigger: 'blur' }],
        // pdId: [{ required: true, message: '答卷详情试题编号不能为空', trigger: 'blur' }],
        paperStatus: [{ required: true, message: '阅卷状态不能为空', trigger: 'blur' }],
        // stuUserId: [{ validator: existUserId, trigger: 'blur', required: true }],
        // termId: [{ required: true, message: '学期不能为空', trigger: 'blur' }],
        // courseId: [{ required: true, message: '课程编号不能为空', trigger: 'blur' }],
        teacherId: [{ required: true, message: '阅卷教师编号不能为空', trigger: 'blur' }]
      },
      labelWidth: '120px',
      // 学期
      options: []
    }
  },
  /** 获取当前时间，自动生成学期下拉列表 */
  created() {
    this.getTerm()
  },
  methods: {
    close() {
      this.editDialog.show = false
    },
    /** 提交按钮 */
    submit() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          paperAllocateApi
            .updatePaperAllocate(this.form)
            .then(result => {
              this.$emit('getList')
              this.$message({
                message: '保存成功',
                type: 'success'
              })
              this.close()
            })
            .catch(err => {
              console.log(err)
            })
        }
      })
    },
    /** 获取当前时间，自动生成学期下拉列表 */
    getTerm() {
      var date = new Date() // 当前时间
      var year = date.getFullYear() // 现在年份
      var month = date.getMonth() + 1 // getMonth()获取当前月份(0-11,0代表1月)
      // 自动生成近五年的学期
      var oldYer = year - 5
      // console.log(oldYer)
      do {
        this.options.push({
          value: oldYer + '春',
          label: oldYer + '-' + (oldYer + 1) + '学年(春)'
        })
        this.options.push({
          value: oldYer + '秋',
          label: oldYer + '-' + (oldYer + 1) + '学年(秋)'
        })
        oldYer = oldYer + 1
      } while (oldYer < year)
      if (month >= 2 && month <= 8) {
        this.options.push({
          value: oldYer + '春',
          label: oldYer + '-' + (oldYer + 1) + '学年(春)'
        })
      } else {
        this.options.push({
          value: oldYer + '春',
          label: oldYer + '-' + (oldYer + 1) + '学年(春)'
        })
        this.options.push({
          value: oldYer + '秋',
          label: oldYer + '-' + (oldYer + 1) + '学年(秋)'
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
