<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="学生学号" prop="studentNumber">
      <el-input
        v-model="queryParams.studentNumber"
        placeholder="请输入学生学号"
        clearable
        style="width:217px;"
      ></el-input>
    </el-form-item>
    <el-form-item label="试卷名称" prop="paperTitle">
      <el-input
        v-model="queryParams.paperTitle"
        placeholder="请输入试卷名称"
        clearable
        style="width:217px;"
      />
    </el-form-item>
    <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        unlink-panels
        :picker-options="pickerOptions"
        style="width:217px;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        icon="el-icon-search"
        :disabled="!button.includes('bank/paperAllocate/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button icon="el-icon-refresh" @click="resetQuery('searchForm')">重置</el-button>
      <el-button
        type="primary"
        icon="el-icon-plus"
        :disabled="!button.includes('bank/paperAllocate/add')"
        @click="addPaperAllocate"
      >新增</el-button>
      <el-button
        icon="el-icon-delete"
        size="medium"
        type="danger"
        :disabled="deldisabled || !button.includes('bank/paperAllocate/deletebatch')"
        @click="handleDeleteMore"
      >删除</el-button>
      <el-button type="info" @click="queryDispute">争议查询</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
export default {
  name: 'HeaderSearch',
  components: {
  },
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    button: {
      type: Array,
      required: true
    },
    deldisabled: {
      type: Boolean,
      required: true
    },
    ids: {
      type: Array,
      required: true
    },
    orgOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      courseOptions: [],
      courseTermOptions: [],
      // 学期下拉框
      options: [],
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      dateRange: ''
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  methods: {
    /** 添加按钮操作 */
    addPaperAllocate() {
      this.$emit('addPaperAllocate')
    },
    /** 点击了批量删除 */
    handleDeleteMore() {
      this.$emit('handleDeleteMore', this.ids)
    },
    /** 争议查询操作 */
    queryDispute() {
      this.$emit('queryDispute')
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.$emit('getList', this.queryParams)
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.$refs['searchForm'].resetFields()
      this.dateRange = ''
      this.queryParams.beginTime = ''
      this.queryParams.endTime = ''
      this.$emit('getList')
    }
  }
}
</script>
<style lang="scss" scoped>
.el-input {
  width: 130px;
}
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
