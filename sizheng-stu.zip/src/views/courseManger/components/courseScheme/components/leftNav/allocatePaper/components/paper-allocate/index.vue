<!--
@description 阅卷试题分配管理
@author chengguangyuan
-->
<template>
  <div class="outer-container">
    <el-row>
      <el-collapse-transition>
        <header-search
          :query-params="queryParams"
          :button="button"
          :deldisabled="deldisabled"
          :ids="ids"
          :org-options="orgOptions"
          @getList="getList"
          @addPaperAllocate="addPaperAllocate"
          @handleDeleteMore="handleDeleteMore"
          @queryDispute="queryDispute"
        />
      </el-collapse-transition>
    </el-row>

    <el-table
      :data="PaperAllocateData"
      style="width:100%;margin-bottom:2%"
      tooltip-effect="dark"
      @select="selectall"
      @select-all="selectall"
    >
      <el-table-column type="selection" align="center" width="55"></el-table-column>
      <el-table-column prop="allocateId" align="center" label="分配编号" sortable min-width="100"></el-table-column>
      <el-table-column
        label="试卷名称"
        align="center"
        prop="paper.paperTitle"
        min-width="150"
        show-overflow-tooltip
      />
      <el-table-column
        prop="tqTypeId"
        :formatter="typeFormat"
        align="center"
        label="试题类型"
        min-width="120"
      ></el-table-column>
      <el-table-column prop="pdId" align="center" label="答卷详情试题编号" sortable min-width="160"></el-table-column>
      <el-table-column prop="teacherId" align="center" label="教师编号" sortable min-width="100"></el-table-column>
      <el-table-column
        prop="paperStatus"
        align="center"
        label="阅卷状态"
        min-width="120"
        :formatter="paperStatusFormat"
      />
      <el-table-column prop="stuUserId" align="center" label="学生用户编号" sortable min-width="160"></el-table-column>
      <el-table-column prop="orgId" align="center" label="创建者机构编号" sortable min-width="160"></el-table-column>
      <el-table-column prop="courseId" align="center" label="课程编号" sortable min-width="100"></el-table-column>
      <el-table-column prop="termId" align="center" label="课程学期编号" sortable min-width="140"></el-table-column>
      <el-table-column label="创建者" prop="createBy" align="center" min-width="100" />
      <el-table-column
        label="创建时间"
        prop="createTime"
        align="center"
        show-overflow-tooltip
        min-width="180"
      />
      <el-table-column label="更新者" prop="updateBy" align="center" min-width="100" />
      <el-table-column
        label="更新时间"
        prop="updateTime"
        align="center"
        show-overflow-tooltip
        min-width="180"
      />
      <el-table-column
        prop="remark"
        label="备注"
        min-width="180"
        align="center"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column label="操作" min-width="230" fixed="right" align="center">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="success"
            :disabled="!button.includes('bank/paperAllocate/update')"
            @click="editPaperAllocate(scope.row)"
          >编辑</el-button>
          <el-button
            size="mini"
            type="danger"
            :disabled="!button.includes('bank/paperAllocate/delete')"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="getList"
    />
    <add-settings
      :org-options="orgOptions"
      :form="PaperAllocate"
      :type-value="typeValue"
      :dialog="dialog"
      @getList="getList"
    />
    <edit-dialog
      :form="PaperAllocate"
      :type-value="typeValue"
      :edit-dialog="editDialog"
      :paper-status-dict="paperStatusDict"
      @getList="getList"
    />
    <dispute-query :query-dialog="queryDialog" />
  </div>
</template>
<script>
import orgApi from '@/api/user/org'
import DisputeQuery from './components/DisputeQuery'
import AddSettings from './components/AddSettings'
import { mapGetters } from 'vuex'
import pagination from '@/components/Pagination/index'
import paperAllocateApi from '@/api/exambank/paper-allocate'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import USER_CONST from '@/constant/user-const'
export default {
  components: {
    HeaderSearch,
    pagination,
    AddSettings,
    EditDialog,
    DisputeQuery
  },
  props: {
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      ids: [],
      PaperAllocateData: [],
      PaperAllocate: {
        paperTitle: '',
        teacherId: '',
        questionIds: [],
        tqTypeIds: [],
        paperIds: [],
        paper: null,
        allocateId: null,
        paperId: '',
        tqTypeId: '',
        pdId: null,
        teacherIds: null,
        stuUserId: null,
        orgId: this.courseTerm.orgId,
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        paperStatus: '',
        tqCount: null,
        remark: ''
      },
      // 编辑弹窗
      editDialog: {
        title: '',
        show: false
      },
      // 新增弹窗
      dialog: {
        title: '',
        show: false
      },
      // 争议查询弹窗
      queryDialog: {
        title: '',
        show: false
      },
      // 是否显示加载遮罩层
      loading: false,
      deldisabled: true,
      total: 1,
      queryParams: {
        paperTitle: '',
        allocateId: null,
        paperId: null,
        tqTypeId: null,
        pdId: null,
        teacherId: null,
        stuUserId: null,
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        orgId: this.courseTerm.orgId,
        paperStatus: '',
        remark: '',
        beginTime: null,
        endTime: null
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // 试题类型数据字典
      typeValue: [],
      // 阅卷状态数据字典
      paperStatusDict: [],
      orgOptions: []
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  created() {
    this.getList()
    // 试题类型数据字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.typeValue = response.data
    })
    // 阅卷状态数据字典获取
    this.getDataByType('exambank_paper_status').then(response => {
      this.paperStatusDict = response.data
    })
    // 获取当前用户的组织机构树
    orgApi.getOrgTreeByCurrentUser().then(result => {
      this.orgOptions = result.data
    })
  },
  methods: {
    // 争议查询
    queryDispute() {
      this.queryDialog.title = '争议查询'
      this.queryDialog.show = true
    },
    /** 阅卷状态数据字典 */
    paperStatusFormat(row) {
      return this.selectDictLabel(this.paperStatusDict, row.paperStatus)
    },
    // 判断值为空
    isEmpty(value) {
      if (value === undefined || value === '' || value === null) {
        return true
      } else {
        return false
      }
    },
    /** 试题类型数据字典 */
    typeFormat(row) {
      return this.selectDictLabel(this.typeValue, row.tqTypeId.toString())
    },
    // 批量删除
    handleDeleteMore(ids) {
      // console.log('ids = ', ids)
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return paperAllocateApi.delPaperAllocate(ids.toString())
        })
        .then(() => {
          this.$message({
            showClose: true,
            message: '删除成功',
            duration: 3000,
            type: 'success'
          })
          this.pageNum = 1
          this.pageSize = USER_CONST.PAGESIZE
          this.getList()
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 表单重置
    reset() {
      this.PaperAllocate = {
        paperTitle: '',
        paperId: '',
        teacherId: '',
        questionIds: [],
        tqTypeIds: [],
        paperIds: [],
        allocateId: null,
        tqTypeId: null,
        pdId: null,
        teacherIds: null,
        stuUserId: null,
        orgId: this.courseTerm.orgId,
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        paperStatus: '',
        tqCount: null,
        remark: ''
      }
    },
    selectall(selection) {
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].allocateId)
      }
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        this.deldisabled = false
      }
    },
    addPaperAllocate() {
      this.reset()
      this.dialog.title = '选择试题'
      this.dialog.show = true
    },
    editPaperAllocate(row) {
      this.PaperAllocate = { ...row }
      this.PaperAllocate.paperTitle = row.paper.paperTitle
      // this.PaperAllocate.tqTypeId = this.typeFormat(row)
      // this.PaperAllocate.paperStatus = this.paperStatusFormat(row)
      this.editDialog.title = '修改阅卷试题分配'
      this.editDialog.show = true
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return paperAllocateApi.delPaperAllocate(row.allocateId.toString())
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.pageNum = 1
          this.pageSize = USER_CONST.PAGESIZE
          this.getList()
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    search(from) {
      this.queryParams.allocateId = from.allocateId
      this.queryParams.stuUserId = from.stuUserId
      this.pageNum = 1
      this.pageSize = USER_CONST.PAGESIZE
      this.getList()
    },
    getList() {
      this.loading = true
      paperAllocateApi
        .getPaperAllocateList(this.queryParams, this.pageNum, this.pageSize)
        .then(response => {
          this.PaperAllocateData = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
</style>
