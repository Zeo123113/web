<template>
  <el-dialog :title="dialog.title" :visible.sync="dialog.show" width="800px" @close="close">
    <el-form ref="form" :model="form" :rules="rules">
      <el-row>
        <el-col :span="12">
          <el-form-item label="教师姓名" prop="teaName" :label-width="labelWidth">
            <el-input v-model="form.teaName" placeholder="请输入教师姓名" style="width:217px;" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="登录密码" prop="password" :label-width="labelWidth">
            <el-input
              v-model="form.password"
              placeholder="请输入登录密码"
              show-password
              style="width:217px;"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="教师权限" prop="privilege" :label-width="labelWidth">
            <el-select v-model="form.privilege" placeholder="请选择教师权限" clearable>
              <el-option
                v-for="item in privilegeDict"
                :key="item.value"
                :label="item.dictLabel"
                :value="item.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item
            v-if="dialog.title === '修改阅卷教师'"
            label="阅卷状态"
            prop="paperStatus"
            :label-width="labelWidth"
          >
            <el-select v-model="form.paperStatus" placeholder="请选择阅卷状态" clearable>
              <el-option
                v-for="item in paperStatusDict"
                :key="item.value"
                :label="item.dictLabel"
                :value="item.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="账号状态" prop="status" :label-width="labelWidth">
            <el-select v-model="form.status" placeholder="请选择账号状态" clearable>
              <el-option
                v-for="item in statusDict"
                :key="item.value"
                :label="item.dictLabel"
                :value="item.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="账号失效" prop="expiryDate" :label-width="labelWidth">
            <el-date-picker
              v-model="form.expiryDate"
              type="datetime"
              placeholder="选择日期时间"
              align="right"
              :picker-options="pickerOptions"
              style="width:217px;"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="22">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入保存的备注"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="mini" @click="submit">保 存</el-button>
      <el-button size="mini" @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import courseSetApi from '@/api/course/courseManage/courseSet'
import courseTermApi from '@/api/course/courseManage/courseTerm'
import scoringTeacherApi from '@/api/exambank/scoring-teacher'
export default {
  name: 'EditDialog',
  components: {
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      default: null
    },
    orgOptions: {
      type: Array,
      required: true
    },
    privilegeDict: {
      type: Array,
      required: true
    },
    statusDict: {
      type: Array,
      required: true
    },
    paperStatusDict: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      courseOptions: [],
      courseTermOptions: [],
      // 表单校验
      rules: {
        teaName: [{ required: true, message: '教师姓名不能为空', trigger: 'blur' }],
        password: [{ required: true, message: '密码不能为空', trigger: 'blur' }],
        orgId: [{ required: true, message: '组织机构不能为空', trigger: 'blur' }],
        courseId: [{ required: true, message: '课程编号不能为空', trigger: 'blur' }],
        termId: [{ required: true, message: '课程学期编号不能为空', trigger: 'blur' }],
        privilege: [{ required: true, message: '权限不能为空', trigger: 'blur' }],
        paperStatus: [{ required: true, message: '阅卷状态不能为空', trigger: 'blur' }],
        status: [{ required: true, message: '账号状态不能为空', trigger: 'blur' }],
        expiryDate: [{ required: true, message: '过期时间不能为空', trigger: 'blur' }]
      },
      labelWidth: '120px',
      // 日期时间选择器
      pickerOptions: {
        shortcuts: [
          {
            text: '今天',
            onClick(picker) {
              picker.$emit('pick', new Date())
            }
          },
          {
            text: '昨天',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24)
              picker.$emit('pick', date)
            }
          },
          {
            text: '一周前',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', date)
            }
          }
        ]
      }
    }
  },
  methods: {
    close() {
      this.previous = false
      this.last = false
      this.dialog.title = '选择学期'
      this.dialog.show = false
    },
    /** 提交按钮 */
    submit: function() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.dialog.title === '添加阅卷教师') {
            scoringTeacherApi
              .addScoringTeacher(this.form)
              .then(result => {
                this.$emit('getList')
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
              })
              .catch(err => {
                console.log(err)
              })
            this.close()
          } else if (this.dialog.title === '修改阅卷教师') {
            scoringTeacherApi
              .updateScoringTeacher(this.form)
              .then(result => {
                this.$emit('getList')
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
              })
              .catch(err => {
                console.log(err)
              })
            this.close()
          }
        }
      })
    },
    /** 组织机构选择发生变化时触发 */
    orgChange(value) {
      this.form.courseId = null
      this.form.termId = null
      this.courseOptions = []
      this.courseTermOptions = []
      if (value !== null && value !== '' && value !== undefined) {
        courseSetApi.getCourseListByOrgId(value).then(response => {
          this.courseOptions = response.data
        })
      }
    },
    /** 课程选择发生变化时触发 */
    courseChange(value) {
      this.form.termId = null
      this.courseTermOptions = []
      if (value !== null && value !== '' && value !== undefined) {
        courseTermApi.getCourseTermByCourseSetId(value).then(response => {
          this.courseTermOptions = response.data
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.el-input {
  width: 130px;
}
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
