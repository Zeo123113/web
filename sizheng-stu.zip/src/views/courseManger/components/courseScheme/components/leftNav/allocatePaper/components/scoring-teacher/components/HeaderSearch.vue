<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="教师权限" prop="privilege">
      <el-select v-model="queryParams.privilege" placeholder="请选择教师权限" clearable>
        <el-option
          v-for="item in privilegeDict"
          :key="item.value"
          :label="item.dictLabel"
          :value="item.dictValue"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="账号状态" prop="status">
      <el-select v-model="queryParams.status" placeholder="请选择账号状态" clearable>
        <el-option
          v-for="item in statusDict"
          :key="item.value"
          :label="item.dictLabel"
          :value="item.dictValue"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="教师姓名" prop="teaName">
      <el-input v-model="queryParams.teaName" placeholder="请输入教师姓名" clearable style="width:217px;"></el-input>
    </el-form-item>
    <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        unlink-panels
        :picker-options="pickerOptions"
        style="width:217px;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item style="display:block">
      <el-button
        type="primary"
        icon="el-icon-search"
        :disabled="!button.includes('bank/scoringTeacher/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button icon="el-icon-refresh" @click="resetQuery('searchForm')">重置</el-button>
      <el-button
        type="primary"
        icon="el-icon-plus"
        :disabled="!button.includes('bank/scoringTeacher/add')"
        @click="addScoringTeacher"
      >新增</el-button>
      <el-button
        icon="el-icon-delete"
        size="medium"
        type="danger"
        :disabled="deldisabled || !button.includes('bank/scoringTeacher/deletebatch')"
        @click="handleDeleteMore(ids)"
      >删除</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
import courseSetApi from '@/api/course/courseManage/courseSet'
import courseTermApi from '@/api/course/courseManage/courseTerm'
export default {
  name: 'HeaderSearch',
  components: {
  },
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    button: {
      type: Array,
      required: true
    },
    privilegeDict: {
      type: Array,
      required: true
    },
    statusDict: {
      type: Array,
      required: true
    },
    paperStatusDict: {
      type: Array,
      required: true
    },
    deldisabled: {
      type: Boolean,
      required: true
    },
    ids: {
      type: Array,
      required: true
    },
    orgOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      courseOptions: [],
      courseTermOptions: [],
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      dateRange: ''
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  methods: {
    /** 添加按钮操作 */
    addScoringTeacher() {
      this.$emit('addScoringTeacher')
    },
    /** 点击了批量删除 */
    handleDeleteMore() {
      this.$emit('handleDeleteMore', this.ids)
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.$emit('getList', this.queryParams)
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.$refs['searchForm'].resetFields()
      this.dateRange = ''
      this.queryParams.beginTime = ''
      this.queryParams.endTime = ''
      this.$emit('getList')
    },
    /** 组织机构选择发生变化时触发 */
    orgChange(value) {
      this.queryParams.courseId = null
      this.queryParams.termId = null
      this.courseOptions = []
      this.courseTermOptions = []
      if (value !== null && value !== '' && value !== undefined) {
        courseSetApi.getCourseListByOrgId(value).then(response => {
          this.courseOptions = response.data
        })
      }
    },
    /** 课程选择发生变化时触发 */
    courseChange(value) {
      this.queryParams.termId = null
      this.courseTermOptions = []
      if (value !== null && value !== '' && value !== undefined) {
        courseTermApi.getCourseTermByCourseSetId(value).then(response => {
          this.courseTermOptions = response.data
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.el-input {
  width: 130px;
}
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
