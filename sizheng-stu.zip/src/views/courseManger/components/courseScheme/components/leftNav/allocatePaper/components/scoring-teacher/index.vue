<!--
@description 阅卷教师管理
@author chengguangyuan
-->
<template>
  <div class="outer-container">
    <header-search
      :query-params="queryParams"
      :button="button"
      :deldisabled="deldisabled"
      :ids="ids"
      :org-options="orgOptions"
      :privilege-dict="privilegeDict"
      :paper-status-dict="paperStatusDict"
      :status-dict="statusDict"
      @getList="getList"
      @addScoringTeacher="addScoringTeacher"
      @handleDeleteMore="handleDeleteMore"
    />
    <el-table
      :data="ScoringTeacherData"
      style="width:100%;margin-bottom:2%"
      tooltip-effect="dark"
      @select="selectall"
      @select-all="selectall"
    >
      <el-table-column type="selection" min-width="50" />
      <el-table-column prop="teacherId" align="center" label="教师编号" min-width="80" />
      <el-table-column prop="teaName" align="center" label="教师姓名" min-width="100" />
      <el-table-column prop="courseId" align="center" label="课程编号" min-width="100" />
      <el-table-column prop="termId" align="center" label="课程学期编号" min-width="140" />
      <el-table-column
        prop="paperStatus"
        align="center"
        label="阅卷状态"
        min-width="120"
        :formatter="paperStatusFormat"
      />
      <el-table-column
        prop="privilege"
        align="center"
        label="权限"
        min-width="100"
        :formatter="privilegeFormat"
      />
      <el-table-column
        prop="status"
        align="center"
        label="账号状态"
        min-width="100"
        :formatter="statusFormat"
      />
      <el-table-column prop="expiryDate" align="center" label="账号失效日期" min-width="160" />
      <el-table-column prop="orgId" align="center" label="创建者机构编号" min-width="160" />
      <el-table-column label="创建者" prop="createBy" align="center" sortable min-width="100" />
      <el-table-column
        label="创建时间"
        prop="createTime"
        align="center"
        show-overflow-tooltip
        min-width="160"
      />
      <el-table-column label="更新者" prop="updateBy" align="center" min-width="100" />
      <el-table-column
        label="更新时间"
        prop="updateTime"
        align="center"
        show-overflow-tooltip
        min-width="160"
      />
      <el-table-column
        prop="remark"
        label="备注"
        min-width="180"
        align="center"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column label="操作" align="center" min-width="300" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="success"
            :disabled="!button.includes('bank/scoringTeacher/update')"
            @click="editScoringTeacher(scope.row)"
          >编辑</el-button>
          <el-button
            size="mini"
            type="danger"
            :disabled="!button.includes('bank/scoringTeacher/delete')"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="getList"
    />
    <edit-dialog
      :org-options="orgOptions"
      :form="ScoringTeacher"
      :dialog="dialog"
      :privilege-dict="privilegeDict"
      :paper-status-dict="paperStatusDict"
      :status-dict="statusDict"
      @getList="getList"
    />
  </div>
</template>
<script>
import orgApi from '@/api/user/org'
import { mapGetters } from 'vuex'
import pagination from '@/components/Pagination/index'
import scoringTeacherApi from '@/api/exambank/scoring-teacher'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import USER_CONST from '@/constant/user-const'
export default {
  components: {
    EditDialog,
    HeaderSearch,
    pagination
  },
  props: {
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      ids: [],
      ScoringTeacherData: [],
      ScoringTeacher: {
        password: '123456',
        teacherId: '',
        teaName: '',
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        paperStatus: '',
        privilege: '',
        status: '',
        expiryDate: '',
        orgId: this.courseTerm.orgId,
        createBy: '',
        createTime: '',
        updateBy: '',
        updateTime: ''
      },
      // 添加/编辑弹窗
      dialog: {
        title: '',
        show: false
      },
      // 是否显示加载遮罩层
      loading: false,
      deldisabled: true,
      total: 1,
      queryParams: {
        teacherId: '',
        teaName: '',
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        orgId: this.courseTerm.orgId,
        paperStatus: '',
        privilege: '',
        status: '',
        expiryDate: '',
        createBy: '',
        createTime: ''
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // 教师权限数据字典
      privilegeDict: [],
      // 阅卷状态数据字典
      paperStatusDict: [],
      // 阅卷状态数据字典
      statusDict: [],
      orgOptions: []
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  created() {
    this.getList()
    // 教师权限数据字典获取
    this.getDataByType('exambank_teacher_privilege').then(response => {
      this.privilegeDict = response.data
    })
    // 阅卷状态数据字典获取
    this.getDataByType('exambank_paper_status').then(response => {
      this.paperStatusDict = response.data
    })
    // 账号状态数据字典获取
    this.getDataByType('exambank_teacher_status').then(response => {
      this.statusDict = response.data
    })
    // 获取当前用户的组织机构树
    orgApi.getOrgTreeByCurrentUser().then(result => {
      this.orgOptions = result.data
    })
  },
  methods: {
    // 判断值为空
    isEmpty(value) {
      if (value === undefined || value === '' || value === null) {
        return true
      } else {
        return false
      }
    },
    /** 教师权限数据字典 */
    privilegeFormat(row) {
      return this.selectDictLabel(this.privilegeDict, row.privilege)
    },
    /** 阅卷状态数据字典 */
    paperStatusFormat(row) {
      return this.selectDictLabel(this.paperStatusDict, row.paperStatus)
    },
    /** 账号状态权限数据字典 */
    statusFormat(row) {
      return this.selectDictLabel(this.statusDict, row.status)
    },
    // 批量删除
    handleDeleteMore(ids) {
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return scoringTeacherApi.delScoringTeacher(ids.toString())
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList()
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 表单重置
    reset() {
      this.ScoringTeacher = {
        password: '123456',
        teacherId: '',
        teaName: '',
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        paperStatus: '',
        privilege: '',
        status: '',
        expiryDate: '',
        orgId: this.courseTerm.orgId,
        createBy: '',
        createTime: '',
        updateBy: '',
        updateTime: ''
      }
    },
    selectall(selection) {
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].teacherId)
      }
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        this.deldisabled = false
      }
    },
    addScoringTeacher() {
      this.reset()
      this.ScoringTeacher.paperStatus = 0
      this.dialog.title = '添加阅卷教师'
      this.dialog.show = true
    },
    editScoringTeacher(row) {
      this.ScoringTeacher = { ...row }
      console.log('this.ScoringTeacher = ', this.ScoringTeacher)
      this.dialog.title = '修改阅卷教师'
      this.dialog.show = true
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return scoringTeacherApi.delScoringTeacher(row.teacherId)
        })
        .then(() => {
          this.$message({
            showClose: true,
            message: '删除成功',
            duration: 3000,
            type: 'success'
          })
          this.getList()
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    search(from) {
      // console.log('ScoringTeacher = ', from)
      this.queryParams.teacherId = from.teacherId
      this.queryParams.stuUserId = from.stuUserId
      this.pageNum = 1
      this.pageSize = USER_CONST.PAGESIZE
      this.getList()
    },
    getList() {
      this.loading = true
      scoringTeacherApi
        .getScoringTeacherList(this.queryParams, this.pageNum, this.pageSize)
        .then(response => {
          this.ScoringTeacherData = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
</style>
