<!--
@description 分组分头管理
@author cgy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">集体阅卷管理</div>
    </div>
    <div class="cd-main__body">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane label="集体阅卷" name="first">
          <allocatePaper :course-term="courseTerm" @login="login" />
        </el-tab-pane>
        <el-tab-pane v-if="(privilege===admin || privilege===groupLeader) && isLogin===true" label="阅卷教师管理" name="second">
          <scoringTeacher :course-term="courseTerm" />
        </el-tab-pane>
        <el-tab-pane v-if="(privilege===admin || privilege===groupLeader) && isLogin===true" label="集体阅卷分配管理" name="third">
          <paperAllocate :course-term="courseTerm" />
        </el-tab-pane>

        <!-- <el-tab-pane label="学员成绩管理" name="three">
          <MemberScore :course-scheme="courseScheme" />
        </el-tab-pane> -->
      </el-tabs>
    </div>
  </div>
</template>
<script>
import paperAllocate from './components/paper-allocate/index'
import scoringTeacher from './components/scoring-teacher/index'
import allocatePaper from './components/allocatePaper/index'
// import ExamGroupMember from './components/examGroupMember/index'
import COURSECONST from '@/constant/course-const'
export default {
  components: {
    paperAllocate,
    scoringTeacher,
    allocatePaper
    // MemberScore
  },
  props: {
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      activeName: 'first',
      isLogin: false,
      privilege: COURSECONST.TEACHER,
      teacher: COURSECONST.TEACHER,
      admin: COURSECONST.ADMIN,
      groupLeader: COURSECONST.GROUPLEADER
    }
  },
  methods: {
    handleClick(tab, event) {
      // console.log(tab, event)
    },
    login(isLogin, scoreTeacher) {
      this.isLogin = isLogin
      this.privilege = scoreTeacher.privilege
    }
  }
}
</script>
<style lang="scss" scoped>
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>
