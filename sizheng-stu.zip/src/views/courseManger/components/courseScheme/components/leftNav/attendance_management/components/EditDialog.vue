<template>
  <el-dialog
    :title="dialog.title"
    :visible.sync="dialog.isEditDialogVisiable"
    width="60%"
    @close="close"
    @open="open"
  >
    <el-form ref="checkinScore" :model="checkinScore" :rules="rules" label-width="140px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="学员分组" prop="mgId">
            <treeselect
              v-model="checkinScore.mgId"
              :options="courseMgOptions"
              style="width:217px;"
              placeholder="请选择学员分组"
              @select="courseMgChange"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item v-if="!isImport" label="学员学号" prop="stuId">
            <el-select
              v-model="checkinScore.stuId"
              placeholder="请选择学员学号"
              clearable
              @change="courseMemberChange"
            >
              <el-option
                v-for="courseMember in courseMemberOptions"
                :key="courseMember.userId"
                :label="courseMember.stuId"
                :value="courseMember"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item v-if="isImport" label="导入成绩文件" prop="scoreFile">
            <el-upload
              ref="upload"
              :action="uploadUrl"
              :limit="1"
              :before-upload="beforeUpload"
              :on-success="uploadSuccess"
              :on-error="uploadError"
              :headers="headers"
              :show-file-list="false"
              :data="checkinScore"
              :auto-upload="false"
            >
              <el-button slot="trigger" type="primary" size="small">选择文件</el-button>
              <div slot="tip" class="el-upload__tip">只能上传xls、xlsx文件，且不超过1Mb</div>
            </el-upload>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <el-form-item v-if="!isImport" label="姓名" prop="realName">
            <el-input v-model="checkinScore.realName" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item v-if="!isImport" label="用户Id" prop="userId">
            <el-input v-model="checkinScore.userId" disabled></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-form-item v-if="!isImport" label="考勤成绩" prop="checkinScore">
        <el-input v-model="checkinScore.checkinScore" placeholder="请输入内容" />
      </el-form-item>
      <el-form-item v-if="!isImport" label="备注" prop="remark">
        <el-input v-model="checkinScore.remark" type="textarea" :rows="4" placeholder="请输入内容" />
      </el-form-item>

      <el-form-item v-if="isImport" label="导入结果">
        <p v-html="importResult"></p>
      </el-form-item>
    </el-form>
    <div v-if="!isImport">
      <el-divider>请在下面添加原始成绩</el-divider>
      <el-button type="text" style="width:100%;" @click="addExperienceData">十 添加成绩</el-button>
      <el-table :data="scoreOptions">
        <el-table-column prop="score" align="center" label="成绩">
          <template slot-scope="scope">
            <el-input-number
              v-model="scoreOptions[scope.$index].score"
              :precision="2"
              :step="1"
              :max="100"
              placeholder="请输入内容"
            ></el-input-number>
          </template>
        </el-table-column>
        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="deleteRowElection(scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit('checkinScore')">保 存</el-button>
      <el-button size="small" @click="dialog.isEditDialogVisiable = false">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import checkinScoreApi from '@/api/course/regularGrade/checkinScore'
import courseMemberApi from '@/api/course/courseManage/courseMember'
import { getToken } from '@/utils/auth'
export default {
  name: 'CourseFavDialog',
  components: {
    Treeselect
  },
  props: {
    dialog: {
      type: Object,
      required: true
    },
    checkinScore: {
      type: Object,
      required: true
    },
    courseScheme: {
      type: Object,
      default: () => {
        return {}
      }
    },
    courseMgOptions: {
      type: Array,
      default: () => {
        return {}
      }
    },
    isImport: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      rules: {
        mgId: [{ required: true, message: '请选择学员分组', trigger: 'blur' }],
        realName: [{ required: true, message: '请选择学员', trigger: 'blur' }],
        checkinScore: [
          {
            required: true,
            pattern: /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/,
            message: '请输入正确的分数',
            trigger: 'blur'
          }
        ]
        // originScore: [{ required: true, message: '请填写原始成绩列表', trigger: 'blur' }]
      },
      courseOptions: [],
      courseTermOptions: [],
      schemeOptions: [],
      courseMemberOptions: [],
      uploadUrl: process.env.VUE_APP_BASE_API + '/course/checkin-score/import',
      headers: {
        token: getToken()
      },
      importResult: '',
      scoreOptions: []
    }
  },
  methods: {
    open() {
      if (this.checkinScore.cisId !== null) {
        courseMemberApi.getCourseMemberListByMgId(this.checkinScore.mgId).then(response => {
          this.courseMemberOptions = response.data
        })
        this.checkinScore.originScore = JSON.parse(this.checkinScore.originScore)
        for (var i = 0; i < this.checkinScore.originScore.length; i++) {
          this.scoreOptions.push({
            score: this.checkinScore.originScore[i].score
          })
        }
      }
    },
    /** 学员分组改变时触发 */
    courseMgChange(value) {
      this.checkinScore.realName = ''
      if (value !== '') {
        courseMemberApi.getCourseMemberListByMgId(value.id).then(response => {
          this.courseMemberOptions = response.data
        })
      } else {
        return
      }
    },
    /** 学员改变时触发 */
    courseMemberChange(value) {
      this.checkinScore.realName = value.realName
      this.checkinScore.stuId = value.stuId
      this.checkinScore.userId = value.userId
    },
    /** 上传之前检测文件类型及大小 */
    beforeUpload: function(file) {
      const FileExt = file.name.replace(/.+\./, '')
      if (['xls', 'xlsx'].indexOf(FileExt.toLowerCase()) === -1) {
        this.$message({
          type: 'warning',
          message: '请上传后缀名为xls、xlsx的附件！'
        })
        return false
      }
      this.isLt2k = file.size / 1024 < 800 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过800k!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 文件上传成功时的勾子 */
    uploadSuccess: function(response, file, fileList) {
      this.$refs.upload.clearFiles()
      if (response.code === 0) {
        this.importResult = response.data
        this.$emit('reset')
      } else {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件失败!' + response.msg,
          type: 'error'
        })
      }
    },
    /** 上传失败时的勾子 */
    uploadError: function(err, file, fileList) {
      this.$refs.upload.clearFiles()
      this.$message({
        message: '上传文件失败!',
        type: 'error'
      })
      console.log(err)
    },
    close() {
      this.$refs['checkinScore'].clearValidate()
      this.courseMemberOptions = []
      this.$emit('update:isImport', false)
      this.importResult = ''
      this.scoreOptions = []
    },
    // 点击确定
    submit(checkinScore) {
      this.$refs[checkinScore].validate(valid => {
        if (valid) {
          if (this.isImport) {
            this.$refs.upload.submit()
          } else {
            this.checkinScore.originScore = []
            this.scoreOptions.forEach(item => {
              this.checkinScore.originScore.push({ score: item.score })
            })
            this.checkinScore.originScore = JSON.stringify(this.checkinScore.originScore)
            if (this.checkinScore.cisId === null) {
              this.checkinScore.csId = this.courseScheme.csId
              this.checkinScore.schemeId = this.courseScheme.schemeId
              this.checkinScore.ctId = this.courseScheme.ctId
              checkinScoreApi.add(this.checkinScore)
                .then(result => {
                  if (result.code === 0) {
                    this.$message({
                      type: 'success',
                      message: '添加成功'
                    })
                  } else {
                    this.$message({
                      type: 'error',
                      message: '添加失败'
                    })
                  }
                  this.$emit('reset')
                  this.dialog.isEditDialogVisiable = false
                })
            } else {
              checkinScoreApi.update(this.checkinScore)
                .then(result => {
                  if (result.code === 0) {
                    this.$message({
                      type: 'success',
                      message: '修改成功'
                    })
                  } else {
                    this.$message({
                      type: 'error',
                      message: '修改失败'
                    })
                  }
                  this.$emit('reset')
                  this.dialog.isEditDialogVisiable = false
                })
            }
          }
        } else {
          return false
        }
      })
    },
    addExperienceData() {
      this.scoreOptions.push({})
    },
    deleteRowElection(index) {
      this.scoreOptions.splice(index, 1)
    }
  }
}
</script>

<style scoped>

</style>
