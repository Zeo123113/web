
<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="学员分组" prop="mgId">
      <treeselect
        v-model="queryParams.mgId"
        :options="courseMgOptions"
        style="width:217px;"
        placeholder="请选择学员分组"
      />
    </el-form-item>
    <el-form-item label="学生学号" prop="stuId">
      <el-input v-model="queryParams.stuId" placeholder="请输入学生学号" clearable />
    </el-form-item>
    <el-form-item label="学生姓名" prop="realName">
      <el-input v-model="queryParams.realName" placeholder="请输入学生姓名" clearable />
    </el-form-item>
    <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        unlink-panels
        :picker-options="pickerOptions"
        style="width:217px;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        icon="el-icon-search"
        :disabled="!button.includes('course/checkinScore/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button icon="el-icon-refresh" @click="resetForm('searchForm')">重置</el-button>
      <el-button
        icon="el-icon-plus"
        type="primary"
        :disabled="!button.includes('course/checkinScore/add')"
        @click="add"
      >新增</el-button>
      <el-button
        type="danger"
        icon="el-icon-delete"
        :disabled="ids.length===0 || !button.includes('course/checkinScore/delete')"
        @click="handleBatchDelete()"
      >删除</el-button>
      <el-button
        type="warning"
        icon="el-icon-upload2"
        :disabled="!button.includes('course/checkinScore/import')"
        @click="importScore()"
      >导入</el-button>
      <el-link type="primary" style="margin-left:10px;" @click="handleDownload">下载导入模板</el-link>
    </el-form-item>
  </el-form>
</template>
<script>
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'HeaderSearch',
  components: {
    Treeselect
  },
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    button: {
      type: Array,
      required: true
    },
    ids: {
      type: Array,
      required: true
    },
    courseMgOptions: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]

      },
      dateRange: ''
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  methods: {
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.dateRange = ''
      this.queryParams.beginTime = null
      this.queryParams.endTime = null
      this.$emit('search')
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.orgId = this.$store.getters.user.orgId
      this.$emit('search')
    },
    /** 点击新增 */
    add() {
      this.$emit('addcheckinScore')
    },
    /** 点击删除 */
    handleBatchDelete() {
      this.$emit('handleBatchDelete')
    },
    importScore() {
      this.$emit('importScore')
    },
    handleDownload() {
      this.$emit('handleDownload')
    }
  }
}
</script>
<style scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
