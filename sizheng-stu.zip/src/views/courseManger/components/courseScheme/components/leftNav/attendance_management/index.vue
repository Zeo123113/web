<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">考勤管理</div>
    </div>
    <div class="cd-main__body">
      <header-search
        :query-params="queryParams"
        :button="button"
        :ids="ids"
        :course-mg-options="courseMgOptions"
        @search="search"
        @addcheckinScore="addcheckinScore"
        @handleBatchDelete="handleBatchDelete"
        @importScore="importScore"
        @handleDownload="handleDownload"
      ></header-search>
      <!-- 表格展示开始 -->
      <el-table
        v-loading="loading"
        :data="checkinScoreData"
        tooltip-effect="light"
        row-key="cisId"
        @select="handleSelectionChange"
        @select-all="selectAll"
      >
        <el-table-column type="selection" align="center" min-width="50" />
        <el-table-column label="考勤成绩编号" type="index" align="center" min-width="120" />
        <el-table-column label="学员分组" :formatter="MgFormat" show-overflow-tooltip prop="mgId" align="center" min-width="120" />
        <el-table-column label="用户Id" prop="userId" align="center" min-width="120" />
        <el-table-column label="学号" prop="stuId" align="center" min-width="120" />
        <el-table-column label="姓名" prop="realName" align="center" min-width="120" />
        <el-table-column
          label="原始成绩列表"
          prop="originScore"
          align="center"
          sortable
          min-width="160"
          show-overflow-tooltip
        />
        <el-table-column label="考勤成绩" prop="checkinScore" align="center" sortable min-width="160" />
        <el-table-column label="所属机构" prop="orgId" :formatter="orgFormat" show-overflow-tooltip align="center" min-width="100" />
        <el-table-column label="操作" fixed="right" align="center" min-width="150">
          <template slot-scope="scope">
            <el-button
              type="success"
              size="mini"
              :disabled="!button.includes('course/checkinScore/update')"
              @click="handleUpdate(scope.row)"
            >编辑</el-button>
            <el-button
              type="danger"
              size="mini"
              :disabled="!button.includes('course/checkinScore/delete')"
              @click="handleDelete(scope.row)"
            >删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 表格结束 -->
      <!-- 分页控件-->
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      />
      <!-- 新增框 更新框-->
      <edit-dialog
        :checkin-score="checkinScore"
        :dialog="dialog"
        :course-scheme="courseScheme"
        :course-mg-options="courseMgOptions"
        :is-import.sync="isImport"
        @reset="search"
      ></edit-dialog>
    </div>
  </div>
</template>

<script>
import { downloadByLink } from '@/utils/index'
import COURSE_CONST from '@/constant/course-const'
import HeaderSearch from './components/HeaderSearch'
import pagination from '@/components/Pagination/index'
import EditDialog from './components/EditDialog'
import orgApi from '@/api/user/org'
import checkinScoreApi from '@/api/course/regularGrade/checkinScore'
import { mapGetters } from 'vuex'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
export default {
  name: 'CheckinScore',
  components: {
    EditDialog,
    HeaderSearch,
    pagination
  },
  props: {
    courseScheme: {
      type: Object,
      default: () => { return {} }
    }
  },
  data() {
    return {
      checkinScoreData: [],
      approveStatusOptions: [],
      orgOptions: [],
      ids: [],
      loading: false,
      isselectAll: false,
      // 分页页数
      pageNum: 1,
      // 每页数据
      pageSize: COURSE_CONST.PAGESIZE,
      // 分页记录总条数
      total: 1,
      queryParams: {
        orgId: null,
        ctId: null,
        csId: null,
        mgId: null,
        stuId: '',
        schemeId: null,
        realName: '',
        beginTime: null,
        endTime: null
      },
      dialog: {
        // 弹出框标题
        title: '',
        // 是否显示弹出框
        isEditDialogVisiable: false
      },
      checkinScore: {},
      /** 是否是导入 */
      isImport: false,
      // 学员分组
      courseMgOptions: []
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  created() {
    // 获取当前用户的组织机构树
    orgApi.getOrgTreeByCurrentUser().then(result => {
      this.orgOptions = result.data
      console.log(result.data)
    })
    courseMemberGroupApi.getCourseMemberGroupBySchemeId(this.courseScheme.schemeId).then(response => {
      this.courseMgOptions = response.data
    })
  },
  methods: {
    // 机构翻译
    orgFormat(row) {
      return this.getorgFormat(row.orgId, this.orgOptions)
    },
    getorgFormat(id, options) {
      for (let i = 0; i < options.length; i++) {
        if (id === options[i].id) {
          return options[i].label
        }
        if (options[i].children != null && options[i].children.length > 0) {
          this.getorgFormat(id, options[i].children)
        }
      }
    },
    // 分组翻译
    MgFormat(row) {
      return this.getMgFormat(row.mgId, this.courseMgOptions)
    },
    getMgFormat(id, options) {
      for (let i = 0; i < options.length; i++) {
        if (id === options[i].id) {
          return options[i].label
        }
        if (options[i].children != null && options[i].children.length > 0) {
          this.getMgFormat(id, options[i].children)
        }
      }
    },
    initcheckinScore() {
      this.checkinScore = {
        cisId: null,
        orgId: null,
        csId: null,
        ctId: null,
        schemeId: null,
        mgId: null,
        stuId: null,
        userId: null,
        realName: '',
        originScore: null,
        checkinScore: '0.0',
        remark: ''
      }
    },
    /** 审批状态字典翻译字典翻译 */
    approveStatusFormat(row) {
      return this.selectDictLabel(this.approveStatusOptions, row.approveStatus)
    },
    /** 处理分页查询 */
    pageQuery(pagePara) {
      this.getList(this.queryParams, pagePara.page, pagePara.limit)
    },
    /** 处理查询 */
    search() {
      this.getList(this.queryParams, this.pageNum, this.pageSize)
    },
    addcheckinScore() {
      this.initcheckinScore()
      this.dialog.title = '增加考勤成绩'
      this.dialog.isEditDialogVisiable = true
    },
    handleBatchDelete() {
      this.$confirm('您确定要删除所选的考勤成绩?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        if (this.isselectAll) {
          checkinScoreApi.deleteByConditions(this.queryParams).then(response => {
            if (response.code === 0) {
              this.getList(this.queryParams, this.pageNum, this.pageSize)
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
              this.ids = []
              this.isselectAll = false
            }
          })
        } else {
          checkinScoreApi.delete(this.ids.toString()).then(response => {
            if (response.code === 0) {
              this.getList(this.queryParams, this.pageNum, this.pageSize)
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
              this.ids = []
            }
          })
        }
      })
    },
    handleUpdate(row) {
      this.checkinScore = { ...row }
      this.dialog.title = '修改考勤成绩'
      this.dialog.isEditDialogVisiable = true
    },
    handleDelete(row) {
      this.$confirm('您确定要删除所选的考勤成绩?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        checkinScoreApi.delete(row.cisId.toString()).then(response => {
          if (response.code === 0) {
            this.getList(this.queryParams, this.pageNum, this.pageSize)
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }
        })
      })
    },
    /** 处理多选按钮 */
    handleSelectionChange(selection, row) {
      this.ids = selection.map(item => item.cisId)
    },
    /** 处理全选 条件删除 */
    selectAll(selection) {
      if (selection.length > 0) {
        this.isSelectAll = true
      } else {
        this.isSelectAll = false
      }
      this.ids = selection.map(item => item.cisId)
    },
    /** 查询列表 */
    getList(param, pageNum, pageSize) {
      this.loading = true
      checkinScoreApi.getList(param, pageNum, pageSize).then(response => {
        this.checkinScoreData = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    },
    importScore() {
      this.initcheckinScore()
      this.dialog.title = '导入考勤成绩'
      this.dialog.isEditDialogVisiable = true
      this.isImport = true
    },
    handleDownload() {
      checkinScoreApi
        .downloadTemplete()
        .then(result => {
          if (result.code === 0) {
            downloadByLink(process.env.VUE_APP_FILE_SERVER, result.data, '考勤成绩导入模板.xlsx')
          }
          // this.downloadLoading = false
        })
        .catch(() => {
          // this.downloadLoading = false
        })
    }
  }

}
</script>

<style lang="scss" scoped>
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 800px;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>
