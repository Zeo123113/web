<!--
@description 课程计划---基础设置
@author cgy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">基础设置</div>
    </div>
    <div class="cd-main__body">
      <el-form ref="form" :model="courseScheme" :rules="rules" class="form-horizontal">
        <div class="course-manage-subltitle cd-mb40">基础信息</div>
        <div role="course-marketing-info">
          <div class="form-group">
            <el-col :span="24">
              <el-form-item label="方案标题" prop="schemeTitle" :label-width="formLabelWidth">
                <el-input
                  v-model="courseScheme.schemeTitle"
                  placeholder="请输入课程名称"
                  style="width:92%;"
                  clearable
                />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="方案副标题" prop="schemeSubtitle" :label-width="formLabelWidth">
                <el-input
                  v-model="courseScheme.schemeSubtitle"
                  type="textarea"
                  style="width:92%;"
                  placeholder="请输入课程副标题"
                  clearable
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="课程学分" prop="giveCredit" :label-width="formLabelWidth">
                <el-input-number
                  v-model="courseScheme.giveCredit"
                  controls-position="right"
                  :min="0"
                  :max="999"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="默认教学计划" prop="isDefaultScheme" :label-width="formLabelWidth">
                <el-switch v-model="courseScheme.isDefaultScheme"></el-switch>
              </el-form-item>
            </el-col>
          </div>
          <div class="course-manage-subltitle cd-mb40">营销设置</div>
          <div role="course-marketing-info">
            <div class="form-group">
              <el-col :span="12">
                <el-form-item label="允许学员自行加入" prop="isAllowedJoin" :label-width="formLabelWidth">
                  <el-switch v-model="courseScheme.isAllowedJoin"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item
                  v-if="courseScheme.isAllowedJoin"
                  label="加入课程密码"
                  prop="joinPassword"
                  :label-width="formLabelWidth"
                >
                  <el-input
                    v-model="courseScheme.joinPassword"
                    placeholder="请输入加入课程密码"
                    show-password
                    clearable
                  />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="免费" prop="isFree" :label-width="formLabelWidth">
                  <el-switch v-model="courseScheme.isFree"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item
                  v-if="!courseScheme.isFree"
                  label="购买开放有效期"
                  prop="openPeriod"
                  :label-width="formLabelWidth"
                >
                  <el-date-picker
                    v-model="courseScheme.openPeriod"
                    type="datetime"
                    style="width:92%;"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="请选择日期"
                  ></el-date-picker>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item
                  v-if="!courseScheme.isFree"
                  label="课程原价"
                  prop="originPrice"
                  :label-width="formLabelWidth"
                >
                  <el-input
                    v-model="courseScheme.originPrice"
                    style="width:92%;"
                    placeholder="请输入课程原价"
                    clearable
                  />
                </el-form-item>
              </el-col>
            </div>
          </div>

          <div class="course-manage-subltitle cd-mb40">基础规则</div>
          <div role="course-base-rule">
            <div class="form-group">
              <el-col :span="12">
                <el-form-item label="学习模式" prop="learnMode" :label-width="formLabelWidth">
                  <el-radio-group v-model="courseScheme.learnMode">
                    <el-radio
                      v-for="dict in learnModeOptions"
                      :key="dict.dictvalue"
                      :label="dict.dictValue"
                    >{{ dict.dictLabel }}</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="课程发布模式" prop="publishMode" :label-width="formLabelWidth">
                  <el-radio-group v-model="courseScheme.publishMode">
                    <el-radio
                      v-for="dict in publishModeOptions"
                      :key="dict.dictvalue"
                      :label="dict.dictValue"
                    >{{ dict.dictLabel }}</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="显示学员数" prop="isShowMemberCount" :label-width="formLabelWidth">
                  <el-switch v-model="courseScheme.isShowMemberCount"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="上锁" prop="isLocked" :label-width="formLabelWidth">
                  <el-switch v-model="courseScheme.isLocked"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="为推荐课程" prop="isRecommended" :label-width="formLabelWidth">
                  <el-switch v-model="courseScheme.isRecommended"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item
                  v-if="courseScheme.isRecommended"
                  label="推荐时间"
                  prop="recommendedTime"
                  :label-width="formLabelWidth"
                >
                  <el-date-picker
                    v-model="courseScheme.recommendedTime"
                    type="datetime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="请选择推荐时间"
                  ></el-date-picker>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="展示服务承诺" prop="isShowPromise" :label-width="formLabelWidth">
                  <el-switch v-model="courseScheme.isShowPromise"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item
                  v-if="courseScheme.isShowPromise"
                  label="服务型说明"
                  prop="serviceInfo"
                  :label-width="formLabelWidth"
                >
                  <el-input
                    v-model="courseScheme.serviceInfo"
                    placeholder="请输入服务型说明"
                    :rows="4"
                    type="textarea"
                  />
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item label="课程目标" prop="goals" :label-width="formLabelWidth">
                  <tinymce
                    ref="goals"
                    v-model="courseScheme.goals"
                    :save-flag="saveFlag"
                    :height="250"
                  />
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item label="课程受众" prop="audiences" :label-width="formLabelWidth">
                  <tinymce
                    ref="audiences"
                    v-model="courseScheme.audiences"
                    :save-flag="saveFlag"
                    :height="250"
                  />
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item label="课程推介" prop="recomIntro" :label-width="formLabelWidth">
                  <tinymce
                    ref="recomIntro"
                    v-model="courseScheme.recomIntro"
                    :save-flag="saveFlag"
                    :height="250"
                  />
                </el-form-item>
              </el-col>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-8">
            <el-button
              v-if="!hold"
              type="primary"
              style="background-color: #E50112;border-color: #E50112;"
              class="course-btn-submit"
              size="small"
              @click="submit"
            >保 存</el-button>
            <el-button
              v-if="hold"
              type="primary"
              class="course-btn-submit"
              size="small"
              disabled
            >正 在 保 存 ...</el-button>
          </div>
        </div>
      </el-form>
    </div>
  </div>
</template>
<script>
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import Tinymce from '@/components/Tinymce'
export default {
  name: 'BaseSetting',
  components: {
    Tinymce
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      isError: false,
      // 表单属性宽度
      formLabelWidth: '150px',
      // 正在保存
      hold: false,
      rules: {
        schemeTitle: [
          { required: true, message: '授课方案标题不能为空', trigger: 'blur' },
          { min: 3, max: 50, message: '长度在 3 到 50 个字符', trigger: 'blur' }
        ],
        originPrice: [{ pattern: /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/, message: '请输入正确的价格', trigger: 'blur' }],
        schemeSubtitle: [
          { required: true, message: '授课方案副标题不能为空', trigger: 'blur' },
          { min: 3, max: 50, message: '长度在 3 到 50 个字符', trigger: 'blur' }
        ],
        giveCredit: [
          { pattern: /^[0-9]+(.[0-9]{0,1})?$/, message: '请输入0-1位小数的正实数', trigger: 'change' }
        ]
      },
      publishModeOptions: [],
      learnModeOptions: [],
      schemeStatusOptions: [],
      scoreStatusDict: [],
      // 富文本开启标志
      saveFlag: false
    }
  },
  created() {
    // 课程发布模式字典获取
    this.getDataByType('course_publish_mode').then(response => {
      this.publishModeOptions = response.data
    })
    // 学习模式字典获取
    this.getDataByType('course_learn_mode').then(response => {
      this.learnModeOptions = response.data
    })
    // 教学计划状态字典获取
    this.getDataByType('course_scheme_status').then(response => {
      this.schemeStatusOptions = response.data
    })
  },
  methods: {
    /** 打开弹窗放入富文本内容 */
    open() {
      this.saveFlag = true
      this.editsaveFlag()
    },
    editsaveFlag() {
      setTimeout(() => {
        this.saveFlag = !this.saveFlag
      }, 500)
    },
    // 拖动 Slider 滑块
    change(value) {
      console.log('value = ', value)
    },
    // 提交
    submit() {
      this.hold = !this.hold
      this.courseScheme.teacherIds = JSON.stringify(this.courseScheme.teacherIds)
      this.$refs['form'].validate(valid => {
        if (valid) {
          // 更新教学计划
          courseSchemeApi.update(this.courseScheme).then(response => {
            if (response.code === 0) {
              this.$message({
                message: '保存成功',
                type: 'success'
              })
            } else {
              this.$message.error('保存失败')
            }
            this.hold = !this.hold
            this.$emit('getList')
          })
        } else {
          this.$message({
            type: 'error',
            message: '表单校验不合法'
          })
          this.hold = !this.hold
        }
      })
    }
  }
}
</script>
<style scoped>
.course-btn-submit {
  color: #fff;
  background: #e50112;
  border-color: #e50112;
}
</style>
<style lang="scss" scoped>
table {
  border-collapse: collapse;

  font-family: Futura, Arial, sans-serif;
}

caption {
  font-size: larger;

  margin: 1em auto;
}

th,
td {
  padding: 0.65em;
}

th,
td {
  border-bottom: 1px solid #ddd;

  border-top: 1px solid #ddd;

  text-align: center;
}
.form-control-static {
  min-height: 34px;
  padding-top: 11px;
  padding-bottom: 7px;
  margin-bottom: 0;
}
.list-group {
  padding-left: 0;
  margin-bottom: 10px;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.col-sm-8 {
  float: left;
  width: 66.66666667%;
}
label + .cd-radio-group .cd-radio {
  margin-top: 12px;
  margin-bottom: 4px;
}
.course-manage-info .cd-radio {
  min-width: 76px;
  color: rgba(0, 0, 0, 0.88);
  font-weight: 400;
}
.cd-radio {
  position: relative;
  padding-right: 20px;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  display: inline-block;
  margin-bottom: 0;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.ml5 {
  margin-left: 5px;
  font-size: 14px;
}
.course-mangae-info__input {
  width: 128px;
  display: inline-block;
}
.form-control {
  color: #616161;
  border-color: #e1e1e1;
}
.mrs {
  margin-right: 5px !important;
}
.form-control {
  //   width: 100%;
  height: 34px;
  padding: 6px 12px;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-transition: border-color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.form-control,
output {
  //   display: block;
  font-size: 14px;
  line-height: 1.42857143;
  color: #919191;
}
.control-label-required {
  position: relative;
}

label {
  display: inline-block;
  max-width: 100%;
  margin-bottom: 5px;
  font-weight: 700;
  //   font-size: 15px;
}
.form-horizontal .control-label {
  text-align: right;
  margin-bottom: 0;
  padding-top: 11px;
}

.col-sm-2 {
  float: left;
  width: 16.66666667%;
}
.course-manage-intro i {
  line-height: 42px;
  font-size: 16px;
}

.es-icon {
  line-height: 1;
}
.es-icon {
  font-family: es-icon !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.course-manage-intro .course-manage-intro__inner {
  width: 42px;
  height: 42px;
  text-align: center;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  color: #fff;
  background-color: #e50112;
}
.course-manage-intro .course-manage-intro__tip {
  font-size: 12px;
  line-height: 1;
  color: #adadad;
}

.mtm {
  margin-top: 10px !important;
}
.course-manage-intro .course-manage-intro__outer {
  padding: 0 15px;
  width: 72px;
}
.cd-mt24 {
  margin-top: 24px !important;
}

.form-group {
  margin-bottom: 15px;
}
.course-manage-info .form-group {
  margin-bottom: 24px;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.course-manage-info .course-manage-info__title {
  box-shadow: none;
}

.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.course-manage-info .course-manage-info__title + div {
  padding-top: 0;
}

.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
form {
  display: block;
  margin-top: 0em;
}
.course-manage-subltitle {
  padding: 9px 0 9px 32px;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  color: rgba(0, 0, 0, 0.8);
  background-color: rgba(0, 0, 0, 0.04);
}

.cd-mb40 {
  margin-bottom: 40px !important;
}
.course-manage-subltitle {
  padding: 9px 0 9px 32px;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  color: rgba(0, 0, 0, 0.8);
  background-color: rgba(0, 0, 0, 0.04);
}
.cd-mb40 {
  margin-bottom: 40px !important;
}
.course-manage-info .form-group {
  margin-bottom: 24px;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
.course-manage-intro {
  position: fixed;
  bottom: 30px;
  z-index: 1000;
}
input {
  line-height: normal;
}

input,
optgroup,
select,
textarea {
  color: inherit;
  font: inherit;
  margin: 0;
}
</style>
