<template>
  <el-dialog :title="dialog.title" :visible.sync="dialog.show" width="400px">
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row>
        <el-col :span="24">
          <el-form-item label="章节名称" prop="chapterName">
            <el-input v-model="form.chapterName" placeholder="请输入章节名称" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" :disabled="saveFlag" @click="submit">{{ saveFlag?'保存中':'保存' }}</el-button>
      <el-button @click="close">取消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import chapterApi from '@/api/exambank/chapter'
export default {
  name: 'EditDialog',
  props: {
    dialog: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      default: null
    },
    chapterOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      // 表单校验
      rules: {
        // courseName: [{ required: true, message: '所属课程不能为空', trigger: 'blur' }],
        parentId: [{ required: true, message: '所属章节不能为空', trigger: 'blur' }],
        chapterName: [
          { required: true, message: '章节名称不能为空', trigger: 'blur' },
          { min: 1, max: 20, message: '长度在2到20个字符', trigger: 'blur' }
        ]
      },
      courseOptions: [],
      // 是否点击保存
      saveFlag: false
    }
  },
  methods: {
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    /** 提交按钮 */
    submit: function() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.saveFlag = true
          if (this.dialog.title === '添加章节') {
            this.form.orgId = this.$store.getters.user.orgId
            this.form.courseId = this.$route.params.csId
            chapterApi
              .addChapter(this.form)
              .then(result => {
                if (result.code === 0) {
                  this.dialog.show = false
                  this.saveFlag = false
                  this.$emit('handleAddSuccess', this.form)
                  this.$message({
                    message: '保存成功',
                    type: 'success'
                  })
                }
              })
              .catch(err => {
                console.log(err)
              })
          } else {
            chapterApi
              .update(this.form)
              .then(result => {
                this.dialog.show = false
                this.$emit('getList')
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
              })
              .catch(err => {
                console.log(err)
              })
          }
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
