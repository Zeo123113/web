<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true">
    <el-form-item label="章节名称" prop="chapterName">
      <el-input v-model="queryParams.chapterName" size="small" placeholder="请输入章节名称" clearable />
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        icon="el-icon-search"
        size="small"
        :disabled="!button.includes('bank/chapter/list')"
        @click="handleQuery"
      >搜索</el-button>
      <!-- <el-button icon="el-icon-refresh" size="small" @click="resetQuery('searchForm')">重置</el-button> -->
      <el-button type="primary" size="small" icon="el-icon-plus" @click="addChapter">新增</el-button>
      <!-- <el-button
        type="danger"
        size="small"
        icon="el-icon-delete"
        :disabled="deldisabled"
        @click="handleBatchDelete(ids)"
      >删除</el-button> -->
    </el-form-item>
  </el-form>
</template>
<script>
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'HeaderSearch',
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    button: {
      type: Array,
      required: true
    },
    deldisabled: {
      type: Boolean,
      default: false
    },
    ids: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      orgOptions: [],
      courseOptions: []
    }
  },
  methods: {
    // 搜索处理
    handleQuery() {
      this.$emit('getList', this.queryParams)
    },
    // 重置操作
    /** 重置按钮操作 */
    resetQuery(formName) {
      this.$refs[formName].resetFields()
      this.$emit('getList')
    },
    handleBatchDelete() {
      this.$emit('handleBatchDelete')
    },
    addChapter() {
      this.$emit('addChapter')
    }
  }
}
</script>
<style scoped>
</style>
