<!--
@description 章节管理
@author liguanjing
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">课程目录</div>
    </div>
    <div class="cd-main__body">
      <!--搜索框-->
      <header-search
        :query-params="queryParams"
        :button="button"
        :deldisabled="deldisabled"
        :ids="ids"
        @getList="getList"
        @addChapter="addChapter"
        @handleBatchDelete="handleBatchDelete"
      ></header-search>
      <el-table
        ref="table"
        v-loading="loading"
        :data="chapterList"
        row-key="chapterSeq"
        lazy
        tooltip-effect="light"
        :load="load"
        :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
        @select-all="handleSelectionChange"
        @select="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column label="章节" align="left" min-width="160">
          <template slot-scope="scope">
            <span
              v-if="scope.row.parentId == 0"
            >第&nbsp;{{ scope.row.seq }}&nbsp;章 {{ scope.row.chapterName }}</span>
            <span v-else>{{ scope.row.chapterSeq }}&nbsp;{{ scope.row.chapterName }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" fixed="right" min-width="150">
          <template slot-scope="scope">
            <el-tooltip effect="light" content="编辑" placement="top">
              <el-button
                size="mini"
                type="text"
                style="padding:5px 3px;"
                icon="el-icon-edit"
                @click="handleUpdate(scope.row)"
              ></el-button>
            </el-tooltip>
            <el-tooltip effect="light" content="新增" placement="top">
              <el-button
                size="mini"
                type="text"
                style="padding:5px 3px;"
                icon="el-icon-plus"
                @click="handleAdd(scope.row)"
              ></el-button>
            </el-tooltip>
            <el-tooltip effect="light" content="删除" placement="top">
              <el-button
                size="mini"
                type="text"
                style="padding:5px 3px;"
                icon="el-icon-delete"
                @click="handleDelete(scope.row)"
              ></el-button>
            </el-tooltip>
            <el-tooltip effect="light" content="上移" placement="top">
              <el-button
                size="mini"
                type="text"
                style="padding:5px 3px;"
                :disabled="submitSet"
                @click="handleTop(scope.row)"
              >
                <svg class="icon" aria-hidden="true">
                  <use xlink:href="#icon-shangyi" />
                </svg>
              </el-button>
            </el-tooltip>
            <el-tooltip effect="light" content="下移" placement="top">
              <el-button
                size="mini"
                type="text"
                style="padding:5px 3px;"
                :disabled="submitSet"
                @click="handleDown(scope.row)"
              >
                <svg class="icon" aria-hidden="true">
                  <use xlink:href="#icon-xiayi" />
                </svg>
              </el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
      <edit-dialog
        :form="chapter"
        :dialog="dialog"
        :course-options="courseOptions"
        :chapter-options="chapterOptions"
        @handleAddSuccess="handleAddSuccess"
      />
    </div>
  </div>
</template>
<script>
import HeaderSearch from './components/HeaderSearch'
import EditDialog from './components/EditDialog'
import chapterApi from '@/api/exambank/chapter.js'
import { mapGetters } from 'vuex'
export default {
  components: {
    HeaderSearch,
    EditDialog
  },
  data() {
    return {
      // 章节实体
      chapter: {
        chapterName: '',
        parentId: null,
        courseId: null,
        createTime: ''
      },
      // 对话框
      dialog: {
        title: '',
        show: false
      },
      // 遮罩层
      loading: true,
      // 表格树数据
      chapterList: [],
      // 查询参数
      queryParams: {
        courseId: null,
        chapterName: null,
        beginTime: null,
        endTime: null,
        orgId: null
      },
      // 课程名
      courseOptions: [],
      // 章节树
      chapterOptions: [],
      // 批量删除按钮
      deldisabled: true,
      // 批量删除id
      ids: [],
      // 待添加新章节的章节
      chapterParent: {},
      // 移动对象父级
      data: null,
      // 保存表格异步数据
      maps: new Map(),
      // 是否上移
      isTop: null,
      // 点击了移动
      submitSet: false,
      treeNode: null,
      resolve: null
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  // 钩子函数 页面加载时生成数据和树
  created() {
    this.getList(this.queryParams)
    // this.getTree()
  },
  methods: {
    /** 查询章节列表 */
    getList() {
      this.loading = true
      this.queryParams.courseId = this.$route.params.csId
      this.queryParams.orgId = this.$store.getters.user.orgId
      chapterApi.listChapter(this.queryParams).then(response => {
        this.chapterList = response.data
        this.loading = false
      })
    },
    // 表单重置
    reset() {
      this.chapter = {
        chapterName: '',
        parentId: null,
        courseId: null,
        seq: '',
        chapterSeq: ''
      }
    },
    /** 增加章节 */
    addChapter() {
      this.reset()
      this.chapter.chapterId = 0
      this.dialog.title = '添加章节'
      this.dialog.show = true
      this.chapterParent = { chapterId: 0 }
    },
    /** 行新增  */
    handleAdd(row) {
      this.reset()
      if (row != null) {
        this.chapter.parentId = row.chapterId
      }
      this.chapterParent = row
      this.dialog.title = '添加章节'
      this.dialog.show = true
    },
    /** 添加成功后的回显 */
    handleAddSuccess(chapter) {
      if (!chapter.parentId) {
        this.getList(this.queryParams)
      } else {
        if (this.maps.has(chapter.parentId)) {
          const { tree, treeNode, resolve } = this.maps.get(chapter.parentId)
          this.$set(this.$refs.table.store.states.lazyTreeNodeMap, chapter.parentId, [])
          this.load(tree, treeNode, resolve)
        } else {
          this.chapterParent.hasChildren = true
        }
      }
    },
    // 删除后调用
    refreshRow(parentId) {
      if (parentId === 0) {
        this.getList(this.queryParams, this.pageNum, this.pageSize)
      } else {
        if (this.maps != null && this.maps.get(parentId) !== null && this.maps.get(parentId) !== undefined) {
          const { tree, treeNode, resolve } = this.maps.get(parentId)
          this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
          this.load(tree, treeNode, resolve)
        } else {
          this.getList(this.queryParams, this.pageNum, this.pageSize)
        }
      }
      this.$message({
        message: '删除成功',
        type: 'error'
      })
    },
    // refreshRowByEntity(row) {
    //   if (this.maps != null && this.maps.get(row.chapterId) !== null && this.maps.get(row.chapterId) !== undefined) {
    //     const { tree, treeNode, resolve } = this.maps.get(row.chapterId)
    //     this.$set(this.$refs.table.store.states.lazyTreeNodeMap, row.chapterId, [])
    //     this.load(tree, treeNode, resolve)
    //   } else {
    //     this.load(row, this.treeNode, this.resolve)
    //   }
    // },
    // 点击节点获取子章节
    load(tree, treeNode, resolve) {
      console.log(tree)
      const id = tree.chapterId
      this.maps.set(id, { tree, treeNode, resolve })
      chapterApi
        .getChapterTreeByParentId(tree)
        .then(result => {
          console.log(tree, result.data)
          resolve(result.data)
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 编辑按钮 */
    handleUpdate(row) {
      this.reset()
      this.chapter = row
      this.dialog.title = '修改章节'
      this.dialog.show = true
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('是否确认删除选择的章节?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          return chapterApi.delChapter(row.chapterId, row.courseId)
        })
        .then(() => {
          if (this.maps.has(row.parentId)) {
            const { row, treeNode, resolve } = this.maps.get(row.parentId)
            this.$set(this.$refs.table.store.states.lazyTreeNodeMap, row.parentId, [])
            this.load(row, treeNode, resolve)
          }

          this.$message({
            message: '删除成功',
            type: 'success'
          })
        })
        .catch(function() {})
    },
    // 选中多个id
    handleSelectionChange(selection) {
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].chapterId)
      }
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        this.deldisabled = false
      }
    },
    /** 批量删除按钮操作 */
    handleBatchDelete() {
      this.$confirm('是否确认删除选择的章节?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          return chapterApi.delChapter(this.ids.toString(), this.$route.params.csId)
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '批量删除成功'
          })
          // this.refreshRow()
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 向上移动 */
    handleTop(row) {
      if (row.seq === 1) {
        this.$message({
          type: 'error',
          message: '第一章节不能上移！'
        })
      } else {
        this.isTop = true
        this.submitSet = true
        chapterApi.settingPosition(row, this.isTop).then(resp => {
          if (resp.code === 0) {
            this.refreshRow(row.parentId)
            this.refreshRow(row.chapterId)
            this.refreshRow(resp.data.chapterId)
            row.hasChildren = false
            this.submitSet = false
          }
        })
      }
    },
    handleDown(row) {
      if (row.parentId !== 0) {
        this.data = this.maps.get(row.parentId).tree.childrenNum
      } else {
        this.data  = this.chapterList.length
      }
      if (row.seq === this.data) {
        this.$message({
          type: 'error',
          message: '最后章节不能下移'
        })
      } else {
        this.isTop = false
        this.submitSet = true
        chapterApi.settingPosition(row, this.isTop).then(resp => {
          if (resp.code === 0) {
            this.refreshRow(row.parentId)
            this.refreshRow(row.chapterId)
            this.refreshRow(resp.data.chapterId)
            this.submitSet = false
          }
        })
      }
    }
  }
}
</script>
