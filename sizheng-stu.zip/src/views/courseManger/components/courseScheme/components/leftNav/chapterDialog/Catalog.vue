<!--
@description 课时添加-目录
@author cgy
-->
<template>
  <div>
    <div v-if="main && !perusalVisible">
      <div v-loading="loading" class="catalog">
        <el-collapse v-for="(item,i) of courseChapters" :key="i" style="border:0;">
          <el-collapse-item v-if="item != null && item.chapterType !== '2'">
            <!-- 一级菜单（章） -->
            <template slot="title">
              <i class="ico_chapter_sty" style="margin-right:10px;"></i>
              <div style="font-size:16px;font-weight:bold;">{{ chapterTitle(item) }}</div>
              <!-- 按钮组 -->
              <div style="display:inline-block;position:absolute;left:90%;">
                <el-dropdown>
                  <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-jia" />
                  </svg>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>
                      <a @click="addSection(item)">添加节</a>
                    </el-dropdown-item>
                    <el-dropdown-item>
                      <a @click="addUnitTask(item)">添加课时</a>
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
                <el-dropdown>
                  <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-shenglvehao" />
                  </svg>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>
                      <a @click="rename(item)">重命名</a>
                    </el-dropdown-item>
                    <el-dropdown-item>
                      <a @click="deleteFront(item)">删除</a>
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </div>
            </template>
            <!-- 二级菜单（节） -->
            <el-collapse v-for="(items,ind) of item.children" :key="ind" style="border:0;padding:0 3%;">
              <div v-if="items.chapterType === '1'">
                <el-collapse-item>
                  <template slot="title">
                    <div
                      class="cf chapter_menu_2"
                      style="width:100%;padding: 0;margin:0;background:none;"
                    >
                      <div class="fl">
                        <span class="ml10 course_fz_sty">{{ chapterTitle(items) }}</span>
                      </div>
                      <!-- <div class="fr">
                    <a class="start_learning_btn mr10">开始学习</a>
                  </div>-->
                      <!-- 按钮组 -->
                      <div style="display:inline-block;position:absolute;right: 100px;">
                        <el-tooltip
                          v-if="typeFormat(items) === '节'"
                          content="添加课时"
                          placement="bottom"
                          effect="light"
                        >
                          <svg class="icon" aria-hidden="true" @click="addUnitTask(items)">
                            <use xlink:href="#icon-jia" />
                          </svg>
                        </el-tooltip>
                        <el-dropdown v-if="typeFormat(items) !== '单元'">
                          <svg class="icon" aria-hidden="true">
                            <use xlink:href="#icon-shenglvehao" />
                          </svg>
                          <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item>
                              <a @click="rename(items)">重命名</a>
                            </el-dropdown-item>
                            <el-dropdown-item>
                              <a @click="deleteFront(items)">删除</a>
                            </el-dropdown-item>
                          </el-dropdown-menu>
                        </el-dropdown>
                        <el-dropdown v-if="typeFormat(items) === '单元'">
                          <svg class="icon" aria-hidden="true">
                            <use xlink:href="#icon-shenglvehao" />
                          </svg>
                          <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item>
                              <a @click="publish(items)">{{ publishStatusFormat(items.publishStatus) }}</a>
                            </el-dropdown-item>
                            <el-dropdown-item>
                              <a @click="setOptional(items)">{{ optionalFormat(items.isOptional) }}</a>
                            </el-dropdown-item>
                            <el-dropdown-item>
                              <a @click="deleteFront(items)">删除课时</a>
                            </el-dropdown-item>
                          </el-dropdown-menu>
                        </el-dropdown>
                      </div>
                    </div>
                  </template>
                  <!-- 三级菜单（单元） -->
                  <div v-for="(itemss,inde) in items.children" :key="inde">
                    <el-collapse-item>
                      <template slot="title">
                        <span>{{ chapterTitle(itemss) }}</span>
                        <!-- 按钮组 -->
                        <div style="display:inline-block;position:absolute;left:80%;">
                          <el-dropdown>
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-shenglvehao" />
                            </svg>
                            <el-dropdown-menu slot="dropdown">
                              <el-dropdown-item>
                                <a
                                  @click="publish(itemss)"
                                >{{ publishStatusFormat(items.publishStatus) }}</a>
                              </el-dropdown-item>
                              <el-dropdown-item>
                                <a @click="setOptional(itemss)">{{ optionalFormat(itemss.isOptional) }}</a>
                              </el-dropdown-item>
                              <el-dropdown-item>
                                <a @click="deleteFront(itemss)">删除课时</a>
                              </el-dropdown-item>
                            </el-dropdown-menu>
                          </el-dropdown>
                        </div>
                      </template>
                      <div>
                        <el-row>
                          <el-col :span="3">
                            <div
                              class="settings-item"
                              :class="{ 'active': (itemss.teachingScheme !== null) }"
                            >
                              <a class="js-lesson-create-btn" @click="addTeachingScheme(itemss)">
                                <svg class="icon" aria-hidden="true">
                                  <use xlink:href="#icon-jiaoan" />
                                </svg>&nbsp;
                                <span>教案</span>
                              </a>
                            </div>
                          </el-col>
                          <el-col :span="4">
                            <div
                              class="settings-item"
                              :class="{ 'active': (itemss.prepareTask !== null && itemss.prepareTask.studyTaskType === '1') }"
                            >
                              <a class="js-lesson-create-btn" @click="addPrepareTask(itemss)">
                                <svg class="icon" aria-hidden="true">
                                  <use xlink:href="#icon-yulan1" />
                                </svg>&nbsp;
                                <span>预习</span>
                              </a>
                            </div>
                          </el-col>
                          <el-col :span="3">
                            <div
                              class="settings-item"
                              :class="{ 'active': (itemss.studyTask !== null && itemss.studyTask.studyTaskType === '0') }"
                            >
                              <a class="js-lesson-create-btn" @click="addStudyTask(itemss)">
                                <svg class="icon" aria-hidden="true">
                                  <use xlink:href="#icon-xinbaniconshangchuan-" />
                                </svg>&nbsp;
                                <span>学习</span>
                              </a>
                            </div>
                          </el-col>
                          <el-col :span="4">
                            <div
                              class="settings-item"
                              :class="{ 'active': itemss.homeworkTask !== null }"
                            >
                              <a class="js-lesson-create-btn" @click="addHomeworkTask(itemss)">
                                <svg class="icon" aria-hidden="true">
                                  <use xlink:href="#icon-zuoye" />
                                </svg>&nbsp;
                                <span>作业</span>
                              </a>
                            </div>
                          </el-col>
                          <el-col :span="3">
                            <div class="settings-item" :class="{ 'active': itemss.testTask !== null }">
                              <a class="js-lesson-create-btn" @click="addTestTask(itemss)">
                                <svg class="icon" aria-hidden="true">
                                  <use xlink:href="#icon-ceyan" />
                                </svg>&nbsp;
                                <span>测验</span>
                              </a>
                            </div>
                          </el-col>
                          <el-col :span="4">
                            <div
                              class="settings-item"
                              :class="{ 'active': itemss.experimentTask !== null }"
                            >
                              <a class="js-lesson-create-btn" @click="addExperimentTask(itemss)">
                                <svg class="icon" aria-hidden="true">
                                  <use xlink:href="#icon-shiyani" />
                                </svg>&nbsp;
                                <span>实验</span>
                              </a>
                            </div>
                          </el-col>
                          <el-col :span="3">
                            <div
                              class="settings-item"
                              :class="{ 'active': itemss.courseTopic !== null }"
                            >
                              <a class="js-lesson-create-btn" @click="addCourseTopicTask(itemss)">
                                <svg class="icon" aria-hidden="true">
                                  <use xlink:href="#icon-taolun" />
                                </svg>&nbsp;
                                <span>话题</span>
                              </a>
                            </div>
                          </el-col>
                        </el-row>
                      </div>
                      <div v-if="showTask(itemss)">
                        <!-- 展示任务列表 -->
                        <component
                          :is="state"
                          :dialog="dialog"
                          :course-chapter="courseChapter"
                          :test-marke-key="testMarkeKey"
                          :perusal-visible.sync="perusalVisible"
                          @setTask="setTask"
                          @getTreeBySchemeId="getTreeBySchemeId"
                          @marking="marking"
                        ></component>
                      </div>
                    </el-collapse-item>
                  </div>
                </el-collapse-item>
              </div>
            </el-collapse>
            <!-- 二级菜单（单元） -->
            <el-collapse
              v-for="(items,index) of item.children"
              :key="'unit'+index"
              style="border:0;padding:0 3%;"
            >
              <!-- 二级菜单（节） -->
              <template slot="title">
                <div class="cf chapter_menu_2" style="width:100%;padding: 0;margin:0;background:none;">
                  <div class="fl">
                    <span class="ml10 course_fz_sty">{{ chapterTitle(items) }}</span>
                  </div>
                  <!-- <div class="fr">
                    <a class="start_learning_btn mr10">开始学习</a>
              </div>-->
                  <!-- 按钮组 -->
                  <div style="display:inline-block;position:absolute;left:80%;">
                    <el-tooltip
                      v-if="typeFormat(items) === '节'"
                      content="添加课时"
                      placement="bottom"
                      effect="light"
                    >
                      <svg class="icon" aria-hidden="true" @click="addUnitTask(items)">
                        <use xlink:href="#icon-jia" />
                      </svg>
                    </el-tooltip>
                    <el-dropdown v-if="typeFormat(items) !== '单元'">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-shenglvehao" />
                      </svg>
                      <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item>
                          <a @click="rename(items)">重命名</a>
                        </el-dropdown-item>
                        <el-dropdown-item>
                          <a @click="deleteFront(items)">删除</a>
                        </el-dropdown-item>
                      </el-dropdown-menu>
                    </el-dropdown>
                    <el-dropdown v-if="typeFormat(items) === '单元'">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-shenglvehao" />
                      </svg>
                      <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item>
                          <a @click="publish(items)">{{ publishStatusFormat(items.publishStatus) }}</a>
                        </el-dropdown-item>
                        <el-dropdown-item>
                          <a @click="setOptional(items)">{{ optionalFormat(items.isOptional) }}</a>
                        </el-dropdown-item>
                        <el-dropdown-item>
                          <a @click="deleteFront(items)">删除课时</a>
                        </el-dropdown-item>
                      </el-dropdown-menu>
                    </el-dropdown>
                  </div>
                </div>
              </template>
              <div v-if="items != null && items.chapterType === '2'">
                <!-- 三级菜单（授课任务） -->
                <el-collapse-item>
                  <template slot="title">
                    <span>{{ chapterTitle(items) }}</span>
                    <!-- 按钮组 -->
                    <div style="display:inline-block;position:absolute;left:80%;">
                      <el-dropdown>
                        <svg class="icon" aria-hidden="true">
                          <use xlink:href="#icon-shenglvehao" />
                        </svg>
                        <el-dropdown-menu slot="dropdown">
                          <el-dropdown-item>
                            <a @click="publish(items)">{{ publishStatusFormat(items.publishStatus) }}</a>
                          </el-dropdown-item>
                          <el-dropdown-item>
                            <a @click="setOptional(items)">{{ optionalFormat(items.isOptional) }}</a>
                          </el-dropdown-item>
                          <el-dropdown-item>
                            <a @click="deleteFront(items)">删除课时</a>
                          </el-dropdown-item>
                        </el-dropdown-menu>
                      </el-dropdown>
                    </div>
                  </template>
                  <div>
                    <el-row>
                      <el-col :span="3">
                        <div
                          class="settings-item"
                          :class="{ 'active': (items.teachingScheme !== null) }"
                        >
                          <a class="js-lesson-create-btn" @click="addTeachingScheme(items)">
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-jiaoan" />
                            </svg>&nbsp;
                            <span>教案</span>
                          </a>
                        </div>
                      </el-col>
                      <el-col :span="4">
                        <div
                          class="settings-item"
                          :class="{ 'active': (items.prepareTask !== null && items.prepareTask.studyTaskType === '1') }"
                        >
                          <a class="js-lesson-create-btn" @click="addPrepareTask(items)">
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-yulan1" />
                            </svg>&nbsp;
                            <span>预习</span>
                          </a>
                        </div>
                      </el-col>
                      <el-col :span="3">
                        <div
                          class="settings-item"
                          :class="{ 'active': (items.studyTask !== null && items.studyTask.studyTaskType === '0') }"
                        >
                          <a class="js-lesson-create-btn" @click="addStudyTask(items)">
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-xinbaniconshangchuan-" />
                            </svg>&nbsp;
                            <span>学习</span>
                          </a>
                        </div>
                      </el-col>
                      <el-col :span="4">
                        <div class="settings-item" :class="{ 'active': items.homeworkTask !== null }">
                          <a class="js-lesson-create-btn" @click="addHomeworkTask(items)">
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-zuoye" />
                            </svg>&nbsp;
                            <span>作业</span>
                          </a>
                        </div>
                      </el-col>
                      <el-col :span="3">
                        <div class="settings-item" :class="{ 'active': items.testTask !== null }">
                          <a class="js-lesson-create-btn" @click="addTestTask(items)">
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-ceyan" />
                            </svg>&nbsp;
                            <span>测验</span>
                          </a>
                        </div>
                      </el-col>
                      <el-col :span="4">
                        <div class="settings-item" :class="{ 'active': items.experimentTask !== null }">
                          <a class="js-lesson-create-btn" @click="addExperimentTask(items)">
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-shiyani" />
                            </svg>&nbsp;
                            <span>实验</span>
                          </a>
                        </div>
                      </el-col>
                      <el-col :span="3">
                        <div class="settings-item" :class="{ 'active': items.courseTopic !== null }">
                          <a class="js-lesson-create-btn" @click="addCourseTopicTask(items)">
                            <svg class="icon" aria-hidden="true">
                              <use xlink:href="#icon-taolun" />
                            </svg>&nbsp;
                            <span>话题</span>
                          </a>
                        </div>
                      </el-col>
                    </el-row>
                  </div>
                  <div v-if="showTask(items)">
                    <!-- 展示任务列表 -->
                    <component
                      :is="state"
                      :dialog="dialog"
                      :course-chapter="courseChapter"
                      :test-marke-key="testMarkeKey"
                      :perusal-visible.sync="perusalVisible"
                      @setTask="setTask"
                      @getTreeBySchemeId="getTreeBySchemeId"
                      @marking="marking"
                    ></component>
                  </div>
                </el-collapse-item>
              </div>
            </el-collapse>
          </el-collapse-item>
          <!-- 一级单元 -->
          <el-collapse-item
            v-if="item != null && item.chapterType === '2'"
            style="border:0;padding:0 3%;"
          >
            <template slot="title">
              <span>{{ chapterTitle(item) }}</span>
              <!-- 按钮组 -->
              <div style="display:inline-block;position:absolute;left:80%;">
                <el-dropdown>
                  <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-shenglvehao" />
                  </svg>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>
                      <a @click="publish(item)">{{ publishStatusFormat(item.publishStatus) }}</a>
                    </el-dropdown-item>
                    <el-dropdown-item>
                      <a @click="setOptional(item)">{{ optionalFormat(item.isOptional) }}</a>
                    </el-dropdown-item>
                    <el-dropdown-item>
                      <a @click="deleteFront(item)">删除课时</a>
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </div>
            </template>
            <div>
              <el-row>
                <el-col :span="3">
                  <div class="settings-item">
                    <a class="js-lesson-create-btn" @click="addTeachingScheme(item)">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-jiaoan" />
                      </svg>&nbsp;
                      <span>教案</span>
                    </a>
                  </div>
                </el-col>
                <el-col :span="4">
                  <div class="settings-item">
                    <a class="js-lesson-create-btn" @click="addPrepareTask(item)">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-yulan1" />
                      </svg>&nbsp;
                      <span>预习</span>
                    </a>
                  </div>
                </el-col>
                <el-col :span="3">
                  <div class="settings-item">
                    <a class="js-lesson-create-btn" @click="addStudyTask(item)">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-xinbaniconshangchuan-" />
                      </svg>&nbsp;
                      <span>学习</span>
                    </a>
                  </div>
                </el-col>
                <el-col :span="4">
                  <div class="settings-item">
                    <a class="js-lesson-create-btn" @click="addHomeworkTask(item)">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-zuoye" />
                      </svg>&nbsp;
                      <span>作业</span>
                    </a>
                  </div>
                </el-col>
                <el-col :span="3">
                  <div class="settings-item">
                    <a class="js-lesson-create-btn" @click="addTestTask(item)">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-ceyan" />
                      </svg>&nbsp;
                      <span>测验</span>
                    </a>
                  </div>
                </el-col>
                <el-col :span="4">
                  <div class="settings-item">
                    <a class="js-lesson-create-btn" @click="addExperimentTask(item)">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-shiyani" />
                      </svg>&nbsp;
                      <span>实验</span>
                    </a>
                  </div>
                </el-col>
                <el-col :span="3">
                  <div class="settings-item">
                    <a class="js-lesson-create-btn" @click="addCourseTopicTask(itemss)">
                      <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-taolun" />
                      </svg>&nbsp;
                      <span>话题</span>
                    </a>
                  </div>
                </el-col>
              </el-row>
            </div>
            <div v-if="showTask(item)">
              <!-- 展示任务列表 -->
              <component
                :is="state"
                :dialog="dialog"
                :course-chapter="courseChapter"
                :test-marke-key="testMarkeKey"
                :perusal-visible.sync="perusalVisible"
                @setTask="setTask"
                @getTreeBySchemeId="getTreeBySchemeId"
                @marking="marking"
              ></component>
            </div>
          </el-collapse-item>
        </el-collapse>
        <div v-if="courseChapters.length < 1" class="nodata">
          <p>
            <svg class="icon icon-tishi" aria-hidden="true">
              <use xlink:href="#icon-tishi" />
            </svg>
          </p>
          <p>什么都没有，快去添加一个课时</p>
        </div>

        <!-- 添加或修改授课任务弹出框 -->
        <edit-unit
          ref="dialog"
          :form="courseUnit"
          :course-scheme="courseScheme"
          :dialog="unitdialog"
          @getTreeBySchemeId="getTreeBySchemeId"
        />

        <!-- 教案列表弹出框 -->
        <teaching-chapter
          :form="teachingScheme"
          :course-scheme="courseScheme"
          :teacherdialog="teacherdialog"
          @getTreeBySchemeId="getTreeBySchemeId"
        />
      </div>
    </div>
    <div v-if="markingKey">
      <markingList
        :exam-log="examLog"
        :exam-status-type-dict="examStatusTypeDict"
      ></markingList>
    </div>
    <!--作业批阅列表-->
    <PersualList v-if="perusalVisible" :persual-task="persualTask" :perusal-visible="perusalVisible" @goback="goback"></PersualList>
  </div>
</template>
<script>
// import prepareStudyTaskApi from '@/api/course/courseTask/prepareStudyTask'
import ExperTasks from './task-list/ExperTasks'
import TestTasks from './task-list/TestTasks'
import HomeworkTasks from './task-list/HomeworkTasks'
import EditUnit from './EditUnit'
import CourseTopicTasks from './task-list/CourseTopicTasks'
import PrepareStudyTasks from './task-list/PrepareStudyTasks'
import TeachingChapter from './task-chapter/TeachingChapter'
import courseChapterApi from '@/api/course/courseManage/courseChapter'
import COURSE_CONST from '@/constant/course-const'
import markingList from './components/markingList'
import EXAMBANK_CONST from '@/constant/exambank-const'
import testTaskApi from '@/api/course/courseTask/testTask.js'
import PersualList from './components/perusal/index'
export default {
  name: 'Catalog',
  components: {
    TeachingChapter,
    EditUnit,
    CourseTopicTasks,
    PrepareStudyTasks,
    HomeworkTasks,
    ExperTasks,
    TestTasks,
    markingList,
    PersualList
  },
  props: {
    schemeId: {
      type: Number,
      required: true
    },
    courseScheme: {
      type: Object,
      required: true
    },
    testMarkeKey: {
      type: Boolean,
      required: true
    },
    chapterMain: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      state: '',
      showContent1: -1,
      showContent2: -1,
      showContent3: -1,
      form: {},
      courseUnit: {},
      courseChapter: {},
      courseChapters: [],
      courseChapterType: [],
      loading: true,
      // 弹出框
      unitdialog: {
        title: '',
        show: false
      },
      // 弹出框
      dialog: {
        title: '',
        show: false
      },
      // 弹出框
      preparestudydialog: {
        title: '',
        show: false
      },
      // 弹出框
      experdialog: {
        title: '',
        show: false
      },
      // 弹出框
      homedialog: {
        title: '',
        show: false
      },
      // 弹出框
      teacherdialog: {
        title: '',
        show: false
      },
      // 弹出框
      testdialog: {
        title: '',
        show: false
      },
      // 弹出框
      topicdialog: {
        title: '',
        show: false
      },
      // 待批阅任务
      persualTask: {},
      homeworkTask: {
        hwtId: -1,
        csId: null,
        ctId: null,
        schemeId: null,
        unitId: null,
        hwTitle: '',
        hwId: null,
        hwArrange: {
          hwId: null,
          hwtitle: '',
          hwdemand: '',
          hwobject: null,
          startTime: null,
          hwEndTime: null,
          isallowdelay: false,
          delaytime: null,
          delFlag: false
        },
        evaluationMethod: '1',
        conditionSet: '{}',
        createOrgId: null,
        orgId: null,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        questionlist: []
      },
      studyTask: {
        pstId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        seq: 1,
        studyTaskType: '0',
        psTitle: null,
        startTime: null,
        endTime: null,
        textMaterials: null,
        textScore: null,
        pptMaterials: [],
        videoMaterials: [],
        audioMaterials: [],
        refMaterials: [],
        finishedMaterials: 0,
        totalMaterials: 0,
        isFinished: 0,
        textCondition: null,
        refPstId: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null,
        chapterId: null
      },
      prepareTask: {
        pstId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        seq: 1,
        studyTaskType: '1',
        psTitle: null,
        startTime: null,
        endTime: null,
        textMaterials: null,
        textScore: null,
        pptMaterials: [],
        videoMaterials: [],
        audioMaterials: [],
        refMaterials: [],
        finishedMaterials: 0,
        totalMaterials: 0,
        isFinished: 0,
        textCondition: null,
        refPstId: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null,
        chapterId: null
      },
      teachingScheme: {
        tsId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        teachingType: '0',
        teachingDate: '',
        teachingTime: null,
        objectAnalyse: null,
        teachingGoals: null,
        teachingRequired: null,
        keyDifficultPoints: null,
        teachingIdeas: null,
        discussionHomework: null,
        teachingReferences: '',
        teachingContent: '',
        teachingMethod: '',
        refTsId: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        chapterId: null
      },
      // 是否显示作业待批阅的列表
      perusalVisible: false,
      main: true,
      markingKey: false,
      examStatusTypeDict: [],
      // 考试记录对象
      examLog: {
        roundId: null,
        examType: EXAMBANK_CONST.TEST
      },
      REVIEWING: COURSE_CONST.REVIEWING
    }
  },
  watch: {
    testMarkeKey: function(val) {
      if (!val) {
        this.markingToMain()
      }
    }
  },
  created() {
    // 课程章节类型数据字典获取
    this.getDataByType('course_chapter_type').then(response => {
      this.courseChapterType = response.data
    })
    this.getTreeBySchemeId()
  },
  methods: {
    markingToMain() {
      this.markingKey = false
      this.main = true
    },
    marking(test) {
      if (test.examStatus === this.REVIEWING) {
        this.examLog.roundId = test.examArrangeId
        this.main = false
        this.markingKey = true
        this.$emit('testMarke')
      } else {
        test.examStatus = this.REVIEWING
        testTaskApi.update(test).then(resp => {
          if (resp.code === 0) {
            this.examLog.roundId = test.examArrangeId
            this.main = false
            this.markingKey = true
            this.$emit('testMarke')
          }
        })
      }
    },
    // 渲染任务
    getTask(task) {
      if (task.prepareTask !== null) {
        return '预习任务：' + task.prepareTask.psTitle
      } else if (task.studyTask !== null) {
        return '学习任务：' + task.studyTask.psTitle
      } else if (task.homeworkTask !== null) {
        return '作业任务：' + task.homeworkTask.hwTitle
      } else if (task.testTask !== null) {
        return '测验任务' + task.testTask.examTitle
      } else if (task.experimentTask !== null) {
        return '实验任务：' + task.experimentTask.experTitle
      }
    },
    showTask(chapter) {
      // console.log('courseChapter.chapterId = ', this.courseChapter.chapterId)
      // console.log('chapter.chapterId = ', chapter.chapterId)
      if (this.courseChapter.chapterId === chapter.chapterId) {
        // console.log('---------> ', this.courseChapter.chapterId === chapter.chapterId)
        return true
      } else {
        return false
      }
    },
    // 添加课时
    addUnitTask(item) {
      this.resetUnit()
      // console.log('item.chapterId ==== ', item.chapterId)
      if (item != null && item !== undefined) {
        this.courseUnit.chapterId = item.chapterId
      }
      this.unitdialog.title = '添加课时'
      this.unitdialog.show = true
    },
    resetUnit() {
      this.courseUnit = {
        unitId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        chapterId: '',
        seq: '',
        unitTitle: '',
        isFree: false,
        isCompulsory: false,
        unitStatus: '',
        refUnitId: '',
        unitPrice: '',
        isBuyable: false,
        isLocked: false,
        buyCount: '',
        watchLimit: '',
        delFlag: false,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        courseTitle: '',
        courseTerm: '',
        schemeTitle: '',
        chapterTitle: '',
        createTime: '',
        remark: ''
      }
    },
    // 添加/编辑作业任务
    addHomeworkTask(courseChapter) {
      this.courseChapter = { ...courseChapter }
      this.courseChapter.unitId = courseChapter.sourceUnitId
      this.state = this.state === 'HomeworkTasks' ? '' : 'HomeworkTasks'
      this.dialog.title = '作业任务列表'
      this.dialog.show = true
    },
    // 添加/编辑教案任务
    addTeachingScheme(courseChapter) {
      const teachingScheme = courseChapter.teachingScheme
      this.resetTeachingScheme()
      if (teachingScheme != null && teachingScheme.tsId != null && teachingScheme.tsId > 0) {
        this.teachingScheme = { ...teachingScheme }
        this.teacherdialog.title = '修改教案任务'
      } else {
        this.teacherdialog.title = '添加教案任务'
      }
      this.teachingScheme.unitId = courseChapter.sourceUnitId
      this.teacherdialog.show = true
    },
    // 添加/编辑实验任务
    addExperimentTask(courseChapter) {
      this.courseChapter = { ...courseChapter }
      this.state = this.state === 'ExperTasks' ? '' : 'ExperTasks'
      this.dialog.title = '实验任务列表'
      this.dialog.show = true
    },
    // 添加/编辑预习任务
    addPrepareTask(courseChapter) {
      this.courseChapter = { ...courseChapter }
      this.state = this.state === 'PrepareStudyTasks' ? '' : 'PrepareStudyTasks'
      this.dialog.title = '预习任务列表'
      this.dialog.show = true
    },
    // 话题讨论发布任务
    addCourseTopicTask(courseChapter) {
      this.courseChapter = { ...courseChapter }
      this.state = this.state === 'CourseTopicTasks' ? '' : 'CourseTopicTasks'
      this.dialog.title = '话题任务列表'
      this.dialog.show = true
    },
    resetHomeworkTask() {
      this.homeworkTask = {
        hwtId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        hwTitle: '',
        hwId: null,
        hwArrange: {
          hwId: null,
          hwtitle: '',
          hwdemand: '',
          hwobject: null,
          startTime: null,
          hwEndTime: null,
          isallowdelay: false,
          delaytime: null,
          delFlag: false
        },
        evaluationMethod: '1',
        conditionSet: '{}',
        createOrgId: null,
        orgId: null,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        questionlist: []
      }
    },
    // 添加/编辑学习任务
    addStudyTask(courseChapter) {
      this.courseChapter = { ...courseChapter }
      console.log('this.courseChapter = ', this.courseChapter)
      this.state = this.state === 'PrepareStudyTasks' ? '' : 'PrepareStudyTasks'
      this.dialog.title = '学习任务列表'
      this.dialog.show = true
    },
    /**
     * 编辑添加测验任务
     */
    addTestTask(courseChapter) {
      this.courseChapter = { ...courseChapter }
      this.state = this.state === 'TestTasks' ? '' : 'TestTasks'
      this.dialog.title = '测验任务列表'
      this.dialog.show = true
    },
    // 删除
    deleteFront(row) {
      this.$confirm('是否确认删除名称为"' + row.chapterTitle + '"的课程章节项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return courseChapterApi.deleteFront(row.chapterId)
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getTreeBySchemeId()
        })
        .catch(function() {})
    },
    // 设置选修/必修
    setOptional(courseChapter) {
      courseChapter.isOptional = !courseChapter.isOptional
      courseChapterApi.updateCourseChapter(courseChapter).then(response => {
        if (response.code === 0) {
          this.$message({
            message: '发布成功',
            type: 'success'
          })
          this.getTreeBySchemeId()
        } else {
          this.$message.error('发布失败')
        }
      })
    },
    // 发布/未发布课时
    publish(courseChapter) {
      courseChapter.publishStatus = courseChapter.publishStatus === '1' ? '0' : '1'
      courseChapterApi.updateCourseChapter(courseChapter).then(response => {
        if (response.code === 0) {
          this.$message({
            message: '发布成功',
            type: 'success'
          })
          this.getTreeBySchemeId()
        } else {
          this.$message.error('发布失败')
        }
      })
    },
    // 重命名
    rename(courseChapter) {
      const type = this.getChineseType(courseChapter.chapterType)
      // console.log('rename---type = ', type)
      this.$prompt('标题', '重命名' + type, {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value.length > 50 || value.length < 1) {
          this.$message({
            type: 'warning',
            message: '标题字符不得超过50个或低于1个'
          })
          return
        }
        // 在章节表末尾添加一章或节
        courseChapter.chapterTitle = value
        courseChapterApi.updateCourseChapter(courseChapter).then(response => {
          if (response.code === 0) {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
            this.getTreeBySchemeId()
          } else {
            this.$message.error('保存失败')
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消输入'
        })
      })
    },
    // 添加节
    addSection(item) {
      this.$prompt('标题', '创建节', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value.length > 50 || value.length < 1) {
          this.$message({
            type: 'warning',
            message: '标题字符不得超过50个或低于1个'
          })
          return
        }
        // 在章节表末尾添加一章或节
        this.courseChapter.schemeId = this.courseScheme.schemeId
        this.courseChapter.parentId = item.chapterId
        this.courseChapter.orgId = this.courseScheme.orgId
        this.courseChapter.csId = this.courseScheme.csId
        this.courseChapter.ctId = this.courseScheme.ctId
        this.courseChapter.chapterTitle = value
        this.courseChapter.chapterType = this.getType('节')
        courseChapterApi.addChapter(this.courseChapter).then(response => {
          if (response.code === 0) {
            this.$message({
              message: '添加成功',
              type: 'success'
            })
            this.getTreeBySchemeId()
          } else {
            this.$message.error('添加失败')
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消输入'
        })
      })
    },
    // 章节类型，0：章、1：节，:2：单元
    getType(type) {
      if (type === '章') {
        return '0'
      } else if (type === '节') {
        return '1'
      } else if (type === '单元') {
        return '2'
      }
    },
    // 章节类型，0：章、1：节，:2：单元
    getChineseType(type) {
      if (type === '0') {
        return '章'
      } else if (type === '1') {
        return '节'
      } else if (type === '2') {
        return '单元'
      }
    },
    // 关闭作业批阅
    goback() {
      this.perusalVisible = false
      this.$emit('update:chapterMain', true)
    },
    resetTeachingScheme() {
      this.teachingScheme = {
        tsId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        teachingType: '0',
        teachingDate: '',
        teachingTime: null,
        objectAnalyse: null,
        teachingGoals: null,
        teachingRequired: null,
        keyDifficultPoints: null,
        teachingIdeas: null,
        discussionHomework: null,
        teachingReferences: '',
        teachingContent: '',
        teachingMethod: '',
        refTsId: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        chapterId: null
      }
    },
    resetExperimentTask() {
      this.form = {
        experId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: '',
        experTitle: '',
        requirement: '',
        labManual: '',
        labTaskObject: null,
        reportTemplate: '',
        experStartTime: '',
        experEndTime: '',
        reportDeadlineTime: '',
        isAllowDelay: '',
        delayTime: '',
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createTime: '',
        updateTime: '',
        createBy: '',
        updateBy: '',
        remark: '',
        chapterId: null
      }
    },
    resetPrepareTask() {
      this.form = {
        pstId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        seq: 1,
        studyTaskType: '1',
        psTitle: null,
        startTime: null,
        endTime: null,
        textMaterials: null,
        textScore: null,
        pptMaterials: [],
        videoMaterials: [],
        audioMaterials: [],
        refMaterials: [],
        finishedMaterials: 0,
        totalMaterials: 0,
        isFinished: 0,
        textCondition: null,
        refPstId: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null,
        chapterId: null
      }
    },
    resetStudyTask() {
      this.form = {
        pstId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        seq: 1,
        studyTaskType: '0',
        psTitle: null,
        startTime: null,
        endTime: null,
        textMaterials: null,
        textScore: null,
        pptMaterials: [],
        videoMaterials: [],
        audioMaterials: [],
        refMaterials: [],
        finishedMaterials: 0,
        totalMaterials: 0,
        isFinished: 0,
        textCondition: null,
        refPstId: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null,
        chapterId: null
      }
    },
    /** 打开批阅列表 */
    setTask(persualTask) {
      this.$emit('update:chapterMain', false)
      this.perusalVisible = true
      this.persualTask = persualTask
    },
    resetTestTask() {
      this.form = {
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: '',
        examArrangeId: '',
        examStatus: COURSE_CONST.NOTSTART,
        requireCredit: '',
        redoInterval: '',
        limitTime: '',
        ttaskId: -1,
        testType: '',
        orgId: this.courseScheme.orgId,
        examTitle: '',
        beginTime: '',
        endTime: '',
        createOrgId: '',
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        chapterId: null,
        remark: ''
      }
    },

    /** 课程章节名称 */
    chapterTitle(row) {
      return '第' + row.chapterSeq + this.typeFormat(row) + ' ' + row.chapterTitle
    },
    /** 字典类型字典翻译 */
    typeFormat(row) {
      return this.selectDictLabel(this.courseChapterType, row.chapterType)
    },
    // 选修/必修状态设置
    optionalFormat(isOptional) {
      if (isOptional) {
        return '设置必修'
      } else {
        return '设置选修'
      }
    },
    // 发布状态的翻译
    publishStatusFormat(publishStatus) {
      if (publishStatus === '0') {
        return '发布课时'
      } else if (publishStatus === '1') {
        return '取消发布'
      } else if (publishStatus === '2') {
        return '已关闭'
      }
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.getTreeBySchemeId(val)
    },
    getTreeBySchemeId() {
      this.loading = true
      // 获取章节列表
      courseChapterApi.getFrontlist(this.courseScheme.schemeId).then(response => {
        this.courseChapters = response.data
        this.loading = false
        // this.$emit('getTotal', this.courseScheme.lessonCount)
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.js-lesson-create-btn {
  color: #616161;
}
span {
  font-size: 14px;
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
body {
  font-size: 14px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 14px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.icon {
  width: 1.5em;
  height: 1.5em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
.active > a {
  color: #e50112;
}
// .chapter_menu_3 {
//   .is-active {
//     height: 64px !important;
//   }
// }
.el-collapse-item__content {
  .el-row {
    padding-left: 20px;
  }
}
.settings-item {
  display: inline-block;
  padding: 2px 8px;
}
.settings-item:hover {
  background: #e6e6e6;
  // padding: 10px;
  border-radius: 3px;
}
.icon {
  width: 1.15em;
  height: 1.15em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
.task-manage-list .settings-list .settings-item > a {
  color: #919191;
  line-height: 58px;
}
.task-manage-list .settings-list .settings-item {
  float: left;
  width: 20%;
  text-align: center;
}
.task-manage-list .settings-list .settings-item {
  float: left;
  width: 20%;
  text-align: center;
}
.course-button {
  margin-right: -18rem;
  // width: 20rem;
  display: inline-block;
}
.icon {
  width: 1.5em;
  height: 1.5em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  // color: #e50112;
}
/* 分页 */
.el-pager li.active {
  color: #e50112;
}
.el-pager li:hover {
  color: #e50112;
}
.el-pagination button,
.el-pagination span:hover {
  color: #e50112;
}
.el-dropdown {
  .icon {
    height: 1em;
  }
}
</style>
