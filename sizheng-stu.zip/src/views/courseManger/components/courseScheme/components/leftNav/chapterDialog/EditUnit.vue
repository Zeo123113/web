<!--
@description 授课单元添加/编辑
@author cgy
-->
<template>
  <el-dialog
    :close-on-click-modal="false"
    :title="dialog.title"
    :visible.sync="dialog.show"
    width="60%"
    @open="openDialog()"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row>
        <!-- <el-col :span="12">
          <el-form-item label="引用课程单元" prop="refUnitId" :label-width="labelWidth">
            <el-select
              v-model="form.refUnitId"
              placeholder="请选择引用课程单元"
              clearable
              @change="getRefUnit"
            >
              <el-option
                v-for="courseUnit in courseUnitOptions"
                :key="courseUnit.unitId"
                :label="courseUnit.unitTitle"
                :value="courseUnit.unitId"
              />
            </el-select>
          </el-form-item>
        </el-col> -->
        <el-col :span="12">
          <el-form-item label="单元标题" prop="unitTitle">
            <el-input
              v-model="form.unitTitle"
              placeholder="请输入单元标题"
              clearable
              style="width:217px;"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否免费" prop="isFree">
            <el-switch v-model="form.isFree"></el-switch>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item v-if="!form.isFree" label="是否允许购买" prop="isBuyable">
            <el-switch v-model="form.isBuyable"></el-switch>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否上锁" prop="isLocked">
            <el-switch v-model="form.isLocked"></el-switch>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item
            v-if="form.isBuyable && !form.isFree"
            label="课程单元价格"
            prop="unitPrice"
            :label-width="labelWidth"
          >
            <el-input
              v-model="form.unitPrice"
              placeholder="请输入课程单元价格"
              clearable
              style="width:217px;"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item v-if="form.isBuyable && !form.isFree" label="课程总购买人数" prop="buyCount">
            <el-input-number v-model="form.buyCount" controls-position="right" :min="0" :max="10" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="观看次数限制" prop="watchLimit">
            <el-input-number
              v-model="form.watchLimit"
              controls-position="right"
              :min="0"
              :max="10"
            />
          </el-form-item>
        </el-col>
        <el-col :span="23">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入备注"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit">保存</el-button>
      <el-button size="small" @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import courseUnitApi from '@/api/course/courseManage/courseUnit'
// import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
// import USER_CONST from '@/constant/user-const'
export default {
  name: 'EditDialog',
  components: {
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      courseUnitOptions: [],
      labelWidth: '120px',
      // 表单校验
      rules: {
        unitTitle: [
          { required: true, message: '单元标题不能为空', trigger: 'blur' },
          { min: 3, max: 50, message: '长度在 3 到 50 个字符', trigger: 'blur' }
        ],
        unitPrice: [
          { pattern: /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/, message: '请输入正确的价格', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    openDialog() {
      this.getRefUnit(this.form.schemeId)
    },
    /** 引用课程单元变化时触发，获得引用单元 */
    getRefUnit(value) {
      // 没有章节时候，从教学方案中获得课程单元
      if (value !== null && value !== '' && value !== undefined) {
        courseUnitApi.getRefUnitBySchemeId(value).then(response => {
          this.courseUnitOptions = response.data
        })
      } else {
        return
      }
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
      // 刷新页面
      this.$emit('getTreeBySchemeId')
    },
    /** 提交按钮 */
    submit: function() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          // console.log('this.form = ', this.form)
          if (this.dialog.title === '添加课时') {
            courseUnitApi
              .addFrontByChapterId(this.form)
              .then(result => {
                this.dialog.show = false
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
                // 关闭弹窗
                this.close()
              })
              .catch(err => {
                console.log(err)
              })
          } else if (this.dialog.title === '修改课时') {
            courseUnitApi
              .updatecourseUnit(this.form)
              .then(result => {
                // console.log('result', result)
                this.dialog.show = false
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                // 关闭弹窗
                this.close()
              })
              .catch(err => {
                console.log(err)
              })
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
