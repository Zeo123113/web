<!--
@description 试卷管理编辑显示试题列表
@author cpy
-->
<template>
  <div>
    <el-table
      ref="dragTable"
      :data="questionlist"
      border
      default-expand-all
      tooltip-effect="light"
      style="width: 100%"
      row-key="groupSeq"
      :tree-props="{children: 'materialQuestions'}"
    >
      >
      <el-table-column prop="groupSeq" label="序号" align="center" min-width="70"></el-table-column>
      <el-table-column
        prop="tqTypeId"
        label="试题类型"
        align="center"
        :formatter="tqTypeFormatter"
        min-width="100"
      ></el-table-column>
      <el-table-column
        prop="title"
        label="题目"
        align="center"
        show-overflow-tooltip
        min-width="180"
      ></el-table-column>
      <el-table-column prop="value" label="分值" align="center" min-width="120">
        <template slot-scope="scope">
          <el-input-number
            v-model="questionlist[scope.$index].value"
            :disabled="scope.row.tqTypeId==MATERIAL"
            :precision="1"
            :step="0.5"
            :max="10"
            placeholder="请输入内容"
          ></el-input-number>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" min-width="50">
        <template slot-scope="scope">
          <el-button
            :disabled="scope.row.seq != null"
            type="text"
            size="small"
            @click="deleteQuestion(scope.row)"
          >移除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
import Sortable from 'sortablejs'
export default {
  name: 'QuestionList',
  props: {
    questionlist: {
      type: Array,
      default: null
    },
    questionTypeOptions: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      // 试题类型常量定义
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      MATERIAL: EXAMBANK_CONST.MATERIAL,
      PROG_FILLBLANK: EXAMBANK_CONST.PROG_FILLBLANK,

      // 填空题进行转换的中间使用变量
      content: [],
      options: [],
      // 加载
      loading: false,
      // 存在的试题类型
      questionOptions: [],
      // 试题序号
      tqSeq: 1,
      // 新列表
      newList: [],
      // 旧列表
      oldList: [],
      sortable: null
    }
  },
  created() {
    this.openDialog()
  },
  methods: {
    // 试题类型翻译
    tqTypeFormatter(row) {
      return this.selectDictLabel(this.questionTypeOptions, row.tqTypeId.toString())
    },
    openDialog() {
      this.$nextTick(() => {
        this.oldList = this.questionlist.map(v => v.tqSeq)
        this.newList = this.oldList.slice()
        this.$nextTick(() => {
          this.setSort()
        })
      })
    },
    setSort() {
      const el = this.$refs.dragTable.$el.querySelectorAll('.el-table__body-wrapper > table > tbody')[0]
      this.sortable = Sortable.create(el, {
        ghostClass: 'sortable-ghost', // Class name for the drop placeholder,
        setData: function(dataTransfer) {
          // to avoid Firefox bug
          // Detail see : https://github.com/RubaXa/Sortable/issues/1012
          dataTransfer.setData('Text', '')
        },
        onEnd: evt => {
          if (this.questionlist[evt.oldIndex].tqTypeId !== this.questionlist[evt.newIndex].tqTypeId) {
            this.$message({
              message: '对不起，只能在相同类型的试题中移动！',
              type: 'error'
            })
            const seq = this.questionlist[evt.oldIndex].groupSeq
            this.questionlist[evt.oldIndex].groupSeq = this.questionlist[evt.newIndex].groupSeq
            this.questionlist[evt.newIndex].groupSeq = seq
            return
          } else {
            const targetRow = this.questionlist.splice(evt.oldIndex, 1)[0]
            this.questionlist.splice(evt.newIndex, 0, targetRow)
            const seq = this.questionlist[evt.oldIndex].tqSeq
            this.questionlist[evt.oldIndex].tqSeq = this.questionlist[evt.newIndex].tqSeq
            this.questionlist[evt.newIndex].tqSeq = seq
            // for show the changes, you can delete in you code
            const tempIndex = this.newList.splice(evt.oldIndex, 1)[0]
            this.newList.splice(evt.newIndex, 0, tempIndex)
          }
        }
      })
    },
    // 移除选择项
    deleteQuestion(paperItem) {
      if (this.questionlist.length <= 1) {
        this.$message({
          message: '试卷的试题数必须大于1',
          type: 'error'
        })
      } else {
        this.questionlist.splice(paperItem.tqSeq - 1, 1)
      }
    },
    // 外部嵌套div
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    // 将内容转化为字符串数组
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    },
    // 清空试题列表
    resetQuestionList() {
      this.questionlist = []
      this.questionOptions = []
    }
  }
}
</script>
<style lang="scss" scoped>
.QuestionItem {
  border: 1px solid #e3e3e3;
  padding: 20px;
  margin-bottom: 15px;
}
.el-collapse-item__header {
  color: #606266;
}
.el-collapse {
  border: 0px;
}
.el-button--text[data-v-6bb6c0b9] {
  border-color: transparent;
  color: #999;
  padding: 0px;
  border-radius: 100%;
}
.el-collapse-item {
  .el-collapse-item__wrap {
    margin-left: 50px;
    border: 0px;
  }
}
.content {
  margin-left: 2em;
  p {
    padding: 0;
    margin: 0;
    -webkit-margin-before: 0em;
    -webkit-margin-after: 0em;
    -webkit-margin-start: 0px;
    -webkit-margin-end: 0px;
    span {
      font-size: 14px !important;
      font-family: 'Microsoft YaHei';
    }
  }
  span {
    font-family: 'Microsoft YaHei';
    font-size: 14px !important;
  }
}
</style>
<style scoped>
.el-collapse-item__header {
  border: 0px !important;
}
.el-dialog__wrapper /deep/ .el-dialog /deep/ .el-dialog__body {
  height: 80vh;
  overflow-y: auto;
}
.el-dialog__wrapper >>> .el-dialog {
    margin-bottom: 0px;
}
</style>
