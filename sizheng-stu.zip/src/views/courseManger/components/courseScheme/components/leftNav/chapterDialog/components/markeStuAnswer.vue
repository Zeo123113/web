<template>
  <el-dialog
    :visible.sync="dialogObject.show"
    width="80%"
    :title="paper.paperTitle"
    center
    @open="open"
    @close="close"
  >
    <div v-loading="loading">
      <div class="re" style="border-top: 15px solid #f8f8f8;">
        <div style=" margin-left: 120px;margin-right: 120px;">
          <div class="tac">
            <img src="images/ico_title_1.jpg" alt />
          </div>

          <div class>
            <!--单选题-->
            <div v-if="selectBankList.list.length>0" class="mt15 mb20">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_1"></i>
                <span class="ml20 fz20 fwb vm">单选题</span>
                <span class="ml20 fz15 vm">共{{ selectBankList.list.length }}题 共{{ selectBankList.value }}分</span>
              </div>
              <!--题目-->
              <div v-for="(item,index) of selectBankList.list" :key="index">
                <div
                  :id="'bank'+item.tqId"
                  :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                  style="padding: 0; "
                >
                  <div class="pa25">
                    <div class="cf">
                      <div class="mr25 fl">
                        <div class>
                          <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                      </div>
                      <div class="ov">
                        <p class="mt5 lh24">
                          <span class="fz16 fwb">{{ item.content }}</span>
                        </p>
                        <!--选项-->
                        <div class="mt10">
                          <div v-for="(item1,index1) of item.options" :key="index1">
                            <p class="fz15 lh38 cor_2">{{ item1.value }}:{{ item1.label }}</p>
                          </div>
                        </div>
                        <!--正确答案-->
                        <div class="mt20 re cf" style="padding-right: 105px;">
                          <div v-if="item.pdId!==null" class="fz15 cor_2">
                            <span class>
                              正确答案是
                              <em class="cor_00c">{{ item.answer }}</em>
                            </span>
                            <span class="ml15">
                              学生答案是
                              <em
                                class="cor_00c"
                                :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                              >{{ item.userAnswer }}</em>
                            </span>
                            <span class="ml15">
                              学生得分
                              <em
                                class="cor_00c"
                              >{{ item.score }} </em>分
                            </span>
                            <span class="ml15">
                              评分者
                              <em>{{ item.grader }}</em>
                            </span>
                            <br />
                            <div class="mt20">
                              <span>
                                修正得分
                                <em
                                  class="cor_00c"
                                >{{ item.reviseScore }} </em>分
                              </span>
                              <span class="ml15">
                                修正者
                                <em
                                  class="cor_00c"
                                >{{ item.reviser }} </em>
                              </span>
                            </div>
                          </div>
                          <div v-else class="fz15 cor_2">
                            <span class>
                              <em class="cor_00c" style="color:#E20312">学生未提交</em>
                            </span>
                          </div>
                          <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                            教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">评阅</el-button>
                          </div>
                          <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                            修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMarking(item)">修改</el-button>
                            <br />
                            修正原因:<el-input
                              v-model="item.reviseReason"
                              type="textarea"
                              :rows="3"
                              placeholder="请输入内容"
                              class="mt10"
                            >
                            </el-input>
                          </div>
                          <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                            <span
                              class="analysis_fz_sty fz15 cor_2 vm"
                            >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                            <i class="ml10 ico_arrow_rotate"></i>
                          </a>
                        </div>
                      <!--正确答案-->
                      </div>
                    </div>
                  </div>
                  <!--pa25-->
                  <!--解析-->
                  <div class="analysis_area_b">
                    <div class="mr25 fl vh">
                      <div class>
                        <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共2分</p>
                    </div>
                    <div class="ov">
                      <p class="fz16 fwb">解析：</p>
                      <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                    </div>
                  </div>
                <!--解析-->
                </div>
              </div>
            </div>
            <!--单选题-->

            <!--多选题-->
            <div v-if="multselectBankList.list.length>0" class="mt15">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_2"></i>
                <span class="ml20 fz20 fwb vm">多选题</span>
                <span class="ml20 fz15 vm">共{{ multselectBankList.list.length }}题 共{{ multselectBankList.value }}分</span>
              </div>
              <!--题目-->
              <div v-for="(item,index) of multselectBankList.list" :key="index">
                <div
                  :id="'bank'+item.tqId"
                  :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                  style="padding: 0;"
                >
                  <div class="pa25">
                    <div class="cf">
                      <div class="mr25 fl">
                        <div class>
                          <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                      </div>
                      <div class="ov">
                        <p class="mt5 lh24">
                          <span class="fz16 fwb">{{ item.content }}</span>
                        <!-- <span class="ml15 state_bg_sty_2">待查</span> -->
                        </p>
                        <!--选项-->
                        <div class="mt10">
                          <div v-for="(item1,index1) of item.options" :key="index1">
                            <p class="fz15 lh38 cor_2">{{ item1.value }}:{{ item1.label }}</p>
                          </div>
                        </div>
                        <!--正确答案-->
                        <div class="mt20 re cf" style="padding-right: 105px;">
                          <div v-if="item.pdId!==null" class="fz15 cor_2">
                            <span class>
                              正确答案是
                              <em class="cor_00c">{{ item.answer }}</em>
                            </span>
                            <span class="ml15">
                              学生答案是
                              <em
                                class="cor_00c"
                                :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                              >{{ item.userAnswer }}</em>
                            </span>
                            <span class="ml15">
                              学生得分
                              <em
                                class="cor_00c"
                              >{{ item.score }} </em>分
                            </span>
                            <span class="ml15">
                              评分者
                              <em>{{ item.grader }}</em>
                            </span>
                            <br />
                            <div class="mt20">
                              <span>
                                修正得分
                                <em
                                  class="cor_00c"
                                >{{ item.reviseScore }} </em>分
                              </span>
                              <span class="ml15">
                                修正者
                                <em
                                  class="cor_00c"
                                >{{ item.reviser }} </em>
                              </span>
                            </div>
                          </div>
                          <div v-else class="fz15 cor_2">
                            <span class>
                              <em class="cor_00c" style="color:#E20312">学生未提交</em>
                            </span>
                          </div>
                          <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                            教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">评阅</el-button>
                          </div>
                          <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                            修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMarking(item)">修改</el-button>
                            <br />
                            修正原因:<el-input
                              v-model="item.reviseReason"
                              type="textarea"
                              :rows="3"
                              placeholder="请输入内容"
                              class="mt10"
                            >
                            </el-input>
                          </div>
                          <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                            <span
                              class="analysis_fz_sty fz15 cor_2 vm"
                            >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                            <i class="ml10 ico_arrow_rotate"></i>
                          </a>
                        </div>
                      <!--正确答案-->
                      </div>
                    </div>
                  </div>
                  <!--解析-->
                  <div class="analysis_area_b cf">
                    <div class="mr25 fl vh">
                      <div class>
                        <i class="ico_subject_num">1</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共2分</p>
                    </div>
                    <div class="ov">
                      <p class="fz16 fwb">解析：</p>
                      <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                    </div>
                  </div>
                <!--解析-->
                </div>
              </div>
            </div>
            <!--多选题-->

            <!--问答题-->
            <div v-if="questanswerBankList.list.length>0" class="mt15">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_3"></i>
                <span class="ml20 fz20 fwb vm">问答题</span>
                <span class="ml20 fz15 vm">共{{ questanswerBankList.list.length }}题 共{{ questanswerBankList.value }}分</span>
              </div>
              <!--题目-->
              <div v-for="(item,index) of questanswerBankList.list" :key="index">
                <div :id="'bank'+item.tqId" :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']">
                  <div class="cf">
                    <div class="mr25 fl">
                      <div class>
                        <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                    </div>
                    <div class="ov">
                      <p class="mt5 lh24">
                        <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                      <!-- <span class="ml15 state_bg_sty_2">待查</span> -->
                      </p>
                      <!--内容-->
                      <div class="mt20 re cf" style="padding-right: 105px;">
                        <div class="cor_1 fz16 mt25">正确答案：</div>
                        <div class=" b2 pa20">
                          <p class="fz16 lh24 cor_1"> {{ item.answer }}</p>
                        </div>
                        <div class="cor_1 fz16 mt25">学生答案：</div>
                        <div class=" b2 pa20">
                          <p class="fz16 lh24 cor_1" v-html="item.userAnswer"></p>
                        </div>
                        <div v-if="item.pdId!==null" class="fz15 cor_2 mt20">
                          <span class="">
                            学生得分
                            <em
                              class="cor_00c"
                            >{{ item.score }} </em>分
                          </span>
                          <span class="ml15">
                            评分者
                            <em>{{ item.grader }}</em>
                          </span>
                          <br />
                          <div class="mt20">
                            <span>
                              修正得分
                              <em
                                class="cor_00c"
                              >{{ item.reviseScore }} </em>分
                            </span>
                            <span class="ml15">
                              修正者
                              <em
                                class="cor_00c"
                              >{{ item.reviser }} </em>
                            </span>
                          </div>
                        </div>
                        <div v-else class="fz15 cor_2 mt20">
                          <span class>
                            <em class="cor_00c" style="color:#E20312">学生未提交</em>
                          </span>
                        </div>
                        <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                          教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                          <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">评阅</el-button>
                        </div>
                        <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                          修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                          <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMarking(item)">修改</el-button>
                          <br />
                          修正原因:<el-input
                            v-model="item.reviseReason"
                            type="textarea"
                            :rows="3"
                            placeholder="请输入内容"
                            class="mt10"
                          >
                          </el-input>
                        </div>
                        <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                          <span
                            class="analysis_fz_sty fz15 cor_2 vm"
                          >{{ item.showFlag ? '收起解析': '展开解析' }}</span>
                          <i class="ml10 ico_arrow_rotate"></i>
                        </a>
                      </div>
                    <!--内容-->
                    <!-- <p class="mt20 pl20 fz16 cor_1">
                      得分：
                      <span class="fz20 cor_e10">2分</span>
                    </p> -->

                    </div>
                  </div>
                  <!--解析-->
                  <div class="analysis_area_b cf mt20">
                    <div class="mr25 fl vh">
                      <div class>
                        <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                    </div>
                    <div class="ov">
                      <p class="fz16 fwb">解析：</p>
                      <p class="fz15 lh28" v-html="item.ideas"></p>
                    </div>
                  </div>
                <!--解析-->
                </div>
              </div>
            </div>
            <!--问答题-->

            <!--判断题-->
            <div v-if="judgeBnakList.list.length>0" class="mt15">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_4"></i>
                <span class="ml20 fz20 fwb vm">判断题</span>
                <span class="ml20 fz15 vm">共{{ judgeBnakList.list.length }}题 共{{ judgeBnakList.value }}</span>
              </div>
              <!--题目-->
              <div v-for="(item,index) of judgeBnakList.list" :key="index">
                <div
                  :id="'bank'+item.tqId"
                  :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                  style="padding: 0;"
                >
                  <div class="pa25">
                    <div class="cf">
                      <div class="mr25 fl">
                        <div class>
                          <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                      </div>
                      <div class="ov">
                        <p class="mt5 lh24">
                          <span class="fz16 fwb">{{ item.content }}</span>
                        <!-- <span class="ml15 state_bg_sty_1">待查</span> -->
                        </p>
                        <!--选择答案-->
                        <!--正确答案-->
                        <div class="mt20 re cf" style="padding-right: 105px;">
                          <div v-if="item.pdId!==null" class="fz15 cor_2">
                            <span class>
                              正确答案是
                              <em class="cor_00c">{{ item.answer }}</em>
                            </span>
                            <span class="ml15">
                              学生答案是
                              <em
                                class="cor_00c"
                                :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                              >{{ item.userAnswer }}</em>
                            </span>
                            <span class="ml15">
                              学生得分
                              <em
                                class="cor_00c"
                              >{{ item.score }} </em>分
                            </span>
                            <span class="ml15">
                              评分者
                              <em>{{ item.grader }}</em>
                            </span>
                            <br />
                            <div class="mt20">
                              <span>
                                修正得分
                                <em
                                  class="cor_00c"
                                >{{ item.reviseScore }} </em>分
                              </span>
                              <span class="ml15">
                                修正者
                                <em
                                  class="cor_00c"
                                >{{ item.reviser }} </em>
                              </span>
                            </div>
                          </div>
                          <div v-else class="fz15 cor_2">
                            <span class>
                              <em class="cor_00c" style="color:#E20312">学生未提交</em>
                            </span>
                          </div>
                          <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                            教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">评阅</el-button>
                          </div>
                          <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                            修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMarking(item)">修改</el-button>
                            <br />
                            修正原因:<el-input
                              v-model="item.reviseReason"
                              type="textarea"
                              :rows="3"
                              placeholder="请输入内容"
                              class="mt10"
                            >
                            </el-input>
                          </div>
                          <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                            <span
                              class="analysis_fz_sty fz15 cor_2 vm"
                            >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                            <i class="ml10 ico_arrow_rotate"></i>
                          </a>
                        </div>
                      <!--正确答案-->
                      </div>
                    </div>
                  </div>

                  <!--解析-->
                  <div class="analysis_area_b cf">
                    <div class="mr25 fl vh">
                      <div class>
                        <i class="ico_subject_num">1</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共2分</p>
                    </div>
                    <div class="ov">
                      <p class="fz16 fwb">解析：</p>
                      <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                    </div>
                  </div>
                <!--解析-->
                </div>
              </div>
            </div>
            <!--判断题-->

            <!--填空题-->
            <div v-if="blankBankList.list.length>0" class="mt15">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_3"></i>
                <span class="ml20 fz20 fwb vm">填空题</span>
                <span class="ml20 fz15 vm">共{{ blankBankList.list.length }}题 共{{ blankBankList.value }}分</span>
              </div>
              <!--题目-->
              <div v-for="(item,index) of blankBankList.list" :key="index">
                <div
                  :id="'bank'+item.tqId"
                  :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                  style="padding: 0;"
                >
                  <div class="pa25">
                    <div class="cf">
                      <div class="mr25 fl">
                        <div class>
                          <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                      </div>
                      <div class="ov">
                        <p class="mt5 lh24"><span class="fz16 fwb" v-html="item.prveContent"><span class="dib h20 lh20 bb4" style="width: 70px;"></span><span class="dib h20 lh20 bb4" style="width: 70px;"></span></span></p>
                        <!--输入框-->
                        <!-- <div class="mt10 cf">
                      <div class="mr15 fl"><p class="fz16 lh40 fwb">空格1</p></div>
                      <div class="dit">
                        <div class="dib w180 vm" style="width: 616px;">
                          <div class="ipt_wrap" style="padding: 0 20px;"><p class="fz16 lh38">思政课不可替代</p></div>
                        </div>
                      </div>
                    </div>

                    <div class="mt10 cf">
                      <div class="mr15 fl"><p class="fz16 lh40 fwb">空格2</p></div>
                      <div class="dit">
                        <div class="dib w180 vm" style="width: 616px;">
                          <div class="ipt_wrap" style="padding: 0 20px;"><p class="fz16 lh38">思政课不可替代</p></div>
                        </div>
                      </div>
                      </div>-->

                        <!--正确答案-->
                        <div class="mt20 re cf" style="padding-right: 105px;">
                          <div v-if="item.pdId!==null" class="fz15 cor_2">
                            <span class>
                              正确答案是
                              <em class="cor_00c">{{ item.answer }}</em>
                            </span>
                            <span class="ml15">
                              学生答案是
                              <em
                                class="cor_00c"
                                :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                              >{{ item.userAnswer }}</em>
                            </span>
                            <span class="ml15">
                              学生得分
                              <em
                                class="cor_00c"
                              >{{ item.score }} </em>分
                            </span>
                            <span class="ml15">
                              评分者
                              <em>{{ item.grader }}</em>
                            </span>
                            <br />
                            <div class="mt20">
                              <span>
                                修正得分
                                <em
                                  class="cor_00c"
                                >{{ item.reviseScore }} </em>分
                              </span>
                              <span class="ml15">
                                修正者
                                <em
                                  class="cor_00c"
                                >{{ item.reviser }} </em>
                              </span>
                            </div>
                          </div>
                          <div v-else class="fz15 cor_2">
                            <span class>
                              <em class="cor_00c" style="color:#E20312">学生未提交</em>
                            </span>
                          </div>
                          <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                            教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">评阅</el-button>
                          </div>
                          <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                            修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                            <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMarking(item)">修改</el-button>
                            <br />
                            修正原因:<el-input
                              v-model="item.reviseReason"
                              type="textarea"
                              :rows="3"
                              placeholder="请输入内容"
                              class="mt10"
                            >
                            </el-input>
                          </div>
                          <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                            <span
                              class="analysis_fz_sty fz15 cor_2 vm"
                            >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                            <i class="ml10 ico_arrow_rotate"></i>
                          </a>
                        </div>
                      <!--正确答案-->
                      </div>
                    </div>
                  </div>
                  <!--解析-->
                  <div class="analysis_area_b cf">
                    <div class="mr25 fl vh">
                      <div class>
                        <i class="ico_subject_num">1</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共2分</p>
                    </div>
                    <div class="ov">
                      <p class="fz16 fwb">解析：</p>
                      <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                    </div>
                  </div>
                <!--解析-->
                </div>
              </div>
            </div>
            <!--填空题-->

            <!--材料题-->
            <div v-if="meteraBankList.list.length>0" class="mt15">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_2"></i>
                <span class="ml20 fz20 fwb vm">材料题</span>
                <span class="ml20 fz15 vm">共{{ meteraBankList.list.length }}题 共{{ meteraBankList.value }}分</span>
              </div>
              <!--题目-->
              <div v-for="(bank,i) of meteraBankList.list" :key="i">
                <div class="pl25 bl1">
                  <div :id="'bank'+bank.tqId" class="subject_area_sty_2">
                    <div class="cf">
                      <p class="mr35 pl30 fl fz20 fwb lh40">材料</p>
                      <div class="ov">
                        <p class="fz18 lh40 ti" v-html="bank.content"></p>
                      </div>
                    </div>
                    <i class="dot_sty_pos"></i>
                  </div>
                  <!-- 单选题 -->
                  <div v-if="bank.mselectBankList.length>0">
                    <div class="pt15 pb15">
                      <i class="ml15 ico_subject_type_3"></i>
                      <span class="ml20 fz20 fwb vm">材料单选题</span>
                    <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                    </div>
                    <div v-for="(item,index) of bank.mselectBankList" :key="index">
                      <div
                        :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                        style="padding: 0;"
                      >
                        <div class="pa25">
                          <div class="cf">
                            <div class="mr25 fl">
                              <div class>
                                <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                              </div>
                              <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                            </div>
                            <div class="ov">
                              <p class="mt5 lh24">
                                <span class="fz16 fwb">{{ item.content }}</span>
                              <!-- <span class="ml15 state_bg_sty_2">待查</span> -->
                              </p>
                              <!--选项-->
                              <div class="mt10">
                                <div v-for="(item1,index1) of item.options" :key="index1">
                                  <p class="fz15 lh38 cor_2">{{ item1.value }}:{{ item1.label }}</p>
                                </div>
                              </div>
                              <!--正确答案-->
                              <div class="mt20 re cf" style="padding-right: 105px;">
                                <div v-if="item.pdId!==null" class="fz15 cor_2">
                                  <span class>
                                    正确答案是
                                    <em class="cor_00c">{{ item.answer }}</em>
                                  </span>
                                  <span class="ml15">
                                    学生答案是
                                    <em
                                      class="cor_00c"
                                      :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                                    >{{ item.userAnswer }}</em>
                                  </span>
                                  <span class="ml15">
                                    学生得分
                                    <em
                                      class="cor_00c"
                                    >{{ item.score }} </em>分
                                  </span>
                                  <span class="ml15">
                                    评分者
                                    <em>{{ item.grader }}</em>
                                  </span>
                                  <br />
                                  <div class="mt20">
                                    <span>
                                      修正得分
                                      <em
                                        class="cor_00c"
                                      >{{ item.reviseScore }} </em>分
                                    </span>
                                    <span class="ml15">
                                      修正者
                                      <em
                                        class="cor_00c"
                                      >{{ item.reviser }} </em>
                                    </span>
                                  </div>
                                </div>
                                <div v-else class="fz15 cor_2">
                                  <span class>
                                    <em class="cor_00c" style="color:#E20312">学生未提交</em>
                                  </span>
                                </div>
                                <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                                  教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                  <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item)">评阅</el-button>
                                </div>
                                <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                                  修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                  <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMaterialAnswerMarking(item)">修改</el-button>
                                  <br />
                                  修正原因:<el-input
                                    v-model="item.reviseReason"
                                    type="textarea"
                                    :rows="3"
                                    placeholder="请输入内容"
                                    class="mt10"
                                  >
                                  </el-input>
                                </div>
                                <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                                  <span
                                    class="analysis_fz_sty fz15 cor_2 vm"
                                  >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                                  <i class="ml10 ico_arrow_rotate"></i>
                                </a>
                              </div>
                            <!--正确答案-->
                            </div>
                          </div>
                        </div>

                        <!--解析-->
                        <div class="analysis_area_b cf">
                          <div class="mr25 fl vh">
                            <div class>
                              <i class="ico_subject_num">1</i>
                            </div>
                            <p class="mt10 cor_e10 tac">共2分</p>
                          </div>
                          <div class="ov">
                            <p class="fz16 fwb">解析：</p>
                            <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                          </div>
                        </div>
                        <!--解析-->

                        <i class="dot_sty_pos"></i>
                      </div>
                    </div>
                  </div>
                  <!-- 单选题 -->
                  <!-- 多选题 -->
                  <div v-if="bank.mmultselectBankList.length>0">
                    <div class="pt15 pb15">
                      <i class="ml15 ico_subject_type_3"></i>
                      <span class="ml20 fz20 fwb vm">材料多选题</span>
                    <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                    </div>
                    <div v-for="(item,index) of bank.mmultselectBankList" :key="index">
                      <div
                        :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                        style="padding: 0;"
                      >
                        <div class="pa25">
                          <div class="cf">
                            <div class="mr25 fl">
                              <div class>
                                <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                              </div>
                              <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                            </div>
                            <div class="ov">
                              <p class="mt5 lh24">
                                <span class="fz16 fwb">{{ item.content }}</span>
                              <!-- <span class="ml15 state_bg_sty_2">待查</span> -->
                              </p>
                              <!--选项-->
                              <div class="mt10">
                                <div v-for="(item1,index1) of item.options" :key="index1">
                                  <p class="fz15 lh38 cor_2">{{ item1.value }}:{{ item1.label }}</p>
                                </div>
                              </div>
                              <!--正确答案-->
                              <div class="mt20 re cf" style="padding-right: 105px;">
                                <div v-if="item.pdId!==null" class="fz15 cor_2">
                                  <span class>
                                    正确答案是
                                    <em class="cor_00c">{{ item.answer }}</em>
                                  </span>
                                  <span class="ml15">
                                    学生答案是
                                    <em
                                      class="cor_00c"
                                      :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                                    >{{ item.userAnswer }}</em>
                                  </span>
                                  <span class="ml15">
                                    学生得分
                                    <em
                                      class="cor_00c"
                                    >{{ item.score }} </em>分
                                  </span>
                                  <span class="ml15">
                                    评分者
                                    <em>{{ item.grader }}</em>
                                  </span>
                                  <br />
                                  <div class="mt20">
                                    <span>
                                      修正得分
                                      <em
                                        class="cor_00c"
                                      >{{ item.reviseScore }} </em>分
                                    </span>
                                    <span class="ml15">
                                      修正者
                                      <em
                                        class="cor_00c"
                                      >{{ item.reviser }} </em>
                                    </span>
                                  </div>
                                </div>
                                <div v-else class="fz15 cor_2">
                                  <span class>
                                    <em class="cor_00c" style="color:#E20312">学生未提交</em>
                                  </span>
                                </div>
                                <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                                  教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                  <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item)">评阅</el-button>
                                </div>
                                <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                                  修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                  <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMaterialAnswerMarking(item)">修改</el-button>
                                  <br />
                                  修正原因:<el-input
                                    v-model="item.reviseReason"
                                    type="textarea"
                                    :rows="3"
                                    placeholder="请输入内容"
                                    class="mt10"
                                  >
                                  </el-input>
                                </div>
                                <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                                  <span
                                    class="analysis_fz_sty fz15 cor_2 vm"
                                  >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                                  <i class="ml10 ico_arrow_rotate"></i>
                                </a>
                              </div>
                            <!--正确答案-->
                            </div>
                          </div>
                        </div>

                        <!--解析-->
                        <div class="analysis_area_b cf">
                          <div class="mr25 fl vh">
                            <div class>
                              <i class="ico_subject_num">1</i>
                            </div>
                            <p class="mt10 cor_e10 tac">共2分</p>
                          </div>
                          <div class="ov">
                            <p class="fz16 fwb">解析：</p>
                            <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                          </div>
                        </div>
                        <!--解析-->

                        <i class="dot_sty_pos"></i>
                      </div>
                    </div>
                  </div>
                  <!-- 多选题 -->

                  <!--问答题-->
                  <div v-if="bank.mquestanswerBankList.length>0" class="mt15">
                    <div class="pt15 pb15">
                      <i class="ml15 ico_subject_type_3"></i>
                      <span class="ml20 fz20 fwb vm">材料问答题</span>
                    <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                    </div>
                    <!--题目-->
                    <div v-for="(item,index) of bank.mquestanswerBankList" :key="index">
                      <div :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']">
                        <div class="cf">
                          <div class="mr25 fl">
                            <div class>
                              <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                            </div>
                            <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                          </div>
                          <div class="ov">
                            <p class="mt5 lh24">
                              <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                            <!-- <span class="ml15 state_bg_sty_1">待查</span> -->
                            </p>

                            <!--内容-->
                            <div class="mt20 re cf" style="padding-right: 105px;">
                              <div class="cor_1 fz16 mt25">正确答案：</div>
                              <div class=" b2 pa20">
                                <p class="fz16 lh24 cor_1"> {{ item.answer }}</p>
                              </div>
                              <div class="cor_1 fz16 mt25">学生答案：</div>
                              <div class=" b2 pa20">
                                <p class="fz16 lh24 cor_1" v-html="item.userAnswer"></p>
                              </div>
                              <div v-if="item.pdId!==null" class="fz15 cor_2 mt20">
                                <span class="">
                                  学生得分
                                  <em
                                    class="cor_00c"
                                  >{{ item.score }} </em>分
                                </span>
                                <span class="ml15">
                                  评分者
                                  <em>{{ item.grader }}</em>
                                </span>
                                <br />
                                <div class="mt20">
                                  <span>
                                    修正得分
                                    <em
                                      class="cor_00c"
                                    >{{ item.reviseScore }} </em>分
                                  </span>
                                  <span class="ml15">
                                    修正者
                                    <em
                                      class="cor_00c"
                                    >{{ item.reviser }} </em>
                                  </span>
                                </div>
                              </div>
                              <div v-else class="fz15 cor_2 mt20">
                                <span class>
                                  <em class="cor_00c" style="color:#E20312">学生未提交</em>
                                </span>
                              </div>
                              <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                                教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item)">评阅</el-button>
                              </div>
                              <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                                修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMaterialAnswerMarking(item)">修改</el-button>
                                <br />
                                修正原因:<el-input
                                  v-model="item.reviseReason"
                                  type="textarea"
                                  :rows="3"
                                  placeholder="请输入内容"
                                  class="mt10"
                                >
                                </el-input>
                              </div>
                              <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                                <span
                                  class="analysis_fz_sty fz15 cor_2 vm"
                                >{{ item.showFlag ? '收起解析': '展开解析' }}</span>
                                <i class="ml10 ico_arrow_rotate"></i>
                              </a>
                            </div>
                          </div>
                          <!--解析-->
                          <div class="analysis_area_b cf mt20">
                            <div class="mr25 fl vh">
                              <div class>
                                <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                              </div>
                              <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                            </div>
                            <div class="ov">
                              <p class="fz16 fwb">解析：</p>
                              <p class="fz15 lh28" v-html="item.ideas"></p>
                            </div>
                          </div>
                        <!--解析-->
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--问答题-->

                  <!--判断题-->
                  <div v-if="bank.mjudgeBnakList.length>0" class="mt15">
                    <div class="pt15 pb15">
                      <i class="ml15 ico_subject_type_4"></i>
                      <span class="ml20 fz20 fwb vm">材料判断题</span>
                    <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                    </div>
                    <!--题目-->
                    <div v-for="(item,index) of bank.mjudgeBnakList" :key="index">
                      <div
                        :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                        style="padding: 0;"
                      >
                        <div class="pa25">
                          <div class="cf">
                            <div class="mr25 fl">
                              <div class>
                                <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                              </div>
                              <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                            </div>
                            <div class="ov">
                              <p class="mt5 lh24">
                                <span class="fz16 fwb">{{ item.content }}</span>
                              <!-- <span class="ml15 state_bg_sty_1">待查</span> -->
                              </p>
                              <!--正确答案-->
                              <div class="mt20 re cf" style="padding-right: 105px;">
                                <div v-if="item.pdId!==null" class="fz15 cor_2">
                                  <span class>
                                    正确答案是
                                    <em class="cor_00c">{{ item.answer }}</em>
                                  </span>
                                  <span class="ml15">
                                    学生答案是
                                    <em
                                      class="cor_00c"
                                      :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                                    >{{ item.userAnswer }}</em>
                                  </span>
                                  <span class="ml15">
                                    学生得分
                                    <em
                                      class="cor_00c"
                                    >{{ item.score }} </em>分
                                  </span>
                                  <span class="ml15">
                                    评分者
                                    <em>{{ item.grader }}</em>
                                  </span>
                                  <br />
                                  <div class="mt20">
                                    <span>
                                      修正得分
                                      <em
                                        class="cor_00c"
                                      >{{ item.reviseScore }} </em>分
                                    </span>
                                    <span class="ml15">
                                      修正者
                                      <em
                                        class="cor_00c"
                                      >{{ item.reviser }} </em>
                                    </span>
                                  </div>
                                </div>
                                <div v-else class="fz15 cor_2">
                                  <span class>
                                    <em class="cor_00c" style="color:#E20312">学生未提交</em>
                                  </span>
                                </div>
                                <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                                  教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                  <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item)">评阅</el-button>
                                </div>
                                <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                                  修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                  <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMaterialAnswerMarking(item)">修改</el-button>
                                  <br />
                                  修正原因:<el-input
                                    v-model="item.reviseReason"
                                    type="textarea"
                                    :rows="3"
                                    placeholder="请输入内容"
                                    class="mt10"
                                  >
                                  </el-input>
                                </div>
                                <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                                  <span
                                    class="analysis_fz_sty fz15 cor_2 vm"
                                  >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                                  <i class="ml10 ico_arrow_rotate"></i>
                                </a>
                              </div>
                            <!--正确答案-->
                            </div>
                          </div>
                        </div>

                        <!--解析-->
                        <div class="analysis_area_b cf">
                          <div class="mr25 fl vh">
                            <div class>
                              <i class="ico_subject_num">1</i>
                            </div>
                            <p class="mt10 cor_e10 tac">共2分</p>
                          </div>
                          <div class="ov">
                            <p class="fz16 fwb">解析：</p>
                            <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                          </div>
                        </div>
                      <!--解析-->
                      </div>
                    </div>
                  </div>
                  <!--判断题-->

                  <!--填空题-->
                  <div v-if="bank.mblankBankList.length>0" class="mt15">
                    <div class="pt15 pb15">
                      <i class="ml15 ico_subject_type_3"></i>
                      <span class="ml20 fz20 fwb vm">材料填空题</span>
                    <!-- <span class="ml20 fz15 vm">共2题 共2分</span> -->
                    </div>
                    <!--题目-->
                    <div v-for="(item,index) of bank.mblankBankList" :key="index">
                      <div
                        :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                        style="padding: 0;"
                      >
                        <div class="pa25">
                          <div class="cf">
                            <div class="mr25 fl">
                              <div class>
                                <i class="ico_subject_num">1</i>
                              </div>
                              <p class="mt10 cor_e10 tac">共2分</p>
                            </div>
                            <div class="ov">
                              <p class="mt5 lh24"><span class="fz16 fwb" v-html="item.prveContent"><span class="dib h20 lh20 bb4" style="width: 70px;"></span><span class="dib h20 lh20 bb4" style="width: 70px;"></span></span></p>
                              <!--输入框-->
                              <!-- <div class="mt10 cf">
                            <div class="mr15 fl"><p class="fz16 lh40 fwb">空格1</p></div>
                            <div class="dit">
                              <div class="dib w180 vm" style="width: 616px;">
                                <div class="ipt_wrap" style="padding: 0 20px;"><p class="fz16 lh38">思政课不可替代</p></div>
                              </div>
                            </div>
                          </div>

                          <div class="mt10 cf">
                            <div class="mr15 fl"><p class="fz16 lh40 fwb">空格2</p></div>
                            <div class="dit">
                              <div class="dib w180 vm" style="width: 616px;">
                                <div class="ipt_wrap" style="padding: 0 20px;"><p class="fz16 lh38">思政课不可替代</p></div>
                              </div>
                            </div>
                            </div>-->

                              <!--正确答案-->
                              <div class="mt20 re cf" style="padding-right: 105px;">
                                <div v-if="item.pdId!==null" class="fz15 cor_2">
                                  <span class>
                                    正确答案是
                                    <em class="cor_00c">{{ item.answer }}</em>
                                  </span>
                                  <span class="ml15">
                                    学生答案是
                                    <em
                                      class="cor_00c"
                                      :style="{color: item.isCorrect? '#00CC56' : '#E20312'}"
                                    >{{ item.userAnswer }}</em>
                                  </span>
                                  <span class="ml15">
                                    学生得分
                                    <em
                                      class="cor_00c"
                                    >{{ item.score }} </em>分
                                  </span>
                                  <span class="ml15">
                                    评分者
                                    <em>{{ item.grader }}</em>
                                  </span>
                                  <br />
                                  <div class="mt20">
                                    <span>
                                      修正得分
                                      <em
                                        class="cor_00c"
                                      >{{ item.reviseScore }} </em>分
                                    </span>
                                    <span class="ml15">
                                      修正者
                                      <em
                                        class="cor_00c"
                                      >{{ item.reviser }} </em>
                                    </span>
                                  </div>
                                </div>
                                <div v-else class="fz15 cor_2">
                                  <span class>
                                    <em class="cor_00c" style="color:#E20312">学生未提交</em>
                                  </span>
                                </div>
                                <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                                  教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                  <el-button type="success" size="medium" style="margin-left:20px" @click="dealMaterialAnswerMarking(item)">评阅</el-button>
                                </div>
                                <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                                  修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                                  <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMaterialAnswerMarking(item)">修改</el-button>
                                  <br />
                                  修正原因:<el-input
                                    v-model="item.reviseReason"
                                    type="textarea"
                                    :rows="3"
                                    placeholder="请输入内容"
                                    class="mt10"
                                  >
                                  </el-input>
                                </div>
                                <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                                  <span
                                    class="analysis_fz_sty fz15 cor_2 vm"
                                  >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                                  <i class="ml10 ico_arrow_rotate"></i>
                                </a>
                              </div>
                            <!--正确答案-->
                            </div>
                          </div>
                        </div>
                        <!--解析-->
                        <div class="analysis_area_b cf">
                          <div class="mr25 fl vh">
                            <div class>
                              <i class="ico_subject_num">1</i>
                            </div>
                            <p class="mt10 cor_e10 tac">共2分</p>
                          </div>
                          <div class="ov">
                            <p class="fz16 fwb">解析：</p>
                            <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                          </div>
                        </div>
                      <!--解析-->
                      </div>
                    </div>
                  </div>
                <!--填空题-->
                </div>
              <!--bl1-->
              </div>
            </div>
            <!--材料题-->
            <!--编程题-->
            <div v-if="programBankList.list.length>0" class="mt15 mb20">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_7"></i>
                <span class="ml20 fz20 fwb vm">编程题</span>
                <span class="ml20 fz15 vm">共{{ programBankList.list.length }}题 共{{ programBankList.value }}分</span>
              </div>
              <!--题目-->
              <div v-for="(item,index) of programBankList.list" :key="index" class="mt20">
                <div
                  :id="'bank'+item.tqId"
                  :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                >
                  <div class="cf">
                    <div class="mr25 fl">
                      <div class>
                        <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                    </div>
                    <div class="ov">
                      <p class="mt5 lh24">
                        <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                      </p>
                      <!--富文本编辑器-->
                      <tinymce
                        ref="topicContent"
                        v-model="item.answer"
                        :save-flag="saveFlag"
                        class="mt25"
                      />
                      <!--正确答案-->
                      <div class="mt20 mb20 re cf" style="padding-right: 105px;">
                        <div v-if="item.pdId!==null" class="fz15 cor_2">
                          <span class="">
                            下载学生答案
                            <em class="cor_00c">
                              <el-button
                                size="small"
                                style="margin-left:20px"
                                type="success"
                                @click="downLoad(item.userAnswer,index)"
                              >下载</el-button>
                            </em>
                          </span>
                          <span class="ml15">
                            学生得分是
                            <em
                              class="cor_00c"
                            >{{ item.score }} </em>分
                          </span>
                          <span class="ml15">
                            评分者
                            <em>{{ item.grader }}</em>
                          </span>
                          <br />
                          <div class="mt20">
                            <span>
                              修正得分
                              <em
                                class="cor_00c"
                              >{{ item.reviseScore }} </em>分
                            </span>
                            <span class="ml15">
                              修正者
                              <em
                                class="cor_00c"
                              >{{ item.reviser }} </em>
                            </span>
                          </div>
                        </div>
                        <div v-else class="fz15 cor_2">
                          <span class>
                            <em class="cor_00c" style="color:#E20312">学生未提交</em>
                          </span>
                        </div>
                        <div v-if="item.pdId!==null" class="fz15 cor_2 mt20 ">
                          <span class="">
                            评分结果：<br>
                            <span style="letter-spacing:1pt;line-height:25px;" v-html="item.gradeResult"></span>
                          </span>
                        </div>
                        <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                          教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                          <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">评阅</el-button>
                        </div>
                        <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                          修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                          <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMarking(item)">修改</el-button>
                          <br />
                          修正原因:<el-input
                            v-model="item.reviseReason"
                            type="textarea"
                            :rows="3"
                            placeholder="请输入内容"
                            class="mt10"
                          >
                          </el-input>
                        </div>
                        <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                          <span
                            class="analysis_fz_sty fz15 cor_2 vm"
                          >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                          <i class="ml10 ico_arrow_rotate"></i>
                        </a>
                      </div>
                    <!--正确答案-->
                    </div>
                    <!--解析-->
                    <div class="analysis_area_b cf">
                      <div class="mr25 fl vh">
                        <div class>
                          <i class="ico_subject_num">1</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共2分</p>
                      </div>
                      <div class="ov">
                        <p class="fz16 fwb">解析：</p>
                        <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                      </div>
                    </div>
                  <!--解析-->
                  </div>
                </div>
              </div>
            </div>
            <!--编程题-->
            <!--程序填空题-->
            <div v-if="programblankBank.list.length>0" class="mt15 mb20">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_3"></i>
                <span class="ml20 fz20 fwb vm">程序填空题</span>
                <span class="ml20 fz15 vm">共{{ programblankBank.list.length }}题 共{{ programblankBank.value }}分</span>
              </div>
              <!--题目-->
              <div v-for="(item,index) of programblankBank.list" :key="index">
                <div
                  :id="'bank'+item.tqId"
                  :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']"
                >
                  <div class="cf">
                    <div class="mr25 fl">
                      <div class>
                        <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                    </div>
                    <div class="ov">
                      <p class="mt5 lh24">
                        <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                      </p>
                      <tinymce
                        v-model="item.code"
                        plugins="codesample"
                        toolbar="false"
                        menubar="false"
                        inline="true"
                        :height="400"
                      />
                      <!--正确答案-->
                      <div class="mt20 re cf" style="padding-right: 105px;">
                        <div v-if="item.pdId!==null" class="fz15 cor_2">
                          <span class="">
                            下载学生答案
                            <em class="cor_00c">
                              <el-button
                                size="small"
                                style="margin-left:20px"
                                type="success"
                                @click="downLoad(item.attachment,index)"
                              >下载</el-button>
                            </em>
                          </span>
                          <span class="ml15">
                            学生得分是
                            <em
                              class="cor_00c"
                            >{{ item.score }} </em>分
                          </span>
                          <span class="ml15">
                            评分者
                            <em>{{ item.grader }}</em>
                          </span>
                          <br />
                          <div class="mt20">
                            <span>
                              修正得分
                              <em
                                class="cor_00c"
                              >{{ item.reviseScore }} </em>分
                            </span>
                            <span class="ml15">
                              修正者
                              <em
                                class="cor_00c"
                              >{{ item.reviser }} </em>
                            </span>
                          </div>
                        </div>
                        <div v-else class="fz15 cor_2">
                          <span class>
                            <em class="cor_00c" style="color:#E20312">学生未提交</em>
                          </span>
                        </div>
                        <div v-if="item.pdId!==null" class="fz15 cor_2 mt20 ">
                          <span class="">
                            评分结果：<br>
                            <span style="letter-spacing:1pt;line-height:25px;" v-html="item.gradeResult"></span>
                          </span>
                        </div>
                        <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                          教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                          <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">评阅</el-button>
                        </div>
                        <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                          修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                          <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMarking(item)">修改</el-button>
                          <br />
                          修正原因:<el-input
                            v-model="item.reviseReason"
                            type="textarea"
                            :rows="3"
                            placeholder="请输入内容"
                            class="mt10"
                          >
                          </el-input>
                        </div>
                        <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                          <span
                            class="analysis_fz_sty fz15 cor_2 vm"
                          >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                          <i class="ml10 ico_arrow_rotate"></i>
                        </a>
                      </div>
                    <!--正确答案-->
                    </div>

                    <div class="analysis_area_b cf">
                      <div class="mr25 fl vh">
                        <div class>
                          <i class="ico_subject_num">1</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共2分</p>
                      </div>
                      <div class="ov">
                        <p class="fz16 fwb">解析：</p>
                        <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                      </div>
                    </div>
                  <!--解析-->
                  </div>
                </div>
              </div>
            </div>
            <!--程序填空题-->
            <!--上传题-->
            <div v-if="fileupload.list.length>0" class="re pb50" style="z-index: 2;">
              <div class="pt15 pb15">
                <i class="ml15 ico_subject_type_3"></i>
                <span class="ml20 fz20 fwb vm">文件上传题</span>
                <span class="ml20 fz15 vm">共{{ fileupload.list.length }}题 共{{ fileupload.value }}分</span>
              </div>
              <!--题目-->
              <div v-for="(item,index) of fileupload.list" :key="index">
                <div :id="'bank'+item.tqId" :class="[item.showFlag ===false ? 'subject_area_sty mt20 ' : 'subject_area_sty mt20 show_flag']">
                  <div class="cf">
                    <div class="mr25 fl">
                      <div class>
                        <i :class="[(item.grader === '' || item.grader === null) ? 'ico_subject_num':'ico_subject_num green']">{{ index+1 }}</i>
                      </div>
                      <p class="mt10 cor_e10 tac">共{{ item.value }}分</p>
                    </div>
                    <div class="ov">
                      <p class="mt5 lh30">
                        <span class="fz16 fwb" v-html="item.content">{{ item.content }}</span>
                      </p>
                    </div>
                    <div class="mt20 mb20 re cf" style="padding-right: 105px;">
                      <div v-if="item.pdId!==null" class="fz15 cor_2">
                        <span class="">
                          下载学生答案
                          <em class="cor_00c">
                            <el-button
                              size="small"
                              style="margin-left:10px"
                              type="success"
                              @click="downLoad(item.userAnswer,index)"
                            >下载</el-button>
                          </em>
                        </span>
                        <span class="ml15">
                          学生得分是
                          <em
                            class="cor_00c"
                          >{{ item.score }} </em>分
                        </span>
                        <span class="ml15">
                          评分者
                          <em>{{ item.grader }}</em>
                        </span>
                        <br />
                        <div class="mt20">
                          <span>
                            修正得分
                            <em
                              class="cor_00c"
                            >{{ item.reviseScore }} </em>分
                          </span>
                          <span class="ml15">
                            修正者
                            <em
                              class="cor_00c"
                            >{{ item.reviser }} </em>
                          </span>
                        </div>
                      </div>
                      <div v-else class="fz15 cor_2">
                        <span class>
                          <em class="cor_00c" style="color:#E20312">学生未提交</em>
                        </span>
                      </div>
                      <div v-if="item.pdId!==null && ! item.grader" class="fz15 cor_2 mt20">
                        教师评分：<el-input-number v-model="item.score" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                        <el-button type="success" size="medium" style="margin-left:20px" @click="dealMarking(item)">评阅</el-button>
                      </div>
                      <div v-if="item.grader" style="width:348px" class="fz15 cor_2 mt20">
                        修正评分：<el-input-number v-model="item.reviseScore" controls-position="right" :min="0" :max="item.value" :step="0.1"></el-input-number>
                        <el-button type="success" size="medium" style="margin-left:20px" @click="dealChangeMarking(item)">修改</el-button>
                        <br />
                        修正原因:<el-input
                          v-model="item.reviseReason"
                          type="textarea"
                          :rows="3"
                          placeholder="请输入内容"
                          class="mt10"
                        >
                        </el-input>
                      </div>
                      <a class="analysis_weizhi_pos click" @click="changeShow(item)">
                        <span
                          class="analysis_fz_sty fz15 cor_2 vm"
                        >{{ item.showFlag? '收起解析': '展开解析' }}</span>
                        <i class="ml10 ico_arrow_rotate"></i>
                      </a>
                    </div>
                    <div class="analysis_area_b cf">
                      <div class="mr25 fl vh">
                        <div class>
                          <i class="ico_subject_num">1</i>
                        </div>
                        <p class="mt10 cor_e10 tac">共2分</p>
                      </div>
                      <div class="ov">
                        <p class="fz16 fwb">解析：</p>
                        <p class="fz15 lh28" v-html="item.ideas">{{ item.ideas }}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            <!--上传题-->
            <!-- <div class="img_bg_pos_sty"></div> -->
            </div>
          </div>
        </div>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <div class="re pt15 pb15">
        <p class="tac lh40">
          <span v-if="isOpen" class="fz24 fwb vm" style="margin-right:40px">学号:{{ examLogData[sindex].stuId }} 姓名:{{ examLogData[sindex].realName }}</span>
          <el-button
            v-show="sindex != 0"
            :style="{display:sindex == 0? 'none':'line-block' }"
            type="primary"
            @click="prve"
          >评阅上一个</el-button>
          <el-button
            v-show="sindex != examLogData.length-1"
            type="primary"
            @click="next"
          >评阅下一个</el-button>
          <el-button
            type="success"
            @click="finish"
          >完成</el-button>
          <el-checkbox v-model="examLogData[sindex].isGrading" style="margin-left:10px" border size="mini">阅卷完成</el-checkbox>
        </p>
        <!-- <div class="mt25 subject_area_sty_2">
            <div class="tac">
              <div class="mt15 re dib">
                <div class="achievement_score_bg">
                  <span class="fwb">{{ stuAnswer.score }}</span>
                  <span class="fz24">分</span>
                </div>
              </div>
            </div>
          </div> -->

      </div>
    </span>
  </el-dialog>
</template>
<script>
import ExamLogApi from '@/api/exambank/exam-record'
import Tinymce from '@/components/Tinymce'
import EXAMBANK_CONST from '@/constant/exambank-const'
import { mapGetters } from 'vuex'
import stuAnswerApi from '@/api/exambank/stu-answer.js'
import stuPaperDetailApi from '@/api/exambank/stu-paper-detail.js'
import { downloadByLink } from '@/utils/index'
import paperApi from '@/api/exambank/paper.js'
import materialAnswerApi from '@/api/exambank/materialAnswer.js'
export default {
  name: 'MarkeStuAnswer',
  components: {
    Tinymce
  },
  props: {
    dialogObject: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      stuAnswer: {},
      questionList: [],
      // 单选题列表
      selectBankList: {
        list: [],
        value: 0
      },
      // 多选题列表
      multselectBankList: {
        list: [],
        value: 0
      },
      // 判断题列表
      judgeBnakList: {
        list: [],
        value: 0
      },
      // 填空题列表
      blankBankList: {
        list: [],
        value: 0
      },
      // 简答题列表
      questanswerBankList: {
        list: [],
        value: 0
      },
      // 材料题列表
      meteraBankList: {
        list: [],
        value: 0
      },
      // 编程题列表
      programBankList: {
        list: [],
        value: 0
      },
      // 程序填空题列表
      programblankBank: {
        list: [],
        value: 0
      },
      // 接口编程题列表
      programminterBank: {
        list: [],
        value: 0
      },
      // 文件上传提列表
      fileupload: {
        list: [],
        value: 0
      },
      // 试题类型常量定义
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      ESSAY_QUESTION: EXAMBANK_CONST.ESSAY_QUESTION,
      MATERIAL: EXAMBANK_CONST.MATERIAL,
      PROGRAMME: EXAMBANK_CONST.PROGRAMME,
      PROG_FILLBLANK: EXAMBANK_CONST.PROG_FILLBLANK,
      INTERFACE: EXAMBANK_CONST.INTERFACE,
      FILE_UPLOAD: EXAMBANK_CONST.FILE_UPLOAD,
      saveFlag: false,
      loading: false,
      searchBarFixed: false,
      paper: {},
      answerId: null,
      VUE_APP_FILE_SERVER: process.env.VUE_APP_FILE_SERVER,
      examLogData: [],
      sindex: 0,
      roundId: null,
      examType: '',
      isOpen: false
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {

  },
  mounted() {

  },
  destroyed() {

  },
  methods: {
    open() {
      this.sindex = this.dialogObject.sindex
      this.roundId = this.dialogObject.roundId
      this.examType = this.dialogObject.examType
      this.getExamLogList(this.roundId, this.examType)
    //  window.addEventListener('scroll', this.handleScroll)
    },
    close() {
      this.isOpen = false
      // window.removeEventListener('scroll', this.handleScroll)
    },
    initQuestion() {
      this.questionList = []
      // 单选题列表
      this.selectBankList = {
        list: [],
        value: 0
      }
      // 多选题列表
      this.multselectBankList = {
        list: [],
        value: 0
      }
      // 判断题列表
      this.judgeBnakList = {
        list: [],
        value: 0
      }
      // 填空题列表
      this.blankBankList = {
        list: [],
        value: 0
      }
      // 简答题列表
      this.questanswerBankList = {
        list: [],
        value: 0
      }
      // 材料题列表
      this.meteraBankList = {
        list: [],
        value: 0
      }
      // 编程题列表
      this.programBankList = {
        list: [],
        value: 0
      }
      // 程序填空题列表
      this.programblankBank = {
        list: [],
        value: 0
      }
      // 接口编程题列表
      this.programminterBank = {
        list: [],
        value: 0
      }
      // 文件上传提列表
      this.fileupload = {
        list: [],
        value: 0
      }
    },
    getStudentAnswer(index) {
      this.loading = true
      this.initQuestion()
      paperApi.getPaperById(this.examLogData[index].paperId)
        .then(resp => {
          this.paper = resp.data
          console.log(this.paper)
        })
      var stuAnswer = {
        paperId: this.examLogData[index].paperId,
        roundId: this.examLogData[index].roundId,
        stuUserId: this.examLogData[index].stuUserId,
        examType: EXAMBANK_CONST.TEST
      }
      stuAnswerApi.getStuAnswerByPaperIdAndUserId(stuAnswer).then(resp => {
        this.answerId = resp.data.answerId
        var studentAnswer = {
          paperId: this.examLogData[index].paperId,
          answerId: resp.data.answerId,
          stuUserId: this.examLogData[index].stuUserId
        }
        stuPaperDetailApi.getMarkeStuPaperDetail(studentAnswer).then(resp => {
          console.log(resp)
          resp.data.forEach(item => {
            if (item.tqTypeId.toString() === this.SINGLE) {
              this.selectBankList.list.push(item)
              this.selectBankList.value += item.value
            } else if (item.tqTypeId.toString() === this.MULTIPLE) {
              this.multselectBankList.list.push(item)
              this.multselectBankList.value += item.value
            } else  if (item.tqTypeId.toString() === this.JUDGEMENT) {
              this.judgeBnakList.list.push(item)
              this.judgeBnakList.value += item.value
            } else if (item.tqTypeId.toString() === this.FILLBLANK) {
              this.blankBankList.list.push(item)
              this.blankBankList.value += item.value
            } else if (item.tqTypeId.toString() === this.ESSAY_QUESTION) {
              this.$set(item, 'showFlag', false)
              this.questanswerBankList.list.push(item)
              this.questanswerBankList.value += item.value
            } else  if (item.tqTypeId.toString() === this.MATERIAL) {
              this.meteraBankList.value += item.value
              this.meteraBankList.list.push(this.meteraSmallBank(item))
            } else  if (item.tqTypeId.toString() === this.PROGRAMME) {
              this.$set(item, 'showFlag', false)
              this.programBankList.value += item.value
              this.programBankList.list.push(item)
            } else  if (item.tqTypeId.toString() === this.PROG_FILLBLANK) {
              this.$set(item, 'showFlag', false)
              this.programblankBank.list.push(item)
              this.programblankBank.value += item.value
            } else  if (item.tqTypeId.toString() === this.INTERFACE) {
              this.$set(item, 'showFlag', false)
              this.programminterBank.value += item.value
              this.programminterBank.list.push(item)
            } else {
              this.fileupload.value += item.value
              this.$set(item, 'showFlag', false)
              this.fileupload.list.push(item)
            }
          })
          setTimeout(() => {
            this.selectBankList.list = this.Rendering(this.selectBankList.list)
            this.multselectBankList.list = this.Rendering(this.multselectBankList.list)
            this.judgeBnakList.list = this.Rendering(this.judgeBnakList.list)
            this.blankBankList.list = this.Rendering(this.blankBankList.list)
            this.programblankBank.list = this.RenderProgramBlank(this.programblankBank.list)
            this.loading = false
          }, 2000)
        })
        console.log(this.stuAnswer)
      })
    },
    goAnchor(selector) {
      console.log(selector)
      document.querySelector(selector).scrollIntoView({
        behavior: 'smooth',  // 平滑过渡
        block: 'center'  // 上边框与视窗顶部平齐。默认值
      })
    },
    // handleScroll() {
    //   var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
    //   var offsetTop = document.querySelector('#fixed_answer_card').offsetTop
    //   if (scrollTop > offsetTop) {
    //     this.searchBarFixed = true
    //   } else {
    //     this.searchBarFixed = false
    //   }
    // },
    // 教师点击修改
    dealMarking(item) {
      var isCorrect = false
      if (item.value === item.score) {
        isCorrect = true
      }
      var stuPaperDetail = {
        pdId: item.pdId,
        grader: this.user.loginName,
        score: item.score,
        isCorrect: isCorrect,
        reviser: null

      }
      stuPaperDetailApi.dealMarking(stuPaperDetail).then(resp => {
        if (resp.code === 0) {
          this.$message({
            message: '保存成功',
            type: 'success'
          })
          item.grader = this.user.loginName
        } else {
          this.$message({
            message: '保存失败',
            type: 'danger'
          })
        }
      })
    },
    getExamLogList(roundId, examType) {
      var examLog = {
        roundId: roundId,
        examType: examType
      }
      ExamLogApi.getExamLogAndScore(examLog).then(resp => {
        this.examLogData = resp.data
        this.getStudentAnswer(this.sindex)
        this.isOpen = true
      })
    },
    // 处理教师修正得分
    dealChangeMarking(item) {
      if (!item.reviseReason) {
        this.$message.error('请输入修正原因')
        return false
      }
      var isCorrect = false
      if (item.value === item.reviseScore) {
        isCorrect = true
      }
      var stuPaperDetail = {
        pdId: item.pdId,
        isCorrect: isCorrect,
        reviseReason: item.reviseReason,
        reviseScore: item.reviseScore,
        reviser: this.user.loginName
      }
      stuPaperDetailApi.dealMarking(stuPaperDetail).then(resp => {
        if (resp.code === 0) {
          this.$message({
            message: '保存成功',
            type: 'success'
          })
          item.reviser = this.user.loginName
        } else {
          this.$message({
            message: '保存失败',
            type: 'danger'
          })
        }
      })
    },
    dealMaterialAnswerMarking(item) {
      var isCorrect = false
      if (item.value === item.score) {
        isCorrect = true
      }
      var materialAnswer = {
        pdId: item.pdId,
        materialId: item.materialId,
        grader: this.user.loginName,
        score: item.score,
        isCorrect: isCorrect,
        reviser: null
      }
      materialAnswerApi.dealMaterialAnswerMarking(materialAnswer).then(resp => {
        if (resp.code === 0) {
          this.$message({
            message: '保存成功',
            type: 'success'
          })
          item.grader = this.user.loginName
        } else {
          this.$message({
            message: '保存失败',
            type: 'danger'
          })
        }
      })
    },
    prve() {
      this.sindex--
      if (this.examLogData[this.sindex].paperId === null) {
        this.prve()
        return false
      }
      this.initQuestion()
      this.getStudentAnswer(this.sindex)
    },
    next() {
      this.sindex++
      if (this.examLogData[this.sindex].paperId === null) {
        this.next()
        return false
      }
      this.initQuestion()
      this.getStudentAnswer(this.sindex)
    },
    finish() {
      if (this.sindex === this.examLogData.length - 1) {
        this.$confirm('是否提交', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            stuAnswerApi.finishMarke(this.answerId, this.examLogData[this.sindex].isGrading).then(resp => {
              if (resp.code === 0) {
                this.$message({
                  type: 'success',
                  message: '阅卷完成'
                })
                this.dialogObject.show = false
                this.$emit('getList')
              }
            })
          })
      } else {
        this.$confirm('是否提交', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            stuAnswerApi.finishMarke(this.answerId, this.examLogData[this.sindex].isGrading).then(resp => {
              if (resp.code === 0) {
                this.$message({
                  type: 'success',
                  message: '阅卷完成'
                })
                this.next()
              }
            })
          })
      }
    },
    dealChangeMaterialAnswerMarking(item) {
      if (!item.reviseReason) {
        this.$message.error('请输入修正原因')
        return false
      }
      var isCorrect = false
      if (item.value === item.reviseScore) {
        isCorrect = true
      }
      var materialAnswer = {
        pdId: item.pdId,
        materialId: item.materialId,
        reviseReason: item.reviseReason,
        reviseScore: item.reviseScore,
        reviser: this.user.loginName,
        isCorrect: isCorrect
      }
      materialAnswerApi.dealMaterialAnswerMarking(materialAnswer).then(resp => {
        if (resp.code === 0) {
          this.$message({
            message: '保存成功',
            type: 'success'
          })
          item.reviser = this.user.loginName
        } else {
          this.$message({
            message: '保存失败',
            type: 'danger'
          })
        }
      })
    },
    /**
     * 完成阅卷
     */
    finishMarke() {
      this.finish()
    },
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    },
    changeShow(item) {
      item.showFlag = !item.showFlag
      console.log(item)
    },
    // 处理材料小题
    meteraSmallBank(list) {
      list = { ...list, mselectBankList: [], mmultselectBankList: [], mjudgeBnakList: [], mblankBankList: [], mquestanswerBankList: [] }
      console.log(list)
      list.materialQuestions.forEach(item => {
        if (item.tqTypeId.toString() === this.SINGLE) {
          list.mselectBankList.push(item)
        } else if (item.tqTypeId.toString() === this.MULTIPLE) {
          list.mmultselectBankList.push(item)
        } else  if (item.tqTypeId.toString() === this.JUDGEMENT) {
          list.mjudgeBnakList.push(item)
        } else if (item.tqTypeId.toString() === this.FILLBLANK) {
          list.mblankBankList.push(item)
        } else  {
          this.$set(item, 'showFlag', false)
          list.mquestanswerBankList.push(item)
        }
      })
      list.mselectBankList = this.Rendering(list.mselectBankList)
      list.mmultselectBankList = this.Rendering(list.mmultselectBankList)
      list.mjudgeBnakList = this.Rendering(list.mjudgeBnakList)
      list.mblankBankList = this.Rendering(list.mblankBankList)
      return list
    },
    // 渲染选择多选判断题
    Rendering(list) {
      var bankList = []
      list.forEach(bank => {
        var options = []
        const dom = this.collectionToArray(this.parseDom(bank.content))
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text' || (dom[i].nodeName === 'P' && dom[i].innerText.trim() === '')) {
            dom.splice(i, 1)
            i--
          }
        }
        if (
          bank.tqTypeId.toString() === this.SINGLE ||
        bank.tqTypeId.toString() === this.JUDGEMENT ||
        bank.tqTypeId.toString() === this.MULTIPLE
        ) {
          let ol_pos = -1
          for (let i = 0; i < dom.length; i++) {
            if (dom[i].nodeName === 'OL') {
              ol_pos = i
            }
          }
          if (ol_pos > 0) {
            const ol = dom[ol_pos]
            dom.splice(ol_pos, 1)
            let str = ''
            for (let i = 0; i < dom.length; i++) {
              str += dom[i].innerHTML
            }
            bank.content = str
            str = ''
            for (let i = 0; i < ol.children.length; i++) {
              const index = String.fromCharCode(i + 65)
              const item = {}
              item.value = index
              item.label = ol.children[i].innerHTML
              options[i] = item
            }
          }
          bank = { ...bank, options: options, showFlag: false }
          bankList.push(bank)
        } else {
          console.log(bank)
          var content = []
          let k = 1
          for (let i = 0; i < dom.length; i++) {
            content[i] = dom[i].innerHTML
            content[i] = content[i].replace(/<input.*?>/g, '&lt;blank&gt;')
            let index = content[i].indexOf('&lt;blank&gt;', 0)
            console.log(index)
            while (index >= 0) {
              const str = ' ( ' + k + ' ) '
              k++
              content[i] = content[i].replace('&lt;blank&gt;', str)
              index = content[i].indexOf('&lt;blank&gt;', index + 7)
            }
            var objE = document.createElement('p')
            objE.innerHTML = content[i]
            content[i] = objE.outerHTML
          }
          let str = ''
          for (let i = 0; i < content.length; i++) {
            str += content[i]
          }
          content = str
          for (let i = 0; i < k - 1; i++) {
            options[i] = i + 1
          }
          bank = { ...bank, prveContent: content, options: options, showFlag: false }
          bankList.push(bank)
          console.log(bank)
        }
      })
      return bankList
    },
    // 渲染程序填空题
    RenderProgramBlank(list) {
      var bankList = []
      list.forEach(bank => {
        var code = []
        var options = []
        // 题目内容处理
        let dom = this.collectionToArray(this.parseDom(bank.content))
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text' || (dom[i].nodeName === 'P' && dom[i].innerText.trim() === '')) {
            dom.splice(i, 1)
            i--
          }
        }
        let str = ''
        for (let i = 0; i < dom.length; i++) {
          str += dom[i].innerHTML + '<br/>'
        }
        bank.content = str
        // 程序体处理
        dom = this.collectionToArray(this.parseDom(bank.code))
        let k = 1
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text') {
            code[i] = dom[i].nodeValue
            continue
          }
          code[i] = dom[i].outerHTML

          let index = code[i].indexOf('&lt;blank&gt;', 0)
          while (index >= 0) {
            const str = ' ( ' + k + ' ) '
            k++
            code[i] = code[i].replace('&lt;blank&gt;', str)
            index = code[i].indexOf('&lt;blank&gt;', index + 7)
          }
        }
        str = ''
        for (let i = 0; i < code.length; i++) {
          str += code[i]
        }
        code = str
        // 保存填空数，用于绘制答案文本框
        for (let i = 0; i < k - 1; i++) {
          options[i] = i + 1
        }
        bank = { ...bank, code: code, options: options }
        bankList.push(bank)
        console.log(bank)
      })
      return bankList
    },
    downLoad(url, index) {
      const fileExtension =  url.replace(/.+\./, '')
      downloadByLink(this.VUE_APP_FILE_SERVER, url, 'StudentAnswer.' + fileExtension)
    }
  }
}
</script>
<style lang="scss" scoped>
.click {
  cursor: pointer;
}
.fixed_answer_card {
    padding-bottom: 25px;
    top: 80px;
    z-index: 0;
    .answer_card_title_bg {
      height: 110px;
      padding-top: 50px;
    }
    .isFixed {
      position: fixed;
      top: 0;
      right: 20px;
      width: 323px;
      background: #fff;
      border: 1px solid #f6f6f6;
      -webkit-box-shadow: 0 5px 10px #eee;
      box-shadow: 0 5px 10px #eee;
      border-radius: 6px;
    }
}
// .mb30 {
//   margin-bottom: 30px;
// }
::-webkit-scrollbar {
  //滚动条整体样式
  width: 5px;
  height: 5px;
}
::-webkit-scrollbar-thumb {
  //滚动条小方块样式
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #ffb8be;
}
::-webkit-scrollbar-track {
  //滚动条滚动轴样式
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #fff;
}
.answer-card {
  overflow: scroll;
  height: 400px;
  overflow-x: hidden;
}
.dialog-footer{
   position:sticky
}
</style>
<style scoped>
.el-dialog__wrapper /deep/ .el-dialog /deep/ .el-dialog__body {
  height: 80vh;
  overflow-y: auto;
}
.el-dialog__wrapper >>> .el-dialog {
    margin-bottom: 0px;
}
</style>
