<template>
  <el-dialog
    :title="homeworkRecord.hwtitle"
    :visible.sync="correctDialogVisible"
    width="80%"
    center
    top
    @open="open"
    @close="close"
  >
    <div class="js-testpaper-container container mt20">
      <div class="prevent-copy">
        <div class="testpaper-body js-testpaper-body" data-copy="0">
          <div class="es-section js-testpaper-heading">
            <div class="testpaper-titlebar clearfix">
              <h1 class="testpaper-title">
                <p class="testpaper-title__content" title="ewrweq" v-html="homeworkRecord.hwtitle"></p>
                <small class="text-sm">
                  答题人：{{ homeworkRecord.realName }}
                  交卷时间：{{ homeworkRecord.hwSubtime }}
                  是否已批阅：{{ homeworkRecord.isGrading? '是':'否' }}
                </small>
              </h1>
              <div class="testpaper-status">
                <div class="label label-info">{{ homeworkRecord.isGrading? '已批阅':'批阅中' }}</div>
              </div>
            </div>

            <div class="testpaper-description cke_editable cke_contents_ltr">
              <p>学号:{{ homeworkRecord.stuId }}</p>
            </div>
          </div>

          <form id="teacherCheckForm" autocomplete="off" novalidate="novalidate">
            <div class="panel panel-default">
              <div class="panel-heading">
                待批阅题目
                <small class="color-gray">共{{ recordList.length }}题</small>
              </div>

              <div class="panel-body">
                <div v-for="(item, index) in recordList" :key="index" class="question-set-items">
                  <!--材料题-->
                  <div v-if="item.tqTypeId.toString() === material" class="material">
                    <div
                      id="question8"
                      class="well testpaper-question-stem-material js-testpaper-question-stem-material"
                      v-html="item.content"
                    ></div>
                    <div class="mbm">
                      <div
                        class="testpaper-question-analysis js-testpaper-question-analysis"
                        style="display: none;"
                      >
                        <div class="well mb0">无解析</div>
                      </div>
                    </div>

                    <div
                      v-for="(materialItem, materialIndex) in item.materialQuestions"
                      id="question9"
                      :key="materialIndex"
                      class="testpaper-question testpaper-question-essay js-testpaper-question"
                      data-watermark-url="/cloud/testpaper_watermark"
                    >
                      <div class="testpaper-question-body">
                        <div class="clearfix">
                          <div class="testpaper-question-seq-wrap">
                            <div :class="materialItem.grader?'testpaper-question-seq-active':'testpaper-question-seq'">{{ item.tqSeq }}.{{ materialItem.tqSeq }}</div>
                          </div>
                          <div class="testpaper-question-stem" v-html="materialItem.content"></div>
                          （{{ materialItem.value }}分）
                        </div>
                      </div>

                      <div class="testpaper-question-footer clearfix">
                        <div class="testpaper-question-result">
                          <div class="tab-content mbl">
                            <div id="studentAnswer9" class="tab-pane active">
                              学员回答
                              <span
                                :style="{color: item.isCorrect!=''&&item.isCorrect!=null? '#00CC56' : '#E20312'}"
                                v-html="materialItem.userAnswer"
                              ></span>
                            </div>
                            <div id="teacherAnswer9" class="tab-pane active">
                              参考答案:
                              <span class="answer">{{ materialItem.answer }}</span>
                            </div>
                          </div>

                          <div class="form-horizontal">
                            <label
                              class="control-label"
                              style="display: inline-block; margin-right:10px;"
                            >得分</label>
                            <div class="controls" style="display: inline-block">
                              <el-input-number
                                v-model="materialItem.score"
                                controls-position="right"
                                :min="0"
                                :max="materialItem.value"
                                :step="0.5"
                                @change="toGrade(item)"
                              ></el-input-number>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--基础试题类型-->
                  <div
                    v-if="item.tqTypeId.toString() !== material && item.tqTypeId.toString() !==PROGRAMME && item.tqTypeId.toString() !==PROGFILLBLANK && item.tqTypeId.toString() !==FILEUPLOAD "
                    id="question4"
                    class="testpaper-question testpaper-question-essay js-testpaper-question"
                    data-watermark-url="/cloud/testpaper_watermark"
                  >
                    <div class="testpaper-question-body">
                      <div class="clearfix">
                        <div class="testpaper-question-seq-wrap">
                          <div :class="item.grader?'testpaper-question-seq-active':'testpaper-question-seq'">{{ item.tqSeq }}</div>
                        </div>
                        <div class="testpaper-question-stem" v-html="item.content"></div>
                        （{{ item.value }}分）
                      </div>
                    </div>

                    <div class="testpaper-question-footer clearfix">
                      <div class="testpaper-question-result">
                        <div class="tab-content mbl">
                          <div id="studentAnswer4" class="tab-pane active">
                            学员回答:
                            <span
                              :style="{color: item.isCorrect!=''&&item.isCorrect!=null? '#00CC56' : '#E20312'}"
                              v-html="item.userAnswer"
                            ></span>
                          </div>
                          <div id="teacherAnswer4" class="tab-pane active">
                            参考答案:
                            <span class="answer" v-html="item.answer"></span>
                          </div>
                        </div>

                        <div class="form-horizontal">
                          <label
                            class="control-label"
                            style="display: inline-block;margin-right:10px;"
                          >得分</label>
                          <div class="controls" style="display: inline-block">
                            <el-input-number
                              v-model="item.score"
                              controls-position="right"
                              :min="0"
                              :max="item.value"
                              :step="0.5"
                              @change="toGrade(item)"
                            ></el-input-number>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--编程题-->
                  <div
                    v-if="item.tqTypeId.toString() ==PROGRAMME || item.tqTypeId.toString() ==PROGFILLBLANK || item.tqTypeId.toString() ==FILEUPLOAD "
                    id="question4"
                    class="testpaper-question testpaper-question-essay js-testpaper-question"
                    data-watermark-url="/cloud/testpaper_watermark"
                  >
                    <div class="testpaper-question-body">
                      <div class="clearfix">
                        <div class="testpaper-question-seq-wrap">
                          <div :class="item.grader?'testpaper-question-seq-active':'testpaper-question-seq'">{{ item.tqSeq }}</div>
                        </div>
                        <div class="testpaper-question-stem" v-html="item.content"></div>
                        （{{ item.value }}分）
                        <tinymce
                          v-if="item.tqTypeId.toString() ==PROGFILLBLANK"
                          v-model="item.code"
                          plugins="codesample"
                          toolbar="false"
                          menubar="false"
                          inline="true"
                          :height="400"
                        />
                      </div>
                    </div>

                    <div class="testpaper-question-footer clearfix">
                      <div class="testpaper-question-result">
                        <div class="tab-content mbl">
                          <div v-if="item.attachment!==null" class="fz15 cor_2">
                            <span class="">
                              下载学生答案
                              <em class="cor_00c">
                                <el-button
                                  size="small"
                                  style="margin-left:20px"
                                  type="success"
                                  @click="downLoad(item.attachment,index)"
                                >下载</el-button>
                              </em>
                            </span>
                          </div>
                          <div v-else class="fz15 cor_2">
                            <span class>
                              <em class="cor_00c" style="color:#E20312">学生未提交</em>
                            </span>
                          </div>
                        </div>

                        <div class="form-horizontal">
                          <label
                            class="control-label"
                            style="display: inline-block;margin-right:10px;"
                          >得分</label>
                          <div class="controls" style="display: inline-block">
                            <el-input-number
                              v-model="item.score"
                              controls-position="right"
                              :min="0"
                              :max="item.value"
                              :step="0.5"
                              @change="toGrade(item)"
                            ></el-input-number>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!---->
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>

      <div
        id="time-pause-dialog"
        class="modal fade"
        data-backdrop="static"
        tabindex="-1"
        role="dialog"
        aria-hidden="true"
      ></div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-row>
        <el-col :span="8" class="info">
          <span>学号：{{ homeworkRecord.stuId }}</span>
          <span>姓名：{{ homeworkRecord.realName }}</span>
          <span>总分：{{ homeworkRecord.score }}</span>
        </el-col>
        <el-button
          :disabled="!currentIndex>0"
          icon="el-icon-d-arrow-left"
          plain
          @click="previous()"
        >上一个</el-button>
        <el-button :disabled="currentIndex>=list.length-1" type="primary" @click="next()">
          下一个
          <i class="el-icon-d-arrow-right" style="margin-left:5px"></i>
        </el-button>
        <el-button type="success" @click="submitCorrect">完成批阅</el-button>
      </el-row>
    </span>
  </el-dialog>
</template>
<script>
import assignApi from '@/api/exambank/homework-arrange'
import EXAMBANK_CONST from '@/constant/exambank-const'
import homeworkRecordApi from '@/api/exambank/homework-record'
import { downloadByLink } from '@/utils/index'
import Tinymce from '@/components/Tinymce'
export default {
  components: {
    Tinymce
  },
  props: {
    correctDialogVisible: {
      type: Boolean,
      default: true
    },
    current: {
      type: Object,
      default: () => {
        return {}
      }
    },
    list: {
      type: Array,
      default: () => {
        return []
      }
    },
    currentIndex: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      recordList: [],
      // 材料题
      material: EXAMBANK_CONST.MATERIAL,
      // 编程题
      PROGRAMME: EXAMBANK_CONST.PROGRAMME,
      // 程序填空题
      PROGFILLBLANK: EXAMBANK_CONST.PROG_FILLBLANK,
      // 文件上传题
      FILEUPLOAD: EXAMBANK_CONST.FILE_UPLOAD,
      // 文件服务器地址
      VUE_APP_FILE_SERVER: process.env.VUE_APP_FILE_SERVER,
      homeworkRecord: {}
    }
  },

  methods: {
    // 上一个
    previous() {
      if (this.currentIndex > 0) {
        this.submit()
        this.currentIndex--
        this.current = this.list[this.currentIndex]
        this.open()
      }
    },
    // 下一个
    next() {
      if (this.currentIndex < this.list.length - 1) {
        this.submit()
        this.currentIndex++
        this.current = this.list[this.currentIndex]
        this.open()
      }
    },
    open() {
      const hwId = this.current.hwId
      const stuUserId = this.current.stuUserId
      assignApi.selectListBeforeCorrect(hwId, stuUserId).then(resp => {
        this.recordList = resp.data
      })
      this.homeworkRecord = {
        stuUserId: stuUserId,
        hwId: this.current.hwId
      }
      homeworkRecordApi.selectHomeworkRecordListByUserId(this.homeworkRecord).then(resp => {
        this.homeworkRecord = resp.data[0]
        console.log(this.homeworkRecord)
      })
    },
    changeShow(item) {
      item.showFlag = !item.showFlag
      console.log(item)
    },
    // 关闭
    close() {
      this.$emit('update:correctDialogVisible', false)
    },
    submit() {
      assignApi.saveCorrect(this.recordList, this.homeworkRecord.hwrId)
    },
    // 提交批阅
    submitCorrect() {
      this.submit()
      this.$message({
        message: '提交成功！',
        type: 'success'
      })
      setTimeout(() => {
        this.$emit('handleCurrentChange')
      }, 1000)
      this.close()
    },
    // 为试题赋值评分者
    toGrade(questiton) {
      questiton.grader = this.$store.getters.user.realName
    },
    // 下载学生答案
    downLoad(url, index) {
      console.log(url)
      const fileExtension =  url.replace(/.+\./, '')
      downloadByLink(this.VUE_APP_FILE_SERVER, url, 'StudentAnswer.' + fileExtension)
    }
  }
}
</script>
<style lang="scss" scoped>
.mt20 {
  margin-top: 20px !important;
}
@media screen and (min-width: 1200px) {
  .container {
    width: 75vw;
  }
}

// @media (min-width: 992px) {
//   .container {
//     width: 960px;
//   }
// }
// @media (min-width: 768px) {
//   .container {
//     width: 740px;
//   }
// }
.answer {
  color: #00cc56;
}
.js-testpaper-body {
  line-height: 22px;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.56);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  font-family: Helvetica Neue, Helvetica, Arial, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, sans-serif;
  .es-section {
    background: #fff;
    padding: 15px;
    margin-bottom: 20px;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    border: 1px solid #e4ecf3;
    .testpaper-titlebar {
      border-bottom: 1px solid #ddd;
      margin-bottom: 20px;
      .testpaper-title {
        width: 85%;
      }
      .testpaper-status {
        margin-top: 20px;
        float: right;
      }
      .text-sm {
        font-size: 12px !important;
      }
      .testpaper-title {
        float: left;
        font-size: 24px;
        font-weight: 700;
        color: #444;
      }
    }
    .testpaper-description {
      color: #444;
      font-size: 14px;
    }
    .cke_editable {
      font-size: 13px;
      line-height: 1.6;
      word-wrap: break-word;
    }
  }
  .panel-default {
    padding: 0 15px;
    border-color: #e4ecf3;
    .panel-heading {
      position: relative;
      font-size: 16px;
      padding: 10px 0;
      line-height: 30px;
      background: #fff;
      border-bottom: 1px solid #f5f5f5;
    }
    .panel-heading {
      color: #616161;
      border-color: #e1e1e1;
    }
    .panel-heading {
      padding: 10px 15px;
      border-bottom: 1px solid transparent;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
    .panel-body {
      position: relative;
      padding: 15px 0;
      .testpaper-card .panel-card {
        position: relative;
        max-height: 270px;
        overflow: hidden;
        .color-lump {
          position: relative;
          display: inline-block;
          -webkit-border-radius: 4px;
          -moz-border-radius: 4px;
          border-radius: 4px;
          width: 30px;
          height: 30px;
          line-height: 30px;
          text-align: center;
          color: #fff;
          background-color: #e1e1e1;
        }
        .mbm {
          margin-bottom: 10px !important;
        }
        .mrm {
          margin-right: 10px !important;
        }
        .bg-warning {
          background-color: #ffa51f !important;
        }
      }
    }
    .panel-footer {
      padding: 15px 0;
      background: none;
      background-color: #fff;
    }
    .text-right {
      text-align: right !important;
    }
  }
  .panel-default {
    border-color: #e1e1e1;
  }
  .panel {
    margin-bottom: 20px;
    background-color: #fff;
    border: 1px solid transparent;
    border-radius: 4px;
  }
  .panel-default {
    padding: 0 15px;
    border-color: #e4ecf3;
    .panel-heading {
      position: relative;
      font-size: 16px;
      padding: 10px 0;
      line-height: 30px;
      background: #fff;
      border-bottom: 1px solid #f5f5f5;
      color: #616161;
      border-color: #e1e1e1;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
      .color-gray {
        color: #919191 !important;
      }
    }
    .panel-body {
      position: relative;
      padding: 15px 0;
      .testpaper-question:first-child {
        border-top: none;
      }
      .testpaper-question {
        position: relative;
        margin-bottom: 20px;
        font-size: 14px;
        border-top: 1px solid #ccc;
        padding-top: 20px;
        .testpaper-question-seq-wrap {
          float: left;
          width: 40px;
          margin-right: 10px;
          text-align: center;
          .testpaper-question-seq {
            font-size: 20px;
            color: #3a87ad;
          }
          .testpaper-question-seq-active {
            color: #fff;
            background: green;
            border-radius: 3px;
          }
        }
        .testpaper-question-stem {
          margin-bottom: 10px;
          border-bottom: 1px dashed #ddd;
          overflow: hidden;
          zoom: 1;
        }
        .testpaper-question-footer {
          padding-left: 50px;
          .testpaper-question-essay .testpaper-question-result {
            float: none;
            .mbm {
              margin-bottom: 10px !important;
            }
            .nav {
              margin-bottom: 0;
              padding-left: 0;
              list-style: none;
            }
            .mbl {
              margin-bottom: 20px !important;
              .tab-content > .active {
                display: block;
              }
              .tab-content > .tab-pane {
                display: none;
              }
              p {
                margin: 0 0 10px !important;
              }
            }
          }
        }
      }
    }
  }
  .form-horizontal .control-label .controls {
    text-align: right;
    margin-bottom: 0;
    padding-top: 7px;
    display: inline-block;
  }
  .panel {
    margin-bottom: 20px;
    background-color: #fff;
    border: 1px solid transparent;
    border-radius: 4px;
  }
}
.mbl {
  margin-top: 10px;
  margin-bottom: 20px !important;
}
.well {
  background-color: #fff !important;
}
.color-lump {
  position: relative;
  display: inline-block;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  width: 30px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  color: #fff;
  background-color: #e1e1e1;
}
.mbm {
  margin-bottom: 10px !important;
}
.mrm {
  margin-right: 10px !important;
}
.bg-warning {
  background-color: #ffa51f !important;
}
.bg-primary,
.bg-primary-hover:hover,
.bg-success {
  background-color: #5cb85c !important;
}
.color-lump.lump-card {
  color: #616161;
  border: 1px solid #e4ecf3;
  background-color: #fff;
}
.bg-danger {
  background-color: #ed3e3e !important;
}
.color-lump.lump-xs {
  width: 10px;
  height: 10px;
}
.testpaper-card-explain small {
  margin-right: 8px;
}
.mls {
  margin-left: 5px !important;
}
.info {
  display: inline-block;
  text-align: left;
  font-size: 16px;
  font-weight: 600;
  line-height: 40px;
  span {
    margin-right: 20px;
  }
}
</style>
<style scoped>
.el-dialog__wrapper /deep/ .el-dialog /deep/ .el-dialog__body {
  height: 80vh;
  overflow-y: auto;
}
.el-dialog__wrapper >>> .el-dialog {
  margin-bottom: 0px;
}
.testpaper-question-stem /deep/ ol /deep/ li {
  list-style-type: upper-alpha;
  margin-left: 20px;
}
</style>

