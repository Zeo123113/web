<template>
  <div class="cd-detailed-main">
    <section v-loading="loading" class="cd-main__body">
      <!--头部显示作业名称-->
      <el-row class="cd-main__heading course-manage-info__title">
        <el-col :span="21"><span class="hwtitle">当前作业：{{ persualTask.hwTitle }}</span></el-col>
        <el-col :span="3"><el-button type="text" icon="el-icon-d-arrow-left" @click="goback">返回课时</el-button></el-col>
      </el-row>
      <div class="headerSelect">
        <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
          <el-form-item label prop="courseName">
            <el-select v-model="queryParams.isGrading" size="small" placeholder="请选择状态">
              <el-option
                v-for="item in Corrected"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label prop="courseName">
            <el-select v-model="queryParams.isHomework" size="small" placeholder="请选择关键字类型">
              <el-option
                v-for="item in courseSelected"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label prop="conditions">
            <el-input v-model="queryParams.conditions" placeholder="请输入关键字" size="small" />
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              icon="el-icon-search"
              size="mini"
              @click="handleCurrentChange"
            >搜索</el-button>
          </el-form-item>
        </el-form>
      </div>
      <!--列表展示-->
      <el-table
        :data="list"
        style="width: 100%"
      >
        <el-table-column
          fixed
          prop="realName"
          label="姓名"
          align="center"
          width="150"
        >
        </el-table-column>
        <el-table-column
          prop="hwtitle"
          label="作业名称"
          width="120"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="isGrading"
          label="已批阅"
          :formatter="isGradFormat"
          width="120"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="score"
          label="得分"
          width="120"
          sortable
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="hwSubtime"
          label="提交时间"
          width="180"
          sortable
          align="center"
        >
        </el-table-column>
        <el-table-column
          fixed="right"
          label="操作"
          width="100"
          align="center"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              class="assign-item-operation"
              :style="{color: scope.row.isGrading?'#E50112':'#FFA51F'}"
              @click="openRecord(scope.row)"
            >{{ scope.row.isGrading?'重新批阅':'开始批阅' }}</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="page_box mt30 pt10 mb10 tac">
        <el-pagination
          v-if="total>0"
          :current-page="pageIndex"
          :page-size="pageSize"
          layout="prev, pager, next"
          :total="total"
          prev-text="上一页"
          next-text="下一页"
          @current-change="handleCurrentChange"
        ></el-pagination>
      </div>
    </section>
    <!--分页-->
    <!--批阅弹窗-->
    <correctDialog :correct-dialog-visible.sync="correctDialogVisible" :list="list" :current-index="currentIndex" :current="current" @handleCurrentChange="handleCurrentChange"></correctDialog>
  </div>
</template>
<script>
import assignApi from '@/api/exambank/homework-arrange'
import correctDialog from './components/correctDialog'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
export default {
  components: {
    correctDialog
  },
  props: {
    perusalVisible: {
      type: Boolean,
      default: false
    },
    persualTask: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      pageSize: 6,
      pageIndex: 1,
      total: 0,
      // 是试卷批阅还是作业批阅
      isall: false,
      queryParams: {
        isGrading: false,
        isHomework: 0,
        conditions: null,
        createBy: this.$store.getters.user.loginName
      },
      // 试卷或作业列表
      list: [],
      Corrected: [
        {
          value: false,
          label: '待批阅'
        },
        {
          value: true,
          label: '已批阅'
        }
      ],
      courseSelected: [
        {
          value: 0,
          label: '用户名'
        }
      ],
      loading: false,
      // 是否打开批阅弹窗
      correctDialogVisible: false,
      // 当前批阅的对象
      current: {},
      // 当前批阅对象的下标
      currentIndex: null,
      // 作业对象翻译
      courseMgOptions: []
    }
  },
  mounted() {
    this.handleCurrentChange()
    courseMemberGroupApi.getCourseMemberGroupBySchemeId(this.persualTask.schemeId).then(response => {
      this.courseMgOptions = response.data
    })
  },
  methods: {
    // 作业对象翻译
    objectFormat(row) {
      return this.getMgFormat(row.hwArrange.hwobject, this.courseMgOptions)
    },
    getMgFormat(id, options) {
      for (let i = 0; i < options.length; i++) {
        if (id === options[i].id) {
          return options[i].label
        }
        if (options[i].children != null && options[i].children.length > 0) {
          this.getMgFormat(id, options[i].children)
        }
      }
    },
    /** 是否批阅翻译 */
    isGradFormat(row) {
      if (row.isGrading) {
        return '是'
      } else {
        return '否'
      }
    },
    selectHomeworkArrangeEndList(queryParams) {
      assignApi.selectHomeworkArrangeEndList(queryParams, this.pageIndex, this.pageSize).then(resp => {
        this.list = resp.data.list
        this.total = resp.data.total
      })
    },
    handleCurrentChange() {
      console.log(this.persualTask)
      this.queryParams.courseSchemaId = this.persualTask.schemeId
      this.queryParams.hwId = this.persualTask.hwId
      this.selectHomeworkArrangeEndList(this.queryParams)
    },
    // 打开详情
    openRecord(row) {
      this.currentIndex = this.list.indexOf(row)
      this.current = row
      this.correctDialogVisible = true
    },
    // 关闭详情
    goback() {
      this.$emit('goback')
    }
  }
}
</script>

<style lang="scss" scoped>
p {
  text-indent: 2em;
}
.el-main {
  text-align: left;
}
.all {
  font-size: 16px;
  padding: 0 25px;
  height: 35px;
  line-height: 30px;
}
.el-pagination {
  text-align: center;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
  .el-button {
    color: black;
    background-color: transparent;
    border: 0;
  }
}
.all-background {
  color: #fff !important;
  background: #e50012 !important;
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.el-form-item {
  margin-bottom: 0;
}
.headerSelect {
  background-color: #fafafa;
  border: 1px solid #f5f5f5;
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  box-shadow: none;
  padding: 9px;
  border-radius: 2px;
  margin-bottom: 10px;
}
.cd-detailed-main {
  background: #fff;
  .cd-main__body {
    padding: 0px;
    min-height: 500px;
    .hwtitle {
      line-height: 40px;
      font-size: 16px;
      font-weight: 500;
    }
    .nodata {
      p {
        font-size: 16px;
        color: #9199a1;
        text-align: center;
        line-height: 24px;
        margin-bottom: 4px;
      }
    }
  }
  .cd-main__heading {
    padding: 0px;
    box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
    margin-bottom: 15px;
    .cd-main__title {
      font-size: 16px;
      color: rgba(0, 0, 0, 0.88);
      line-height: 1;
      margin: 0 auto;
      font-weight: 500;
    }
  }
}
.homework-record-list {
  .assign-list-item {
    padding: 20px;
    border: 1px solid #dddddd;
    border-radius: 5px;
    margin-top: 10px;
    position: relative;
    padding: 15px;
    background: #fff;
    cursor: pointer;
    border-radius: 5px;
    text-align: left;
    .assign_item_title {
      font-size: 14px;
    }
    span {
      color: #cccccc;
      line-height: 24px;
    }
    .assign-item-operation {
      color: #E50112 !important;
      font-size: 14px;
      cursor: pointer;
    }
  }
}
</style>
