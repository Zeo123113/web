<!--
@description 试卷管理--题库选题--头部搜索组件
@author cpy
-->
<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="题目类型" prop="tqTypeId">
      <el-select v-model="queryParams.tqTypeId" size="small" clearable placeholder="请选择题目类型">
        <el-option
          v-for="dict in questionTypeOptions"
          :key="dict.dictValue"
          :label="dict.dictLabel"
          :value="dict.dictValue"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="题目简述" prop="title">
      <el-input v-model="queryParams.title" placeholder="请输入题目简述" size="small" clearable />
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="queryParams.isShare">共享试题</el-checkbox>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" icon="el-icon-search" size="small" @click="handleQuery">搜索</el-button>
      <el-button icon="el-icon-refresh" size="small" @click="handleRecycleBin('searchForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
export default {
  name: 'HeaderSearch',
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    questionTypeOptions: {
      type: Array,
      required: true
    }
  },
  methods: {
    /** 搜索按钮操作 */
    handleQuery() {
      if (!this.queryParams.isShare) {
        this.queryParams.createBy = this.$store.getters.user.loginName
      }
      const queryParams = { ...this.queryParams }
      this.$emit('handleQuery', queryParams)
    },
    /** 点击了回收站 */
    handleRecycleBin(formName) {
      if (!this.queryParams.isShare) {
        this.queryParams.createBy = this.$store.getters.user.loginName
      }
      this.$refs[formName].resetFields()
      this.dateRange = ''
      this.queryParams.beginTime = null
      this.queryParams.endTime = null
      const queryParams = { ...this.queryParams }
      queryParams.tqTypeId = parseInt(queryParams.tqTypeId)
      this.$emit('handleQuery', queryParams)
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
