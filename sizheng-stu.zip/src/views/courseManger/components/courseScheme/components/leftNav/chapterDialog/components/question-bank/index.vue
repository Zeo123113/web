<!--
@description 试卷管理题库选题试题列表
@author CPY
-->
<template>
  <div>
    <!--搜索框-->
    <header-search
      :query-params="bankSelect"
      :question-type-options="questionTypeOptions"
      @handleQuery="handleQuery"
    ></header-search>
    <!--试题展示-->
    <!--全局分数-->
    <el-form ref="globalValueValidateForm" :rules="globalValueRules" :model="globalValueForm" :inline="true" class="form-inline">
      <el-form-item
        v-if="bankSelect.tqTypeId != MATERIAL"
        label="全局分数"
        prop="value"
      >
        <el-input v-model="globalValueForm.value" size="small" placeholder="请输入全局分数"></el-input>
      </el-form-item>
      <el-form-item
        v-else
        label="小题分数"
        prop="material"
      >
        <el-input v-model="globalValueForm.material" size="small" placeholder="请输入小题分数"></el-input>
      </el-form-item>
    </el-form>
    <!--非材料题-->
    <el-table
      v-if="bankSelect.tqTypeId !== MATERIAL"
      v-loading="loading"
      :data="bankList"
      style="width: 100%"
      tooltip-effect="light"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column label="ID" min-width="55" type="index"></el-table-column>
      <el-table-column label="题目" min-width="350" prop="title" show-overflow-tooltip>
      </el-table-column>
      <el-table-column prop="tqTypeId" label="类型" :formatter="questionTypeFormat" min-width="50"></el-table-column>
      <el-table-column prop="diffLevel" :formatter="diffLevelFormat" label="难度" min-width="50"></el-table-column>
      <el-table-column prop="value" label="分数" min-width="100">
        <template slot-scope="scope">
          <el-input-number v-model="scope.row.value" :disabled="scope.row.materialLists && scope.row.materialLists != [] ? true: false" :min="1" :max="20" size="mini"></el-input-number>
        </template>
      </el-table-column>
    </el-table>
    <!--材料题-->
    <el-table
      v-if="bankSelect.tqTypeId === MATERIAL"
      v-loading="loading"
      :data="bankList"
      row-key="seq"
      style="width: 100%"
      tooltip-effect="light"
      :tree-props="{children: 'materialLists'}"
      @selection-change="handleCheckAllChangeItem"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column label="ID" min-width="55" prop="tqId"></el-table-column>
      <el-table-column label="题目" min-width="350" prop="content" show-overflow-tooltip>
      </el-table-column>
      <el-table-column prop="tqTypeId" label="类型" :formatter="questionTypeFormat" min-width="50"></el-table-column>
      <el-table-column prop="diffLevel" :formatter="diffLevelFormat" label="难度" min-width="50"></el-table-column>
      <!-- <el-table-column prop="value" label="分数" min-width="100">
        <template slot-scope="scope">
          <el-input-number v-model="scope.row.value" :min="1" :max="20" size="mini"></el-input-number>
        </template>
      </el-table-column> -->
    </el-table>
    <!-- 分页控件-->
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="pageQuery"
    />
    <div slot="footer" class="dialog-footer" style="float: right">
      <el-button
        v-if="bankSelect.tqTypeId !== MATERIAL"
        type="primary"
        size="mini"
        @click="saveQuestion()"
      >保存</el-button>
      <el-button
        v-if="bankSelect.tqTypeId === MATERIAL"
        type="primary"
        size="mini"
        @click="saveMATERIALQuestion"
      >保存</el-button>
      <el-button size="mini" @click="closeQuestion()">取消</el-button>
    </div>
    <!--结束试题列表-->
  </div>
</template>
<script>
import assignApi from '@/api/exambank/homework-arrange'
import HeaderSearch from './components/HeaderSearch'
import TypeNumber from '@/constant/question-type-const'
import pagination from '@/components/Pagination/index'
import EXAMBANK_CONST from '@/constant/exambank-const'
import QUESTIONTYPE from '@/constant/question-type-const'

export default {
  components: { HeaderSearch, pagination },
  props: {
    courseId: {
      type: Number,
      default: null
    },
    questionIds: {
      type: String,
      default: null
    }
  },
  data() {
    var validateValue = (rule, value, callback) => {
      if (value === '' || value === null) {
        callback(new Error('全局分数不能为空'))
      } else if (!value.replace(/[^0-9.]/g, '')) {
        callback(new Error('全局分数只能是数字或小数'))
      } else {
        callback()
      }
    }
    return {
      // 全局分数规则
      globalValueRules: {
        value: [
          { validator: validateValue, trigger: 'blur' }
        ],
        material: [{ validator: validateValue, trigger: 'blur' }]
      },
      // 全局分数
      globalValueForm: {
        value: null,
        material: null
      },
      // 试题列表
      bankList: [],
      // 选择试题列表
      checkedQuestions: [],
      // 添加试题
      addQuestionType: false,
      // 是否预览
      IsPreview: true,
      // 富文本
      saveFlag: false,
      loading: false,
      // 选中试题存储
      checkList: [],
      // 分页记录总条数
      total: 1,
      // 默认分页参数
      pageNum: 1,
      // 条数限制
      pageSize: EXAMBANK_CONST.PAGESIZE,
      // 试题类型
      MATERIAL: QUESTIONTYPE.MATERIAL,
      // 材料子题存放数组
      MATERIALItem: [],
      // 查找对象
      bankSelect: {
        courseId: null,
        tqTypeId: EXAMBANK_CONST.SINGLE,
        title: null,
        createBy: null,
        beginTime: null,
        endTime: null,
        isHwAllowed: null,
        isShare: true
      },
      // 难度数据字典
      diffLevelOptions: [],
      // 试题类型数据字典
      questionTypeOptions: [],
      // 打开题库弹窗
      listDialogVisible: false,
      // 选中的试题列表
      multipleSelection: [],
      // 材料题选中试题列表
      multipleMaterialSelection: []
    }
  },
  mounted() {
    this.QuestTypeList = TypeNumber
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.questionTypeOptions = response.data
    })
    // 试题难度数据字典获取
    this.getDataByType('exambank_diff_level').then(response => {
      this.diffLevelOptions = response.data
    })
    // 获取试题列表
    this.$nextTick(() => {
      this.bankSelect.courseId = this.courseId
      this.bankSelect.tqIds = this.questionIds
      this.bankSelect.orgId = this.$store.getters.user.orgId
      this.getQuestionList()
    })
  },
  methods: {
    /** 难易度字典翻译 */
    diffLevelFormat(row) {
      return this.selectDictLabel(this.diffLevelOptions, row.diffLevel)
    },
    /** 试题类型字典翻译 */
    questionTypeFormat(row) {
      return this.selectDictLabel(this.questionTypeOptions, row.tqTypeId.toString())
    },
    getQuestionList() {
      this.checkedQuestions = []
      this.multipleSelection = []
      this.checkList = []
      this.loading = true
      const bankSelect = { ...this.bankSelect }
      bankSelect.tqTypeId = parseInt(bankSelect.tqTypeId)
      // 允许作业使用
      bankSelect.isHwAllowed = true
      // 将已有试题id传值，获取未添加的试题列表
      if (bankSelect.tqTypeId.toString() === this.MATERIAL) {
        assignApi.listQuestions(bankSelect, this.pageNum, this.pageSize).then(response => {
          if (response.code === 0) {
            this.bankList = response.data
            this.loading = false
          }
        })
      } else {
        assignApi.list(bankSelect, this.pageNum, this.pageSize).then(response => {
          if (response.code === 0) {
            this.bankList = response.data.list
            this.total = response.data.total
            this.loading = false
          }
        })
      }
    },
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    },
    // 关闭题库
    closeQuestion() {
      this.$emit('closeQuestion')
    },
    /** 关闭添加试题 */
    closeAddQuestion() {
      this.addQuestionType = false
    },
    /** 打开添加试题 */
    addQuestion() {
      this.addQuestionType = true
    },
    /**
     * 复选框变化时触发
     */
    handleSelectionChange(val) {
      console.log(val)
      this.multipleSelection = val
    },
    /** 保存试题列表 */
    saveQuestion() {
      if (this.multipleSelection.length > 0) {
        this.$refs['globalValueValidateForm'].validate((valid) => {
          if (valid) {
            this.multipleSelection.forEach((item, index) => {
              item.amount = 1
              item.value = this.globalValueForm.value
              this.checkedQuestions.push(item)
            })
            this.closeQuestion()
            this.$emit('saveQuestion', this.checkedQuestions)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      } else {
        this.closeQuestion()
        this.$emit('saveQuestion', this.checkedQuestions)
      }
    },
    // 材料题保存
    saveMATERIALQuestion() {
      this.$refs['globalValueValidateForm'].validate((valid) => {
        if (valid) {
          console.log(this.bankList)
          this.bankList.forEach(item => {
            if (item.checkList.length > 0) {
              item.amount = 1
              item.checkList.forEach(material => {
                material.value = this.globalValueForm.material
              })
              item.value = item.checkList.length * this.globalValueForm.material
              this.checkedQuestions.push(item)
            }
          })
          this.closeQuestion()
          this.$emit('saveQuestion', this.checkedQuestions)
        }
      })
    },
    /** 查询操作，处理条件查询操作 */
    handleQuery() {
      this.getQuestionList()
    },
    // 分页查询
    pageQuery(pagePara) {
      this.getQuestionList()
    },
    // 全选
    // renderHeader() {
    //   this.multipleMaterialSelection = this.bankList
    //   console.log(this.multipleMaterialSelection)
    // },
    // 多选改变
    handleCheckAllChange(val) {
      this.multipleSelection = val
      val.forEach(item => {
        item.checkList = item.materialLists
      })
    },
    // 材料题多选
    handleCheckAllChangeItem(val) {
      val.forEach(question => {
        if (question.materialLists && question.materialLists.length > 0) {
          question.checkList = question.materialLists
        } else {
          this.bankList.forEach(item => {
            if (question.tqId === item.tqId) {
              item.checkList.push(question)
            }
          })
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.QuestionItem {
  border: 1px solid #e3e3e3;
  padding: 20px;
  margin-bottom: 15px;
  width: 100%;
}
.contentItem {
  margin-bottom: 10px;
}
.deletebutton {
  float: right;
}
.el-main {
  padding: 0px;
}
.tqIdTotal {
  border: 1px solid #1890ff;
  color: #1890ff;
  padding: 0 5px;
  border-radius: 10%;
}
.question-footer {
  padding: 0;
  border: none;
  line-height: 30px;
  color: #999;
  font-size: 14px;
  cursor: pointer;
}
.question-value {
  float: right;
}
.MItem {
  margin-left: 2em;
  border-bottom: solid 1px #ccc;
  padding-bottom: 1em;
  margin-bottom: 1em;
}
.MATERIALItem {
  width: 100%;
  min-height: 100px;
}
.dialog-footer {
  margin-top: 20px;
}
</style>
<style scoped>
.editor-content >>> ol {
  margin-left: 32px;
}
.editor-content >>> ol li {
  list-style-type: upper-alpha;
}
</style>
<style lang="scss">
.el-tooltip__popper {
  max-width: 50% !important;
  ol li {
     list-style-type: upper-alpha;
  }
}
.el-popover {
  max-width: 40%;
}
</style>
