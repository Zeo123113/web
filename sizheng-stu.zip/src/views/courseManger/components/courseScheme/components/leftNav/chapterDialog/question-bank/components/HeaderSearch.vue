<!--
@description 试卷管理--题库选题--头部搜索组件
@author cpy
-->
<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="课程章节">
      <treeselect
        v-model="queryParams.chapterId"
        :options="chapterOptions"
        style="display: inline-block;width:220px;"
        placeholder="请选择章节"
      />
    </el-form-item>
    <el-form-item label="知识点">
      <el-select v-model="queryParams.kidList" filterable clearable multiple>
        <el-option
          v-for="item in knowledgeOptions"
          :key="item.knowledgeId"
          :label="item.knowledgeName"
          :value="item.knowledgeId"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="试题难度">
      <el-select v-model="queryParams.diffLevel" clearable>
        <el-option
          v-for="item in diffLevelOptions"
          :key="item.dictValue"
          :label="item.dictLabel"
          :value="item.dictValue"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="题目简述" prop="title">
      <el-input
        v-model="queryParams.title"
        placeholder="请输入题目简述"
        size="small"
        clearable
      />
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="publiced" style="margin：0 20px; margin-right: 50px;">公共题库</el-checkbox>
      <el-button
        type="primary"
        icon="el-icon-search"
        size="mini"
        @click="handleQuery"
      >搜索</el-button>
      <el-button
        icon="el-icon-refresh"
        size="mini"
        @click="handleRecycleBin('searchForm')"
      >重置</el-button>
      <el-button
        type="success"
        icon="el-icon-plus"
        size="mini"
        @click="handleQuery"
      >添加</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
import Treeselect from '@riophae/vue-treeselect'
import chapterApi from '@/api/exambank/chapter'
import knowledgeApi from '@/api/exambank/knowledge'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'HeaderSearch',
  components: {
    Treeselect
  },
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    courseId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      chapterOptions: [],
      diffLevelOptions: [],
      knowledgeOptions: [],
      publiced: false
    }
  },
  // watch: {
  //   publiced: function(val) {
  //     if (val) {
  //       this.queryParams.beginTime = val[0]
  //       this.queryParams.endTime = val[1]
  //     } else {
  //       this.dateRange.time = ''
  //     }
  //   }
  // },
  mounted() {
    console.log(this.courseId)
    chapterApi.getChapterTreeByCourseId(this.courseId).then(response => {
      this.chapterOptions = response.data
      this.knowledgeOptions = []
      this.queryParams.chapterId = null
      this.queryParams.kidList = null
    })
    knowledgeApi.getKnownledgeListByCourseId(this.courseId).then(response => {
      this.knowledgeOptions = response.data
      this.queryParams.kidList = null
    })
    // 试题难度数据字典获取
    this.getDataByType('exambank_diff_level').then(response => {
      this.diffLevelOptions = response.data
    })
  },
  methods: {
    /** 搜索按钮操作 */
    handleQuery() {
      if (this.publiced) {
        this.queryParams.createBy = null
        this.queryParams.isShare = true
      } else {
        this.queryParams.createBy = this.$store.getters.user.loginName
        this.queryParams.isShare = false
      }
      this.queryParams.kidList = JSON.stringify(this.queryParams.kidList)
      this.$emit('handleQuery', this.queryParams)
    },
    /** 点击了回收站 */
    handleRecycleBin(formName) {
      this.$refs[formName].resetFields()
      this.queryParams.chapterId = null
      this.queryParams.kidList = null
      this.queryParams.diffLevel = null
      this.$emit('handleQuery', this.queryParams)
    }
  }
}
</script>
<style scoped>
.el-select >>> .el-select__tags{
  overflow-x: hidden;
}
</style>
