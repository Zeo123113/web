<!--
@description 添加课时-实验任务
@author cgy
-->
<template>
  <el-dialog
    :close-on-click-modal="false"
    :title="experdialog.title"
    :visible.sync="experdialog.show"
    :before-close="closeDialog"
    width="80%"
    @open="openDialog"
  >
    <div class="modal-body">
      <div id="task-create-editor" class="task-create-editor">
        <!-- 头部导航栏 -->
        <ul id="task-create-step" class="es-step es-step-3 clearfix">
          <li class="doing">
            <span class="number" style="background-color: #E50112;border-color:rgb(229, 1, 18)">1</span>
            第一步
          </li>
          <li :class="{'doing': isStep('1') || isStep('2')}">
            <span class="number" :class="{'number_active': isStep('1') || isStep('2')}">2</span>
            第二步
          </li>
          <li :class="{'doing': isStep('2')}">
            <span class="number" :class="{'number_active': isStep('2')}">3</span>
            第三步
          </li>
        </ul>
        <el-form ref="form" :model="form" :rules="rules" label-width="80px">
          <!-- 步骤1 -->
          <el-row v-if="isStep('0')">
            <el-col :span="12">
              <el-form-item label="实验对象" prop="labTaskObject" :label-width="labelWidth">
                <treeselect
                  v-model="form.labTaskObject"
                  :options="courseMemberGroupOptions"
                  style="width:300px"
                  placeholder="请选择实验对象"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="实验标题" prop="experTitle" :label-width="labelWidth">
                <el-input
                  v-model="form.experTitle"
                  type="input"
                  placeholder="请输入实验标题"
                  style="width:300px;"
                />
              </el-form-item>
            </el-col>
            <el-col :span="22">
              <el-form-item label="实验要求" prop="requirement" :label-width="labelWidth">
                <tinymce
                  ref="requirement"
                  v-model="form.requirement"
                  :save-flag="saveFlag"
                  :height="250"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="实验时间" prop="startEndTime" :label-width="labelWidth">
                <el-date-picker
                  v-model="startEndTime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  type="datetimerange"
                  align="right"
                  unlink-panels
                  range-separator="-"
                  start-placeholder="开课时间"
                  end-placeholder="结课时间"
                  :picker-options="pickerOptions"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <!-- 步骤2 -->
          <el-row v-if="isStep('1')">
            <div id="task-create-content" class="task-create-content">
              <el-col :span="22">
                <el-form-item label="实验手册" prop="labManual" :label-width="labelWidth">
                  <el-input
                    v-model="form.labManual"
                    placeholder="上传实验手册"
                    disabled
                    style="margin-bottom:10px;"
                  />
                  <el-upload
                    ref="upload"
                    :action="uploadUrl"
                    :data="fileTag"
                    :limit="1"
                    :before-upload="beforeUploadLabManual"
                    :on-success="uploadSuccess"
                    :on-error="uploadError"
                    :headers="headers"
                    class="p_upload"
                    :auto-upload="false"
                  >
                    <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
                    <el-button
                      style="margin-left: 10px;"
                      size="small"
                      type="success"
                      @click="inputFileSubmitUpload"
                    >上传到服务器</el-button>
                  </el-upload>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="提交结止时间" prop="reportDeadlineTime" :label-width="labelWidth">
                  <el-date-picker
                    v-model="form.reportDeadlineTime"
                    type="datetime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="实验报告提交结止时间"
                    align="right"
                    clearable
                  ></el-date-picker>
                </el-form-item>
              </el-col>
            </div>
          </el-row>
          <!-- 步骤3 -->
          <el-row v-if="isStep('2')">
            <el-col :span="20">
              <el-form-item label="实验报告模板" prop="reportTemplate" :label-width="labelWidth">
                <el-input
                  v-model="form.reportTemplate"
                  placeholder="上传实验报告模板"
                  disabled
                  style="margin-bottom:10px;"
                />
                <el-upload
                  ref="upload"
                  :action="uploadUrl"
                  :data="fileTag"
                  :limit="1"
                  :before-upload="beforeUploadReportTemplate"
                  :on-success="uploadSuccess"
                  :on-error="uploadError"
                  :headers="headers"
                  class="p_upload"
                  :auto-upload="false"
                >
                  <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
                  <el-button
                    style="margin-left: 10px;"
                    size="small"
                    type="success"
                    @click="inputFileSubmitUpload"
                  >上传到服务器</el-button>
                  <div slot="tip" class="el-upload__tip">只能上传jpg、png、gif文件，且不超过2Mb</div>
                </el-upload>
              </el-form-item>
            </el-col>
            <el-col :span="20">
              <el-form-item label="是否允许补交" prop="isAllowDelay" :label-width="labelWidth">
                <el-switch v-model="form.isAllowDelay"></el-switch>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                v-if="form.isAllowDelay"
                label="补交截止时间"
                prop="delayTime"
                :label-width="labelWidth"
              >
                <el-date-picker
                  v-model="form.delayTime"
                  type="datetime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="补交截止时间"
                  align="right"
                  clearable
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="20">
              <el-form-item label="备注" prop="remark" :label-width="labelWidth">
                <el-input v-model="form.remark" type="textarea" placeholder="请输入备注"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </div>
    <!-- 步骤1--下的按钮 -->
    <div v-if="isStep('0')" class="modal-footer">
      <el-button size="mini" class="btn btn-default" @click="first('1')">下一步</el-button>
      <!-- <el-button type="primary" size="mini" class="btn btn-primary" @click="clickFirstSubmit">保存</el-button> -->
    </div>
    <!-- 步骤2--下的按钮 -->
    <div v-if="isStep('1')" class="modal-footer">
      <el-button size="mini" class="btn btn-default" @click="clickStep('0')">上一步</el-button>
      <el-button size="mini" class="btn btn-default" @click="next('2')">下一步</el-button>
      <!-- <el-button type="primary" size="mini" class="btn btn-primary" @click="clickFirstSubmit">保存</el-button> -->
    </div>
    <!-- 步骤3--下的按钮 -->
    <div v-if="isStep('2')" slot="footer" class="dialog-footer">
      <el-button size="mini" class="btn btn-default" @click="last('1')">上一步</el-button>
      <el-button type="primary" size="mini" class="btn btn-primary" @click="clickLastSubmit">保存</el-button>
    </div>
  </el-dialog>
</template>

<script>
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import { getToken } from '@/utils/auth'
import experimentTaskApi from '@/api/course/courseTask/experimentTask'
import Tinymce from '@/components/Tinymce'
export default {
  name: 'ExperChapter',
  components: {
    Treeselect,
    Tinymce
  },
  props: {
    experdialog: {
      type: Object,
      required: true
    },
    courseChapter: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      courseMemberGroupOptions: [],
      labelWidth: '120px',
      startEndTime: '',
      rules: {
        experTitle: [
          { required: true, message: '实验标题不能为空', trigger: 'blur' },
          { min: 3, max: 15, message: '长度在 3 到 15 个字符', trigger: 'blur' }
        ],
        requirement: [
          { required: true, message: '实验要求不能为空', trigger: 'blur' },
          { min: 3, max: 500, message: '长度在 3 到 500 个字符', trigger: 'blur' }
        ],
        labTaskObject: [{ required: true, message: '请选择实验对象', trigger: 'blur' }],
        labManual: [{ required: true, message: '请上传实验手册', trigger: 'blur' }],
        reportTemplate: [{ required: true, message: '请上传实验报告模板', trigger: 'blur' }],
        experStartTime: [{ required: true, message: '请输入开始时间', trigger: 'blur' }],
        experEndTime: [{ required: true, message: '请输入结束时间', trigger: 'blur' }]
      },
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      // 上传文件时文件标签
      fileTag: { fileTag: '' },
      headers: {
        token: getToken()
      },
      uploadUrl: process.env.VUE_APP_BASE_API + '/file/student-files/uploadfile',
      // 步数的标志
      step: '0',
      // 富文本开启标志
      saveFlag: false
    }
  },
  watch: {
    startEndTime: function(val) {
      console.log('val = ', val)
      if (val != null) {
        this.form.experStartTime = val[0]
        this.form.experEndTime = val[1]
      } else {
        this.startEndTime = ''
      }
    }
  },
  methods: {
    // 获取分组对象
    getCourseMember() {
      if (this.courseChapter.schemeId == null || this.courseChapter.schemeId === undefined) {
        return
      }
      courseMemberGroupApi.getCourseMemberGroupBySchemeId(this.courseChapter.schemeId).then(response => {
        this.courseMemberGroupOptions = response.data
        if (response.data.length < 1) {
          this.$message({
            message: '分组对象对应课程分组对象，请先在成员管理中创建课程分组',
            type: 'info'
          })
        }
      })
    },
    // 第一步的下一步
    first(step) {
      // 对表单信息进行校验
      this.$refs['form'].validateField('labTaskObject', (error) => {
        if (!error) {
          this.$refs['form'].validateField('experTitle', (error) => {
            // console.log('error = ', error.length)
            if (!error) {
              this.$refs['form'].validateField('requirement', (error) => {
                if (!error) {
                  if (this.form.experStartTime !== '' && this.form.experEndTime !== '') {
                    this.step = step
                    return true
                  }
                  this.$message({
                    message: '实验时间的开始时间和结束时间必填',
                    type: 'warning'
                  })
                  return false
                }
                return false
              })
            }
            return false
          })
        }
      })
    },
    // 第二步的下一步
    next(step) {
      this.$refs['form'].validateField('labManual', (error) => {
        if (!error) {
          this.step = step
        }
      })
    },
    // 第三步
    last(step) {
      this.$refs['form'].validateField('reportTemplate', (error) => {
        if (!error) {
          if (this.form.isAllowDelay) {
            // 允许补交
            this.$message({
              message: '补交时间必填',
              type: 'warning'
            })
            return
          } else {
            this.step = step
          }
        }
      })
    },
    // 渲染步数
    isStep(step) {
      this.setStep()
      return this.step === step
    },
    setStep() {
      // if (this.step === '0') {
      //   if (this.form.experId > 0) {
      //     this.clickStep('1')
      //   }
      // }
    },
    // 点击第三步的保存
    clickLastSubmit() {
      if (this.form.labManual instanceof Object) {
        this.form.labManual = JSON.stringify(this.form.labManual)
      }
      if (this.form.reportTemplate instanceof Object) {
        this.form.reportTemplate = JSON.stringify(this.form.reportTemplate)
      }
      this.experimentFormSubmit()
    },
    // 点击一步
    clickStep(step) {
      this.step = step
    },
    /** 提交上传文件 */
    inputFileSubmitUpload() {
      this.$refs.upload.submit()
    },
    /** 清除表单验证信息 */
    resetForm() {
      this.startEndTime = ''
      this.$refs['form'].clearValidate()
    },
    /** 关闭弹框 */
    closeDialog() {
      this.resetForm()
      this.experdialog.show = false
      this.step = '0'
    },
    // 实验任务添加或编辑
    experimentFormSubmit() {
      if (this.form.experId === -1) {
        // 保存到数据库
        experimentTaskApi
          .addexperimentTask(this.form)
          .then(response => {
            this.$message({
              type: 'success',
              message: '保存成功!'
            })
            // 关闭弹窗
            this.closeDialog()
            // 刷新页面
            this.$emit('getList')
          })
          .catch(err => {
            console.log(err)
          })
      } else if (this.form.experId > 0) {
        // 修改到数据库
        experimentTaskApi
          .updateexperimentTask(this.form)
          .then(response => {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
            // 关闭弹窗
            this.closeDialog()
            // 刷新页面
            this.$emit('getList')
          })
          .catch(err => {
            console.log(err)
          })
      }
    },
    /** 上传之前检测文件类型及大小 */
    beforeUploadLabManual: function(file) {
      this.fileTag.fileTag = '实验手册'
      this.isLt2k = file.size / 1024 / 1024 < 5 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过5M!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 上传之前检测文件类型及大小 */
    beforeUploadReportTemplate: function(file) {
      this.fileTag.fileTag = '实验报告模板'
      this.isLt2k = file.size / 1024 / 1024 < 5 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过5M!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 文件上传成功时的勾子 */
    uploadSuccess: function(response, file, fileList) {
      this.$refs.upload.clearFiles()
      // console.log('response = ', response)
      if (response.code === 0) {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件成功！',
          type: 'success'
        })
        // 构建json格式
        // {title:"实验一",fileid:122,url:"file.pdf",length:12},
        const studentFile = response.data
        if (studentFile.fileTag === '实验手册') {
          const labManual = {
            title: studentFile.fileName,
            fileId: studentFile.fileIdHexString,
            url: studentFile.fileUrl,
            length: studentFile.fileSize
          }
          this.form.labManual = JSON.stringify(labManual)
        } else if (studentFile.fileTag === '实验报告模板') {
          // {
          //       title:"实验1 报告模板", fileId:11, url:"file.docx"
          //    }
          const reportTemplate = {
            title: studentFile.fileName,
            fileId: studentFile.fileIdHexString,
            url: studentFile.fileUrl
          }
          this.form.reportTemplate = JSON.stringify(reportTemplate)
        }
        console.log('this.form = ', this.form)
      } else {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件失败!' + response.msg,
          type: 'error'
        })
      }
    },
    /** 上传失败时的勾子 */
    uploadError: function(err, file, fileList) {
      this.$refs.upload.clearFiles()
      this.$message({
        message: '上传文件失败!',
        type: 'error'
      })
      console.log(err)
    },
    /** 打开弹窗放入富文本内容 */
    openDialog() {
      this.getCourseMember()
      this.saveFlag = true
      this.editsaveFlag()
    },
    editsaveFlag() {
      setTimeout(() => {
        this.saveFlag = !this.saveFlag
      }, 500)
    }
  }
}
</script>
<style lang="scss" scoped>
.p_upload >>> .el-upload__input {
  display: none;
}
.p_upload >>> .el-upload >>> input {
  display: none;
}
.icon {
  width: 3em;
  height: 3em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-top: 1.5em;
}
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.btn {
  border-radius: 5px;
}
span {
  cursor: pointer;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}

.btn-primary {
  border-color: #e50112;
  background-color: #e50112;
  color: #fff;
}
.btn-default,
.btn-default.disabled:hover,
.btn-default[disabled]:hover {
  color: #616161;
  background-color: #f5f5f5;
  border-color: #dcdcdc;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-type-list .task-create-type-item i {
  display: block;
  font-size: 35px;
  line-height: 1;
  padding-top: 18px;
  margin-bottom: 10px;
}
.task-create-editor .task-create-type-list .task-create-type-item > a {
  height: 110px;
  background-color: #f4f6f8;
  display: block;
  text-align: center;
  color: #919191;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  border: 3px solid #f4f6f8;
}

a {
  text-decoration: none;
}
.task-create-editor .task-create-type-list .task-create-type-item {
  margin-bottom: 20px;
}

.col-xs-3 {
  float: left;
  width: 25%;
}
.task-create-editor .task-create-type-list {
  padding: 0 55px;
  margin-bottom: 0;
  list-style: none;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.es-step li .number {
  width: 20px;
  height: 20px;
  line-height: 18px;
  display: inline-block;
  margin-right: 5px;
  border: 1px solid #e1e1e1;
  background-color: #e1e1e1;
  color: #fff;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}
.es-step.es-step-3 li {
  width: 33.33%;
}

.es-step li {
  float: left;
  padding: 15px;
  list-style-type: none;
  border-bottom: 2px solid #e1e1e1;
  color: #e1e1e1;
  font-size: 14px;
  text-align: center;
}
.es-step li.doing {
  color: #616161;
}
.number_active {
  background-color: #e50112 !important;
  border-color:rgb(229, 1, 18);
}
.es-step li.doing,
.es-step li.done {
  border-color: #e50112;
}
.es-step.es-step-3 li {
  width: 33.33%;
}
.es-step li {
  float: left;
  padding: 15px;
  list-style-type: none;
  border-bottom: 2px solid #e1e1e1;
  color: #e1e1e1;
  font-size: 14px;
  text-align: center;
}
.es-step {
  padding-left: 0;
  margin-bottom: 35px;
}
.task-create-editor {
  padding: 0 20px;
}
.modal-body {
  word-wrap: break-word;
  overflow: hidden;
  padding-left: 20px;
  padding-right: 20px;
}

.modal-body {
  position: relative;
  padding: 15px;
}
.modal-title {
  word-break: break-all;
  color: #313131;
  font-size: 18px;
}

.modal-title {
  margin: 0;
  line-height: 1.42857143;
}
.cd-icon {
  line-height: 1;
}

.cd-icon {
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.close {
  float: right;
  font-size: 21px;
  font-weight: 700;
  line-height: 1;
  color: #000;
  text-shadow: 0 1px 0 #fff;
  opacity: 0.2;
  filter: alpha(opacity=20);
}
.modal-header .close {
  margin-top: -2px;
}

button.close {
  padding: 0;
  cursor: pointer;
  background: transparent;
  border: 0;
  -webkit-appearance: none;
}
.modal-header {
  padding: 15px 20px;
}

.modal-header {
  padding: 15px;
  border-bottom: 1px solid #e5e5e5;
  min-height: 16.42857143px;
}
</style>

