<!--
@description 上传文件弹出框组件
@author zhouhuan
-->
<template>
  <div>
    <el-dialog
      width="60%"
      title="视频文件上传"
      :close-on-click-modal="false"
      :visible="videoFileUploade.show"
      @close="closeVideoDialog('fileUploadForm')"
      @open="openDialog()"
    >
      <el-form ref="fileUploadForm" :model="videoFile" label-width="80px">
        <el-form-item label="文件标签">
          <el-input
            v-model="videoFile.fileTag"
            autocomplete="off"
            placeholder="同一文件的多个标签用空格分隔，不同文件的标签用逗号分隔"
          ></el-input>
        </el-form-item>
        <el-form-item label="文件名">
          <el-input
            v-model="videoFile.fileOriginalName"
            autocomplete="off"
            placeholder="上传文件的新名称，多个文件之间用逗号分隔，不填取原文件名"
          ></el-input>
        </el-form-item>
        <el-alert
          type="warning"
          description="支持上传的文件格式：mp4、avi、rm、rmvb、wmv、ogg、3gp、mov、flv、mkv等。"
          show-icon
        ></el-alert>
      </el-form>
      <!--用于实时显示上传信息-->
      <div class="file-panel">
        <div class="file-list">
          <ul
            v-for="item in fileList"
            :key="item.file.id"
            class="file-item"
            :class="`file-${item.file.id}`"
          >
            <li class="file-type" :class="fileCategory(item.file.ext)"></li>
            <li class="file-name">{{ formatstr(item.file.name,22) }}</li>
            <li class="file-size">{{ fileSize(item.file.size) }}</li>
            <li class="file-status">{{ formatstr(item.info,20) }}</li>
            <li class="file-operate">
              <a title="移除" @click="remove(item.file.id)">
                <i class="el-icon-delete" style="color:#409EFF"></i>
              </a>
            </li>
            <li class="progress"></li>
          </ul>
          <div v-if="!fileList.length" class="no-file">
            <i class="icon-empty-file"></i> 最多可传5个文件,每个文件最大500M
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <div id="picker" style="display:inline-block;margin-right:10px;">选择文件</div>
        <el-button size="small" @click="upload()">开始上传</el-button>
        <el-button size="small" @click="cancel('testCaseForm')">取 消</el-button>
      </div>
    </el-dialog>
    <el-dialog title="系统文件上传" :visible.sync="systemFileUploade.show" width="80%">
      <el-form :model="fileInfo" label-width="80px">
        <el-form-item label="文件标签">
          <el-input v-model="fileInfo.fileTag" placeholder="请输入文件标签,用于文件管理" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="文件名">
          <el-input
            v-model="fileInfo.fileOriginalName"
            placeholder="请输入文件名,用于前端展示"
            autocomplete="off"
          ></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-upload
          ref="upload"
          :action="systemUploadUrl"
          :data="fileInfo"
          :limit="1"
          :before-upload="beforeUpload"
          :on-success="uploadSuccess"
          :on-error="uploadError"
          :headers="headers"
          :auto-upload="false"
          class="p_upload"
        >
          <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
          <el-button
            style="margin-left: 10px;"
            size="small"
            type="success"
            @click="inputFileSubmitUpload"
          >上传到服务器</el-button>
        </el-upload>
      </span>
    </el-dialog>
    <el-dialog title="学生文件上传" :visible.sync="studentFileUploade.show" width="80%">
      <el-form :model="fileInfo" label-width="80px">
        <el-form-item label="文件标签">
          <el-input v-model="fileInfo.fileTag" placeholder="请输入文件标签,用于文件管理" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="文件名">
          <el-input
            v-model="fileInfo.fileOriginalName"
            placeholder="请输入文件名,用于前端展示"
            autocomplete="off"
          ></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-upload
          ref="upload"
          :action="studentUploadUrl"
          :data="fileInfo"
          :limit="1"
          :before-upload="beforeUpload"
          :on-success="uploadSuccess"
          :on-error="uploadError"
          :headers="headers"
          :auto-upload="false"
          class="p_upload"
        >
          <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
          <el-button
            style="margin-left: 10px;"
            size="small"
            type="success"
            @click="inputFileSubmitUpload"
          >上传到服务器</el-button>
        </el-upload>
      </span>
    </el-dialog>
    <el-dialog title="音频文件上传" :visible.sync="audioFileUploade.show" width="80%">
      <el-form :model="fileInfo" label-width="80px">
        <el-form-item label="文件标签">
          <el-input v-model="fileInfo.fileTag" placeholder="请输入文件标签,用于文件管理" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="文件名">
          <el-input
            v-model="fileInfo.fileOriginalName"
            placeholder="请输入文件名,用于前端展示"
            autocomplete="off"
          ></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-upload
          ref="upload"
          :action="audioUploadUrl"
          :data="fileInfo"
          :limit="1"
          :before-upload="beforeUpload"
          :on-success="uploadSuccess"
          :on-error="uploadError"
          :headers="headers"
          :auto-upload="false"
          class="p_upload"
        >
          <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
          <el-button
            style="margin-left: 10px;"
            size="small"
            type="success"
            @click="inputFileSubmitUpload"
          >上传到服务器</el-button>
        </el-upload>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import FILE_CONST from '@/constant/file-const'
import WebUploader from 'webuploader' // 引入webuploder
import { getToken } from '@/utils/auth'
import videoFileApi from '@/api/file/video-file.js'
import mediaFileApi from '@/api/file/media-file'
import { gbSubstr } from '@/utils/index'
export default {
  name: 'FileUploadDialog',
  props: {
    systemFileUploade: {
      type: Object,
      required: true
    },
    studentFileUploade: {
      type: Object,
      required: true
    },
    videoFileUploade: {
      type: Object,
      required: true
    },
    audioFileUploade: {
      type: Object,
      required: true
    },
    fileInfo: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      videoFile: {
        fileId: '',
        fileTag: '',
        md5: '',
        fileName: '',
        fileOriginalName: '',
        ext: '',
        fileSize: 0,
        filePath: '',
        fileUrl: '',
        m3u8: '',
        createBy: '',
        createTime: '',
        updateBy: '',
        updateTime: '',
        fileIdHexString: ''
      },
      headers: {
        token: getToken()
      },
      studentUploadUrl: process.env.VUE_APP_BASE_API + '/file/student-files/upload/info',
      systemUploadUrl: process.env.VUE_APP_BASE_API + '/file/student-files/upload/info',
      audioUploadUrl: process.env.VUE_APP_BASE_API + '/file/audio-files/upload/info',
      videoUploadUrl: process.env.VUE_APP_BASE_API + '/file/video-files/uploadchunk',
      fileList: [],   // 保存选择文件的列表
      uploader: {},   // 上传对象
      fileOriginalNameList: [],
      fileTagList: [],
      fileStatusOptions: [],
      isLt2k: '',
      isedit: false
    }
  },
  watch: {
    fileList: function(oldValue, newValue) {}
  },
  created() {
    // 文件状态获取
    this.getDataByType('video_file_status').then(response => {
      this.fileStatusOptions = response.data
    })
  },
  mounted() {
    /** 添加组件 */
    WebUploader.Uploader.register(
      {
        'before-send-file': 'beforeSendFile',
        'before-send': 'beforeSend',
        'after-send-file': 'afterSendFile'
      },
      {
        // 发送文件前先检查文件是否已存在
        beforeSendFile: function(file) {
          var deferred = WebUploader.Deferred()
          const index = this.getIndexFromFileList(file.id)
          if (index === -1) {
            this.uploader.skipFile(file)
            deferred.reject('查找文件索引失败')
            return deferred.promise()
          }
          // 填充fileOriginalNameList和fileTagList
          if (this.videoFile.fileOriginalName.trim().length > 0) {
            this.fileOriginalNameList = this.videoFile.fileOriginalName.split(',')
          }
          if (this.videoFile.fileTag.trim().length > 0) {
            this.fileTagList = this.videoFile.fileTag.split(',')
          }
          let fileOriginalName = ''
          if (this.fileOriginalNameList.length > 0 && this.fileOriginalNameList.length >= index) {
            fileOriginalName = this.fileOriginalNameList[index]
          } else {
            fileOriginalName = file.name
          }
          const item = this.fileList[index]
          // 向服务端发送请求，检查文件是否存在
          videoFileApi.checkFileExistBeforeSend(item.md5, fileOriginalName, item.file.ext, item.file.size)
            .then(response => {
              if (response.data === FILE_CONST.FILE_UPLOADED_TO_FASTDFS) {
                this.uploader.skipFile(file)
                item.status = FILE_CONST.FILE_UPLOADED_TO_FASTDFS
                this.$set(this.fileList, index, item)
                deferred.reject('文件已上传至文件服务器')
              } else if (response.data === FILE_CONST.FILE_UPLOADED_TO_LOCAL) {
                this.uploader.skipFile(file)
                item.status = FILE_CONST.FILE_UPLOADED_TO_LOCAL
                this.$set(this.fileList, index, item)
                deferred.reject('文件已上传到本地')
              } else {
                item.info = '等待上传'
                item.status = FILE_CONST.FILE_NOT_EXIST
                this.$set(this.fileList, index, item)
                deferred.resolve('等待上传')
              }
            })
            .catch(err => {
              item.info = err
              deferred.reject(err)
            })
          return deferred.promise()
        }.bind(this),

        // 发送文件分块前先检查分块是否已存在
        beforeSend: function(block) {
          var deferred = WebUploader.Deferred()
          const index = this.getIndexFromFileList(block.file.id)
          if (index === -1) {
            deferred.reject('查找文件索引失败')
            return deferred.promise()
          }
          const item = this.fileList[index]
          // 每次上传分块前校验分块，如果已存在分块则不再上传
          videoFileApi.beforeSend(item.md5, block.chunk, block.end - block.start).then(response => {
            if (response.data === FILE_CONST.FILE_CHUNK_EXIST) {
              item.status = FILE_CONST.FILE_CHUNK_EXIST
              deferred.reject(`分块${block.chunk}已存在`)
            } else {
              item.status = FILE_CONST.FILE_CHUNK_NOT_EXIST
              deferred.resolve('分块不存在可以上传')
            }
          })
            .catch(err => {
              item.info = err
              deferred.reject(err)
            })
          // 构建fileMd5参数，上传分块时带上fileMd5
          this.uploader.options.formData.fileMd5 = item.md5
          this.uploader.options.formData.chunk = block.chunk
          return deferred.promise()
        }.bind(this),

        // 文件分块上传完成后，合并文件分块
        afterSendFile: function(file) {
          var deferred = WebUploader.Deferred()
          const index = this.getIndexFromFileList(file.id)
          if (index === -1) {
            deferred.reject('查找文件索引失败')
            return deferred.promise()
          }
          const item = this.fileList[index]
          // 合并分块
          let fileOriginalName = ''
          if (this.fileOriginalNameList.length > 0 && this.fileOriginalNameList.length >= index) {
            fileOriginalName = this.fileOriginalNameList[index]
          } else {
            fileOriginalName = file.name
          }
          videoFileApi
            .afterSendFile(item.md5, fileOriginalName, file.size, file.ext)
            .then(response => {
              item.info = response.msg
              if (response.data === FILE_CONST.MERGE_FILE_FAILED) {
                item.status = FILE_CONST.MERGE_FILE_FAILED
                this.$set(this.fileList, index, item)
                deferred.reject(response.msg)
              } else if (response.data === FILE_CONST.CHECK_FILE_FAILED) {
                item.status = FILE_CONST.CHECK_FILE_FAILED
                this.$set(this.fileList, index, item)
                deferred.reject(response.msg)
              } else {
                item.status = FILE_CONST.MERGE_FILE_SUCCESS
                this.$set(this.fileList, index, item)
                deferred.resolve(response.msg)
              }
            })
            .catch(err => {
              item.info = err
              deferred.reject(err)
            })
          return deferred.promise()
        }.bind(this)
      }
    )
    // 创建uploader对象，配置参数,create一定要放到register的后面，否则register方法不能被调用
    this.uploader = WebUploader.create({
      swf: '@/assets/Uploader.swf', // 上传文件的flash文件，浏览器不支持h5时启动flash
      server: this.videoUploadUrl, // 上传分块的服务端地址，注意跨域问题
      pick: '#picker',
      auto: false, // 手动触发上传
      disableGlobalDnd: true, // 禁掉整个页面的拖拽功能
      compress: false,
      chunked: true, // 是否分块上传
      chunkSize: 5 * 1024 * 1024, // 分块大小（默认5M）
      threads: 3, // 开启多个线程（默认3个）
      prepareNextFile: true, // 允许在文件传输时提前把下一个文件准备好
      headers: this.headers, // Token,防止网关拦截请求
      duplicate: false, // 是否支持重复上传,true为可重复，false为不可重复
      fileNumLimit: 5,   // 验证文件总数量, 超出则不允许加入队列
      fileSingleSizeLimit: 500 * 1024 * 1024, // 验证单个文件大小是否超出限制, 超出则不允许加入队列
      accept: {
        title: '',
        extensions: 'mp4,avi,rm,rmvb,wmv,ogg,3gp,mov,flv,mkv',
        mimeTypes: '.mp4,.avi,.rm,.rmvb,.wmv,.ogg,.3gp,.mov,.flv,.mkv'
      }
    })
    // 将文件添加到队列
    this.uploader.on('fileQueued', file => {
      const index = this.fileList.length
      const obj = { id: index, file: file, md5: '', info: '正在计算MD5...', status: 0, timeCallback: null }
      this.$set(this.fileList, index, obj)
      this.uploader
        .md5File(file, 0, 5 * 1024 * 1024)  // 只计算前5M的MD5
        .then(val => {
          obj.md5 = val
          obj.info = 'MD5计算完成'
          this.$set(this.fileList, index, obj)
        })
        .catch(err => {
          obj.info = err
          this.$set(this.fileList, index, obj)
        })
    })
    // 监控上传进度
    // percentage:代表上传文件的百分比
    this.uploader.on('uploadProgress', (file, percentage) => {
      const index = this.getIndexFromFileList(file.id)
      if (index === -1) {
        return
      }
      const item = this.fileList[index]
      item.info = '已上传' + Math.ceil(percentage * 100) + '%'
      this.$set(this.fileList, index, item)
    })
    // 上传失败触发
    this.uploader.on('uploadError', (file, reason) => {
      const index = this.getIndexFromFileList(file.id)
      if (index === -1) {
        return
      }
      const item = this.fileList[index]
      if (reason !== undefined || reason !== '') {
        item.info = reason
      } else {
        item.info = '文件上传失败'
      }
      this.$set(this.fileList, index, item)
    })

    // 不管成功或者失败，文件上传完成时触发
    this.uploader.on('uploadComplete', (file) => {
      const index = this.getIndexFromFileList(file.id)
      if (index === -1) {
        return
      }
      const item = this.fileList[index]
      if (item.status === FILE_CONST.MERGE_FILE_SUCCESS || item.status === FILE_CONST.FILE_UPLOADED_TO_LOCAL || item.status === FILE_CONST.FILE_UPLOADED_TO_FASTDFS) {
        if (item.status === FILE_CONST.MERGE_FILE_SUCCESS || item.status === FILE_CONST.FILE_UPLOADED_TO_LOCAL) {
          item.status = FILE_CONST.UPLOAD_FILE_TO_FASTDFS
          item.info = '请等待，上传远程服务器中...'
        } else {
          item.info = '文件已上传'
        }
        this.$set(this.fileList, index, item)

        let fileOriginalName = ''
        if (this.fileOriginalNameList.length > 0 && this.fileOriginalNameList.length >= index) {
          fileOriginalName = this.fileOriginalNameList[index]
        } else {
          fileOriginalName = file.name
        }
        let fileTag = ''
        if (this.fileTagList.length > 0 && this.fileTagList.length >= index) {
          fileTag = this.fileTagList[index]
        } else {
          fileTag = ''
        }
        // 上传文件到fastdfs
        this.uploadFileToFastDFS(index, item.md5, fileOriginalName, file.size, file.ext, fileTag)
          .then(response => {
            item.info = response
            this.$set(this.fileList, index, item)
            // 发送转码消息
            return this.sendFileConvertMsg(index, item.md5)
          })
          .then(response => {
            item.info = response
            this.$set(this.fileList, index, item)
            // 查询转码进度
            if (item.timeCallback != null) {
              clearInterval(item.timeCallback)
              item.timeCallback = null
            }
            item.timeCallback = setInterval(() => {
              videoFileApi.getFileStatusByMd5(item.md5).then(response => {
                if (response.data === FILE_CONST.CONVERT_FAILED ||
                    response.data === FILE_CONST.SLICE_UPLOAD_FAILED ||
                    response.data === FILE_CONST.VIDEOFILE_NOT_EXIST ||
                    response.data === FILE_CONST.DOWNLOAD_FILE_FAILED ||
                    response.data === FILE_CONST.SLICE_UPLOAD_SUCCESS) {
                  clearInterval(item.timeCallback)
                  item.timeCallback = null
                }
                item.info = this.selectDictLabel(this.fileStatusOptions, response.data)
                this.$set(this.fileList, index, item)
              })
            }, 3000)
          })
          .catch(err => {
            item.info = err
            this.$set(this.fileList, index, item)
          })
      }
    })
    // 每个分块上传请求后触发
    this.uploader.on('uploadAccept', (file, response) => {
      // console.log(response)
    })
  },
  methods: {
    /** 提交上传文件 */
    inputFileSubmitUpload() {
      this.$refs.upload.submit()
    },
    /**
   * @description 把文件上传到FastDFS
   * @param {number} index 当前上传文件的列表索引
   * @param {string} fileMd5 文件的MD5
   * @param {string} fileOriginalName 文件的原始名称
   * @param {number} fileSize 文件大小
   * @param {string} fileExt 文件扩展名
   * @param {string} fileTag 文件标签
   * @returns {object} 返回json对象，response.data为1代表合并成功，为0代表合并失败
   */
    uploadFileToFastDFS(index, fileMd5, fileOriginalName, fileSize, mimeType, fileExt, fileTag) {
      var deferred = WebUploader.Deferred()
      const item = this.fileList[index]
      videoFileApi
        .uploadFileToFastDFS(fileMd5, fileOriginalName, fileSize, mimeType, fileExt, fileTag)
        .then(response => {
          if (response.msg !== 'success') {
            item.status = FILE_CONST.UPLOAD_FILE_TO_FASTDFS_FAILED
            item.info = response.msg
            this.$set(this.fileList, index, item)
            deferred.reject(item.info)
          } else {
            item.status = FILE_CONST.UPLOAD_FILE_TO_FASTDFS_SUCCESS
            item.info = '上传文件到远程服务器成功'
            this.$set(this.fileList, index, item)
            deferred.resolve(item.info)
          }
        })
        .catch(err => {
          item.info = err
          item.status = FILE_CONST.UPLOAD_FILE_TO_FASTDFS_FAILED
          this.$set(this.fileList, index, item)
          deferred.reject(err)
        })
      if (item.timeCallback != null) {
        clearInterval(item.timeCallback)
        item.timeCallback = null
      }
      item.timeCallback = setInterval(() => {
        videoFileApi.uploadProgress(fileMd5).then(response => {
          if (response.data >= 100 ||
          item.status >= FILE_CONST.UPLOAD_FILE_TO_FASTDFS_FAILED) {
            clearInterval(item.timeCallback)
            item.timeCallback = null
            deferred.resolve('上传文件到远程服务器成功')
            return
          }
          item.info = `向文件服务器已上传${response.data}%`
          this.$set(this.fileList, index, item)
        })
      }, 3000)
      return deferred.promise()
    },
    /**
   * @description 发送文件转码消息
   * @param {number} index 当前上传文件的列表索引
   * @param {string} fileMd5 文件的MD5
   * @returns {object} 返回json对象
   */
    sendFileConvertMsg(index, fileMd5) {
      // 在发送文件转码消息之前，先向父组件传递上传后的文件信息
      mediaFileApi.getMediaFile(fileMd5).then(response => {
        this.$emit('fileInfo', response.data)
      })
      var deferred = WebUploader.Deferred()
      const item = this.fileList[index]
      videoFileApi
        .sendFileConvertMsg(fileMd5)
        .then(response => {
          if (response.data === 0) {
            item.status = FILE_CONST.SEND_FILE_CONVERT_MSG_SUCCESS
            item.info = response.msg
            this.$set(this.fileList, index, item)
            deferred.resolve(item.info)
          } else if (response.data === 1) {
            item.status = FILE_CONST.VIDEO_FILE_FORMAT_NOT_CORRECT
            item.info = response.msg
            this.$set(this.fileList, index, item)
            deferred.reject(item.info)
          } else if (response.data === 2) {
            item.status = FILE_CONST.VIDEO_FILE_NOT_EXIST
            item.info = response.msg
            this.$set(this.fileList, index, item)
            deferred.reject(item.info)
          } else {
            item.status = FILE_CONST.VIDEO_FILE_CONVERT_SUCCESS
            item.info = response.msg
            this.$set(this.fileList, index, item)
            deferred.resolve(item.info)
          }
        })
        .catch(err => {
          item.info = err
          item.status = FILE_CONST.SEND_FILE_CONVERT_MSG_FAILED
          this.$set(this.fileList, index, item)
          deferred.reject(err)
        })
      return deferred.promise()
    },
    /** 取消按钮 */
    cancel(formName) {
      this.videoFileUploade.show = false
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeVideoDialog(formName) {
      this.fileList.forEach(item => {
        if (item.timeCallback != null) {
          clearInterval(item.timeCallback)
          item.timeCallback = null
        }
      })
      this.$refs[formName].clearValidate()
      this.videoFileUploade.show = false
      this.fileList = []
      this.uploader.reset()
    },
    /** 打开窗口时，初始化 */
    openDialog() {
      this.fileList = []
      this.uploader.reset()
    },

    /**
     * @description 格式化字符串为指定长度，字母占1个宽度，汉字占2个宽度
     * @method
     * @param {string} str 要格式化的字符串
     * @param {number} len 要截取的字符串长度
     * @returns {string} 格式化后的字符串，超长部分用“...”表示
     */
    formatstr(str, len) {
      return gbSubstr(str, len)
    },

    /**
     * @description 格式化文件长度
     * @method
     * @param {number} size 文件长度
     * @returns {string} 格式化后的文件长度
     */
    fileSize(size) {
      return WebUploader.Base.formatSize(size)
    },

    /**
     * @description 根据文件扩展名显示不同的图标
     * @method
     * @param {string} ext 文件扩展名
     * @returns {string} 返回图标名称
     */
    fileCategory(ext) {
      let type = ''
      const typeMap = {
        'image': ['gif', 'jpg', 'jpeg', 'png', 'bmp', 'webp'],
        'video': ['mp4', 'avi', 'rm', 'rmvb', 'wmv', 'ogg', '3gp', 'mov', 'flv', 'mkv'],
        'text': ['doc', 'txt', 'docx', 'pages', 'epub', 'pdf', 'numbers', 'csv', 'xls', 'xlsx', 'keynote', 'ppt', 'pptx']
      }
      Object.keys(typeMap).forEach((_type) => {
        const extensions = typeMap[_type]
        if (extensions.indexOf(ext) > -1) {
          type = _type
        }
      })
      const map = { 'image': 'el-icon-picture', 'video': 'el-icon-video-camera', 'text': 'el-icon-document' }
      return map[type]
    },

    /**
     * @description 从文件队列中删除文件
     * @method
     * @param {string} fileId 要删除的文件Id
     * @returns 无
     */
    remove(fileId) {
      let id = null
      this.fileList.forEach(item => {
        if (item.file.id === fileId) {
          id = item.id
        }
      })
      this.fileList.splice(id, 1)
      this.uploader.removeFile(fileId, true)
      this.fileList.forEach((item, index) => {
        item.id = index
        this.$set(this.fileList, index, item)
      })
    },
    /**
     * @description 根据文件id查找文件在文件列表中的索引
     * @method
     * @param {string} fileId 文件Id
     * @returns {number} 文件在文件列表中的索引，找不到返回-1
     */
    getIndexFromFileList(fileId) {
      let fileIndex = -1
      this.fileList.forEach((item, index) => {
        if (item.file.id === fileId) {
          fileIndex = index
        }
      })
      return fileIndex
    },

    /**
     * @description 开始上传文件
     * @method
     * @returns 无
     */
    upload() {
      if (this.fileList.length === 0) {
        this.$message({
          type: 'info',
          message: '请先选择要上传的文件!'
        })
        return
      }
      this.uploader.upload()
    },
    /** 上传之前检测文件类型及大小 */
    videoFileInfo(val) {
      this.$emit('fileInfo', val)
    },
    /** 上传之前检测文件类型及大小 */
    beforeUpload: function(file) {
      this.isLt2k = file.size / 1024 / 1024 < 5 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过5M!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 文件上传成功时的勾子 */
    uploadSuccess: function(response, file, fileList) {
      this.$refs.upload.clearFiles()
      this.closedialog()
      if (response.code === 0) {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件成功！',
          type: 'success'
        })
        // console.log(response.data)
        this.$emit('fileInfo', response.data)
      } else {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件失败!' + response.msg,
          type: 'error'
        })
      }
    },
    /** 上传失败时的勾子 */
    uploadError: function(err, file, fileList) {
      this.$refs.upload.clearFiles()
      this.closedialog()
      this.$message({
        message: '上传文件失败!',
        type: 'error'
      })
      console.log(err)
    },
    closedialog() {
      this.fileInfo.fileTag = ''
      this.fileInfo.fileOriginalName = null
      this.videoFileUploade.show = false
      this.studentFileUploade.show = false
      this.systemFileUploade.show = false
      this.audioFileUploade.show = false
    }
  }
}
</script>
<style lang="scss" scoped>
.p_upload >>> .el-upload__input {
  display: none;
}
.p_upload >>> .el-upload >>> input {
  display: none;
}
.app-main {
  background-color: #f3f3f4;
}
.container-div {
  padding: 0 28px 0 28px;
  height: 100%;
}
.searchbox {
  box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
  background: #fff;
  width: 100%;
  border-radius: 6px;
  margin-top: 10px;
  padding-top: 10px;
  padding-left: 5px;
  padding-bottom: 5px;
}
.el-form--inline .el-form-item {
  margin-right: 10px;
}
.btn {
  border-radius: 50px;
  padding: 8px 10px;
}
.upload-button {
  display: inline-block;
  padding: 0px 10px;
}
.el-dialog__body {
  padding: 10px 20px;
}
#picker div:nth-child(2) {
  display: inline-block;
  background: #1890ff;
  border-radius: 4px;
  padding: 16px 40px;
  overflow: inherit !important;
  text-decoration: none;
  text-indent: 0;
  line-height: 20px;
  position: relative !important;
  top: 12px !important;
  left: 0px !important;
}
#picker div:nth-child(2) > input {
  position: absolute;
  top: 0px;
  left: 0px;
  font-size: 20px;
  opacity: 0;
  width: 100px;
  height: 36px;
}
#picker .webuploader-pick {
  position: absolute;
  top: 0px;
  left: 0px;
  opacity: 0;
}
#picker div:nth-child(2)::before {
  content: '选择文件';
  display: block;
  position: absolute;
  top: 6px;
  right: 15px;
  color: #fff;
  font-size: 12px;
  cursor: pointer;
}
.uploader-list {
  margin-top: 10px;
}
$h-row: 32px;
.file-panel {
  .file-list {
    position: relative;
    background-color: #ffffff;
  }
  .file-item {
    font-size: 14px;
    margin: 0px;
    position: relative;
    height: $h-row;
    line-height: $h-row;
    padding: 0 10px;
    border-bottom: 1px solid #ccc;
    background-color: #fff;
    z-index: 1;
    > li {
      display: inline-block;
    }
  }
  .file-type {
    width: 4%;
    color: #409eff;
  }
  .file-name {
    width: 36%;
    margin-left: 10px;
  }
  .file-size {
    width: 15%;
  }
  .file-status {
    width: 35%;
  }
  .file-operate {
    width: 5%;
    margin: 0px auto;
    text-align: center;
    > a {
      padding: 8px 5px;
      cursor: pointer;
      color: #666;
      &:hover {
        color: #ff4081;
      }
    }
  }
  .progress {
    position: absolute;
    top: 0;
    left: 0;
    height: $h-row - 1;
    width: 0;
    background-color: #e2edfe;
    z-index: -1;
  }
  .no-file {
    display: block;
    height: $h-row;
    line-height: $h-row;
    margin: 0px auto;
    text-align: center;
    font-size: 14px;
  }
}
</style>
<style scoped>
.el-dialog__wrapper >>> .el-dialog{
  margin: 3rem auto !important;
}
.el-dialog__wrapper >>> .el-dialog /deep/ .el-dialog__body {
  max-height: 35rem;
  overflow-y: auto;
}
</style>
