<!--
@description 添加课时-作业任务
@author cgy
-->
<template>
  <el-dialog
    :close-on-click-modal="false"
    :title="homedialog.title"
    :visible.sync="homedialog.show"
    :before-close="closeDialog"
    width="70%"
    top
    @open="openDialog"
  >
    <div class="modal-body">
      <div id="task-create-editor" class="task-create-editor">
        <el-form ref="form" :model="form" :rules="rules" label-width="80px">
          <!-- 步骤1 -->
          <el-row v-if="isStep('0')">
            <el-col :span="12">
              <el-form-item label="作业对象" prop="hwArrange.hwobject" :label-width="labelWidth">
                <treeselect
                  v-model="form.hwArrange.hwobject"
                  :options="courseMemberGroupOptions"
                  style="width:100%"
                  placeholder="请选择作业对象"
                />
                <el-alert
                  v-if="courseMemberGroupOptions.length < 1"
                  type="warning"
                  description="请先到学员管理中添加课程分组"
                  show-icon
                />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="作业标题" prop="hwTitle" :label-width="labelWidth">
                <el-input v-model="form.hwTitle" clearable />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="作业要求" prop="hwdemand" :label-width="labelWidth">
                <el-input
                  v-model="form.hwArrange.hwdemand"
                  type="textarea"
                  :autosize="{ minRows: 2, maxRows: 4}"
                  clearable
                />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="评价方法" prop="evaluationMethod" :label-width="labelWidth">
                <el-radio-group v-model="form.evaluationMethod" @change="changeEvaluationMethod">
                  <el-radio
                    v-for="item in evaluationMethodOptions"
                    :key="item.dictvalue"
                    :label="item.dictValue"
                  >{{ item.dictLabel }}</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="开始时间" prop="hwArrange.startTime" :label-width="labelWidth">
                <el-date-picker
                  v-model="form.hwArrange.startTime"
                  type="datetime"
                  placeholder="选择日期时间"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :disabled="nowTime>form.hwArrange.startTime? true:false"
                  style="width:80%"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="终止时间" prop="hwArrange.hwEndTime" :label-width="labelWidth">
                <el-date-picker
                  v-model="form.hwArrange.hwEndTime"
                  type="datetime"
                  placeholder="选择日期时间"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :disabled="nowTime>form.hwArrange.startTime? true:false"
                  style="width:80%"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-row v-if="isMutualEvaluation">
              <el-col :span="6">
                <el-form-item label="去掉最高分" prop="isTakeoutMax" :label-width="labelWidth">
                  <el-switch v-model="isTakeoutMax"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span="6">
                <el-form-item label="去掉最低分" prop="isTakeoutMin" :label-width="labelWidth">
                  <el-switch v-model="isTakeoutMin"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="作业互评人数" prop="minimumCount" :label-width="labelWidth">
                  <el-input-number v-model="minimumCount" :min="1" :max="10" label="描述文字" />
                </el-form-item>
              </el-col>
            </el-row>
          </el-row>

          <!-- 步骤2 -->
          <el-row v-if="isStep('1')">
            <div id="task-create-content" class="task-create-content">
              <el-row>
                <div v-if="!isBank">
                  <el-button type="text" style="width:100%;" @click="AddQuestion">十 添加作业题</el-button>
                  <QuestionList
                    ref="QuestionList"
                    :question-type-options="questionTypeOptions"
                    :questionlist="questionlist"
                  ></QuestionList>
                </div>
                <div v-if="isBank">
                  <!--题库选题-->
                  <QuestionBank
                    ref="questionBank"
                    :course-id="Number(this.$route.params.csId)"
                    :question-ids="questionIds"
                    @saveQuestion="saveQuestion"
                    @saveMATERIALQuestion="saveMATERIALQuestion"
                    @closeQuestion="closeQuestion"
                  ></QuestionBank>
                </div>
              </el-row>
            </div>
          </el-row>
        </el-form>
      </div>
    </div>
    <!-- 步骤1--下的按钮 -->
    <div v-if="isStep('0')" slot="footer" class="dialog-footer">
      <el-button size="mini" class="btn btn-default" @click="first('1')">下一步</el-button>
    </div>
    <!-- 步骤2--下的按钮 -->
    <div v-if="isStep('1') && !isBank" slot="footer" class="dialog-footer">
      <el-button size="mini" class="btn btn-default" @click="clickStep('0')">上一步</el-button>
      <el-button type="primary" size="mini" class="btn btn-primary" :disabled="nowTime>form.hwArrange.startTime" @click="clickLastSubmit">保 存</el-button>
    </div>
  </el-dialog>
</template>

<script>
import QuestionBank from '../components/question-bank/index.vue'
import homworkTaskApi from '@/api/course/courseTask/homeworkTask'
import COURSE_CONST from '@/constant/course-const'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import QuestionList from '../components/AddQuestionList'
import homeworkArrangeApi from '@/api/exambank/homework-arrange'
export default {
  name: 'HomeworkChapter',
  components: {
    Treeselect,
    QuestionList,
    QuestionBank
  },
  props: {
    homedialog: {
      type: Object,
      required: true
    },
    courseChapter: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 是否提交
      hold: false,
      // 是否显示题库
      isBank: false,
      // 作业评价方法
      evaluationMethodOptions: [],
      // 分组列表
      courseMemberGroupOptions: [],
      // 是否去除最高分
      isTakeoutMax: true,
      // 是否去除最低分
      isTakeoutMin: true,
      // 作业互评人数
      minimumCount: 5,
      // 是否互评
      isMutualEvaluation: false,
      // 试题类型弹窗
      isQuestionTypeDialogVisible: false,
      // 选择试题类型
      selectedRadio: '',
      labelWidth: '120px',
      rules: {
        hwTitle: [{ required: true, message: '请输入作业简述', trigger: 'blur' }],
        startTime: [{ required: true, message: '请选作业开始时间', trigger: 'blur' }],
        hwEndTime: [{ required: true, message: '请选择作业终止时间', trigger: 'blur' }]
      },
      // 步数的标志
      step: '0',
      // 富文本开启标志
      saveFlag: false,
      // 试题类型列表
      questionTypeOptions: [],
      // 试题列表
      questionlist: [],
      // 已有试题列表
      questionIds: null,
      // 当前时间
      nowTime: null
    }
  },
  mounted() {
    // console.log(this.form)
    // 作业评价方法字典获取
    this.getDataByType('course_ht_evaluation_method').then(response => {
      this.evaluationMethodOptions = response.data
      console.log('this.evaluationMethodOptions = ', this.evaluationMethodOptions)
    })
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.questionTypeOptions = response.data
    })
    this.getCourseMember()
  },
  methods: {
    // 第一步的下一步
    first(step) {
      // 对表单信息进行校验
      this.$refs['form'].validateField('hwTitle', (error) => {
        console.log('error = ', error)
        if (!error) {
          if (this.form.hwArrange != null && this.form.hwArrange.hwobject != null && this.form.hwArrange.hwobject !== '') {
            // 时间验证
            if (this.form.hwArrange.startTime != null && this.form.hwArrange.startTime !== '') {
              if (this.form.hwArrange.hwEndTime != null && this.form.hwArrange.hwEndTime !== '') {
                if (this.form.hwArrange.startTime > this.form.hwArrange.hwEndTime) {
                  this.$message({
                    type: 'warning',
                    message: '作业开始时间不能大于终止时间！'
                  })
                  return
                }
              } else {
                this.$message({
                  message: '请选择终止时间',
                  type: 'error'
                })
                return
              }
              if (this.form.hwArrange.isallowdelay && !this.form.hwArrange.delaytime) {
                this.$message({
                  type: 'warning',
                  message: '请设置补交截止时间！'
                })
                return
              }
              if (
                this.form.hwArrange.isallowdelay &&
          this.form.hwArrange.hwEndTime > this.form.hwArrange.delaytime
              ) {
                this.$message({
                  type: 'warning',
                  message: '作业终止时间不能大于作业补交截止时间！'
                })
                return
              }
              this.step = step
              return
            }
            this.$message({
              message: '请选择开始时间',
              type: 'error'
            })
          }
          return false
        }
        return false
      })
    },
    // 获取分组对象
    getCourseMember() {
      if (this.courseChapter.schemeId == null || this.courseChapter.schemeId === undefined) {
        return
      }
      courseMemberGroupApi.getCourseMemberGroupBySchemeId(this.courseChapter.schemeId).then(response => {
        this.courseMemberGroupOptions = response.data
      })
    },
    changeEvaluationMethod(value) {
      this.isMutualEvaluation = value === COURSE_CONST.STUDENT_GRADING
    },
    // 渲染步数
    isStep(step) {
      return this.step === step
    },
    // 点击第三步的保存
    clickLastSubmit() {
      this.submitForm()
    },
    // 点击一步
    clickStep(step) {
      this.step = step
    },
    /** 添加试题 */
    AddQuestion() {
      this.selectedRadio = '0'
      this.isBank = true
      // this.$refs.questionBank.openQuestionBankDialog()
    },
    // 关闭题库
    closeQuestion() {
      this.isBank = false
    },
    // 保存试题
    saveQuestion(list) {
      let groupSeq = 0
      if (this.questionlist.length > 0) {
        groupSeq = Number(this.questionlist[this.questionlist.length - 1].groupSeq) + 1
      } else {
        groupSeq = 1
      }
      list.forEach(item => {
        item.groupSeq = groupSeq
        groupSeq++
      })
      this.questionlist = this.questionlist.concat(list)
      // 按照试题类型排序
      for (let i = 0; i < this.questionlist.length - 1; i++) {
        for (let j = 0; j < this.questionlist.length - i - 1; j++) {
          if (this.questionlist[j].tqTypeId > this.questionlist[j + 1].tqTypeId) {
            const temp = this.questionlist[j]
            this.questionlist[j] = this.questionlist[j + 1]
            this.questionlist[j + 1] = temp
          }
        }
      }
      setTimeout(() => {
        this.isBank = false
      }, 500)
      list.forEach(item => {
        this.questionIds = this.questionIds + ',' + item.tqId
      })
    },
    // 移除试题
    deleteQuestion(tqId) {
      this.questionIds.replace(tqId, 0)
    },
    saveMATERIALQuestion() {},
    // 选择试题类型确定
    submitSelect() {
      this.isQuestionTypeDialogVisible = false
      // this.addQuestionType = true
      this.$refs.questionBank.openQuestionBankDialog()
    },
    /** 清除表单验证信息 */
    resetForm() {
      this.$refs['form'].clearValidate()
    },
    /** 关闭弹框 */
    closeDialog() {
      this.resetForm()
      this.homedialog.show = false
      this.step = '0'
    },
    submitForm() {
      this.hold = true
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.isMutualEvaluation) {
            const jsonObj = {}
            jsonObj.isTakeoutMax = this.isTakeoutMax
            jsonObj.isTakeoutMin = this.isTakeoutMin
            jsonObj.minimumCount = this.minimumCount
            this.form.conditionSet = JSON.stringify(jsonObj)
          }
          this.form.unitId = this.courseChapter.unitId
          this.form.questionlist = this.questionlist
          this.form.hwArrange.isallowdelay = false
          this.AddHomeworkTask(this.form)
        } else {
          this.hold = false
        }
      })
    },
    // 处理新增编辑窗口的提交动作
    AddHomeworkTask(homeworkTask) {
      if (homeworkTask.hwtId === -1) {
        homworkTaskApi
          .addEntry(homeworkTask)
          .then(response => {
            this.$message({
              type: 'success',
              message: '添加成功'
            })
            this.hold = false
            // 关闭弹窗
            this.closeDialog()
            // 刷新页面
            this.$emit('getList')
          })
          .catch(err => {
            console.log(err)
          })
      } else {
        homworkTaskApi
          .updateEntry(homeworkTask)
          .then(response => {
            this.$message({
              type: 'success',
              message: '更新成功'
            })
            this.hold = false
            // 关闭弹窗
            this.closeDialog()
            // 刷新页面
            this.$emit('getList')
          })
          .catch(err => {
            console.log(err)
          })
      }
    },
    openDialog() {
      this.nowTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
      console.log(this.nowTime)
      this.questionIds = null
      if (this.form.hwId !== null) {
        this.form.unitId = this.courseChapter.unitId
        homeworkArrangeApi.getQuestionByAssignId(this.form.hwId).then(resp => {
          this.questionlist = resp.data
          this.questionlist.forEach(item => {
            this.questionIds = this.questionIds + ',' + item.tqId
          })
        })
      } else {
        this.questionlist = []
      }
      this.isMutualEvaluation = this.form.evaluationMethod === COURSE_CONST.STUDENT_GRADING
      if (this.form.hwtId > 0) {
        if (this.isMutualEvaluation) {
          const jsonObj = JSON.parse(this.form.conditionSet)
          this.isTakeoutMax = jsonObj.isTakeoutMax
          this.isTakeoutMin = jsonObj.isTakeoutMin
          this.minimumCount = jsonObj.minimumCount
        }
      }
    },
    /*
     * 获取当前时间
     */
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    },
    /** 打开弹窗放入富文本内容 */
    open() {
      this.saveFlag = true
      this.editsaveFlag()
    },
    editsaveFlag() {
      setTimeout(() => {
        this.saveFlag = !this.saveFlag
      }, 500)
    }
  }
}
</script>
<style lang="scss" scoped>
.p_upload >>> .el-upload__input {
  display: none;
}
.p_upload >>> .el-upload >>> input {
  display: none;
}
.icon {
  width: 3em;
  height: 3em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-top: 1.5em;
}
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.btn {
  border-radius: 5px;
}
span {
  cursor: pointer;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}

.btn-primary {
  border-color: #e50112;
  background-color: #e50112;
  color: #fff;
}
.btn-default,
.btn-default.disabled:hover,
.btn-default[disabled]:hover {
  color: #616161;
  background-color: #f5f5f5;
  border-color: #dcdcdc;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-type-list .task-create-type-item i {
  display: block;
  font-size: 35px;
  line-height: 1;
  padding-top: 18px;
  margin-bottom: 10px;
}
.task-create-editor .task-create-type-list .task-create-type-item > a {
  height: 110px;
  background-color: #f4f6f8;
  display: block;
  text-align: center;
  color: #919191;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  border: 3px solid #f4f6f8;
}

a {
  text-decoration: none;
}
.task-create-editor .task-create-type-list .task-create-type-item {
  margin-bottom: 20px;
}

.col-xs-3 {
  float: left;
  width: 25%;
}
.task-create-editor .task-create-type-list {
  margin-bottom: 0;
  list-style: none;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.es-step li .number {
  width: 20px;
  height: 20px;
  line-height: 18px;
  display: inline-block;
  margin-right: 5px;
  border: 1px solid #e1e1e1;
  background-color: #e1e1e1;
  color: #fff;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}
.es-step.es-step-3 li {
  width: 33.33%;
}

.es-step li {
  float: left;
  padding: 15px;
  list-style-type: none;
  border-bottom: 2px solid #e1e1e1;
  color: #e1e1e1;
  font-size: 14px;
  text-align: center;
}
.es-step li.doing {
  color: #616161;
}
.number_active {
  background-color: #e50112 !important;
  border: 1px solid #e50112 !important;
}
.es-step li.doing,
.es-step li.done {
  border-color: #e50112;
}
.es-step.es-step-3 li {
  width: 33.33%;
}
.es-step li {
  float: left;
  padding: 15px;
  list-style-type: none;
  border-bottom: 2px solid #e1e1e1;
  color: #e1e1e1;
  font-size: 14px;
  text-align: center;
}
.es-step {
  padding-left: 0;
  margin-bottom: 35px;
}
.modal-body {
  position: relative;
  word-wrap: break-word;
  overflow: hidden;
  padding: 0;
}
.modal-title {
  word-break: break-all;
  color: #313131;
  font-size: 18px;
}

.modal-title {
  margin: 0;
  line-height: 1.42857143;
}
.cd-icon {
  line-height: 1;
}

.cd-icon {
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.close {
  float: right;
  font-size: 21px;
  font-weight: 700;
  line-height: 1;
  color: #000;
  text-shadow: 0 1px 0 #fff;
  opacity: 0.2;
  filter: alpha(opacity=20);
}
.modal-header .close {
  margin-top: -2px;
}

button.close {
  padding: 0;
  cursor: pointer;
  background: transparent;
  border: 0;
  -webkit-appearance: none;
}
.modal-header {
  padding: 15px 20px;
}

.modal-header {
  padding: 15px;
  border-bottom: 1px solid #e5e5e5;
  min-height: 16.42857143px;
}
</style>
<style scoped>
.el-dialog__wrapper /deep/ .el-dialog /deep/ .el-dialog__body {
  height: 81vh;
  overflow-y: auto;
}
.el-dialog__wrapper >>> .el-dialog {
  margin-bottom: 0px;
}
</style>
