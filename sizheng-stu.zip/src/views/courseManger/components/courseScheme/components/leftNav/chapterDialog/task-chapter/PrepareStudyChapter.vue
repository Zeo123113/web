<!--
@description 添加预习/学习任务任务
@author cgy
-->
<template>
  <el-dialog
    :close-on-click-modal="false"
    :title="dialog.title"
    :visible.sync="dialog.show"
    :before-close="closedialog"
    width="80%"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="80px">
      <el-row>
        <div class="modal-body">
          <div id="task-create-editor" class="task-create-editor">
            <!-- 头部导航栏 -->
            <ul id="task-create-step" class="es-step es-step-3 clearfix">
              <li class="doing">
                <span class="number" style="background-color: #E50112;border-color:rgb(229, 1, 18)">1</span>
                添加教学任务
              </li>
              <li :class="{'doing': isStep('1') || isStep('2')}">
                <span class="number" :class="{'number_active': isStep('1') || isStep('2')}">2</span>
                设置内容
              </li>
              <li :class="{'doing': isStep('2')}">
                <span class="number" :class="{'number_active': isStep('2')}">3</span>
                设置完成条件
              </li>
            </ul>
            <!-- 步骤1 -->
            <div v-if="isStep('0')" id="task-create-type">
              <form id="step1-form" class="form-horizontal" novalidate="novalidate">
                <ul class="form-group task-create-type-list">
                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('TextTask')">
                      <svg class="icon icon-graphic" aria-hidden="true">
                        <use xlink:href="#icon-31tuwenxiangqing" />
                      </svg>
                      <p>图文</p>
                    </a>
                  </li>
                  <li
                    class="col-xs-3 task-create-type-item js-course-tasks-item"
                    data-role="activityType"
                    data-type="video"
                  >
                    <a @click="clickFirstStep('VideoTask')">
                      <svg class="icon icon-video" aria-hidden="true">
                        <use xlink:href="#icon-icon_video" />
                      </svg>
                      <p>视频</p>
                    </a>
                  </li>
                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('AudioTask')">
                      <svg class="icon icon-audio" aria-hidden="true">
                        <use xlink:href="#icon-yinpin" />
                      </svg>
                      <p>音频</p>
                    </a>
                  </li>

                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('DocTask')">
                      <svg class="icon icon-document" aria-hidden="true">
                        <use xlink:href="#icon-wendang" />
                      </svg>
                      <p>文档</p>
                    </a>
                  </li>

                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('PDFTask')">
                      <svg class="icon icon-document" aria-hidden="true">
                        <use xlink:href="#icon-pdf" />
                      </svg>
                      <p>PDF</p>
                    </a>
                  </li>

                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('PPTTask')">
                      <svg class="icon icon-document" aria-hidden="true">
                        <use xlink:href="#icon-ppt" />
                      </svg>
                      <p>PPT</p>
                    </a>
                  </li>

                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('ExcelTask')">
                      <svg class="icon icon-document" aria-hidden="true">
                        <use xlink:href="#icon-excel" />
                      </svg>
                      <p>Excel</p>
                    </a>
                  </li>

                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('WordTask')">
                      <svg class="icon icon-document" aria-hidden="true">
                        <use xlink:href="#icon-word" />
                      </svg>
                      <p>Word</p>
                    </a>
                  </li>

                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('TxtTask')">
                      <svg class="icon icon-document" aria-hidden="true">
                        <use xlink:href="#icon-wenjian_txt" />
                      </svg>
                      <p>Txt</p>
                    </a>
                  </li>
                  <li class="col-xs-3 task-create-type-item js-course-tasks-item">
                    <a @click="clickFirstStep('DownloadTask')">
                      <svg class="icon icon-document" aria-hidden="true">
                        <use xlink:href="#icon-icon_xiazaiziliaoliang" />
                      </svg>
                      <p>下载资料</p>
                    </a>
                  </li>
                </ul>
              </form>
            </div>
            <!-- 步骤2 -->
            <component
              :is="state"
              v-if="isStep('1')"
              :task="task"
              :dialog="dialog"
              :type="docType"
              :form="form"
              :course-material="courseMaterial"
              :course-scheme="courseChapter"
              @getMaterial="getMaterial"
            />
            <!-- 步骤3 + 下载资料 -->
            <div
              v-if="isStep('2') && isType('RefTask')"
              id="task-create-content"
              class="task-create-content"
            >
              <el-col :span="24">
                <el-form-item label="完成条件" :label-width="formLabelWidth">
                  <span>下载过资料</span>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item label="完成获得积分" prop="score" :label-width="formLabelWidth">
                  <el-input-number v-model="form.score" clearable :min="0" />
                  <span>分</span>
                </el-form-item>
              </el-col>
            </div>
            <!-- 步骤3 + ppt资料 -->
            <div
              v-if="isStep('2') && isState('DocTask')"
              id="task-create-content"
              class="task-create-content"
            >
              <el-col :span="24">
                <el-form-item label="完成条件" :label-width="formLabelWidth">
                  <el-select
                    v-model="form.condition"
                    style="width:217px;"
                    placeholder="请选择完成条件"
                    @change="changePpt()"
                  >
                    <el-option
                      v-for="dict in conditionPptOptions"
                      :key="dict.dictValue"
                      :label="dict.dictLabel"
                      :value="dict.dictValue"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item
                  v-if="form.condition === '2'"
                  label="至少学习"
                  :label-width="formLabelWidth"
                  prop="finshTime"
                >
                  <el-input-number
                    v-model="form.finshTime"
                    style="width:200px;"
                    clearable
                    :min="0"
                    @change="learnPages()"
                  />
                  <span>页</span>
                  <span>(共{{ form.pages }}页)</span>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item label="完成获得积分" prop="score" :label-width="formLabelWidth">
                  <el-input-number v-model="form.score" clearable :min="0" />
                  <span>分</span>
                </el-form-item>
              </el-col>
            </div>
            <!-- 步骤3 + 音频或视频 -->
            <div
              v-if="isStep('2') && !isState('TextTask') && !isState('DocTask') && !isState('RefTask')"
              id="task-create-content"
              class="task-create-content"
            >
              <el-col :span="24">
                <el-form-item label="完成条件" :label-width="formLabelWidth">
                  <el-select
                    v-model="form.condition"
                    style="width:217px;"
                    placeholder="请选择完成条件"
                    @change="change()"
                  >
                    <el-option
                      v-for="dict in conditionOptions"
                      :key="dict.dictValue"
                      :label="dict.dictLabel"
                      :value="dict.dictValue"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item
                  v-if="form.condition === '1'"
                  label="至少观看"
                  :label-width="formLabelWidth"
                  prop="finshTime"
                >
                  <el-input-number
                    v-model="form.finshTime"
                    style="width:200px;"
                    clearable
                    :min="0"
                  />
                  <span>分</span>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item label="完成获得积分" prop="score" :label-width="formLabelWidth">
                  <el-input-number v-model="form.score" clearable :min="0" />
                  <span>分</span>
                </el-form-item>
              </el-col>
            </div>
            <!-- 步骤3 + 图文 -->
            <div
              v-if="isStep('2') && isState('TextTask')"
              id="task-create-content"
              class="task-create-content"
            >
              <el-col :span="24">
                <el-form-item label="至少要学习" prop="textCondition" :label-width="formLabelWidth">
                  <el-input-number v-model="form.textCondition" clearable :min="0" />
                  <span>秒</span>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item label="完成获得积分" prop="textScore" :label-width="formLabelWidth">
                  <el-input-number v-model="form.textScore" clearable :min="0" />
                  <span>分</span>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="学习时间" prop="startEndTime" :label-width="formLabelWidth">
                  <el-date-picker
                    v-model="startEndTime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    type="datetimerange"
                    align="right"
                    unlink-panels
                    range-separator="-"
                    start-placeholder="开始时间"
                    end-placeholder="结束时间"
                    :picker-options="pickerOptions"
                  ></el-date-picker>
                </el-form-item>
              </el-col>
            </div>
          </div>
        </div>
        <!-- 步骤2--下的按钮 -->
        <div v-if="isStep('1')" class="modal-footer">
          <el-button size="mini" class="btn btn-default" @click="clickStep('0')">上一步</el-button>
          <el-button size="mini" class="btn btn-default" @click="next">下一步</el-button>
          <!-- <el-button type="primary" size="mini" class="btn btn-primary" @click="clickFirstSubmit">保存</el-button> -->
        </div>
      </el-row>
    </el-form>
    <!-- 步骤3--下的按钮 -->
    <div v-if="isStep('2')" slot="footer" class="dialog-footer">
      <el-button size="mini" class="btn btn-default" @click="clickStep('1')">上一步</el-button>
      <el-button type="primary" size="mini" class="btn btn-primary" @click="clickLastSubmit">保存</el-button>
    </div>
  </el-dialog>
</template>

<script>
import RefTask from '../task/RefTask'
import DocTask from '../task/DocTask'
import AudioTask from '../task/AudioTask'
import VideoTask from '../task/VideoTask'
import TextTask from '../task/TextTask'
import TestTask from '../task/TestTask'
import DocUpload from '../upload/DocUpload'
import AudioUpload from '../upload/AudioUpload'
import VideoUpload from '../upload/VideoUpload'
// import courseMaterialApi from '@/api/course/courseManage/courseMaterial'
import prepareStudyTaskApi from '@/api/course/courseTask/prepareStudyTask'
import Tinymce from '@/components/Tinymce'
// import PptUploadVue from '../upload/PptUpload.vue'
export default {
  name: 'PrepareStudyChapter',
  components: {
    Tinymce,
    VideoUpload,
    AudioUpload,
    DocUpload,
    TextTask,
    VideoTask,
    AudioTask,
    TestTask,
    DocTask,
    RefTask
  },
  props: {
    dialog: {
      type: Object,
      required: true
    },
    courseChapter: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    },
    task: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 文件上传后的资料数据
      material: {},
      docType: '',
      conditionPptOptions: [
        {
          dictValue: '0',
          dictLabel: '学习到最后'
        },
        {
          dictValue: '2',
          dictLabel: '学习页数'
        }
      ],
      conditionOptions: [
        {
          dictValue: '0',
          dictLabel: '学习到最后'
        },
        {
          dictValue: '1',
          dictLabel: '学习时长'
        }
      ],
      startEndTime: '',
      state: '',
      rules: {
        textCondition: [{ required: true, message: '请输入时长', trigger: 'blur' }],
        textScore: [{ required: true, message: '请输入获得积分', trigger: 'blur' }]
      },
      // 步数的标志
      step: '0',
      // 第一步选择的内容类型标志(text,)
      type: '',
      // 富文本开启标志
      saveFlag: false,
      // 表单属性宽度
      formLabelWidth: '120px',
      courseMaterial: {
        materialId: -1,
        orgId: null,
        ctId: this.courseChapter.ctId,
        csId: this.courseChapter.csId,
        schemeId: this.courseChapter.schemeId,
        unitId: null,
        materialTitle: null,
        fileUrl: null,
        fileId: null,
        fileName: null,
        fileMime: null,
        fileSize: null,
        mediaLength: 0,
        isPublic: true,
        isCanDownload: true,
        remark: null
      },
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      }
    }
  },
  watch: {
    startEndTime: function(val) {
      // console.log('val = ', val)
      if (val != null) {
        this.form.startTime = val[0]
        this.form.stopTime = val[1]
      } else {
        this.startEndTime = ''
      }
    }
  },
  methods: {
    learnPages() {
      if (this.form.pages < this.form.finshTime) {
        this.$message({
          type: 'warning',
          message: '不能超过总页数'
        })
      }
    },
    change() {
      if (this.form.condition === '0') {
        this.form.finshTime = ''
      }
      this.$forceUpdate()
    },
    changePpt() {
      if (this.form.condition === '0') {
        this.form.finshTime = ''
      }
    },
    getMaterial(val) {
      this.material = { ...val }
    },
    // 文件上传类型
    fileUploadType() {
      return this.isType('video') || this.isType('audio') || this.isType('doc') || this.isType('ppt') || this.isType('download')
    },
    // 渲染类型
    isType(type) {
      return this.type === type
    },
    isState(state) {
      return this.state === state
    },
    // 渲染步数
    isStep(step) {
      this.setStep()
      return this.step === step
    },
    setStep() {
      if (this.step === '0') {
        // 判断是否为修改
        // console.log('this.dialog.type = ', this.dialog.type)
        // console.log('setStep---this.form = ', this.form)
        if (this.dialog.title === '修改预习任务' || this.dialog.title === '修改学习任务') {
          this.material = { ...this.task }
          if (this.dialog.type === 'ppt') {
            this.clickFirstStep('PPTTask')
          } else if (this.dialog.type === '图文') {
            this.clickFirstStep('TextTask')
          } else if (this.dialog.type === 'video') {
            // 获取文件数据
            const videoMaterials = this.form.videoMaterials
            // 查找元素
            const video2Index = videoMaterials.findIndex((item) => item.fileId === this.task.fileId)
            const video = videoMaterials[video2Index]
            this.task.score = video.score
            this.form.score = video.score
            this.clickFirstStep('VideoTask')
            // this.$emit('fileLastInfo', video)
          } else if (this.dialog.type === '音频') {
            this.clickFirstStep('AudioTask')
          } else if (this.dialog.type === '文档') {
            this.clickFirstStep('DocTask')
          } else if (this.dialog.type === 'excel') {
            this.clickFirstStep('ExcelTask')
          } else if (this.dialog.type === 'pdf') {
            this.clickFirstStep('PDFTask')
          } else if (this.dialog.type === 'Txt') {
            this.clickFirstStep('TxtTask')
          } else if (this.dialog.type === 'word') {
            this.clickFirstStep('WordTask')
          } else if (this.dialog.type === 'download') {
            this.clickFirstStep('RefTask')
          }
          // this.clickStep('1')
        }
      }
    },
    // 对第二步的表单校验
    next() {
      const condition = this.form.condition
      if (condition === '' || condition === undefined || condition == null) {
        this.form.condition = '0'
      }
      // this.form.textCondition = 0
      // 将文件信息赋值
      if (this.state === 'VideoTask') {
        const videoMaterials = this.form.videoMaterials
        // 编辑
        if (this.dialog.title === '修改预习任务' || this.dialog.title === '修改学习任务') {
          // const audioMaterials = this.form.audioMaterials
          console.log('videoMaterials = ', videoMaterials)
          // 查找元素
          const video3Index = videoMaterials.findIndex((item) => item.fileId === this.task.fileId)
          let video = videoMaterials[video3Index]
          if (this.material.fileId !== undefined) {
            video = { ...this.material }
          }
          video.title = this.form.fileTitle
          this.form.videoMaterials[video3Index] = { ...video }
        } else {
          // 添加
          this.material.title = this.form.fileTitle
          this.form.videoMaterials.push(this.material)
        }
      } else if (this.state === 'AudioTask') {
        const audioMaterials = this.form.audioMaterials
        // 编辑
        if (this.dialog.title === '修改预习任务' || this.dialog.title === '修改学习任务') {
          console.log('audioMaterials = ', audioMaterials)
          // 查找元素
          const audioIndex = audioMaterials.findIndex((item) => item.fileId === this.task.fileId)
          console.log('audioIndex = ', audioIndex)
          let audio = audioMaterials[audioIndex]
          if (audio != null) {
            audio = { ...this.material }
          }
          audio.title = this.form.fileTitle
          this.form.audioMaterials[audioIndex] = { ...audio }
        } else {
          // 添加
          this.material.title = this.form.fileTitle
          this.form.audioMaterials.push(this.material)
        }
      } else if (this.state === 'DocTask') {
        // 编辑
        if (this.dialog.title === '修改预习任务' || this.dialog.title === '修改学习任务') {
          if (this.docType === 'doc' || this.docType === 'ppt' || this.docType === 'pdf' || this.docType === 'excel' || this.docType === 'word' || this.docType === 'txt') {
            const pptMaterials = this.form.pptMaterials
            // 查找元素
            const docIndex = pptMaterials.findIndex((item) => item.fileId === this.task.fileId)
            let ppt = pptMaterials[docIndex]
            if (this.material.fileId !== undefined) {
              ppt = { ...this.material }
            }
            ppt.title = this.form.fileTitle
            this.form.pptMaterials[docIndex] = { ...ppt }
          }
        } else {
          // 添加
          if (this.docType === 'doc' || this.docType === 'ppt' || this.docType === 'excel' || this.docType === 'word' || this.docType === 'pdf' || this.docType === 'txt') {
            this.material.title = this.form.fileTitle
            this.form.pptMaterials.push(this.material)
          }
        }
      } else if (this.state === 'RefTask') {
        // 编辑
        if (this.dialog.title === '修改预习任务' || this.dialog.title === '修改学习任务') {
          if (this.docType === 'download') {
            const refMaterials = this.form.refMaterials
            // 查找元素
            const refIndex = refMaterials.findIndex((item) => item.fileId === this.task.fileId)
            let ref = refMaterials[refIndex]
            if (this.material.fileId !== undefined) {
              ref = { ...this.material }
            }
            ref.title = this.form.fileTitle
            this.form.refMaterials[refIndex] = { ...ref }
          }
        } else {
          // 添加
          if (this.docType === 'download') {
            this.material.title = this.form.fileTitle
            this.form.refMaterials.push(this.material)
          }
        }
      }
      console.log('this.form = ', this.form)
      // 校验文件信息
      if (this.state === 'TextTask') {
        if (this.form.psTitle !== '' && this.form.psTitle.length > 1 && this.form.psTitle.length < 50) {
          if (this.form.textMaterials !== null && this.form.textMaterials !== '') {
            // 进入第三步
            this.clickStep('2')
          } else {
            this.$message({
              type: 'error',
              message: '图文内容不能为空'
            })
          }
        } else {
          this.$message({
            type: 'error',
            message: '标题不能为空，且长度大于1，小于50个字符'
          })
        }
      } else if (this.state === 'VideoTask') {
        console.log('this.form.videoMaterials = ', this.form.videoMaterials)
        if (this.form.fileTitle !== '' && this.form.fileTitle.length > 1 && this.form.fileTitle.length < 50) {
          if (this.material.fileId !== undefined) {
            // 进入第三步
            this.clickStep('2')
            return
          } else {
            this.$message({
              type: 'error',
              message: '请上传视频资料'
            })
            return
          }
        } else {
          this.$message({
            type: 'error',
            message: '标题不能为空，且长度大于1，小于50个字符'
          })
          return
        }
      } else if (this.state === 'AudioTask') {
        if (this.form.fileTitle !== '' && this.form.fileTitle.length > 1 && this.form.fileTitle.length < 50) {
          if (this.material.fileId !== undefined) {
            // 进入第三步
            this.clickStep('2')
            return
          } else {
            this.$message({
              type: 'error',
              message: '请上传音频资料'
            })
            return
          }
        } else {
          this.$message({
            type: 'error',
            message: '标题不能为空，且长度大于1，小于50个字符'
          })
          return
        }
      } else if (this.state === 'DocTask') {
        if (this.form.fileTitle !== '' && this.form.fileTitle.length > 1 && this.form.fileTitle.length < 50) {
          if (this.material.fileId !== undefined) {
            // 进入第三步
            this.clickStep('2')
            return
          } else {
            this.$message({
              type: 'error',
              message: '请上传文件资料'
            })
            return
          }
        } else {
          this.$message({
            type: 'error',
            message: '标题不能为空，且长度大于1，小于50个字符'
          })
          return
        }
      } else if (this.state === 'RefTask') {
        this.form.condition = '0'
        if (this.form.fileTitle !== '' && this.form.fileTitle.length > 1 && this.form.fileTitle.length < 50) {
          if (this.material.fileId !== undefined) {
            // 进入第三步
            this.clickStep('2')
            return
          } else {
            this.$message({
              type: 'error',
              message: '请上传下载资料'
            })
          }
        } else {
          this.$message({
            type: 'error',
            message: '标题不能为空，且长度大于1，小于50个字符'
          })
        }
      }
      // this.clickStep('2')
    },
    // 点击第三步的保存
    clickLastSubmit() {
      // 校验完成条件和完成时间，完成获得积分
      if (this.form.condition === '1' && this.form.finshTime == null) {
        this.$message({
          type: 'error',
          message: '请选择完成时间'
        })
      } else {
        // 将文件信息赋值
        if (this.state === 'TextTask') {
          this.$refs['form'].validateField('textScore', (error) => {
            if (!error) {
              this.$refs['form'].validateField('textCondition', (error) => {
                if (!error) {
                  if (this.form.startTime > this.form.stopTime) {
                    this.$message({
                      type: 'warning',
                      message: '预学习任务开始时间不能大于终止时间！'
                    })
                  } else {
                    this.prepareStudyFormSubmit()
                    return
                  }
                }
              })
            }
          })
        } else if (this.state === 'VideoTask') {
          if (this.form.score == null || this.form.score < 0) {
            this.$message({
              type: 'warning',
              message: '积分不能为空'
            })
            return
          }
          console.log('this.form.videoMaterials = ', this.form.videoMaterials)
          const videoMaterials = this.form.videoMaterials
          // 查找元素
          const videoIndex = videoMaterials.findIndex((item) => item.fileId === this.material.fileId)
          const video = videoMaterials[videoIndex]
          video.score = this.form.score
          video.condition = this.form.condition
          video.finshTime = this.form.finshTime
          video.type = 'video'
          this.form.videoMaterials[videoIndex] = { ...video }
          this.prepareStudyFormSubmit()
          return
        } else if (this.state === 'AudioTask') {
          if (this.form.score == null || this.form.score < 0) {
            this.$message({
              type: 'warning',
              message: '积分不能为空'
            })
            return
          }
          const audioMaterials = this.form.audioMaterials
          console.log('audioMaterials = ', audioMaterials)
          // 查找元素
          const audio2Index = audioMaterials.findIndex((item) => item.fileId === this.material.fileId)
          const audio = audioMaterials[audio2Index]
          audio.score = this.form.score
          audio.condition = this.form.condition
          audio.finshTime = this.form.finshTime
          audio.type = 'audio'
          this.form.audioMaterials[audio2Index] = { ...audio }
          this.prepareStudyFormSubmit()
          return
        } else if (this.state === 'DocTask') {
          if (this.form.score == null || this.form.score < 0) {
            this.$message({
              type: 'warning',
              message: '积分不能为空'
            })
            return
          }
          if (this.form.pages < this.form.finshTime) {
            this.$message({
              type: 'warning',
              message: '不能超过总页数'
            })
            return
          }
          if (this.docType === 'doc' || this.docType === 'ppt' || this.docType === 'pdf' || this.docType === 'excel' || this.docType === 'word' || this.docType === 'txt') {
            const pptMaterials = this.form.pptMaterials
            const fileId = this.material.fileId
            // 查找元素
            const pptIndex = pptMaterials.findIndex(item => item.fileId === fileId)
            const ppt = pptMaterials[pptIndex]
            ppt.score = this.form.score
            ppt.condition = this.form.condition
            ppt.finshTime = this.form.finshTime
            ppt.type = this.docType
            this.form.pptMaterials[pptIndex] = { ...ppt }
            this.prepareStudyFormSubmit()
            return
          }
        } else if (this.state === 'RefTask') {
          if (this.form.score == null || this.form.score < 0) {
            this.$message({
              type: 'warning',
              message: '积分不能为空'
            })
            return
          }
          if (this.docType === 'download') {
            const refMaterials = this.form.refMaterials
            // 查找元素
            const refIndex = refMaterials.findIndex((item) => item.fileId === this.material.fileId)
            const ref = refMaterials[refIndex]
            ref.score = this.form.score
            ref.condition = this.form.condition
            ref.finshTime = this.form.finshTime
            ref.type = this.docType
            this.form.refMaterials[refIndex] = { ...ref }
            this.prepareStudyFormSubmit()
            return
          }
        }
      }
    },
    // 点击一步
    clickStep(step) {
      this.step = step
    },
    // 点击文档
    clickFirstStep(type) {
      if (type === 'PPTTask') {
        this.docType = 'ppt'
        type = 'DocTask'
      } else if (type === 'PDFTask') {
        this.docType = 'pdf'
        type = 'DocTask'
      } else if (type === 'ExcelTask') {
        this.docType = 'excel'
        type = 'DocTask'
      } else if (type === 'WordTask') {
        this.docType = 'word'
        type = 'DocTask'
      } else if (type === 'TxtTask') {
        this.docType = 'txt'
        type = 'DocTask'
      } else if (type === 'DownloadTask') {
        this.docType = 'download'
        type = 'RefTask'
      } else if (type === 'DocTask') {
        this.docType = 'doc'
        type = 'DocTask'
      }
      this.type = type
      this.state =  type
      this.clickStep('1')
    },
    /** 清除表单验证信息 */
    resetForm() {
      this.$refs['form'].clearValidate()
    },
    /** 关闭弹框 */
    closedialog() {
      this.resetForm()
      this.dialog.show = false
      this.dialog.title = ''
      this.dialog.type = ''
      this.type = ''
      this.step = '0'
      // 刷新页面
      this.$emit('fetchData')
    },
    // 预习/学习任务添加或编辑
    prepareStudyFormSubmit() {
      const form =  { ...this.form }
      form.pptMaterials = JSON.stringify(this.form.pptMaterials)
      form.refMaterials = JSON.stringify(this.form.refMaterials)
      form.audioMaterials = JSON.stringify(this.form.audioMaterials)
      form.videoMaterials = JSON.stringify(this.form.videoMaterials)
      if (this.form.pstId === -1) {
        form.totalMaterials = form.totalMaterials + 1
        // 保存到数据库
        prepareStudyTaskApi
          .addFrontStudyTask(form)
          .then(response => {
            this.$message({
              type: 'success',
              message: '保存成功!'
            })
            // 关闭弹窗
            this.closedialog()
          })
          .catch(err => {
            console.log(err)
          })
      } else if (this.form.pstId > 0) {
        // 修改到数据库
        prepareStudyTaskApi
          .updateFrontStudyTask(form)
          .then(response => {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
            // 关闭弹窗
            this.closedialog()
          })
          .catch(err => {
            console.log(err)
          })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.icon {
  width: 3em;
  height: 3em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-top: 1.5em;
}
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.btn {
  border-radius: 5px;
}
span {
  cursor: pointer;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}

.btn-primary {
  border-color: #e50112;
  background-color: #e50112;
  color: #fff;
}
.btn-default,
.btn-default.disabled:hover,
.btn-default[disabled]:hover {
  color: #616161;
  background-color: #f5f5f5;
  border-color: #dcdcdc;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-type-list .task-create-type-item i {
  display: block;
  font-size: 35px;
  line-height: 1;
  padding-top: 18px;
  margin-bottom: 10px;
}
.task-create-editor .task-create-type-list .task-create-type-item > a {
  height: 110px;
  background-color: #f4f6f8;
  display: block;
  text-align: center;
  color: #919191;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  border: 3px solid #f4f6f8;
}

a {
  text-decoration: none;
}
.task-create-editor .task-create-type-list .task-create-type-item {
  margin-bottom: 20px;
}

.col-xs-3 {
  float: left;
  width: 25%;
}
.task-create-editor .task-create-type-list {
  padding: 0 55px;
  margin-bottom: 0;
  list-style: none;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.es-step li .number {
  width: 20px;
  height: 20px;
  line-height: 18px;
  display: inline-block;
  margin-right: 5px;
  border: 1px solid #e1e1e1;
  background-color: #e1e1e1;
  color: #fff;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}
.es-step.es-step-3 li {
  width: 33.33%;
}

.es-step li {
  float: left;
  padding: 15px;
  list-style-type: none;
  border-bottom: 2px solid #e1e1e1;
  color: #e1e1e1;
  font-size: 14px;
  text-align: center;
}
.es-step li.doing {
  color: #616161;
}
.number_active {
  background-color: #e50112 !important;
  border-color:rgb(229, 1, 18);
}
.es-step li.doing,
.es-step li.done {
  border-color: #e50112;
}
.es-step.es-step-3 li {
  width: 33.33%;
}
.es-step li {
  float: left;
  padding: 15px;
  list-style-type: none;
  border-bottom: 2px solid #e1e1e1;
  color: #e1e1e1;
  font-size: 14px;
  text-align: center;
}
.es-step {
  padding-left: 0;
  margin-bottom: 35px;
}
.task-create-editor {
  padding: 0 20px;
}
.modal-body {
  word-wrap: break-word;
  overflow: hidden;
  padding-left: 20px;
  padding-right: 20px;
}

.modal-body {
  position: relative;
  padding: 15px;
}
.modal-title {
  word-break: break-all;
  color: #313131;
  font-size: 18px;
}

.modal-title {
  margin: 0;
  line-height: 1.42857143;
}
.cd-icon {
  line-height: 1;
}

.cd-icon {
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.close {
  float: right;
  font-size: 21px;
  font-weight: 700;
  line-height: 1;
  color: #000;
  text-shadow: 0 1px 0 #fff;
  opacity: 0.2;
  filter: alpha(opacity=20);
}
.modal-header .close {
  margin-top: -2px;
}

button.close {
  padding: 0;
  cursor: pointer;
  background: transparent;
  border: 0;
  -webkit-appearance: none;
}
.modal-header {
  padding: 15px 20px;
}

.modal-header {
  padding: 15px;
  border-bottom: 1px solid #e5e5e5;
  min-height: 16.42857143px;
}
</style>

