<!--
@description 添加课时-教案任务
@author cgy
-->
<template>
  <el-dialog
    :close-on-click-modal="false"
    :title="teacherdialog.title"
    :visible.sync="teacherdialog.show"
    :before-close="closeDialog"
    style="margin: 0 auto;"
    width="80%"
  >

    <div id="task-create-editor" class="task-create-editor">
      <!-- 头部导航栏 -->
      <ul id="task-create-step" class="es-step es-step-3 clearfix">
        <li class="doing">
          <span class="number" style="background-color: #E50112;border-color:rgb(229, 1, 18)">1</span>
          第一步
        </li>
        <li :class="{'doing': isStep('1') || isStep('2')}">
          <span class="number" :class="{'number_active': isStep('1') || isStep('2')}">2</span>
          第二步
        </li>
        <li :class="{'doing': isStep('2')}">
          <span class="number" :class="{'number_active': isStep('2')}">3</span>
          第三步
        </li>
      </ul>
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <!-- 步骤1 -->
        <el-row v-if="isStep('0')">
          <el-col :span="16">
            <el-form-item label="授课方式" prop="teachingType" :label-width="labelWidth">
              <el-select
                v-model="form.teachingType"
                style="width:220px"
                placeholder="请选择授课方式"
                clearable
              >
                <el-option
                  v-for="dict in teachingTypeOptions"
                  :key="dict.dictValue"
                  :label="dict.dictLabel"
                  :value="dict.dictValue"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="教学目的" prop="teachingGoals" :label-width="labelWidth">
              <el-input
                v-model="form.teachingGoals"
                placeholder="请输入教学目的"
                type="textarea"
                :rows="3"
                clearable
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="授课对象分析" prop="objectAnalyse" :label-width="labelWidth">
              <el-input
                v-model="form.objectAnalyse"
                placeholder="请对授课对象进行分析"
                type="textarea"
                :rows="6"
                clearable
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="教学要求" prop="teachingRequired" :label-width="labelWidth">
              <el-input
                v-model="form.teachingRequired"
                placeholder="请输入教学要求"
                type="textarea"
                :rows="3"
                clearable
              />
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="教学方法" prop="teachingMethod" :label-width="labelWidth">
              <el-input
                v-model="form.teachingMethod"
                placeholder="请输入教学方法"
                type="textarea"
                :rows="3"
                clearable
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="授课日期" prop="teachingDate" :label-width="labelWidth">
              <el-date-picker
                v-model="form.teachingDate"
                value-format="yyyy-MM-dd"
                type="date"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="授课时间" prop="teachingTime" :label-width="labelWidth">
              <el-time-picker
                v-model="form.teachingTime"
                :picker-options="{selectableRange: ''}"
                value-format="HH:mm:ss"
                placeholder="任意时间点"
              ></el-time-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- 步骤3 -->
        <el-row v-if="isStep('2')">
          <div id="task-create-content" class="task-create-content">
            <el-col :span="24">
              <el-form-item label="教学重难点" prop="keyDifficultPoints" :label-width="labelWidth">
                <el-input
                  v-model="form.keyDifficultPoints"
                  placeholder="请输入教学重难点"
                  type="textarea"
                  :rows="3"
                  clearable
                />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="教学思路" prop="teachingIdeas" :label-width="labelWidth">
                <el-input
                  v-model="form.teachingIdeas"
                  placeholder="请输入教学要求"
                  type="textarea"
                  :rows="3"
                  clearable
                />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="思考作业" prop="discussionHomework" :label-width="labelWidth">
                <el-input
                  v-model="form.discussionHomework"
                  placeholder="请输入思考作业"
                  type="textarea"
                  :rows="3"
                  clearable
                />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="参考资料" prop="teachingReferences" :label-width="labelWidth">
                <el-input
                  v-model="form.teachingReferences"
                  placeholder="请输入参考资料"
                  type="textarea"
                  :rows="3"
                  clearable
                />
              </el-form-item>
            </el-col>
          </div>
        </el-row>
        <!-- 步骤2 -->
        <el-row v-if="isStep('1')">
          <el-col :span="24">
            <el-form-item label="教学过程" prop="teachingContent" :label-width="labelWidth">
              <tinymce
                ref="requirement"
                v-model="form.teachingContent"
                :save-flag="saveFlag"
                :height="500"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <!-- 步骤1--下的按钮 -->
    <div v-if="isStep('0')" slot="footer" class="modal-footer dialog-footer">
      <el-button size="mini" class="btn btn-default" @click="first('1')">下一步</el-button>
      <!-- <el-button type="primary" size="mini" class="btn btn-primary" @click="clickFirstSubmit">保存</el-button> -->
    </div>
    <!-- 步骤2--下的按钮 -->
    <div v-if="isStep('1')" slot="footer" class="modal-footer dialog-footer">
      <el-button size="mini" class="btn btn-default" @click="clickStep('0')">上一步</el-button>
      <el-button size="mini" class="btn btn-default" @click="next('2')">下一步</el-button>
      <!-- <el-button type="primary" size="mini" class="btn btn-primary" @click="clickFirstSubmit">保存</el-button> -->
    </div>
    <!-- 步骤3--下的按钮 -->
    <div v-if="isStep('2')" slot="footer" class="dialog-footer">
      <el-button size="mini" class="btn btn-default" @click="last('1')">上一步</el-button>
      <el-button type="primary" size="mini" class="btn btn-primary" @click="clickLastSubmit">保存</el-button>
    </div>
  </el-dialog>
</template>

<script>
import Tinymce from '@/components/Tinymce'
import { getToken } from '@/utils/auth'
import teachingSchemeApi from '@/api/course/courseTask/teachingScheme'
export default {
  name: 'TeachingChapter',
  components: {
    Tinymce
  },
  props: {
    teacherdialog: {
      type: Object,
      required: true
    },
    courseScheme: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      teachingTypeOptions: [],
      labelWidth: '120px',
      rules: {
        teachingType: [{ required: true, message: '请选择授课方式', trigger: 'blur' }],
        teachingRequired: [{ required: true, message: '请输入教学要求', trigger: 'blur' }],
        keyDifficultPoints: [{ required: true, message: '请输入教学重点', trigger: 'blur' }],
        teachingContent: [{ required: true, message: '请输入教学过程', trigger: 'blur' }]
      },
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      // 上传文件时文件标签
      fileTag: { fileTag: '' },
      headers: {
        token: getToken()
      },
      // 步数的标志
      step: '0',
      // 富文本开启标志
      saveFlag: false
    }
  },
  created() {
    // 教学类型字典获取
    this.getDataByType('course_teachingScheme-teachingType').then(response => {
      this.teachingTypeOptions = response.data
    })
  },
  methods: {
    // 第一步的下一步
    first(step) {
      // 对表单信息进行校验
      this.$refs['form'].validateField('teachingType', (error) => {
        // console.log('error = ', error.length)
        if (!error) {
          this.$refs['form'].validateField('teachingRequired', (error) => {
            if (!error) {
              this.step = step
            }
            return false
          })
        }
        return false
      })
    },
    // 第二步的下一步
    next(step) {
      this.$refs['form'].validateField('teachingContent', (error) => {
        if (!error) {
          this.step = step
        }
      })
    },
    // 第三步
    last(step) {
      this.$refs['form'].validateField('keyDifficultPoints', (error) => {
        if (!error) {
          this.step = step
        }
      })
    },
    // 渲染步数
    isStep(step) {
      // this.setStep()
      return this.step === step
    },
    setStep() {
      // if (this.step === '0') {
      //   if (this.form.tsId > 0) {
      //     this.clickStep('1')
      //   }
      // }
    },
    // 点击第三步的保存
    clickLastSubmit() {
      this.formSubmit('form')
    },
    // 点击一步
    clickStep(step) {
      this.step = step
    },
    /** 清除表单验证信息 */
    resetForm() {
      this.$refs['form'].clearValidate()
    },
    /** 关闭弹框 */
    closeDialog() {
      this.resetForm()
      this.teacherdialog.show = false
      this.step = '0'
    },
    // 教案任务添加或编辑
    formSubmit(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.teacherdialog.title === '添加教案任务') {
            teachingSchemeApi.addTeachingScheme(this.form).then(result => {
              if (result.code === 0) {
                this.$message({
                  type: 'success',
                  message: '添加成功'
                })
                // 关闭弹窗
                this.closeDialog()
                // 刷新页面
                this.$emit('getTreeBySchemeId')
              } else {
                this.$message({
                  type: 'error',
                  message: '添加失败'
                })
              }
            })
          } else {
            teachingSchemeApi.updateEntity(this.form).then(result => {
              if (result.code === 0) {
                this.$message({
                  type: 'success',
                  message: '修改成功'
                })
                // 关闭弹窗
                this.closeDialog()
                // 刷新页面
                this.$emit('getTreeBySchemeId')
              } else {
                this.$message({
                  type: 'error',
                  message: '修改失败'
                })
              }
            })
          }
        } else {
          return false
        }
      })
    },
    /** 打开弹窗放入富文本内容 */
    open() {
      this.saveFlag = true
      this.editsaveFlag()
    },
    editsaveFlag() {
      setTimeout(() => {
        this.saveFlag = !this.saveFlag
      }, 500)
    }
  }
}
</script>
<style lang="scss" scoped>
.p_upload >>> .el-upload__input {
  display: none;
}
.p_upload >>> .el-upload >>> input {
  display: none;
}
.icon {
  width: 3em;
  height: 3em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-top: 1.5em;
}
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.btn {
  border-radius: 5px;
}
span {
  cursor: pointer;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}

.btn-primary {
  border-color: #e50112;
  background-color: #e50112;
  color: #fff;
}
.btn-default,
.btn-default.disabled:hover,
.btn-default[disabled]:hover {
  color: #616161;
  background-color: #f5f5f5;
  border-color: #dcdcdc;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-type-list .task-create-type-item i {
  display: block;
  font-size: 35px;
  line-height: 1;
  padding-top: 18px;
  margin-bottom: 10px;
}
.task-create-editor .task-create-type-list .task-create-type-item > a {
  height: 110px;
  background-color: #f4f6f8;
  display: block;
  text-align: center;
  color: #919191;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  border: 3px solid #f4f6f8;
}

a {
  text-decoration: none;
}
.task-create-editor .task-create-type-list .task-create-type-item {
  margin-bottom: 20px;
}

.col-xs-3 {
  float: left;
  width: 25%;
}
.task-create-editor .task-create-type-list {
  padding: 0 55px;
  margin-bottom: 0;
  list-style: none;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.es-step li .number {
  width: 20px;
  height: 20px;
  line-height: 18px;
  display: inline-block;
  margin-right: 5px;
  border: 1px solid #e1e1e1;
  background-color: #e1e1e1;
  color: #fff;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}
.es-step.es-step-3 li {
  width: 33.33%;
}

.es-step li {
  float: left;
  padding: 15px;
  list-style-type: none;
  border-bottom: 2px solid #e1e1e1;
  color: #e1e1e1;
  font-size: 14px;
  text-align: center;
}
.es-step li.doing {
  color: #616161;
}
.number_active {
  background-color: #e50112 !important;
  border-color:rgb(229, 1, 18);
}
.es-step li.doing,
.es-step li.done {
  border-color: #e50112;
}
.es-step.es-step-3 li {
  width: 33.33%;
}
.es-step li {
  float: left;
  padding: 15px;
  list-style-type: none;
  border-bottom: 2px solid #e1e1e1;
  color: #e1e1e1;
  font-size: 14px;
  text-align: center;
}
.es-step {
  padding-left: 0;
  margin-bottom: 35px;
}
.task-create-editor {
  padding: 0 20px;
}
.modal-body {
  word-wrap: break-word;
  overflow: hidden;
  padding-left: 20px;
  padding-right: 20px;
}

.modal-body {
  position: relative;
  padding: 15px;
}
.modal-title {
  word-break: break-all;
  color: #313131;
  font-size: 18px;
}

.modal-title {
  margin: 0;
  line-height: 1.42857143;
}
.cd-icon {
  line-height: 1;
}

.cd-icon {
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.close {
  float: right;
  font-size: 21px;
  font-weight: 700;
  line-height: 1;
  color: #000;
  text-shadow: 0 1px 0 #fff;
  opacity: 0.2;
  filter: alpha(opacity=20);
}
.modal-header .close {
  margin-top: -2px;
}

button.close {
  padding: 0;
  cursor: pointer;
  background: transparent;
  border: 0;
  -webkit-appearance: none;
}
.modal-header {
  padding: 15px 20px;
}

.modal-header {
  padding: 15px;
  border-bottom: 1px solid #e5e5e5;
  min-height: 16.42857143px;
}
</style>
<style scoped>
.el-dialog__wrapper >>> .el-dialog{
  margin: 3rem auto !important;
}
.el-dialog__wrapper >>> .el-dialog /deep/ .el-dialog__body {
  max-height: 35rem;
  overflow-y: auto;
}
</style>
