<!--
@description 话题讨论列表展示
@author cgy
-->
<template>
  <div id="tasklist">
    <el-button
      type="text"
      icon="el-icon-plus"
      size="mini"
      @click="addCourseTopicTask(courseTopicTask)"
    >新增</el-button>
    <!-- <el-button icon="el-icon-delete" size="small" type="danger" @click="handleBatchDelete">删除</el-button> -->
    <div>
      <span>图文资料{{ textTotal }}个</span>
      <span style="margin-left: 1rem">视频资料{{ videoTotal }}个</span>
      <span style="margin-left: 1rem">音频资料{{ audioTotal }}个</span>
      <span style="margin-left: 1rem">讲稿资料{{ pptTotal }}个</span>
      <span style="margin-left: 1rem">下载资料{{ refTotal }}个</span>
      <span style="margin-left: 1rem">总资料{{ allTotal }}个</span>
    </div>
    <el-table
      ref="table"
      v-loading="loading"
      size="mini"
      :data="tableData"
      tooltip-effect="light"
      style="width: 100%"
      @selection-change="handleSelectionChange"
      @select-all="selectAll"
    >
      <el-table-column
        label="标题"
        prop="title"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column label="类型" prop="type" align="center" min-width="100" />
      <el-table-column label="长度" prop="length" align="center" min-width="100" />
      <el-table-column label="积分" prop="score" align="center" min-width="100" />
      <el-table-column
        label="完成条件"
        prop="condition"
        align="center"
        min-width="100"
        :formatter="conditionFormat"
      />
      <el-table-column label="完成时间" prop="finshTime" align="center" min-width="120" />
      <el-table-column label="操作" align="center" min-width="200" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button type="text" icon="el-icon-edit" size="mini" @click="handleUpdate(scope.row)">编辑</el-button>
          <el-button
            type="text"
            icon="el-icon-delete"
            size="mini"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 添加或修改预习/学习弹出框 -->
    <course-topic-chapter
      ref="dialog"
      :task="task"
      :form="form"
      :course-chapter="courseChapter"
      :dialog="topicdialog"
      @fetchData="fetchData"
    />
  </div>
</template>

<script>
import topicApi from '@/api/course/courseTask/topic'
import CourseTopicChapter from '../task-chapter/CourseTopicChapter'
// import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
export default {
  name: 'CourseTopicTasks',
  components: {
    CourseTopicChapter
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseChapter: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      // 图文资料数（0或1）
      textTotal: 0,
      videoTotal: 0,
      audioTotal: 0,
      pptTotal: 0,
      refTotal: 0,
      allTotal: 0,
      courseTopicTask: {},
      total: 0,
      ids: [],
      // 是否点击全部删除
      isSelectAll: false,
      queryParams: {
        ctId: this.courseChapter.ctId,
        orgId: this.courseChapter.orgId,
        csId: this.courseChapter.csId,
        schemeId: this.courseChapter.schemeId,
        unitId: this.courseChapter.sourceUnitId,
        topicType: ''
      },
      task: {},
      fileTask: {
        title: '',
        type: '',
        url: '',
        length: 0,
        score: 0
      },
      form: {},
      // 弹出框
      topicdialog: {
        title: '',
        type: '',
        show: false
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // 公告类型数据字典
      noticeTypeDict: [],
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      experimentTaskData: [],
      labelWidth: '120px',
      tableData: []
    }
  },
  created() {
    this.openDialog()
  },
  methods: {
    // 对文件（字节）大小进行处理
    changeFileSize(a, b) {
      if (a === 0) {
        return '0 Bytes'
      }
      const c = 1024
      const d = b || 2
      const e = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
      const f = Math.floor(Math.log(a) / Math.log(c))
      return parseFloat((a / Math.pow(c, f)).toFixed(d)) + ' ' + e[f]
    },
    // 是否已完成翻译
    isFinishedFormat(row) {
      return row.isFinished === true ? '是' : '否'
    },
    // 获取tableData,带有分页
    fetchData() {
      this.loading = true
      this.queryParams.topicType = '0'
      topicApi.getCourseTopicByUnitId(this.queryParams).then(response => {
        this.courseTopicTask = response.data
        this.loading = false
        this.ids = []
        this.tableData = []
        if (this.courseTopicTask == null) {
          return
        }
        if (this.courseTopicTask.topicTitle !== null && this.courseTopicTask.topicTitle !== '') {
          // 将图文格式化
          // 插入表格
          const fileTask = {
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.title = this.courseTopicTask.topicTitle
          fileTask.type = '图文'
          // fileTask.length = this.courseTopicTask.topicContent.size
          fileTask.score = this.courseTopicTask.textScore
          fileTask.condition = '学习时长'
          fileTask.finshTime = this.courseTopicTask.textCondition
          // console.log('1-----------this.tableData = ', this.tableData)
          this.tableData.push(fileTask)
          this.textTotal = 1
        }
        // console.log('2-----------this.tableData = ', this.tableData)
        // console.log('this.courseTopicTask = ', this.courseTopicTask)
        // 视频
        this.courseTopicTask.videoMaterials = JSON.parse(response.data.videoMaterials)
        // 将预习/学习任务格式化列表
        const videoMaterials = this.courseTopicTask.videoMaterials
        // console.log('audioMaterials = ', audioMaterials)
        videoMaterials.forEach((item, index) => {
          // 插入表格
          const fileTask = {
            fileId: '',
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.fileId = item.fileId
          fileTask.title = item.title
          fileTask.type = item.type
          fileTask.url = item.url
          fileTask.length = item.length
          fileTask.score = item.score
          fileTask.condition = item.condition
          fileTask.finshTime = item.finshTime
          this.tableData.push(fileTask)
          // console.log('this.tableData = ', this.tableData)
        })
        this.videoTotal = videoMaterials.length
        // 音频
        this.courseTopicTask.audioMaterials = JSON.parse(response.data.audioMaterials)
        // 将预习/学习任务格式化列表
        const audioMaterials = this.courseTopicTask.audioMaterials
        // console.log('audioMaterials = ', audioMaterials)
        audioMaterials.forEach((item, index) => {
          // 插入表格
          const fileTask = {
            fileId: '',
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.fileId = item.fileId
          fileTask.title = item.title
          fileTask.type = item.type
          fileTask.url = item.url
          fileTask.length = item.length
          fileTask.score = item.score
          fileTask.condition = item.condition
          fileTask.finshTime = item.finshTime
          this.tableData.push(fileTask)
          // console.log('this.tableData = ', this.tableData)
        })
        this.audioTotal = audioMaterials.length
        // ppt,文档等
        // console.log('this.courseTopicTask = ', this.courseTopicTask)
        this.courseTopicTask.pptMaterials = JSON.parse(response.data.pptMaterials)
        // 将预习/学习任务格式化列表
        const pptMaterials = this.courseTopicTask.pptMaterials
        pptMaterials.forEach((item, index) => {
          // 插入表格
          const fileTask = {
            fileId: '',
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.fileId = item.fileId
          fileTask.title = item.title
          fileTask.type = item.type
          fileTask.url = item.url
          fileTask.length = item.length
          fileTask.score = item.score
          fileTask.condition = item.condition
          fileTask.finshTime = item.finshTime
          this.tableData.push(fileTask)
          // console.log('this.tableData = ', this.tableData)
        })
        this.pptTotal = pptMaterials.length
        // 下载资料
        // console.log('this.courseTopicTask = ', this.courseTopicTask)
        this.courseTopicTask.refMaterials = JSON.parse(response.data.refMaterials)
        // 将预习/学习任务格式化列表
        const refMaterials = this.courseTopicTask.refMaterials
        refMaterials.forEach((item, index) => {
          // 插入表格
          const fileTask = {
            fileId: '',
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.fileId = item.fileId
          fileTask.title = item.title
          fileTask.type = item.type
          fileTask.url = item.url
          fileTask.length = item.length
          fileTask.score = item.score
          fileTask.condition = item.condition
          fileTask.finshTime = item.finshTime
          this.tableData.push(fileTask)
          // console.log('this.tableData = ', this.tableData)
        })
        this.refTotal = refMaterials.length
        this.allTotal = this.tableData.length
      })
    },
    // 编辑预习/学习任务
    handleUpdate(item) {
      const courseTopicTask = this.courseTopicTask
      if (courseTopicTask === null) {
        return
      }
      this.resetCourseTopicTask()
      if (courseTopicTask != null && courseTopicTask.pstId != null && courseTopicTask.pstId > 0) {
        this.form = { ...courseTopicTask }
        this.topicdialog.title = '修改话题任务'
        // this.form.pstId = courseTopicTask.pstId
        // this.form.topicType = courseTopicTask.topicType
      }
      this.task = { ...item }
      this.topicdialog.type = item.type
      this.form.fileTitle = this.task.title
      this.form.unitId = this.courseChapter.sourceUnitId
      this.topicdialog.show = true
    },
    // 添加预习/学习任务
    addCourseTopicTask(courseTopicTask) {
      // const courseTopicTask = courseChapter.courseTopicTask
      this.resetCourseTopicTask()
      if (courseTopicTask != null && courseTopicTask.pstId != null && courseTopicTask.pstId > 0) {
        this.form = { ...courseTopicTask }
        console.log('addCourseTopicTask------this.form.pptMaterials = ', this.form.pptMaterials)
      }
      // this.task = null
      this.form.topicType = this.dialog.title === '学习任务列表' ? '0' : '1'
      this.form.unitId = this.courseChapter.sourceUnitId
      this.topicdialog.show = true
    },
    resetCourseTopicTask() {
      this.form = {
        cqId: -1,
        csId: this.courseChapter.csId,
        ctId: this.courseChapter.ctId,
        schemeId: this.courseChapter.schemeId,
        unitId: null,
        topicType: null,
        topicTitle: '',
        topicContent: '',
        audioMaterials: '',
        videoMaterials: '',
        refMaterials: '',
        topicUserId: null,
        realName: '',
        readCount: 0,
        replyCount: 0,
        hitCount: 0,
        isStick: false,
        isElite: false,
        lastReplyUserId: null,
        lastReplyTime: '',
        status: '',
        studyScore: 0,
        createOrgId: null,
        orgId: this.courseChapter.orgId,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        topicUser: '',
        lastReplyUser: ''
      }
    },
    openDialog() {
      this.queryParams.ctId = this.courseChapter.ctId
      this.queryParams.orgId = this.courseChapter.orgId
      this.queryParams.csId = this.courseChapter.csId
      this.queryParams.schemeId = this.courseChapter.schemeId
      this.queryParams.unitId = this.courseChapter.sourceUnitId
      this.fetchData()
    },
    // 选中多个id
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.fileId)
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        // 删除按钮可用状态
        this.deldisabled = false
      }
    },
    // 当点击全选时则通过条件全部删除
    selectAll(selection) {
      this.ids = selection.map(item => item.fileId)
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        // 删除按钮可用状态
        this.deldisabled = false
        this.isSelectAll = true
      }
    },
    /** 删除按钮操作 */
    handleDelete(item) {
      // 处理删除
      this.$confirm('您确定要删除所选任务?', '警告', {
        cancelButtonText: '取消',
        confirmButtonText: '确定',
        type: 'warning'
      })
        .then(
          this.handleDelete2(item)
        )
    },
    // 单条删除按钮
    handleDelete2(item) {
      console.log('handleDelete2============item = ', item)
      const courseTopicTask = this.courseTopicTask
      const type = item.type
      const fileId = item.fileId
      console.log('fileId = ', fileId)
      // 如果是图文
      if (type === '图文') {
        // courseTopicTask.topicTitle = null
        courseTopicTask.textScore = 0
        courseTopicTask.textCondition = 0
        courseTopicTask.topicContent = null
        this.CourseTopicFormSubmit(courseTopicTask)
      } else if (type === 'ppt' || type === 'excel' || type === 'doc' || type === 'word' || type === 'txt' || type === 'pdf') {
        // arr.splice(arr.findIndex(item => item.id === 8), 1)
        const ppt = courseTopicTask.pptMaterials
        const index = ppt.findIndex(item => item.fileId === fileId)
        if (index !== -1) {
          courseTopicTask.pptMaterials.splice(index, 1)
          this.CourseTopicFormSubmit(courseTopicTask)
        }
        if (courseTopicTask.pptMaterials === undefined) {
          courseTopicTask.pptMaterials = []
        }
      } else if (type === 'audio') {
        const audio = courseTopicTask.audioMaterials
        const audioIndex = audio.findIndex(item => item.fileId === fileId)
        if (audioIndex !== -1) {
          courseTopicTask.audioMaterials.splice(audioIndex, 1)
          this.CourseTopicFormSubmit(courseTopicTask)
        }
        if (courseTopicTask.audioMaterials === undefined) {
          courseTopicTask.audioMaterials = []
        }
      } else if (type === 'download') {
        const ref = courseTopicTask.refMaterials
        const refIndex = ref.findIndex(item => item.fileId === fileId)
        if (refIndex !== -1) {
          courseTopicTask.refMaterials.splice(refIndex, 1)
          this.CourseTopicFormSubmit(courseTopicTask)
        }
        if (courseTopicTask.refMaterials === undefined) {
          courseTopicTask.refMaterials = []
        }
      } else if (type === 'video') {
        const ref = courseTopicTask.videoMaterials
        const videoIndex = ref.findIndex(item => item.fileId === fileId)
        if (videoIndex !== -1) {
          courseTopicTask.videoMaterials.splice(videoIndex, 1)
          this.CourseTopicFormSubmit(courseTopicTask)
        }
        if (courseTopicTask.videoMaterials === undefined) {
          courseTopicTask.videoMaterials = []
        }
      }
    },
    // 预习/学习任务添加或编辑
    CourseTopicFormSubmit(form) {
      form.pptMaterials = JSON.stringify(form.pptMaterials)
      form.refMaterials = JSON.stringify(form.refMaterials)
      form.audioMaterials = JSON.stringify(form.audioMaterials)
      form.videoMaterials = JSON.stringify(form.videoMaterials)
      // 修改到数据库
      topicApi
        .updateFrontStudyTask(form)
        .then(response => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
          this.fetchData()
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 批量删除
    handleBatchDelete() {
      // const courseTopicTask = this.courseTopicTask
      // pptMaterials.forEach((item, index) => {
      // })
    },
    close() {
      // this.$refs['form'].clearValidate()
      this.courseTopicTask = {}
      this.tableData = []
      this.textTotal = 0
      this.videoTotal = 0
      this.audioTotal = 0
      this.pptTotal = 0
      this.refTotal = 0
      this.allTotal = 0
      this.dialog.show = false
      // 刷新页面
      this.$emit('getTreeBySchemeId')
    }
  }
}
</script>

<style scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
