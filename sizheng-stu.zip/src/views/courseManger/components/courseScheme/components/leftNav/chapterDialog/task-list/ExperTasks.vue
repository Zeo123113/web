<!--
@description 实验列表展示
@author cgy
-->
<template>
  <div class="experTask">
    <el-button type="text" icon="el-icon-plus" size="mini" @click="addExperimentTask">新增</el-button>
    <el-table
      v-loading="loading"
      size="mini"
      :data="experimentTaskData"
      tooltip-effect="light"
      row-key="experId"
      @select="selectall"
      @select-all="selectall"
    >
      <el-table-column
        label="实验标题"
        prop="experTitle"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column
        label="实验开始时间"
        prop="experStartTime"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column
        label="实验结束时间"
        prop="experEndTime"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column
        label="提交结止时间"
        prop="reportDeadlineTime"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column
        label="是否允许补交"
        prop="isAllowDelay"
        align="center"
        min-width="120"
        :formatter="allowDelayFormat"
      />
      <el-table-column
        label="补交截止时间"
        prop="delayTime"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column
        label="创建时间"
        prop="createTime"
        align="center"
        sortable
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column
        label="更新时间"
        prop="updateTime"
        align="center"
        sortable
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column label="操作" align="center" min-width="300" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button
            type="text"
            icon="el-icon-edit"
            size="mini"
            @click="addExperimentTask(scope.row)"
          >编辑</el-button>
          <el-button
            type="text"
            icon="el-icon-download"
            size="mini"
            @click="handleExportLabManual(scope.row)"
          >实验手册</el-button>
          <el-button
            type="text"
            icon="el-icon-download"
            size="mini"
            @click="handleExportReportTemplate(scope.row)"
          >实验模板</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 添加或修改实验弹出框 -->
    <exper-chapter
      ref="experdialog"
      :form="form"
      :course-chapter="courseChapter"
      :experdialog="experdialog"
      @getList="getList"
    />
  </div>
</template>

<script>
// import pagination from '@/components/Pagination/index'
import ExperChapter from '../task-chapter/ExperChapter'
import { downloadByLink } from '@/utils/index'
import USER_CONST from '@/constant/user-const'
import experimentTaskApi from '@/api/course/courseTask/experimentTask'
// import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
// import USER_CONST from '@/constant/user-const'
export default {
  name: 'ExperTasks',
  components: {
    ExperChapter
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseChapter: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      total: 0,
      ids: [],
      queryParams: {
        ctId: this.courseChapter.ctId,
        orgId: this.courseChapter.orgId,
        csId: this.courseChapter.csId,
        schemeId: this.courseChapter.schemeId,
        unitId: this.courseChapter.sourceUnitId
      },
      form: {},
      // 弹出框
      experdialog: {
        title: '',
        show: false
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // 公告类型数据字典
      noticeTypeDict: [],
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      experimentTaskData: [],
      labelWidth: '120px'
    }
  },
  created() {
    this.openDialog()
  },
  methods: {
    // 添加/编辑实验任务
    addExperimentTask(experimentTask) {
      // const experimentTask = this.courseChapter.experimentTask
      this.resetExperimentTask()
      // console.log('experimentTask = ', experimentTask)
      if (experimentTask != null && experimentTask.experId > 0) {
        this.form = { ...experimentTask }
        // if (!(this.form.labManual instanceof Object) && this.form.labManual !== null) {
        //   this.form.labManual = JSON.parse(this.form.labManual)
        // }
        // if (!(this.form.reportTemplate instanceof Object) && this.form.reportTemplate !== null) {
        //   this.form.reportTemplate = JSON.parse(this.form.reportTemplate)
        // }
        this.experdialog.title = '修改实验任务'
      } else {
        this.experdialog.title = '添加实验任务'
      }
      this.form.unitId = this.courseChapter.sourceUnitId
      // this.form.chapterId = this.courseChapter.chapterId
      console.log('addExperimentTask----this.form = ', this.form)
      this.experdialog.show = true
    },
    resetExperimentTask() {
      this.form = {
        experId: -1,
        csId: this.courseChapter.csId,
        ctId: this.courseChapter.ctId,
        schemeId: this.courseChapter.schemeId,
        unitId: this.courseChapter.unitId,
        experTitle: '',
        requirement: '',
        labManual: '',
        labTaskObject: null,
        reportTemplate: '',
        experStartTime: '',
        experEndTime: '',
        reportDeadlineTime: '',
        isAllowDelay: false,
        delayTime: '',
        createOrgId: null,
        orgId: this.courseChapter.orgId,
        createTime: '',
        updateTime: '',
        createBy: '',
        updateBy: '',
        remark: '',
        chapterId: null
      }
    },
    openDialog() {
      // 公告类型数据字典
      this.getDataByType('course_notice_type').then(response => {
        this.noticeTypeDict = response.data
      })
      this.queryParams.ctId = this.courseChapter.ctId
      this.queryParams.orgId = this.courseChapter.orgId
      this.queryParams.csId = this.courseChapter.csId
      this.queryParams.schemeId = this.courseChapter.schemeId
      this.queryParams.unitId = this.courseChapter.sourceUnitId
      console.log('this.courseChapter = ', this.courseChapter)
      console.log('this.queryParams = ', this.queryParams)
      this.getList()
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    /** 下载按钮操作 */
    handleExportLabManual(row) {
      const labManual = JSON.parse(row.labManual)
      downloadByLink(process.env.VUE_APP_FILE_SERVER, labManual.url, labManual.title)
    },
    handleExportReportTemplate(row) {
      const reportTemplate = JSON.parse(row.reportTemplate)
      downloadByLink(process.env.VUE_APP_FILE_SERVER, reportTemplate.url, reportTemplate.title)
    },
    allowDelayFormat(row) {
      return row.isAllowDelay === true ? '是' : '否'
    },
    noticeTypeFormat(row) {
      return this.selectDictLabel(this.noticeTypeDict, row.noticeType)
    },
    selectall(selection) {
      this.deldisabled = !this.deldisabled
      this.ids = selection.map(item => item.experId)
    },
    // 批量删除
    handleDeleteMore() {
      const ids = this.ids.toString()
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return experimentTaskApi.delexperimentTask(ids)
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList()
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
          // this.$message.error(err.msg)
        })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return experimentTaskApi.delexperimentTask(row.experId)
        })
        .then(() => {
          this.$message({
            showClose: true,
            message: '删除成功',
            duration: 3000,
            type: 'success'
          })
          this.getList()
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    getList() {
      this.loading = true
      experimentTaskApi
        .getexperimentTaskList(this.queryParams, this.pageNum, this.pageSize)
        .then(response => {
          this.experimentTaskData = response.data.list
          this.total = response.data.total
          this.loading = false
          this.ids = []
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>

<style scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
