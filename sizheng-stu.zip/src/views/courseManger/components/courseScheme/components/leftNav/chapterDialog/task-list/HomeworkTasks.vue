<!--
@description 作业列表展示
@author cgy
-->
<template>
  <div class="homeworklist">
    <el-button type="text" icon="el-icon-plus" size="mini" @click="addHomeworkTask">新增</el-button>
    <!--表格展示-->
    <el-table
      ref="table"
      v-loading="loading"
      :data="homeworkTaskList"
      row-key="hwtId"
      tooltip-effect="light"
      @select-all="checkboxSelectAll"
      @select="checkboxSelect"
    >
      <el-table-column
        label="作业标题"
        align="center"
        show-overflow-tooltip
        min-width="160"
      >
        <template slot-scope="scope">
          {{ scope.row.hwTitle }}
        </template>
      </el-table-column>
      <el-table-column label="作业对象" align="center" :formatter="objectFormat" min-width="120" show-overflow-tooltip>
      </el-table-column>
      <el-table-column label="开始时间" align="center" min-width="160">
        <template slot-scope="scope">
          {{ scope.row.hwArrange.startTime }}
        </template>
      </el-table-column>
      <el-table-column label="终止时间" align="center" min-width="160">
        <template slot-scope="scope">
          {{ scope.row.hwArrange.hwEndTime }}
        </template>
      </el-table-column>
      <el-table-column label="操作" min-width="150px" align="center" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-tooltip content="编辑" placement="top" effect="light">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              @click="addHomeworkTask(scope.row)"
            ></el-button>
          </el-tooltip>
          <el-tooltip content="时间设置" placement="top" effect="light">
            <el-button
              type="text"
              size="mini"
              @click="editTime(scope.row)"
            >
              <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-shijian" />
              </svg>
            </el-button>
          </el-tooltip>
          <el-tooltip content="批阅" placement="top" effect="light">
            <el-button
              type="text"
              size="mini"
              @click="perusal(scope.row)"
            >
              <svg class="icon" aria-hidden="true">
                <use
                  xlink:href="#icon-piyue1"
                />
              </svg>
            </el-button>
          </el-tooltip>
          <el-tooltip content="删除" placement="top" effect="light">
            <el-button
              type="text"
              size="mini"
              icon="el-icon-delete"
              @click="handleDelete(scope.row)"
            ></el-button>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <!--时间设置弹窗-->
    <el-dialog title="作业时间设置" :visible.sync="dialogFormVisible" width="60%">
      <el-form :rules="rules" :model="form">
        <el-row>
          <el-col :span="12">
            <el-form-item label="开始时间" prop="hwArrange.startTime" :label-width="labelWidth">
              <el-date-picker
                v-model="form.hwArrange.startTime"
                type="datetime"
                placeholder="选择日期时间"
                value-format="yyyy-MM-dd HH:mm:ss"
                style="width:80%"
                :disabled="nowTime>form.hwArrange.startTime? true:false"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="终止时间" prop="hwArrange.hwEndTime" :label-width="labelWidth">
              <el-date-picker
                v-model="form.hwArrange.hwEndTime"
                type="datetime"
                placeholder="选择日期时间"
                value-format="yyyy-MM-dd HH:mm:ss"
                style="width:80%"
                :disabled="nowTime>form.hwArrange.startTime? true:false"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="是否允许补交" prop="isallowdelay" :label-width="labelWidth">
              <el-switch v-model="form.hwArrange.isallowdelay"></el-switch>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item
              v-if="form.hwArrange.isallowdelay"
              label="补交截止时间"
              prop="delaytime"
              :label-width="labelWidth"
            >
              <el-date-picker
                v-model="form.hwArrange.delaytime"
                type="datetime"
                placeholder="选择日期时间"
                value-format="yyyy-MM-dd HH:mm:ss"
                style="width:80%"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="clickTimeEdit()">确 定</el-button>
      </div>
    </el-dialog>
    <!--结束表格展示-->
    <!-- 添加或修改作业弹出框 -->
    <homework-chapter
      :form="homeworkTask"
      :course-chapter="courseChapter"
      :homedialog="homedialog"
      @getList="getList"
    />
  </div>
</template>

<script>
// import homeworkArrangeApi from '@/api/exambank/homework-arrange'
import HomeworkChapter from '../task-chapter/HomeworkChapter'
import homworkTaskApi from '@/api/course/courseTask/homeworkTask'
import USER_CONST from '@/constant/user-const'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
export default {
  name: 'HomeworkTasks',
  components: {
    HomeworkChapter
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseChapter: {
      type: Object,
      default: null
    },
    perusalVisible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 弹出框
      homedialog: {
        title: '',
        show: false
      },
      loading: false,
      teachingScheme: {},
      evaluationMethodOptions: [],
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      queryParams: {
        ctId: this.courseChapter.ctId,
        orgId: this.courseChapter.orgId,
        csId: this.courseChapter.csId,
        schemeId: this.courseChapter.schemeId,
        unitId: this.courseChapter.sourceUnitId
      },
      total: 0,
      ids: [],
      isSelectAll: false,
      // 时间设置弹窗
      dialogFormVisible: false,
      // 批阅作业对象
      persualTask: {},
      // 时间设置
      rules: {
        startTime: [{ required: true, message: '请选作业开始时间', trigger: 'blur' }],
        hwEndTime: [{ required: true, message: '请选择作业终止时间', trigger: 'blur' }]
      },
      homeworkTask: {
        hwtId: -1,
        csId: this.courseChapter.csId,
        ctId: this.courseChapter.ctId,
        schemeId: this.courseChapter.schemeId,
        unitId: null,
        hwTitle: '',
        hwId: null,
        hwArrange: {
          hwId: null,
          hwtitle: '',
          hwdemand: '',
          hwobject: null,
          startTime: null,
          hwEndTime: null,
          isallowdelay: false,
          delaytime: null,
          delFlag: false
        },
        evaluationMethod: '1',
        conditionSet: '{}',
        createOrgId: null,
        orgId: null,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        questionlist: []
      },
      homeworkTaskList: [],
      labelWidth: '120px',
      // 学员分组
      courseMgOptions: [],
      // 时间设置实体
      form: { hwtId: -1,
        csId: this.courseChapter.csId,
        ctId: this.courseChapter.ctId,
        schemeId: this.courseChapter.schemeId,
        unitId: null,
        hwTitle: '',
        hwId: null,
        hwArrange: {
          hwId: null,
          hwtitle: '',
          hwdemand: '',
          hwobject: null,
          startTime: null,
          hwEndTime: null,
          isallowdelay: false,
          delaytime: null,
          delFlag: false
        },
        evaluationMethod: '1',
        conditionSet: '{}',
        createOrgId: null,
        orgId: null,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        questionlist: [] },
      // 当前时间
      nowTime: null
    }
  },
  created() {
    this.openDialog()
    courseMemberGroupApi.getCourseMemberGroupBySchemeId(this.courseChapter.schemeId).then(response => {
      this.courseMgOptions = response.data
    })
  },
  methods: {
    // 作业对象翻译
    objectFormat(row) {
      return this.getMgFormat(row.hwArrange.hwobject, this.courseMgOptions)
    },
    getMgFormat(id, options) {
      for (let i = 0; i < options.length; i++) {
        if (id === options[i].id) {
          return options[i].label
        }
        if (options[i].children != null && options[i].children.length > 0) {
          this.getMgFormat(id, options[i].children)
        }
      }
    },
    // 添加/编辑作业任务
    addHomeworkTask(homeworkTask) {
      // const homeworkTask = courseChapter.homeworkTask
      this.resetHomeworkTask()
      console.log('homeworkTask = ', homeworkTask)
      if (homeworkTask != null && homeworkTask.hwtId != null && homeworkTask.hwtId > 0) {
        this.homeworkTask = { ...homeworkTask }
        this.homedialog.title = '修改作业任务'
      } else {
        this.homedialog.title = '添加作业任务'
      }
      console.log('addhomeworkTask----this.homeworkTask = ', this.homeworkTask)
      this.homedialog.show = true
    },
    /** 时间设置 */
    editTime(homework) {
      this.dialogFormVisible = true
      this.form = { ...homework }
    },
    /** 保存时间设置 */
    clickTimeEdit() {
      if (this.form.hwArrange.startTime != null && this.form.hwArrange.startTime !== '') {
        if (this.form.hwArrange.hwEndTime != null && this.form.hwArrange.hwEndTime !== '') {
          if (this.form.hwArrange.startTime > this.form.hwArrange.hwEndTime) {
            this.$message({
              type: 'warning',
              message: '作业开始时间不能大于终止时间！'
            })
            return
          }
        } else {
          this.$message({
            message: '请选择终止时间',
            type: 'error'
          })
          return
        }
        if (this.form.hwArrange.isallowdelay && !this.form.hwArrange.delaytime) {
          this.$message({
            type: 'warning',
            message: '请设置补交截止时间！'
          })
          return
        }
        if (
          this.form.hwArrange.isallowdelay &&
          this.form.hwArrange.hwEndTime > this.form.hwArrange.delaytime
        ) {
          this.$message({
            type: 'warning',
            message: '作业终止时间不能大于作业补交截止时间！'
          })
          return
        }
        homworkTaskApi
          .updateEntry(this.form)
          .then(response => {
            this.$message({
              type: 'success',
              message: '更新成功'
            })
            this.dialogFormVisible = false
          })
          .catch(err => {
            console.log(err)
          })
      }
      if (this.form.hwArrange.startTime == null && this.form.hwArrange.startTime === '') {
        this.$message({
          message: '请选择开始时间',
          type: 'error'
        })
      }
    },
    resetHomeworkTask() {
      this.homeworkTask = {
        hwtId: -1,
        csId: this.courseChapter.csId,
        ctId: this.courseChapter.ctId,
        schemeId: this.courseChapter.schemeId,
        unitId: null,
        hwTitle: '',
        hwId: null,
        hwArrange: {
          hwId: null,
          hwtitle: '',
          hwdemand: '',
          hwobject: null,
          startTime: null,
          hwEndTime: null,
          isallowdelay: false,
          delaytime: null,
          delFlag: false
        },
        evaluationMethod: '1',
        conditionSet: '{}',
        createOrgId: null,
        orgId: null,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        questionlist: []
      }
    },
    /** 作业评价方法字典翻译 */
    evaluationMethodFormat(row) {
      return this.selectDictLabel(this.evaluationMethodOptions, row.evaluationMethod)
    },
    /** 表格复选框选择操作 */
    checkboxSelect(selection) {
      this.isSelectAll = false
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].hwtId)
      }
    },
    /** 表格复选框全选操作 */
    checkboxSelectAll(selection) {
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].hwtId)
      }
      if (selection.length === 0) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
    },
    openDialog() {
      this.nowTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
      console.log(this.nowTime)
      // 作业评价方法字典获取
      this.getDataByType('course_ht_evaluation_method').then(response => {
        this.evaluationMethodOptions = response.data
      })
      this.queryParams.unitId = this.courseChapter.sourceUnitId
      this.getList()
    },
    /*
     * 获取当前时间
     */
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    },
    /** 查询列表 */
    getList() {
      this.loading = true
      homworkTaskApi.getHomeworkByUnitId(this.queryParams.unitId).then(response => {
        this.homeworkTaskList = response.data
        this.total = response.data.total
        this.loading = false
        this.ids = []
      })
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('您确定要删除所选项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return homworkTaskApi.batchDelete(row.hwtId.toString())
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 批量删除/批量还原 */
    handleBatchDelete() {
      if (this.ids.length === 0) {
        this.$message({
          type: 'info',
          message: '请先选择要删除的条目！'
        })
        return
      }
      this.$confirm('您确定要删除所选欺项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          if (this.isSelectAll) {
            return homworkTaskApi.batchDeleteByCriteria(this.queryParams)
          } else {
            return homworkTaskApi.batchDelete(this.ids.toString())
          }
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.ids = []
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 批阅 */
    perusal(row) {
      this.$emit('setTask', row)
      console.log(row)
    }
  }
}
</script>
<style scoped>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 120px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>
<style scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
.homeworklist {
  margin-top: 24px;
}
</style>
