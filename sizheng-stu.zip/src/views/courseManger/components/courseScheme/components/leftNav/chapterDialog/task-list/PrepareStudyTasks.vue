<!--
@description 预习/学习列表展示
@author cgy
-->
<template>
  <div id="tasklist">
    <el-button
      type="text"
      icon="el-icon-plus"
      size="mini"
      @click="addPrepareStudyTask(prepareStudyTask)"
    >新增</el-button>
    <!-- <el-button icon="el-icon-delete" size="small" type="danger" @click="handleBatchDelete">删除</el-button> -->
    <div>
      <span>图文资料{{ textTotal }}个</span>
      <span style="margin-left: 1rem">视频资料{{ videoTotal }}个</span>
      <span style="margin-left: 1rem">音频资料{{ audioTotal }}个</span>
      <span style="margin-left: 1rem">讲稿资料{{ pptTotal }}个</span>
      <span style="margin-left: 1rem">下载资料{{ refTotal }}个</span>
      <span style="margin-left: 1rem">总资料{{ allTotal }}个</span>
    </div>
    <el-table
      ref="table"
      v-loading="loading"
      size="mini"
      :data="tableData"
      tooltip-effect="light"
      style="width: 100%"
      @selection-change="handleSelectionChange"
      @select-all="selectAll"
    >
      <el-table-column
        label="标题"
        prop="title"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column label="类型" prop="type" align="center" min-width="100" />
      <el-table-column label="长度" prop="length" align="center" min-width="100" />
      <el-table-column label="积分" prop="score" align="center" min-width="100" />
      <el-table-column
        label="完成条件"
        prop="condition"
        align="center"
        min-width="100"
        :formatter="conditionFormat"
      />
      <el-table-column label="完成时间/页数" prop="finshTime" align="center" min-width="120" />
      <el-table-column label="操作" align="center" min-width="200" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button type="text" icon="el-icon-edit" size="mini" @click="handleUpdate(scope.row)">编辑</el-button>
          <el-button
            type="text"
            icon="el-icon-delete"
            size="mini"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 添加或修改预习/学习弹出框 -->
    <prepare-study-chapter
      ref="dialog"
      :task="task"
      :form="form"
      :course-chapter="courseChapter"
      :dialog="prestudydialog"
      @fetchData="fetchData"
    />
  </div>
</template>

<script>
import prepareStudyTaskApi from '@/api/course/courseTask/prepareStudyTask'
import PrepareStudyChapter from '../task-chapter/PrepareStudyChapter'
// import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
export default {
  name: 'PrepareStudyTasks',
  components: {
    PrepareStudyChapter
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseChapter: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      // 图文资料数（0或1）
      textTotal: 0,
      videoTotal: 0,
      audioTotal: 0,
      pptTotal: 0,
      refTotal: 0,
      allTotal: 0,
      prepareStudyTask: {
        pstId: -1,
        csId: this.courseChapter.csId,
        ctId: this.courseChapter.ctId,
        schemeId: this.courseChapter.schemeId,
        unitId: this.courseChapter.unitId,
        seq: 1,
        studyTaskType: '1',
        psTitle: null,
        startTime: null,
        endTime: null,
        textMaterials: null,
        textScore: null,
        pptMaterials: [],
        videoMaterials: [],
        audioMaterials: [],
        refMaterials: [],
        finishedMaterials: 0,
        totalMaterials: 0,
        isFinished: 0,
        textCondition: null,
        refPstId: null,
        createOrgId: null,
        orgId: this.courseChapter.orgId,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null,
        chapterId: null
      },
      total: 0,
      ids: [],
      // 是否点击全部删除
      isSelectAll: false,
      queryParams: {
        ctId: this.courseChapter.ctId,
        orgId: this.courseChapter.orgId,
        csId: this.courseChapter.csId,
        schemeId: this.courseChapter.schemeId,
        unitId: this.courseChapter.sourceUnitId,
        studyTaskType: ''
      },
      task: {},
      fileTask: {
        title: '',
        type: '',
        url: '',
        length: 0,
        score: 0
      },
      form: {},
      // 弹出框
      prestudydialog: {
        title: '',
        type: '',
        show: false
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // 公告类型数据字典
      noticeTypeDict: [],
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      experimentTaskData: [],
      labelWidth: '120px',
      tableData: []
    }
  },
  created() {
    this.openDialog()
  },
  methods: {
    conditionFormat(row) {
      const condition = row.condition
      if (condition === '0') {
        return '学习到最后'
      } else if (condition === '1') {
        return '学习时长'
      } else if (condition === '2') {
        return '学习页数'
      } else {
        return condition
      }
    },
    // 对文件（字节）大小进行处理
    changeFileSize(a, b) {
      if (a === 0) {
        return '0 Bytes'
      }
      const c = 1024
      const d = b || 2
      const e = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
      const f = Math.floor(Math.log(a) / Math.log(c))
      return parseFloat((a / Math.pow(c, f)).toFixed(d)) + ' ' + e[f]
    },
    // 是否已完成翻译
    isFinishedFormat(row) {
      return row.isFinished === true ? '是' : '否'
    },
    // 获取tableData,带有分页
    fetchData() {
      this.loading = true
      if (this.dialog.title === '预习任务列表') {
        this.queryParams.studyTaskType = '1'
      } else {
        this.queryParams.studyTaskType = '0'
      }
      prepareStudyTaskApi.getPerpareStudyByUnitId(this.queryParams).then(response => {
        // this.prepareStudyTask = response.data
        this.ids = []
        this.tableData = []
        if (response.data == null) {
          if (this.dialog.title === '预习任务列表') {
            this.prepareStudyTask.studyTaskType = '1'
          } else {
            this.prepareStudyTask.studyTaskType = '0'
          }
          this.loading = false
          return
        }
        this.prepareStudyTask = response.data
        if (this.prepareStudyTask.psTitle !== null && this.prepareStudyTask.psTitle !== '') {
          // 将图文格式化
          // 插入表格
          const fileTask = {
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.title = this.prepareStudyTask.psTitle
          fileTask.type = '图文'
          // fileTask.length = this.prepareStudyTask.textMaterials.size
          fileTask.score = this.prepareStudyTask.textScore
          fileTask.condition = '学习时长'
          fileTask.finshTime = this.prepareStudyTask.textCondition
          // console.log('1-----------this.tableData = ', this.tableData)
          this.tableData.push(fileTask)
          this.textTotal = 1
        }
        // 视频
        this.prepareStudyTask.videoMaterials = JSON.parse(response.data.videoMaterials)
        // 将预习/学习任务格式化列表
        const videoMaterials = this.prepareStudyTask.videoMaterials
        // console.log('audioMaterials = ', audioMaterials)
        videoMaterials.forEach((item, index) => {
          // 插入表格
          const fileTask = {
            fileId: '',
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.fileId = item.fileId
          fileTask.title = item.title
          fileTask.type = item.type
          fileTask.url = item.url
          fileTask.length = item.length
          fileTask.score = item.score
          fileTask.condition = item.condition
          fileTask.finshTime = item.finshTime
          this.tableData.push(fileTask)
          // console.log('this.tableData = ', this.tableData)
        })
        this.videoTotal = videoMaterials.length
        // 音频
        this.prepareStudyTask.audioMaterials = JSON.parse(response.data.audioMaterials)
        // 将预习/学习任务格式化列表
        const audioMaterials = this.prepareStudyTask.audioMaterials
        // console.log('audioMaterials = ', audioMaterials)
        audioMaterials.forEach((item, index) => {
          // 插入表格
          const fileTask = {
            fileId: '',
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.fileId = item.fileId
          fileTask.title = item.title
          fileTask.type = item.type
          fileTask.url = item.url
          fileTask.length = item.length
          fileTask.score = item.score
          fileTask.condition = item.condition
          fileTask.finshTime = item.finshTime
          this.tableData.push(fileTask)
          // console.log('this.tableData = ', this.tableData)
        })
        this.audioTotal = audioMaterials.length
        // ppt,文档等
        // console.log('this.prepareStudyTask = ', this.prepareStudyTask)
        this.prepareStudyTask.pptMaterials = JSON.parse(response.data.pptMaterials)
        // 将预习/学习任务格式化列表
        const pptMaterials = this.prepareStudyTask.pptMaterials
        pptMaterials.forEach((item, index) => {
          // 插入表格
          const fileTask = {
            fileId: '',
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.fileId = item.fileId
          fileTask.title = item.title
          fileTask.type = item.type
          fileTask.url = item.url
          fileTask.length = item.length
          fileTask.score = item.score
          fileTask.condition = item.condition
          fileTask.finshTime = item.finshTime
          this.tableData.push(fileTask)
          // console.log('this.tableData = ', this.tableData)
        })
        this.pptTotal = pptMaterials.length
        // 下载资料
        // console.log('this.prepareStudyTask = ', this.prepareStudyTask)
        this.prepareStudyTask.refMaterials = JSON.parse(response.data.refMaterials)
        // 将预习/学习任务格式化列表
        const refMaterials = this.prepareStudyTask.refMaterials
        refMaterials.forEach((item, index) => {
          // 插入表格
          const fileTask = {
            fileId: '',
            title: '',
            type: '',
            url: '',
            length: '',
            score: 0,
            condition: '',
            finshTime: 0
          }
          fileTask.fileId = item.fileId
          fileTask.title = item.title
          fileTask.type = item.type
          fileTask.url = item.url
          fileTask.length = this.changeFileSize(item.length, 2)
          fileTask.score = item.score
          fileTask.condition = item.condition
          fileTask.finshTime = item.finshTime
          this.tableData.push(fileTask)
          // console.log('this.tableData = ', this.tableData)
        })
        this.refTotal = refMaterials.length
        this.allTotal = this.tableData.length
        this.loading = false
      })
    },
    // 编辑预习/学习任务
    handleUpdate(item) {
      const prepareStudyTask = this.prepareStudyTask
      if (prepareStudyTask === null) {
        return
      }
      this.resetPrepareStudyTask()
      if (prepareStudyTask != null && prepareStudyTask.pstId != null && prepareStudyTask.pstId > 0) {
        this.form = { ...prepareStudyTask }
        if (this.form.studyTaskType === '1') {
          this.prestudydialog.title = '修改预习任务'
        } else {
          this.prestudydialog.title = '修改学习任务'
        }
        // this.form.pstId = prepareStudyTask.pstId
        // this.form.studyTaskType = prepareStudyTask.studyTaskType
      }
      this.task = { ...item }
      if (item.length !== '') {
        this.task.pages = item.length
      }
      this.form.pages = item.length
      this.form.condition = item.condition
      this.prestudydialog.type = item.type
      this.form.fileTitle = item.title
      this.form.finshTime = item.finshTime
      this.form.score = item.score
      this.form.unitId = this.courseChapter.sourceUnitId
      this.prestudydialog.show = true
    },
    // 添加预习/学习任务
    addPrepareStudyTask(prepareStudyTask) {
      // const prepareStudyTask = courseChapter.prepareStudyTask
      this.resetPrepareStudyTask()
      if (prepareStudyTask != null && prepareStudyTask.pstId != null && prepareStudyTask.pstId > 0) {
        this.form = { ...prepareStudyTask }
        // console.log('addPrepareStudyTask------this.form.pptMaterials = ', this.form.pptMaterials)
      }
      // this.task = null
      this.form.studyTaskType = this.dialog.title === '学习任务列表' ? '0' : '1'
      this.form.unitId = this.courseChapter.sourceUnitId
      this.prestudydialog.show = true
    },
    resetPrepareStudyTask() {
      this.form = {
        pstId: -1,
        csId: this.courseChapter.csId,
        ctId: this.courseChapter.ctId,
        schemeId: this.courseChapter.schemeId,
        unitId: null,
        seq: 1,
        studyTaskType: '1',
        psTitle: null,
        startTime: null,
        endTime: null,
        textMaterials: null,
        textScore: 0,
        pptMaterials: [],
        videoMaterials: [],
        audioMaterials: [],
        refMaterials: [],
        finishedMaterials: 0,
        totalMaterials: 0,
        isFinished: 0,
        textCondition: 0,
        refPstId: null,
        createOrgId: null,
        orgId: this.courseChapter.orgId,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null,
        chapterId: null
      }
    },
    openDialog() {
      this.queryParams.ctId = this.courseChapter.ctId
      this.queryParams.orgId = this.courseChapter.orgId
      this.queryParams.csId = this.courseChapter.csId
      this.queryParams.schemeId = this.courseChapter.schemeId
      this.queryParams.unitId = this.courseChapter.sourceUnitId
      this.fetchData()
    },
    // 选中多个id
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.fileId)
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        // 删除按钮可用状态
        this.deldisabled = false
      }
    },
    // 当点击全选时则通过条件全部删除
    selectAll(selection) {
      this.ids = selection.map(item => item.fileId)
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        // 删除按钮可用状态
        this.deldisabled = false
        this.isSelectAll = true
      }
    },
    /** 删除按钮操作 */
    handleDelete(item) {
      // 处理删除
      this.$confirm('您确定要删除所选任务?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.handleDelete2(item)
        })
    },
    // 单条删除按钮
    handleDelete2(item) {
      console.log('handleDelete2============item = ', item)
      const prepareStudyTask = this.prepareStudyTask
      const type = item.type
      const fileId = item.fileId
      console.log('fileId = ', fileId)
      // 如果是图文
      if (type === '图文') {
        // prepareStudyTask.psTitle = null
        prepareStudyTask.textScore = 0
        prepareStudyTask.textCondition = 0
        prepareStudyTask.textMaterials = null
        prepareStudyTask.psTitle = ''
        this.prepareStudyFormSubmit(prepareStudyTask)
      } else if (type === 'ppt' || type === 'excel' || type === 'doc' || type === 'word' || type === 'txt' || type === 'pdf') {
        // arr.splice(arr.findIndex(item => item.id === 8), 1)
        if (typeof prepareStudyTask.pptMaterials === 'object') {
          prepareStudyTask.pptMaterials = JSON.parse(prepareStudyTask.pptMaterials)
        }
        const ppt = prepareStudyTask.pptMaterials
        const index = ppt.findIndex(item => item.fileId === fileId)
        if (index !== -1) {
          prepareStudyTask.pptMaterials.splice(index, 1)
          this.prepareStudyFormSubmit(prepareStudyTask)
        }
        if (prepareStudyTask.pptMaterials === undefined) {
          prepareStudyTask.pptMaterials = []
        }
      } else if (type === 'audio') {
        const audio = prepareStudyTask.audioMaterials
        const audioIndex = audio.findIndex(item => item.fileId === fileId)
        if (audioIndex !== -1) {
          prepareStudyTask.audioMaterials.splice(audioIndex, 1)
          this.prepareStudyFormSubmit(prepareStudyTask)
        }
        if (prepareStudyTask.audioMaterials === undefined) {
          prepareStudyTask.audioMaterials = []
        }
      } else if (type === 'download') {
        if (typeof prepareStudyTask.refMaterials === 'object') {
          prepareStudyTask.refMaterials = JSON.parse(prepareStudyTask.refMaterials)
        }
        const ref = prepareStudyTask.refMaterials
        const refIndex = ref.findIndex(item => item.fileId === fileId)
        if (refIndex !== -1) {
          prepareStudyTask.refMaterials.splice(refIndex, 1)
          this.prepareStudyFormSubmit(prepareStudyTask)
        }
        if (prepareStudyTask.refMaterials === undefined) {
          prepareStudyTask.refMaterials = []
        }
      } else if (type === 'video') {
        if (typeof prepareStudyTask.videoMaterials === 'object') {
          prepareStudyTask.videoMaterials = JSON.parse(prepareStudyTask.videoMaterials)
        }
        const ref = prepareStudyTask.videoMaterials
        const videoIndex = ref.findIndex(item => item.fileId === fileId)
        if (videoIndex !== -1) {
          prepareStudyTask.videoMaterials.splice(videoIndex, 1)
          this.prepareStudyFormSubmit(prepareStudyTask)
        }
        if (prepareStudyTask.videoMaterials === undefined) {
          prepareStudyTask.videoMaterials = []
        }
      }
    },
    // 预习/学习任务添加或编辑
    prepareStudyFormSubmit(form) {
      form.pptMaterials = JSON.stringify(form.pptMaterials)
      form.refMaterials = JSON.stringify(form.refMaterials)
      form.audioMaterials = JSON.stringify(form.audioMaterials)
      form.videoMaterials = JSON.stringify(form.videoMaterials)
      form.totalMaterials = form.totalMaterials - 1
      // 修改到数据库
      prepareStudyTaskApi
        .updateFrontStudyTask(form)
        .then(response => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
          this.fetchData()
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 批量删除
    handleBatchDelete() {
      // const prepareStudyTask = this.prepareStudyTask
      // pptMaterials.forEach((item, index) => {
      // })
    },
    close() {
      // this.$refs['form'].clearValidate()
      this.prepareStudyTask = {}
      this.tableData = []
      this.textTotal = 0
      this.videoTotal = 0
      this.audioTotal = 0
      this.pptTotal = 0
      this.refTotal = 0
      this.allTotal = 0
      this.dialog.show = false
      // 刷新页面
      this.$emit('getTreeBySchemeId')
    }
  }
}
</script>

<style scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
