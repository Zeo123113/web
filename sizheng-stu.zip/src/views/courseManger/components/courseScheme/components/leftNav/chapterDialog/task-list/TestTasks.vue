<!--
@description 测验任务列表展示
@author cgy
-->
<template>
  <div class="testtask">

    <el-form ref="form" :model="form" label-width="150px">
      <el-row>
        <el-button type="text" icon="el-icon-plus" size="mini" @click="addTestTask">新增</el-button>
        <el-table
          v-loading="loading"
          size="mini"
          :data="testTaskList"
          @selection-change="handleSelectionChange"
          @select-all="selectAll"
        >
          <el-table-column label="测验标题" prop="examTitle" align="center" min-width="100" />
          <el-table-column
            label="是否开始测验"
            prop="isBeginExam"
            :formatter="isBeginExamFormatter"
            align="center"
            sortable
            min-width="135"
          />
          <el-table-column
            label="测验开始时间"
            prop="examStartTime"
            align="center"
            sortable
            show-overflow-tooltip
            min-width="135"
          />
          <el-table-column
            label="测验时长(分钟)"
            prop="limitTime"
            align="center"
            sortable
            min-width="150"
          ></el-table-column>
          <el-table-column label="创建时间" prop="createTime" align="center" sortable min-width="160" />
          <el-table-column label="更新时间" prop="updateTime" align="center" sortable min-width="160" />
          <el-table-column
            label="操作"
            align="center"
            min-width="200"
            fixed="right"
            style="height:90px"
          >
            <template slot-scope="scope">
              <el-button
                type="text"
                icon="el-icon-edit"
                size="mini"
                @click="addTestTask(scope.row)"
              >编辑</el-button>
              <el-button
                type="text"
                icon="el-icon-edit"
                size="mini"
                @click="marking(scope.row)"
              >批阅</el-button>
              <el-button
                type="text"
                icon="el-icon-delete"
                size="mini"
                @click="handleDelete(scope.row)"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <!-- 添加或修改实验弹出框 -->
        <TestChapter
          ref="testdialog"
          :form="form"
          :course-chapter="courseChapter"
          :testdialog="testdialog"
          @getList="getList"
        />
      </el-row>
    </el-form>
  </div>
</template>

<script>
// import pagination from '@/components/Pagination/index'
import TestChapter from '../task-chapter/TestChapter'
import USER_CONST from '@/constant/user-const'
import testTaskApi from '@/api/course/courseTask/testTask.js'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import COURSE_CONST from '@/constant/course-const'
export default {
  name: 'TestTasks',
  components: {
    TestChapter
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseChapter: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      ids: [],
      queryParams: {
        ctId: this.courseChapter.ctId,
        orgId: this.courseChapter.orgId,
        csId: this.courseChapter.csId,
        schemeId: this.courseChapter.schemeId,
        unitId: this.courseChapter.sourceUnitId
      },
      form: {},
      // 弹出框
      testdialog: {
        title: '',
        show: false
      },
      // 当前页
      pageIndex: 1,
      // 页数限制
      pageNum: USER_CONST.PAGESIZE,
      // 总记录数
      total: 0,
      // 批量操作数组
      multipleSelection: [],
      // 批量按钮状态
      multselect: true,
      // 批量删除Ids数组
      testTaskIds: [],
      // 测验类型数据字典
      testTypeOptions: [],
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      testTaskList: [],
      labelWidth: '120px'
    }
  },
  created() {
    this.openDialog()
  },
  methods: {
    marking(row) {
      this.$emit('marking', row)
    },
    // 添加/编辑测验任务
    addTestTask(testTask) {
      this.resetTestTask()
      if (testTask != null && testTask.ttaskId > 0) {
        this.form = { ...testTask }
        this.testdialog.title = '修改测验任务'
      } else {
        this.testdialog.title = '添加测验任务'
      }
      this.form.unitId = this.courseChapter.sourceUnitId
      this.form.chapterId = this.courseChapter.chapterId
      this.testdialog.show = true
    },
    // 用户类型字典翻译
    testTypeFormat(row) {
      return this.selectDictLabel(this.testTypeOptions, row.testType)
    },
    // 分页查询
    pageQuery(pagePara) {
      this.getList(this.testTaskSelect, pagePara.page, pagePara.limit)
    },
    // 是否开始测验
    isBeginExamFormatter(row) {
      if (row.isBeginExam) {
        return '是'
      } else {
        return '否'
      }
    },
    resetTestTask() {
      this.form = {
        csId: this.courseChapter.csId,
        ctId: this.courseChapter.ctId,
        schemeId: this.courseChapter.schemeId,
        unitId: '',
        examArrangeId: '',
        requireCredit: '',
        redoInterval: '',
        limitTime: '',
        ttaskId: -1,
        examStatus: COURSE_CONST.NOTSTART,
        testType: '',
        orgId: this.courseChapter.orgId,
        examTitle: '',
        beginTime: '',
        endTime: '',
        createOrgId: '',
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        chapterId: null,
        remark: ''
      }
    },
    openDialog() {
      // 测验类型数据字典获取
      this.getDataByType('course_testtask_testtype').then(response => {
        this.testTypeOptions = response.data
      })
      this.getDataByType('exambank_exam_status').then(response => {
        this.examStatusTypeDict = response.data
      })
      this.queryParams.ctId = this.courseChapter.ctId
      this.queryParams.orgId = this.courseChapter.orgId
      this.queryParams.csId = this.courseChapter.csId
      this.queryParams.schemeId = this.courseChapter.schemeId
      this.queryParams.unitId = this.courseChapter.sourceUnitId
      this.getList()
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },

    // 当选择项发生变化时，赋值多选数组
    handleSelectionChange(val) {
      this.multipleSelection = val
      this.testTaskIds = val.map(item => item.ttaskId)
    },
    /** 全选 */
    selectAll(selection) {
      if (selection.length > 0) {
        this.isSelectAll = true
      } else {
        this.isSelectAll = false
      }
      this.testTaskIds = selection.map(item => item.ttaskId)
    },
    /**
     *处理删除
     */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        testTaskApi
          .delete(row.ttaskId)
          .then(resp => {
            if (resp.code === 0) {
              this.$message({
                message: '删除成功',
                type: 'success'
              })
            } else {
              this.$message({
                message: resp.msg,
                type: 'error'
              })
            }
            this.getList()
          })
          .catch(err => {
            console.log(err)
          })
      })
    },
    /**
     *批量删除成绩设置
     * */
    handleDeleteMore(param) {
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        if (this.isSelectAll) {
          testTaskApi
            .deleteBatch(this.testTaskIds.toString())
            .then(resp => {
              if (resp.code === 0) {
                this.$message({
                  type: 'success',
                  message: '删除成功!'
                })
                this.getList()
              }
            })
            .catch(err => {
              console.log(err)
            })
        }
      })
    },
    // 初始化获取数据
    getList() {
      this.loading = true
      testTaskApi.list(this.queryParams, this.pageIndex, this.pageNum).then(response => {
        this.testTaskList = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    }
  }
}
</script>

<style scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
