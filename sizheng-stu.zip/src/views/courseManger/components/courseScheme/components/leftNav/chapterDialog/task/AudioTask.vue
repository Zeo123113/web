<!--
@description 音频资料
@author cgy
-->
<template>
  <div class="TextTask">
    <div id="task-create-content" class="task-create-content">
      <el-col :span="24">
        <el-form-item label="标题名称" :label-width="formLabelWidth" prop="fileTitle">
          <el-input v-model="form.fileTitle" style="width:300px;" placeholder="请输入标题名称" clearable />
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-form-item label="音频" :label-width="formLabelWidth" prop="audioMaterials">
          <AudioUpload
            v-if="!isTask"
            :audio-materials="form.audioMaterials"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="material"
            @fileLastInfo="fileLastInfo"
            @deleteAudio="deleteAudio"
          />
          <div v-else>
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
      </el-col>
    </div>
  </div>
</template>
<script>
// import courseMaterialApi from '@/api/course/courseManage/courseMaterial'
import AudioUpload from '../upload/AudioUpload'
export default {
  name: 'VideoTask',
  components: {
    AudioUpload
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    },
    dialog: {
      type: Object,
      required: true
    },
    task: {
      type: Object,
      required: true
    },
    courseMaterial: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      isTask: false,
      // 表单属性宽度
      formLabelWidth: '100px',
      material: {}
    }
  },
  created() {
    console.log('task = ', this.task)
  },
  methods: {
    updateFile() {
      this.isTask = !this.isTask
    },
    // 得到上传后的文件信息
    fileLastInfo(material) {
      this.form.fileTitle = material.title
      this.task.title = material.title
      material.type = 'audio'
      this.isTask = !this.isTask
      this.$emit('getMaterial', material)
    },
    // 删除audioMaterials的index位的元素
    deleteAudio(index) {
      // array.splice(start,delCount);//从start的位置开始向后删除delCount个元素
      this.form.audioMaterials.splice(index, 1)
    }
  }
}
</script>
<style lang="scss" scoped>
.icon {
  // TODO： 触摸小手
  cursor: pointer;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}
</style>

