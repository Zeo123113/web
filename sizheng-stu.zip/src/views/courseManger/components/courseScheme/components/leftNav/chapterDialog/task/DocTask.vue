<!--
@description 文档资料
@author cgy
-->
<template>
  <div class="TextTask">
    <div id="task-create-content" class="task-create-content">
      <el-col :span="24">
        <el-form-item label="标题名称" :label-width="formLabelWidth">
          <el-input
            v-model="form.fileTitle"
            style="width:300px;"
            placeholder="请输入标题名称"
            @input="($event)"
          />
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-form-item
          v-if="type === 'ppt'"
          label="PPT"
          :label-width="formLabelWidth"
          prop="pptMaterials"
        >
          <DocUpload
            v-if="!isTask"
            :doc-suffix="docSuffix"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="courseMaterial"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
        <el-form-item
          v-if="type === 'doc'"
          label="文档"
          :label-width="formLabelWidth"
          prop="pptMaterials"
        >
          <DocUpload
            v-if="!isTask"
            :doc-suffix="docSuffix"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="courseMaterial"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
        <el-form-item
          v-if="type === 'excel'"
          label="Excel"
          :label-width="formLabelWidth"
          prop="pptMaterials"
        >
          <DocUpload
            v-if="!isTask"
            :doc-suffix="docSuffix"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="courseMaterial"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
        <el-form-item
          v-if="type === 'pdf'"
          label="PDF"
          :label-width="formLabelWidth"
          prop="pptMaterials"
        >
          <DocUpload
            v-if="!isTask"
            :doc-suffix="docSuffix"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="courseMaterial"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
        <el-form-item
          v-if="type === 'word'"
          label="Word"
          :label-width="formLabelWidth"
          prop="pptMaterials"
        >
          <DocUpload
            v-if="!isTask"
            :doc-suffix="docSuffix"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="courseMaterial"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
        <el-form-item
          v-if="type === 'txt'"
          label="Txt"
          :label-width="formLabelWidth"
          prop="pptMaterials"
        >
          <DocUpload
            v-if="!isTask"
            :doc-suffix="docSuffix"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="courseMaterial"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
        <el-form-item
          v-if="type === 'download'"
          label="选择资料"
          :label-width="formLabelWidth"
          prop="refMaterials"
        >
          <DocUpload
            v-if="!isTask"
            :doc-suffix="docSuffix"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="courseMaterial"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-form-item v-if="isTask" label="文档页数" :label-width="formLabelWidth">
          <span>{{ task.pages }}</span>页
        </el-form-item>
      </el-col>
    </div>
  </div>
</template>
<script>
import DocUpload from '../upload/DocUpload'
export default {
  name: 'DocTask',
  components: {
    DocUpload
  },
  props: {
    type: {
      type: String,
      required: true
    },
    courseScheme: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    },
    courseMaterial: {
      type: Object,
      required: true
    },
    task: {
      type: Object,
      required: true
    },
    dialog: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      docSuffix: '.ppt, .pptx, .xls, .xlsx, .doc, .pdf, .docx, .txt',
      // 表单属性宽度
      formLabelWidth: '100px',
      isTask: false
    }
  },
  created() {
    if (this.dialog.title === '修改预习任务' || this.dialog.title === '修改学习任务') {
      this.isTask = true
    }
    if (this.type === 'ppt') {
      this.docSuffix = '.ppt, .pptx'
    } else if (this.type === 'pdf') {
      this.docSuffix = '.pdf'
    } else if (this.type === 'excel') {
      this.docSuffix = '.xlsx, .xls'
    } else if (this.type === 'word') {
      this.docSuffix = '.docx, .doc'
    } else if (this.type === 'txt') {
      this.docSuffix = '.txt'
    } else if (this.type === 'doc') {
      this.docSuffix = '.ppt, .pptx, .xls, .xlsx, .doc, .pdf, .docx, .txt'
    } else if (this.type === 'download') {
      this.docSuffix = '.ppt, .pptx, .xls, .xlsx, .doc, .pdf, .docx, .txt, .mp3'
    }
    console.log('this.type = ', this.type)
    console.log('DocTask--------this.form = ', this.form)
  },
  methods: {
    change() {
      this.$forceUpdate()
    },
    updateFile() {
      this.isTask = !this.isTask
    },
    // 得到上传后的文件信息
    fileLastInfo(material) {
      this.task.title = material.title
      this.task.pages = material.length
      this.form.pages = material.length
      this.form.fileTitle = material.title
      material.type = this.type
      console.log('material = ', material)
      const mater = { ...material }
      this.$emit('getMaterial', mater)
      this.isTask = !this.isTask
    },
    // 删除refMaterials的index位的元素
    deleteRef(index) {
      if (this.type === 'ppt' || this.type === 'pdf' || this.type === 'excel' || this.type === 'word' || this.type === 'txt') {
        this.form.pptMaterials.splice(index, 1)
      }
      if (this.type === 'download') {
        // array.splice(start,delCount);//从start的位置开始向后删除delCount个元素
        this.form.refMaterials.splice(index, 1)
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.icon {
  // TODO： 触摸小手
  cursor: pointer;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}
</style>

