<!--
@description 下载资料（不用转换）
@author cgy
-->
<template>
  <div class="TextTask">
    <div id="task-create-content" class="task-create-content">
      <el-col :span="24">
        <el-form-item label="标题名称" :label-width="formLabelWidth" prop="fileTitle">
          <el-input
            v-model="form.fileTitle"
            style="width:300px;"
            placeholder="请输入标题名称"
            @input="($event)"
          />
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-form-item label="选择资料" :label-width="formLabelWidth" prop="refMaterials">
          <RefUpload
            v-if="!isTask"
            :doc-suffix="docSuffix"
            :course-scheme="courseScheme"
            :form="form"
            :course-material="courseMaterial"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
      </el-col>
    </div>
  </div>
</template>
<script>
import RefUpload from '../upload/refUpload'
export default {
  name: 'RefTask',
  components: {
    RefUpload
  },
  props: {
    type: {
      type: String,
      required: true
    },
    courseScheme: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    },
    courseMaterial: {
      type: Object,
      required: true
    },
    task: {
      type: Object,
      required: true
    },
    dialog: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      docSuffix: '.ppt, .pptx, .xls, .xlsx, .doc, .pdf, .docx, .txt',
      // 表单属性宽度
      formLabelWidth: '100px',
      isTask: false
    }
  },
  created() {
    if (this.dialog.title === '修改预习任务' || this.dialog.title === '修改学习任务') {
      this.isTask = true
    }
  },
  methods: {
    change() {
      this.$forceUpdate()
    },
    updateFile() {
      this.isTask = !this.isTask
    },
    // 得到上传后的文件信息
    fileLastInfo(material) {
      this.task.title = material.title
      this.form.fileTitle = material.title
      material.type = this.type
      console.log('material = ', material)
      this.$emit('getMaterial', material)
      this.isTask = !this.isTask
    },
    // 删除refMaterials的index位的元素
    deleteRef(index) {
      this.form.refMaterials.splice(index, 1)
    }
  }
}
</script>
<style lang="scss" scoped>
.icon {
  // TODO： 触摸小手
  cursor: pointer;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}
</style>

