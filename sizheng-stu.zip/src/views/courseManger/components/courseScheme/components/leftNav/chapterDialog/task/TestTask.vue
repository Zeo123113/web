<!--
@description 课程设置
@author cgy
-->
<template>
  <div class="TextTask">
    <el-form ref="form" :model="form" :rules="rules" label-width="140px">
      <el-row>
        <el-col :span="20">
          <el-form-item label="测验标题" prop="examTitle" :label-width="formLabelWidth">
            <el-input
              v-model="form.examTitle"
              placeholder="请输入测验标题"
              autocomplete="off"
              clearable
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <el-form-item label="测验安排" prop="examArrangeId" :label-width="formLabelWidth">
            <el-select v-model="form.examArrangeId" placeholder="请选择测验安排" clearable style="width:225px">
              <el-option
                v-for="examArrange in examArrangeOptions"
                :key="examArrange.roundId"
                :label="examArrange.examTitle"
                :value="examArrange.roundId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="所需学分" prop="requireCredit" :label-width="formLabelWidth">
            <el-input-number
              v-model="form.requireCredit"
              controls-position="right"
              :step="1"
              :min="0"
              :max="10"
              style="width:225px"
            ></el-input-number>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <el-form-item label="重做间隔(分钟）" prop="redoInterval" :label-width="formLabelWidth">
            <el-input-number
              v-model="form.redoInterval"
              controls-position="right"
              :step="10"
              :min="10"
              :max="240"
              style="width:225px"
            ></el-input-number>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="测验类型" prop="testType" :label-width="formLabelWidth">
            <el-select v-model="form.testType" placeholder="请选择测验类型">
              <el-option
                v-for="dict in testTypeOptions"
                :key="dict.dictvalue"
                :label="dict.dictLabel"
                :value="dict.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <!-- <el-row>
        <el-col :span="12">
          <el-form-item label="开始测验" prop="isBeginExam" :label-width="formLabelWidth">
            <el-switch
              v-model="form.isBeginExam"
              active-color="#13ce66"
              inactive-color="#ff4949"
            ></el-switch>
          </el-form-item>
        </el-col>
      </el-row> -->
      <el-row>
        <el-col :span="20">
          <el-form-item label="备注" prop="remark" :label-width="formLabelWidth">
            <el-input
              v-model="form.remark"
              type="textarea"
              :rows="3"
              placeholder="请输入备注"
              controls-position="right"
              :min="1"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
import examArrangeApi from '@/api/exambank/examArrange'
export default {
  name: 'TextTask',
  components: {

  },
  props: {
    form: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 表单属性宽度
      formLabelWidth: '140px',
      rules: {
        examArrangeId: [{ required: true, message: '请选择测验安排', trigger: 'blur' }],
        examTitle: [{ required: true, message: '测验标题不能为空', trigger: 'blur' }]
      },
      testTypeOptions: [],
      examArrangeOptions: []
    }
  },
  created() {
    // 测验类型数据字典获取
    this.getDataByType('course_testtask_testtype').then(response => {
      console.log(response)
      this.testTypeOptions = response.data
    })
    var data = {
      courseId: this.form.csId,
      termId: this.form.ctId,
      examType: EXAMBANK_CONST.TEST
    }
    examArrangeApi.getExamArrangeByCondition(data).then(response => {
      this.examArrangeOptions = response.data
    })
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}
</style>

