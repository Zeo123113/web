<!--
@description 课程设置
@author cgy
-->
<template>
  <div class="TextTask">
    <div id="task-create-content" class="task-create-content">
      <el-col :span="24">
        <el-form-item label="标题名称" :label-width="formLabelWidth" prop="psTitle">
          <el-input v-model="form.psTitle" style="width:300px;" placeholder="请输入标题名称" clearable />
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-form-item label="内容" :label-width="formLabelWidth" prop="textMaterials">
          <tinymce v-model="form.textMaterials" :save-flag="saveFlag" :height="500" />
        </el-form-item>
      </el-col>
    </div>
  </div>
</template>
<script>
import Tinymce from '@/components/Tinymce'
export default {
  name: 'TextTask',
  components: {
    Tinymce
  },
  props: {
    form: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 表单属性宽度
      formLabelWidth: '100px',
      // 富文本开启标志
      saveFlag: false
    }
  },
  methods: {
  }
}
</script>
<style lang="scss" scoped>
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}
</style>

