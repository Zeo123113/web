<!--
@description 课程设置
@author cgy
-->
<template>
  <div class="TextTask">
    <div id="task-create-content" class="task-create-content">
      <el-col :span="24">
        <el-form-item label="标题名称" :label-width="formLabelWidth" prop="fileTitle">
          <el-input
            v-model="form.fileTitle"
            style="width:300px;"
            placeholder="请输入标题名称"
            @input="($event)"
          />
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-form-item label="视频" :label-width="formLabelWidth" prop="videoMaterials">
          <VideoUpload
            v-if="!isTask"
            :form="form"
            :course-material="courseMaterial"
            :task="task"
            :scheme="courseScheme"
            @fileLastInfo="fileLastInfo"
            @deleteRef="deleteRef"
          />
          <div v-if="isTask">
            <span>{{ task.title }}</span>
            <svg
              class="icon"
              aria-hidden="true"
              style="margin-left: 1rem"
              @click="updateFile(task.fileId)"
            >
              <use xlink:href="#icon-cross8" />
            </svg>
          </div>
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-form-item v-if="isTask" label="视频时长" :label-width="formLabelWidth">
          <span>{{ task.time }}</span>
        </el-form-item>
      </el-col>
    </div>
  </div>
</template>
<script>
import VideoUpload from '../upload/VideoUpload'
export default {
  name: 'VideoTask',
  components: {
    VideoUpload
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    },
    courseMaterial: {
      type: Object,
      required: true
    },
    dialog: {
      type: Object,
      required: true
    },
    task: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 表单属性宽度
      formLabelWidth: '100px',
      isTask: false
    }
  },
  created() {
    if (this.dialog.title === '修改预习任务' || this.dialog.title === '修改学习任务') {
      this.isTask = true
    }
  },
  methods: {
    change() {
      this.$forceUpdate()
    },
    /**
     * 时间秒数格式化
     * @param s 时间戳（单位：秒）
     * @returns {*} 格式化后的时分秒
     */
    sec_to_time(s) {
      let t
      if (s > -1) {
        const hour = Math.floor(s / 3600)
        const min = Math.floor(s / 60) % 60
        const sec = s % 60
        if (hour < 10) {
          t = hour + '时'
        } else {
          t = hour + '时'
        }
        // if (min < 10) { t += '0' }
        t += min + '分'
        // if (sec < 10) { t += '0' }
        t += sec + '秒'
      }
      return t
    },
    // 得到上传后的文件信息
    fileLastInfo(material) {
      this.task.title = material.title
      this.task.fileId = material.fileId
      this.task.time = this.sec_to_time(material.length)
      this.form.fileTitle = material.title
      material.type = 'video'
      console.log('fileLastInfo---------------material = ', material)
      // this.form.videoMaterials.push(material)
      this.isTask = true
      this.$emit('getMaterial', material)
    },
    updateFile() {
      this.isTask = false
    },
    // 删除refMaterials的index位的元素
    deleteRef(index) {
      this.form.videoMaterials.splice(index, 1)
    }
  }
}
</script>
<style lang="scss" scoped>
.icon {
  // TODO： 触摸小手
  cursor: pointer;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-finish {
  min-height: 200px;
}

.hidden {
  display: none !important;
}
.task-create-editor .task-create-content-iframe,
.task-create-editor .task-create-finish-iframe {
  width: 100%;
  min-height: 200px;
  border: none;
}
.task-create-editor .task-create-content {
  min-height: 200px;
  position: relative;
}
</style>

