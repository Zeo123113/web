<!--
@description 课程资源文件管理--上传文件弹出框组件
@author zhouhuan
-->
<template>
  <div>
    <el-dialog :title="fileUploade.title" :visible.sync="fileUploade.show" width="60%">
      <span slot="footer" class="dialog-footer">
        <el-upload
          ref="upload"
          :action="studentUploadUrl"
          :data="fileInfo"
          :limit="1"
          accept=".ppt, .xls, .xlsx, .doc, .pdf, .docx, .txt"
          :before-upload="beforeUpload"
          :on-success="uploadSuccess"
          :on-error="uploadError"
          :headers="headers"
          :on-progress="uploadFileProcess"
          :show-file-list="false"
          class="p_upload"
          :auto-upload="false"
        >
          <el-button slot="trigger" size="small" type="primary">选取文档</el-button>
          <el-button
            style="margin-left: 10px;"
            size="small"
            type="success"
            @click="inputFileSubmitUpload"
          >上传到服务器</el-button>
        </el-upload>
        <el-button size="small" @click="closedialog()">取 消</el-button>
      </span>
    </el-dialog>
    <el-dialog title="音频文件上传" :visible.sync="FileUploade.show" width="60%">
      <span slot="footer" class="dialog-footer">
        <el-upload
          ref="upload"
          :action="audioUploadUrl"
          :data="fileInfo"
          :limit="1"
          accept=".mp3"
          :before-upload="beforeUpload"
          :on-success="uploadSuccess"
          :on-error="uploadError"
          :headers="headers"
          :show-file-list="false"
          :auto-upload="false"
          class="p_upload"
        >
          <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
          <el-button
            style="margin-left: 10px;"
            size="small"
            type="success"
            @click="inputFileSubmitUpload"
          >上传到服务器</el-button>
        </el-upload>
        <el-button size="small" @click="closedialog()">取 消</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
// import FILE_CONST from '@/constant/file-const'
import WebUploader from 'webuploader' // 引入webuploder
import { getToken } from '@/utils/auth'
// import mediaFileApi from '@/api/file/media-file'
import { gbSubstr } from '@/utils/index'
export default {
  name: 'FileUploadDialog',
  props: {
    fileUploade: {
      type: Object,
      required: true
    },
    fileInfo: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      headers: {
        token: getToken()
      },
      studentUploadUrl: process.env.VUE_APP_BASE_API + '/file/student-files/upload/info',
      systemUploadUrl: process.env.VUE_APP_BASE_API + '/file/system-files/upload/info',
      audioUploadUrl: process.env.VUE_APP_BASE_API + '/file/audio-files/upload/info',
      fileList: [],   // 保存选择文件的列表
      uploader: {},   // 上传对象
      fileOriginalNameList: [],
      fileTagList: [],
      fileStatusOptions: [],
      isLt2k: '',
      isedit: false
    }
  },
  watch: {
    fileList: function(oldValue, newValue) {}
  },
  created() {
    // 文件状态获取
    this.getDataByType('video_file_status').then(response => {
      this.fileStatusOptions = response.data
    })
  },
  methods: {
    // 文件上传过程中的函数(在这里获取进度条的进度)
    uploadFileProcess(event, file, fileList) {
      this.fileArr = fileList
      this.fileArr.forEach(item => {
        if (item.percentage == 100) {

        } else {
          item.progressFlag = true
          item.progressPercent = Math.abs(item.percentage.toFixed(0))
        }
      })
    },
    /** 提交上传文件 */
    inputFileSubmitUpload() {
      this.$refs.upload.submit()
    },
    /** 打开窗口时，初始化 */
    openDialog() {
      this.fileList = []
      this.uploader.reset()
    },

    /**
     * @description 格式化字符串为指定长度，字母占1个宽度，汉字占2个宽度
     * @method
     * @param {string} str 要格式化的字符串
     * @param {number} len 要截取的字符串长度
     * @returns {string} 格式化后的字符串，超长部分用“...”表示
     */
    formatstr(str, len) {
      return gbSubstr(str, len)
    },

    /**
     * @description 格式化文件长度
     * @method
     * @param {number} size 文件长度
     * @returns {string} 格式化后的文件长度
     */
    fileSize(size) {
      return WebUploader.Base.formatSize(size)
    },

    /**
     * @description 根据文件扩展名显示不同的图标
     * @method
     * @param {string} ext 文件扩展名
     * @returns {string} 返回图标名称
     */
    fileCategory(ext) {
      let type = ''
      const typeMap = {
        'image': ['gif', 'jpg', 'jpeg', 'png', 'bmp', 'webp'],
        'video': ['mp4', 'avi', 'rm', 'rmvb', 'wmv', 'ogg', '3gp', 'mov', 'flv', 'mkv'],
        'text': ['doc', 'txt', 'docx', 'pages', 'epub', 'pdf', 'numbers', 'csv', 'xls', 'xlsx', 'keynote', 'ppt', 'pptx']
      }
      Object.keys(typeMap).forEach((_type) => {
        const extensions = typeMap[_type]
        if (extensions.indexOf(ext) > -1) {
          type = _type
        }
      })
      const map = { 'image': 'el-icon-picture', 'video': 'el-icon-video-camera', 'text': 'el-icon-document' }
      return map[type]
    },

    /**
     * @description 从文件队列中删除文件
     * @method
     * @param {string} fileId 要删除的文件Id
     * @returns 无
     */
    remove(fileId) {
      let id = null
      this.fileList.forEach(item => {
        if (item.file.id === fileId) {
          id = item.id
        }
      })
      this.fileList.splice(id, 1)
      this.uploader.removeFile(fileId, true)
      this.fileList.forEach((item, index) => {
        item.id = index
        this.$set(this.fileList, index, item)
      })
    },
    /**
     * @description 根据文件id查找文件在文件列表中的索引
     * @method
     * @param {string} fileId 文件Id
     * @returns {number} 文件在文件列表中的索引，找不到返回-1
     */
    getIndexFromFileList(fileId) {
      let fileIndex = -1
      this.fileList.forEach((item, index) => {
        if (item.file.id === fileId) {
          fileIndex = index
        }
      })
      return fileIndex
    },

    /**
     * @description 开始上传文件
     * @method
     * @returns 无
     */
    upload() {
      if (this.fileList.length === 0) {
        this.$message({
          type: 'info',
          message: '请先选择要上传的文件!'
        })
        return
      }
      this.uploader.upload()
    },
    /** 上传之前检测文件类型及大小 */
    beforeUpload: function(file) {
      this.isLt2k = file.size / 1024 / 1024 < 10 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过10M!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 文件上传成功时的勾子 */
    uploadSuccess: function(response, file, fileList) {
      this.$refs.upload.clearFiles()
      this.closedialog()
      if (response.code === 0) {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件成功！',
          type: 'success'
        })
        console.log('uploadSuccess-----response.data = ', response.data)
        this.$emit('fileInfo', response.data)
      } else {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件失败!' + response.msg,
          type: 'error'
        })
      }
    },
    /** 上传失败时的勾子 */
    uploadError: function(err, file, fileList) {
      this.$refs.upload.clearFiles()
      this.closedialog()
      this.$message({
        message: '上传文件失败!',
        type: 'error'
      })
      console.log(err)
    },
    closedialog() {
      this.fileInfo.fileTag = ''
      this.fileInfo.fileOriginalName = null
      this.fileUploade.show = false
    }
  }
}
</script>
<style lang="scss" scoped>
/* TODO: 上传组件样式 */
.p_upload >>> .el-upload__input {
  display: none;
}
.p_upload >>> .el-upload >>> input {
  display: none;
}
.app-main {
  background-color: #f3f3f4;
}
.container-div {
  padding: 0 28px 0 28px;
  height: 100%;
}
.searchbox {
  box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
  background: #fff;
  width: 100%;
  border-radius: 6px;
  margin-top: 10px;
  padding-top: 10px;
  padding-left: 5px;
  padding-bottom: 5px;
}
.el-form--inline .el-form-item {
  margin-right: 10px;
}
.btn {
  border-radius: 50px;
  padding: 8px 10px;
}
.p_upload {
  display: inline-block;
  padding: 0px 10px;
}
.el-dialog__body {
  padding: 10px 20px;
}
#picker div:nth-child(2) {
  display: inline-block;
  background: #1890ff;
  border-radius: 4px;
  padding: 16px 40px;
  overflow: inherit !important;
  text-decoration: none;
  text-indent: 0;
  line-height: 20px;
  position: relative !important;
  top: 12px !important;
  left: 0px !important;
}
#picker div:nth-child(2) > input {
  position: absolute;
  top: 0px;
  left: 0px;
  font-size: 20px;
  opacity: 0;
  width: 100px;
  height: 36px;
}
#picker .webuploader-pick {
  position: absolute;
  top: 0px;
  left: 0px;
  opacity: 0;
}
#picker div:nth-child(2)::before {
  content: '选择文件';
  display: block;
  position: absolute;
  top: 6px;
  right: 15px;
  color: #fff;
  font-size: 12px;
  cursor: pointer;
}
.uploader-list {
  margin-top: 10px;
}
$h-row: 32px;
.file-panel {
  .file-list {
    position: relative;
    background-color: #ffffff;
  }
  .file-item {
    font-size: 14px;
    margin: 0px;
    position: relative;
    height: $h-row;
    line-height: $h-row;
    padding: 0 10px;
    border-bottom: 1px solid #ccc;
    background-color: #fff;
    z-index: 1;
    > li {
      display: inline-block;
    }
  }
  .file-type {
    width: 4%;
    color: #409eff;
  }
  .file-name {
    width: 36%;
    margin-left: 10px;
  }
  .file-size {
    width: 15%;
  }
  .file-status {
    width: 35%;
  }
  .file-operate {
    width: 5%;
    margin: 0px auto;
    text-align: center;
    > a {
      padding: 8px 5px;
      cursor: pointer;
      color: #666;
      &:hover {
        color: #ff4081;
      }
    }
  }
  .progress {
    position: absolute;
    top: 0;
    left: 0;
    height: $h-row - 1;
    width: 0;
    background-color: #e2edfe;
    z-index: -1;
  }
  .no-file {
    display: block;
    height: $h-row;
    line-height: $h-row;
    margin: 0px auto;
    text-align: center;
    font-size: 14px;
  }
}
</style>
