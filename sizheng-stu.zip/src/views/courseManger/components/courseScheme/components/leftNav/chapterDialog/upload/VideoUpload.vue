<template>
  <div class="file-chooser-main">
    <div class="file-chooser-nav">
      <ul id="material" class="nav nav-pills nav-pills-sm nav-pills-gray mb0">
        <li role="presentation" :class="{'active': active == '1'}">
          <a @click="selectPresent('1')">上传资料</a>
        </li>
        <li role="presentation" :class="{'active': active == '2'}">
          <a @click="selectPresent('2')">从资料库中选择</a>
        </li>
        <li role="presentation" :class="{'active': active == '3'}">
          <a @click="selectPresent('3')">从课程中选择文件</a>
        </li>
      </ul>
    </div>
    <div class="tab-content">
      <div v-if="active == '1'" class="tab-pane file-chooser-tab">
        <el-button @click="videoUploade()">上传视频</el-button>
      </div>
      <div v-if="active == '2'" class="tab-pane">
        <div class="chooser-content">
          <div class="row">
            <div class="col-sm-6 radios">
              <label class="js-material-type prm" data-type="my">
                <input
                  type="radio"
                  name="file-browser-video-source"
                  value="upload"
                  checked
                  @click="fromUpload()"
                />
                来自上传
              </label>
              <label class="js-material-type prm" data-type="public">
                <input
                  type="radio"
                  name="file-browser-video-source"
                  value="public"
                  @click="isPublic()"
                />
                公共资料
              </label>
            </div>
            <div class="col-sm-6 material-search-form hidden-xs">
              <span class="input-group js-file-name-group">
                <el-input v-model="queryParams.materialTitle" placeholder="输入标题关键字" size="medium" />
                <span class="input-group-btn">
                  <el-button size="medium" @click="fetchData">搜索</el-button>
                </span>
              </span>
            </div>
          </div>
        </div>
        <div class="js-material-list chooser-list-parent">
          <div class="chooser-list">
            <table v-loading="loading" class="table table-striped table-hover">
              <tbody>
                <tr
                  v-for="(item,i) of tableData"
                  :key="i"
                  class="file-browser-item"
                  @click="addMaterial(item)"
                >
                  <td>{{ item.fileName }}</td>
                  <td>{{ item.fileLength }}</td>
                  <td>{{ item.createTime }}</td>
                </tr>
                <tr id="material-table-tr-17" class="file-browser-item">
                  <td class="mlm" @click="fetchData">更多请搜索</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div v-if="active == '3'" class="tab-pane file-chooser-tab">
        <span class="input-group js-file-name-group mb10">
          <el-input v-model="queryParams.materialTitle" placeholder="输入标题关键字" size="medium" />
          <span class="input-group-btn">
            <el-button size="medium" @click="fetchData">搜索</el-button>
          </span>
        </span>

        <table v-loading="loading" class="table table-striped table-hover">
          <tbody>
            <tr
              v-for="(item,i) of tableData"
              :key="i"
              class="file-browser-item"
              @click="addMaterial(item)"
            >
              <td>{{ item.fileName }}</td>
              <td>{{ item.fileLength }}</td>
              <td>{{ item.createTime }}</td>
            </tr>
            <tr id="material-table-tr-17" class="file-browser-item">
              <td class="mlm" @click="fetchData">更多请搜索</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- <div v-if="active == '4'" class="tab-pane file-chooser-tab">
        <div class="tab-pane">
          <div class="import-content">
            <div class="input-group">
              <input class="form-control border-gray mb0" />
              <span class="input-group-btn">
                <button type="button" class="btn btn-default js-video-import">导入</button>
              </span>
            </div>
            <div class="text-warning mts">
              <div>* 腾讯和网易的视频不支持手机端播放</div>
              <div>* 优酷和腾讯视频额外支持“复制通用代码”导入（鼠标移到视频页面的“分享”上出现）</div>
            </div>
          </div>
        </div>
      </div>-->
    </div>
    <!-- 上传文件组件 -->
    <video-upload-dialog
      ref="VideoUploadDialog"
      :video-file-uploade="videoFileUploade"
      :file-info="fileInfo"
      @fileUploadInfo="fileUploadInfo"
    />
  </div>
</template>
<script>
import courseMaterialApi from '@/api/course/courseManage/courseMaterial'
import VideoUploadDialog from './VideoUploadDialog'
export default {
  name: 'VideoUpload',
  components: { VideoUploadDialog },
  props: {
    scheme: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    },
    task: {
      type: Object,
      required: true
    },
    courseMaterial: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      docSuffix: '.mp4, .avi, .rm, .rmvb, .wmv, .ogg, .3gp, .mov, .flv, .mkv',
      loading: false,
      active: '1',
      // 查询条件
      queryParams: {
        orgId: this.scheme.orgId,
        csId: this.scheme.csId,
        ctId: null,
        schemeId: null,
        materialTitle: null,
        isPublic: null,
        createOrgId: null,
        fileMime: null
      },
      // 上传文件时文件标签
      fileType: '',
      tableData: [],
      videoFileUploade: {
        show: false
      },
      fileInfo: {
        fileId: {},
        fileTag: '',
        md5: '',
        fileName: '',
        fileOriginalName: '',
        filePath: '',
        fileUrl: '',
        fileType: '',
        fileSize: 0,
        fileLength: '',
        createBy: '',
        createTime: '',
        updateBy: '',
        updateTime: ''
      },
      material: {
        fileId: '',
        title: '',
        url: '',
        length: null,
        score: null
      }
    }
  },
  methods: {
    // 公开资料
    isPublic() {
      this.queryParams.isPublic = true
      this.fetchData()
    },
    // 来自上传
    fromUpload() {
      this.queryParams.createOrgId = this.user.orgId
      this.fetchData()
    },
    // 对文件（字节）大小进行处理
    changeFileSize(a, b) {
      if (a === 0) {
        return '0 Bytes'
      }
      const c = 1024
      const d = b || 2
      const e = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
      const f = Math.floor(Math.log(a) / Math.log(c))
      return parseFloat((a / Math.pow(c, f)).toFixed(d)) + ' ' + e[f]
    },
    // 从课程资料中选择资料
    addMaterial(item) {
      console.log('addMaterial(item) = ', item)
      const material = {
        fileId: '',
        title: '',
        type: '',
        url: '',
        length: '',
        score: '',
        condition: '',
        finshTime: ''
      }
      material.title = item.fileName
      material.fileId = item.fileId
      material.url = item.fileUrl
      material.length = item.fileSize
      console.log('addMaterial----material = ', material)
      this.$emit('fileLastInfo', material)
      // this.selectPresent('1')
    },
    selectPresent(active) {
      this.active = active
      if (active === '2') {
        this.queryParams.csId = this.scheme.csId
        this.queryParams.ctId = this.scheme.ctId
        this.queryParams.schemeId = this.scheme.schemeId
        this.fetchData()
      } else if (active === '3') {
        // 从课程中选择
        this.queryParams.csId = this.scheme.csId
        // this.queryParams.ctId = this.scheme.ctId
        // this.queryParams.schemeId = this.scheme.schemeId
        this.fetchData()
      }
    },
    // 获得tableData,带有分页
    fetchData() {
      this.loading = true
      this.tableData = []
      this.queryParams.fileMime = 'mp4'
      courseMaterialApi.listCourseMaterial(this.queryParams, 1, 5).then(response => {
        this.tableData = response.data.list
        // const docSuffix = this.docSuffix
        this.loading = false
        this.tableData.forEach(item => {
          item.fileLength = this.changeFileSize(item.fileSize, 2)
        })
      })
    },
    // 得到上传后的文件信息
    fileUploadInfo(val) {
      if (
        val.ext === 'mp4' ||
        val.ext === 'avi' ||
        val.ext === 'rm' ||
        val.ext === 'rmvb' ||
        val.ext === 'wmv' ||
        val.ext === 'ogg' ||
        val.ext === '3gp' ||
        val.ext === 'mov' ||
        val.ext === 'flv' ||
        val.ext === 'mkv'
      ) {
        console.log('视频------val = ', val)
        // this.task = { ...val }
        const fileTask = {
          fileId: '',
          title: '',
          type: '',
          url: '',
          length: '',
          score: '',
          condition: '',
          finshTime: ''
        }
        fileTask.fileId = val.fileIdHexString
        fileTask.title = val.fileOriginalName
        fileTask.type = 'video'
        fileTask.url = val.m3u8
        fileTask.length = val.playDuration
        console.log('this.form.videoMaterials = ', this.form.videoMaterials)
        // this.form.videoMaterials.push(fileTask)
        this.$emit('fileLastInfo', fileTask)
        // 添加到课程资料中
        // this.resetCourseMaterial()
        this.courseMaterial.orgId = this.$store.getters.user.orgId
        this.courseMaterial.materialTitle = val.fileOriginalName
        this.courseMaterial.fileUrl = val.m3u8
        this.courseMaterial.fileId = val.fileIdHexString
        this.courseMaterial.fileName = val.fileOriginalName
        this.courseMaterial.fileSize = val.playDuration
        this.courseMaterial.unitId = this.form.unitId
        this.courseMaterial.fileMime = val.ext
        this.courseMaterialSubmit()
        // this.$emit('fileLastInfo', val)
      }
    },
    // 课程资料的添加或编辑
    courseMaterialSubmit() {
      if (this.courseMaterial.materialId > 0) {
        courseMaterialApi.updateCourseMaterial(this.courseMaterial).then(response => {
          if (response.code === 0) {
            this.$message({
              message: '课程资料修改成功',
              type: 'success'
            })
            // this.dialog.show = false
            // this.$emit('reset')
          } else {
            this.$message.error('课程资料修改失败')
          }
        })
      } else {
        courseMaterialApi.addCourseMaterial(this.courseMaterial).then(response => {
          if (response.code === 0) {
            this.$message({
              message: '课程资料添加成功',
              type: 'success'
            })
            // this.dialog.show = false
            // this.$emit('reset')
          } else {
            this.$message.error('课程资料添加失败')
          }
        })
      }
    },
    // 点击上传视频资料
    videoUploade() {
      this.videoFileUploade.show = true
    }
  }
}
</script>
<style lang="scss" scoped>
.icon {
  width: 1.5em;
  height: 1.5em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
@media (min-width: 768px) {
  .col-sm-6 {
    float: left;
    width: 50%;
  }
}
.row {
  margin-left: -10px;
  margin-right: -10px;
}
.chooser-content,
.import-content {
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  background-color: #f8fbfd;
}
.chooser-content {
  margin: 0 15px 15px;
  padding: 15px;
}
.tab-content > .tab-pane {
  display: block;
}
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.app-main {
  background-color: #f3f3f4;
}
.container-div {
  padding: 0 28px 0 28px;
  height: 100%;
}
.searchbox {
  box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
  background: #fff;
  width: 100%;
  border-radius: 6px;
  margin-top: 10px;
  padding-top: 10px;
  padding-left: 5px;
  padding-bottom: 5px;
}
.el-form--inline .el-form-item {
  margin-right: 10px;
}
.btn {
  border-radius: 50px;
  padding: 8px 10px;
}
.upload-button {
  display: inline-block;
  padding: 0px 10px;
}
.el-dialog__body {
  padding: 10px 20px;
}
#picker div:nth-child(2) {
  display: inline-block;
  background: #1890ff;
  border-radius: 4px;
  padding: 16px 40px;
  overflow: inherit !important;
  text-decoration: none;
  text-indent: 0;
  line-height: 20px;
  position: relative !important;
  top: 12px !important;
  left: 0px !important;
}
#picker div:nth-child(2) > input {
  position: absolute;
  top: 0px;
  left: 0px;
  font-size: 20px;
  opacity: 0;
  width: 100px;
  height: 36px;
}
#picker .webuploader-pick {
  position: absolute;
  top: 0px;
  left: 0px;
  opacity: 0;
}
#picker div:nth-child(2)::before {
  content: '选择文件';
  display: block;
  position: absolute;
  top: 6px;
  right: 15px;
  color: #fff;
  font-size: 12px;
  cursor: pointer;
}
.uploader-list {
  margin-top: 10px;
}
$h-row: 32px;
.file-panel {
  .file-list {
    position: relative;
    background-color: #ffffff;
  }
  .file-item {
    font-size: 14px;
    margin: 0px;
    position: relative;
    height: $h-row;
    line-height: $h-row;
    padding: 0 10px;
    border-bottom: 1px solid #ccc;
    background-color: #fff;
    z-index: 1;
    > li {
      display: inline-block;
    }
  }
  .file-type {
    width: 4%;
    color: #409eff;
  }
  .file-name {
    width: 36%;
    margin-left: 10px;
  }
  .file-size {
    width: 15%;
  }
  .file-status {
    width: 35%;
  }
  .file-operate {
    width: 5%;
    margin: 0px auto;
    text-align: center;
    > a {
      padding: 8px 5px;
      cursor: pointer;
      color: #666;
      &:hover {
        color: #ff4081;
      }
    }
  }
  .progress {
    position: absolute;
    top: 0;
    left: 0;
    height: $h-row - 1;
    width: 0;
    background-color: #e2edfe;
    z-index: -1;
  }
  .no-file {
    display: block;
    height: $h-row;
    line-height: $h-row;
    margin: 0px auto;
    text-align: center;
    font-size: 14px;
  }
}
.chooser-list .table-striped > tbody > tr > td {
  border-top: 0;
  padding: 10px;
}

.table > tbody > tr > td,
.table > tbody > tr > th,
.table > tfoot > tr > td,
.table > tfoot > tr > th,
.table > thead > tr > td,
.table > thead > tr > th {
  padding: 10px 15px;
}
.table > tbody > tr > td,
.table > tbody > tr > th,
.table > tfoot > tr > td,
.table > tfoot > tr > th,
.table > thead > tr > td,
.table > thead > tr > th {
  padding: 8px;
  line-height: 1.42857143;
  vertical-align: top;
  border-top: 1px solid #ddd;
}
.table td {
  word-wrap: break-word;
  word-break: break-all;
}
.mlm {
  margin-left: 10px !important;
}
td,
th {
  padding: 0;
}
.chooser-list .table-striped > tbody > tr:nth-of-type(odd) {
  background-color: #fafafa;
}
.table-striped > tbody > tr:nth-of-type(odd) {
  background-color: #f9f9f9;
}
.chooser-list .table-striped {
  margin-bottom: 0;
}

.table {
  width: 100%;
  max-width: 100%;
  margin-bottom: 20px;
}
table {
  background-color: transparent;
}
table {
  border-collapse: collapse;
  border-spacing: 0;
}
.chooser-list {
  position: relative;
  height: 163px;
  overflow: auto;
  background-color: #fff;
}
.input-group-btn:last-child > .btn,
.input-group-btn:last-child > .btn-group {
  margin-left: -1px;
}
.input-group-btn,
.input-group-btn > .btn {
  position: relative;
}
.input-group-btn {
  font-size: 0;
  white-space: nowrap;
}
.input-group-addon:first-child,
.input-group-btn:first-child > .btn,
.input-group-btn:first-child > .btn-group > .btn,
.input-group-btn:first-child > .dropdown-toggle,
.input-group-btn:last-child > .btn-group:not(:last-child) > .btn,
.input-group-btn:last-child > .btn:not(:last-child):not(.dropdown-toggle),
.input-group .form-control:first-child {
  border-bottom-right-radius: 0;
  border-top-right-radius: 0;
}
.input-group-addon,
.input-group-btn,
.input-group .form-control {
  display: table-cell;
}
.input-group .form-control {
  position: relative;
  z-index: 2;
  float: left;
  width: 100%;
  margin-bottom: 0;
}
.form-control {
  color: #616161;
  border-color: #e1e1e1;
}
.form-control {
  width: 100%;
  height: 34px;
  padding: 6px 12px;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-transition: border-color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.mb10 {
  margin-bottom: 10px !important;
}

.input-group {
  position: relative;
  display: table;
  border-collapse: separate;
}
.file-chooser-main .file-chooser-tab {
  padding: 15px;
  border-top: 1px solid #e1e1e1;
}
.tab-content {
  height: 24rem;
  width: 100%;
}
.uploader-content .uploader-container {
  border: 1px dashed #e4ecf3;
  padding: 5px 10px;
}
.uploader-content {
  background-color: #f8fbfd;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  padding: 30px 30px 15px;
}
.file-chooser-main .file-chooser-tab {
  padding: 15px;
  border-top: 1px solid #e1e1e1;
}

.tab-content > .active {
  display: block;
}
.nav-pills.nav-pills-gray > li.active > a {
  background: #e50112;
}
.nav-pills.nav-pills-gray > li > a {
  background-color: #f8fbfd;
}
.nav-pills.nav-pills-sm > li > a {
  font-size: 12px;
  line-height: 1.5;
  padding: 4px 13px;
}
.nav-pills > li.active > a {
  color: #fff;
  background: #e50112;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.nav-pills > li.active > a,
.nav-pills > li.active > a:focus,
.nav-pills > li.active > a:hover {
  color: #fff;
  background-color: #e50112;
}
.nav-pills > li {
  margin-right: 5px;
}
.nav-pills > li {
  float: left;
}
.nav > li,
.nav > li > a {
  position: relative;
  display: block;
}
.mb0 {
  margin-bottom: 0 !important;
}

.nav {
  margin-bottom: 0;
  padding-left: 0;
  list-style: none;
}
ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.file-chooser-main .file-chooser-nav {
  padding: 15px;
}
.file-chooser-main {
  width: 80%;
  border: 1px solid #e1e1e1;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
}
</style>
