<template>
  <div class="file-chooser-main">
    <div class="file-chooser-nav">
      <ul id="material" class="nav nav-pills nav-pills-sm nav-pills-gray mb0">
        <li role="presentation" :class="{'active': active == '1'}">
          <a @click="selectPresent('1')">上传资料</a>
        </li>
        <li role="presentation" :class="{'active': active == '2'}">
          <a @click="selectPresent('2')">从资料库中选择</a>
        </li>
        <li role="presentation" :class="{'active': active == '3'}">
          <a @click="selectPresent('3')">从课程中选择文件</a>
        </li>
      </ul>
    </div>
    <div class="tab-content">
      <div v-if="active == '1'" class="tab-pane file-chooser-tab">
        <div v-if="progressFlag">
          <el-progress :percentage="progressPercent"></el-progress>上传中
        </div>
        <div style="margin: 0 auto">
          <span slot="footer" class="dialog-footer">
            <el-upload
              ref="upload"
              :action="inputFileUploadUrl"
              :data="fileInfo"
              :limit="1"
              :accept="docSuffix"
              :before-upload="beforeUpload"
              :on-progress="uploadFileProcess"
              :on-success="uploadSuccess"
              :on-error="uploadError"
              :headers="headers"
              :show-file-list="false"
              class="p_upload"
            >
              <el-button slot="trigger" size="small" type="primary">点击上传</el-button>
            </el-upload>
          </span>
        </div>
      </div>
      <div v-if="active === '2' || active === '3'" class="tab-pane">
        <div class="chooser-content">
          <div class="row">
            <div class="col-sm-6 radios">
              <label class="js-material-type prm" data-type="my">
                <input
                  type="radio"
                  name="file-browser-audio-source"
                  value="upload"
                  checked
                  @click="fromUpload()"
                />
                来自上传
              </label>
              <label class="js-material-type prm" data-type="public">
                <input
                  type="radio"
                  name="file-browser-audio-source"
                  value="public"
                  @click="isPublic()"
                />
                公共资料
              </label>
            </div>
            <div class="col-sm-6 material-search-form hidden-xs">
              <span class="input-group js-file-name-group">
                <el-input
                  v-model="queryParams.materialTitle"
                  style="width: 60%;"
                  placeholder="输入标题关键字"
                  size="medium"
                />
                <el-button size="medium" @click="fetchData">搜索</el-button>
              </span>
            </div>
          </div>
        </div>
        <div class="js-material-list chooser-list-parent">
          <div class="chooser-list">
            <table v-loading="loading" class="table table-striped table-hover">
              <tbody>
                <tr
                  v-for="(item,i) of tableData"
                  :key="i"
                  class="file-browser-item"
                  @click="addMaterial(item)"
                >
                  <td>{{ item.fileName }}</td>
                  <td>{{ item.fileLength }}</td>
                  <td>{{ item.createTime }}</td>
                </tr>
                <tr class="mlm">更多请搜索</tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div v-if="active == '3'" class="tab-pane">
        <span class="input-group js-file-name-group mb10">
          <el-input
            v-model="queryParams.materialTitle"
            style="width: 60%;"
            placeholder="输入标题关键字"
            size="medium"
          />
          <el-button size="medium" @click="fetchData">搜索</el-button>
        </span>

        <div class="js-material-list chooser-list-parent">
          <div class="chooser-list">
            <table v-loading="loading" class="table table-striped table-hover">
              <tbody>
                <tr
                  v-for="(item,i) of tableData"
                  :key="i"
                  class="file-browser-item"
                  @click="addMaterial(item)"
                >
                  <td>{{ item.fileName }}</td>
                  <td>{{ item.fileLength }}</td>
                  <td>{{ item.createTime }}</td>
                </tr>
                <tr id="material-table-tr-17" class="file-browser-item">
                  <td class="mlm">更多请搜索</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { getToken } from '@/utils/auth'
import courseMaterialApi from '@/api/course/courseManage/courseMaterial'
// import FileUploadDialog from './FileUploadDialog'
export default {
  name: 'DocUpload',
  components: { },
  props: {
    docSuffix: {
      type: String,
      required: true
    },
    form: {
      type: Object,
      required: true
    },
    courseScheme: {
      type: Object,
      required: true
    },
    courseMaterial: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      fileArr: [],
      progressFlag: false,
      progressPercent: 0,
      headers: {
        token: getToken()
      },
      inputFileUploadUrl: process.env.VUE_APP_BASE_API + '/file/student-files/upload/info',
      loading: false,
      active: '1',
      // 查询条件
      queryParams: {
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        ctId: null,
        schemeId: null,
        materialTitle: null,
        isPublic: null,
        isCanDownload: null,
        docSuffixList: []
      },
      // 上传文件时文件标签
      fileType: '',
      tableData: [],
      FileUploade: {
        title: '',
        type: '',
        show: false
      },
      fileInfo: {
        fileId: {},
        fileTag: '',
        md5: '',
        fileName: '',
        fileOriginalName: '',
        filePath: '',
        fileUrl: '',
        fileType: '',
        fileSize: 0,
        createBy: '',
        createTime: '',
        updateBy: '',
        updateTime: ''
      },
      materials: [],
      material: {
        title: '',
        fileId: null,
        url: '',
        length: null,
        score: null
      }
    }
  },
  methods: {
    // 公开资料
    isPublic() {
      this.queryParams.isPublic = true
      this.fetchData()
    },
    // 来自上传
    fromUpload() {
      this.queryParams.createOrgId = this.user.orgId
      this.fetchData()
    },
    // 对文件（字节）大小进行处理
    changeFileSize(a, b) {
      if (a === 0) {
        return '0 Bytes'
      }
      const c = 1024
      const d = b || 2
      const e = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
      const f = Math.floor(Math.log(a) / Math.log(c))
      return parseFloat((a / Math.pow(c, f)).toFixed(d)) + ' ' + e[f]
    },
    // 文件上传过程中的函数(在这里获取进度条的进度)
    uploadFileProcess(event, file, fileList) {
      // console.log('fileList = ', fileList)
      this.progressFlag = true
      this.progressPercent = Math.abs(fileList[0].percentage.toFixed(0))
      // this.fileArr = { ...fileList }
      // this.fileArr.forEach(item => {
      //   if (item.percentage !== 100) {
      //     item.progressFlag = true
      //     item.progressPercent = Math.abs(item.percentage.toFixed(0))
      //   }
      // })
    },
    /** 提交上传文件 */
    inputFileSubmitUpload() {
      this.$refs.upload.submit()
    },
    selectPresent(active) {
      this.active = active
      if (active === '2') {
        this.queryParams.csId = this.courseScheme.csId
        this.queryParams.ctId = this.courseScheme.ctId
        this.queryParams.schemeId = this.courseScheme.schemeId
        this.fetchData()
      } else if (active === '3') {
        this.queryParams.csId = this.courseScheme.csId
        // this.queryParams.ctId = this.courseScheme.ctId
        // this.queryParams.schemeId = this.courseScheme.schemeId
        this.fetchData()
      }
    },
    // 获得tableData,带有分页
    fetchData() {
      this.loading = true
      this.tableData = []
      this.queryParams.isCanDownload = true
      const queryParams = this.queryParams
      const docSuffixList = this.docSuffix.split(', ')
      const arr2 = []
      docSuffixList.forEach(item => {
        arr2.push(item.slice(1))
      })
      queryParams.docSuffixList = arr2
      this.listCourseMaterial(queryParams)
    },
    listCourseMaterial(queryParams) {
      courseMaterialApi.listCourseMaterial(queryParams, 1, 5).then(response => {
        const tableData = response.data.list
        const arr2 = []
        tableData.forEach(item => {
          const fileLength = this.changeFileSize(item.fileSize, 2)
          item.fileLength = fileLength
          arr2.push(item)
        })
        this.tableData = arr2
        // const docSuffix = this.docSuffix
        this.loading = false
      })
    },
    /** 上传之前检测文件类型及大小 */
    beforeUpload: function(file) {
      this.isLt2k = file.size / 1024 / 1024 < 20 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过20M!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 文件上传成功时的勾子 */
    uploadSuccess: function(response, file, fileList) {
      // this.$refs.upload.clearFiles()
      // this.closedialog()
      if (response.code === 0) {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件成功！',
          type: 'success'
        })
        this.progressPercent = 100
        this.progressFlag = false
        console.log('response.data = ', response.data)
        this.fileUploadInfo(response.data)
      } else {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件失败!' + response.msg,
          type: 'error'
        })
      }
    },
    /** 上传失败时的勾子 */
    uploadError: function(err, file, fileList) {
      // this.$refs.upload.clearFiles()
      // this.closedialog()
      this.$message({
        message: '上传文件失败!',
        type: 'error'
      })
      console.log(err)
    },
    // 得到上传后的文件信息
    fileUploadInfo(val) {
      this.material.title = val.fileOriginalName.split('.')[0]
      this.material.fileId = val.fileIdHexString
      this.material.url = val.fileUrl
      this.material.length = val.fileSize
      console.log('fileUploadInfo-----material = ', this.material)
      // 添加到课程资料中
      // this.resetCourseMaterial()
      this.courseMaterial.orgId = this.$store.getters.user.orgId
      this.courseMaterial.materialTitle = val.fileOriginalName.split('.')[0]
      this.courseMaterial.fileUrl = val.fileUrl
      this.courseMaterial.fileId = val.fileIdHexString
      this.courseMaterial.fileName = val.fileOriginalName.split('.')[0]
      this.courseMaterial.fileSize = val.fileSize
      this.courseMaterial.unitId = this.form.unitId
      this.courseMaterial.fileMime = val.fileType
      this.courseMaterialSubmit()
      this.$emit('fileLastInfo', this.material)
      // this.$emit('materialInfo', this.courseMaterial)
    },
    // 从课程资料中选择资料
    addMaterial(item) {
      console.log('addMaterial(item) = ', item)
      this.material.title = item.fileName
      this.material.fileId = item.fileId
      this.material.url = item.fileUrl
      this.material.length = item.fileSize
      console.log('addMaterial----material = ', this.material)
      this.selectPresent('1')
      this.$emit('fileLastInfo', this.material)
    },
    // 删除已有的音频
    deleteRef(index) {
      this.$emit('deleteRef', index)
    },
    // 课程资料的添加或编辑
    courseMaterialSubmit() {
      if (this.courseMaterial.materialId > 0) {
        courseMaterialApi.updateCourseMaterial(this.courseMaterial).then(response => {
          if (response.code === 0) {
            this.$message({
              message: '课程资料修改成功',
              type: 'success'
            })
            // this.dialog.show = false
            // this.$emit('reset')
          } else {
            this.$message.error('课程资料修改失败')
          }
        })
      } else {
        courseMaterialApi.addCourseMaterial(this.courseMaterial).then(response => {
          if (response.code === 0) {
            this.$message({
              message: '课程资料添加成功',
              type: 'success'
            })
            // this.dialog.show = false
            // this.$emit('reset')
          } else {
            this.$message.error('课程资料添加失败')
          }
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.icon {
  width: 1.5em;
  height: 1.5em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
</style>
<style scoped>
/* TODO: 上传组件样式 */
.p_upload >>> .el-upload__input {
  display: none;
}
.p_upload >>> .el-upload >>> input {
  display: none;
}
</style>
<style lang="scss" scoped>
@media (min-width: 768px) {
  .col-sm-6 {
    float: left;
    width: 50%;
  }
}
.row {
  margin-left: -10px;
  margin-right: -10px;
}
.chooser-content,
.import-content {
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  background-color: #f8fbfd;
}
.chooser-content {
  margin: 0 15px 15px;
  padding: 15px;
}
.tab-content > .tab-pane {
  display: block;
}
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.app-main {
  background-color: #f3f3f4;
}
.container-div {
  padding: 0 28px 0 28px;
  height: 100%;
}
.searchbox {
  box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
  background: #fff;
  width: 100%;
  border-radius: 6px;
  margin-top: 10px;
  padding-top: 10px;
  padding-left: 5px;
  padding-bottom: 5px;
}
.el-form--inline .el-form-item {
  margin-right: 10px;
}
.btn {
  border-radius: 50px;
  padding: 8px 10px;
}
.upload-button {
  display: inline-block;
  padding: 0px 10px;
}
.el-dialog__body {
  padding: 10px 20px;
}
#picker div:nth-child(2) {
  display: inline-block;
  background: #1890ff;
  border-radius: 4px;
  padding: 16px 40px;
  overflow: inherit !important;
  text-decoration: none;
  text-indent: 0;
  line-height: 20px;
  position: relative !important;
  top: 12px !important;
  left: 0px !important;
}
#picker div:nth-child(2) > input {
  position: absolute;
  top: 0px;
  left: 0px;
  font-size: 20px;
  opacity: 0;
  width: 100px;
  height: 36px;
}
#picker .webuploader-pick {
  position: absolute;
  top: 0px;
  left: 0px;
  opacity: 0;
}
#picker div:nth-child(2)::before {
  content: '选择文件';
  display: block;
  position: absolute;
  top: 6px;
  right: 15px;
  color: #fff;
  font-size: 12px;
  cursor: pointer;
}
.uploader-list {
  margin-top: 10px;
}
$h-row: 32px;
.file-panel {
  .file-list {
    position: relative;
    background-color: #ffffff;
  }
  .file-item {
    font-size: 14px;
    margin: 0px;
    position: relative;
    height: $h-row;
    line-height: $h-row;
    padding: 0 10px;
    border-bottom: 1px solid #ccc;
    background-color: #fff;
    z-index: 1;
    > li {
      display: inline-block;
    }
  }
  .file-type {
    width: 4%;
    color: #409eff;
  }
  .file-name {
    width: 36%;
    margin-left: 10px;
  }
  .file-size {
    width: 15%;
  }
  .file-status {
    width: 35%;
  }
  .file-operate {
    width: 5%;
    margin: 0px auto;
    text-align: center;
    > a {
      padding: 8px 5px;
      cursor: pointer;
      color: #666;
      &:hover {
        color: #ff4081;
      }
    }
  }
  .progress {
    position: absolute;
    top: 0;
    left: 0;
    height: $h-row - 1;
    width: 0;
    background-color: #e2edfe;
    z-index: -1;
  }
  .no-file {
    display: block;
    height: $h-row;
    line-height: $h-row;
    margin: 0px auto;
    text-align: center;
    font-size: 14px;
  }
}
</style>

<style lang="scss" scoped>
.chooser-list .table-striped > tbody > tr > td {
  border-top: 0;
  padding: 10px;
}

.table > tbody > tr > td,
.table > tbody > tr > th,
.table > tfoot > tr > td,
.table > tfoot > tr > th,
.table > thead > tr > td,
.table > thead > tr > th {
  padding: 10px 15px;
}
.table > tbody > tr > td,
.table > tbody > tr > th,
.table > tfoot > tr > td,
.table > tfoot > tr > th,
.table > thead > tr > td,
.table > thead > tr > th {
  padding: 8px;
  line-height: 1.42857143;
  vertical-align: top;
  border-top: 1px solid #ddd;
}
.table td {
  word-wrap: break-word;
  word-break: break-all;
}
.mlm {
  margin-left: 10px !important;
}
td,
th {
  padding: 0;
}
.chooser-list .table-striped > tbody > tr:nth-of-type(odd) {
  background-color: #fafafa;
}
.table-striped > tbody > tr:nth-of-type(odd) {
  background-color: #f9f9f9;
}
.chooser-list .table-striped {
  margin-bottom: 0;
}

.table {
  width: 100%;
  max-width: 100%;
  margin-bottom: 20px;
}
table {
  background-color: transparent;
}
table {
  border-collapse: collapse;
  border-spacing: 0;
}
.chooser-list {
  position: relative;
  height: 163px;
  overflow: auto;
  background-color: #fff;
}
.input-group-btn:last-child > .btn,
.input-group-btn:last-child > .btn-group {
  margin-left: -1px;
}
.input-group-btn,
.input-group-btn > .btn {
  position: relative;
}
.input-group-btn {
  font-size: 0;
  white-space: nowrap;
}
.input-group-addon:first-child,
.input-group-btn:first-child > .btn,
.input-group-btn:first-child > .btn-group > .btn,
.input-group-btn:first-child > .dropdown-toggle,
.input-group-btn:last-child > .btn-group:not(:last-child) > .btn,
.input-group-btn:last-child > .btn:not(:last-child):not(.dropdown-toggle),
.input-group .form-control:first-child {
  border-bottom-right-radius: 0;
  border-top-right-radius: 0;
}
.input-group-addon,
.input-group-btn,
.input-group .form-control {
  display: table-cell;
}
.input-group .form-control {
  position: relative;
  z-index: 2;
  float: left;
  width: 100%;
  margin-bottom: 0;
}
.form-control {
  color: #616161;
  border-color: #e1e1e1;
}
.form-control {
  width: 100%;
  height: 34px;
  padding: 6px 12px;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-transition: border-color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.mb10 {
  margin-bottom: 10px !important;
}

.input-group {
  position: relative;
  display: table;
  border-collapse: separate;
}
.file-chooser-main .file-chooser-tab {
  padding: 15px;
  border-top: 1px solid #e1e1e1;
}
.tab-content {
  height: 24rem;
  width: 100%;
}
.uploader-content .uploader-container {
  border: 1px dashed #e4ecf3;
  padding: 5px 10px;
}
.uploader-content {
  background-color: #f8fbfd;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  padding: 30px 30px 15px;
}
.file-chooser-main .file-chooser-tab {
  padding: 15px;
  border-top: 1px solid #e1e1e1;
}

.tab-content > .active {
  display: block;
}
.nav-pills.nav-pills-gray > li.active > a {
  background: #e50112;
}
.nav-pills.nav-pills-gray > li > a {
  background-color: #f8fbfd;
}
.nav-pills.nav-pills-sm > li > a {
  font-size: 12px;
  line-height: 1.5;
  padding: 4px 13px;
}
.nav-pills > li.active > a {
  color: #fff;
  background: #e50112;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.nav-pills > li.active > a,
.nav-pills > li.active > a:focus,
.nav-pills > li.active > a:hover {
  color: #fff;
  background-color: #e50112;
}
.nav-pills > li {
  margin-right: 5px;
}
.nav-pills > li {
  float: left;
}
.nav > li,
.nav > li > a {
  position: relative;
  display: block;
}
.mb0 {
  margin-bottom: 0 !important;
}

.nav {
  margin-bottom: 0;
  padding-left: 0;
  list-style: none;
}
ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.file-chooser-main .file-chooser-nav {
  padding: 15px;
}
.file-chooser-main {
  width: 80%;
  border: 1px solid #e1e1e1;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
}
</style>
