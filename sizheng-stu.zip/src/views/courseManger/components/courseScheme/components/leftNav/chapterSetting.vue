<!--
@description 课时设置
@author cgy
-->
<template>
  <div class="cd-main">
    <div v-if="main" class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">课时设置</div>
    </div>
    <div v-if="testMarkeKey" class="cd-main__heading course-manage-info__title">
      <el-page-header content="阅卷" @back="TestmarkingToMain">
      </el-page-header>
    </div>
    <div class="cd-main__body">
      <div v-if="main" class="task-list-header clearfix js-task-list-header">
        <span data-html="true" class="js-lessons-publish-status" data-original-title>
          课时总数
          <span id="task-num" class="cd-mr16 cd-ml8">{{ courseScheme.lessonCount }}</span>
        </span>
        <label id="isHideUnPublish" class="cd-switch task-list-header__switch hidden">
          <input id="isHideUnpublish" type="checkbox" class="js-switch" name="isHideUnpublish" />
        </label>

        <div class="pull-right">
          <button
            id="step-3"
            class="cd-btn cd-btn-primary cd-btn-sm cd-mr16 js-lesson-create-btn"
            @click="addUnit"
          >添加课时</button>
          <div class="cd-dropdown" data-toggle="cd-dropdown">
            <el-dropdown trigger="click">
              <button class="cd-btn cd-btn-default cd-btn-sm">
                添加章 / 节
                <span class="caret"></span>
              </button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>
                  <a @click="addChapter('章')">添加章</a>
                </el-dropdown-item>
                <el-dropdown-item>
                  <a @click="addChapter('节')">添加节</a>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
      </div>
      <!-- 章，节，课时的目录结构的显示 -->
      <Catalog
        v-if="update"
        :scheme-id="schemeId"
        :course-scheme="courseScheme"
        :test-marke-key="testMarkeKey"
        :chapter-main.sync="main"
        @getTreeBySchemeId="getTreeBySchemeId"
        @testMarke="testMarke"
      />
      <div v-loading="!update" class="nodata"></div>
    </div>
    <!-- 添加或修改预习学习弹出框 -->
    <edit-unit
      ref="dialog"
      :form="courseUnit"
      :course-scheme="courseScheme"
      :dialog="dialog"
      @getTreeBySchemeId="getTreeBySchemeId"
    />
  </div>
</template>
<script>
import courseChapterApi from '@/api/course/courseManage/courseChapter'
import { mapGetters } from 'vuex'
import EditUnit from '../leftNav/chapterDialog/EditUnit'
import Catalog from './chapterDialog/Catalog'
export default {
  name: 'ChapterSetting',
  components: {
    EditUnit,
    Catalog
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      total: 0,
      // 是否刷新
      update: true,
      // 添加课时弹出框
      dialog: {
        title: '',
        show: false
      },
      // 是否显示作业待批阅的列表
      perusalVisible: false,
      courseChapter: {
        chapterId: null,
        orgId: 0,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        parentId: 0,
        chapterTitle: '',
        prePublishTime: null,
        chapterType: '0',
        isOptional: false,
        seq: 0,
        createBy: '',
        updateBy: ''
      },
      schemeId: this.courseScheme.schemeId,
      courseUnit: {},
      form: {},
      main: true,
      testMarkeKey: false
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {
    this.form.orgId = this.user.orgId
  },
  methods: {
    testMarke() {
      this.main = false
      this.testMarkeKey = true
    },
    TestmarkingToMain() {
      this.main = true
      this.testMarkeKey = false
    },
    // 重新刷新页面
    getTreeBySchemeId() {
      // this.update = true
      this.$emit('getTreeBySchemeId')
    },
    // 添加章节
    addChapter(type) {
      this.$prompt('标题', '创建' + type, {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value.length > 50 || value.length < 1) {
          this.$message({
            type: 'warning',
            message: '标题字符不得超过50个或低于1个'
          })
          return
        }
        // 在章节表末尾添加一章或节
        // 算法：1，检索出该课程计划的最后一章
        // 2，如果添加的是章，seq+1
        // 2，如果添加的是节，检索出最后一章的最后节的seq+1
        this.courseChapter.schemeId = this.courseScheme.schemeId
        this.courseChapter.orgId = this.user.orgId
        this.courseChapter.csId = this.courseScheme.csId
        this.courseChapter.ctId = this.courseScheme.ctId
        this.courseChapter.chapterTitle = value
        this.courseChapter.chapterType = this.getType(type)
        this.update = false
        courseChapterApi.addChapter(this.courseChapter).then(response => {
          if (response.code === 0) {
            this.$message({
              message: '添加成功',
              type: 'success'
            })
            this.update = true
            // this.$emit('getTreeBySchemeId')
            // this.dialog.show = false
            // this.$emit('reset')
          } else {
            this.$message.error('添加失败')
            this.update = true
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消输入'
        })
        this.update = true
      })
    },
    // 章节类型，0：章、1：节，:2：单元
    getType(type) {
      if (type === '章') {
        return '0'
      } else if (type === '节') {
        return '1'
      } else if (type === '单元') {
        return '2'
      }
    },
    resetStudyTask() {
      this.form = {
        pstId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        seq: 1,
        studyTaskType: '0',
        psTitle: null,
        startTime: null,
        endTime: null,
        textMaterials: null,
        textScore: null,
        pptMaterials: [],
        videoMaterials: [],
        audioMaterials: [],
        refMaterials: [],
        finishedMaterials: 0,
        totalMaterials: 0,
        isFinished: 0,
        textCondition: null,
        refPstId: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null,
        chapterId: null
      }
    },
    // 添加课时
    addUnit() {
      this.resetUnit()
      this.dialog.title = '添加课时'
      this.dialog.show = true
      // this.update = !this.update
    },
    resetUnit() {
      this.courseUnit = {
        unitId: -1,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        chapterId: '',
        seq: '',
        unitTitle: '',
        isFree: '',
        isCompulsory: '',
        unitStatus: '',
        refUnitId: '',
        unitPrice: '',
        isBuyable: '',
        isLocked: '',
        buyCount: '',
        watchLimit: '',
        delFlag: false,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        courseTitle: '',
        courseTerm: '',
        schemeTitle: '',
        chapterTitle: '',
        createTime: '',
        remark: ''
      }
    },
    // 获取课程总数
    getTotal(total) {
      this.total = total
    }
  }
}
</script>
<style lang="scss" scoped>
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
body {
  font-size: 14px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 14px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.task-empty {
  margin-bottom: 96px;
}
.empty {
  text-align: center;
  color: #c1c1c1;
  padding: 20px 0;
}
.task-empty .task-empty-icon {
  font-size: 50px;
  display: block;
  margin: 60px 0 20px;
}

.es-icon {
  line-height: 1;
}
.es-icon {
  font-family: es-icon !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.cd-btn.cd-btn-default {
  color: rgba(0, 0, 0, 0.88);
  background: #ececec;
  border-color: #ececec;
}

.cd-btn.cd-btn-default,
.cd-btn.cd-btn-warning:active {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn.cd-btn-sm {
  font-size: 12px;
  padding: 7px 10px;
  border-radius: 4px;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.cd-dropdown {
  position: relative;
  display: inline-block;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

.cd-btn.cd-btn-primary {
  color: #fff;
  background: #E50112;
  border-color: #E50112;
}
.cd-btn.cd-btn-sm {
  font-size: 12px;
  padding: 7px 10px;
  border-radius: 4px;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.cd-mr16 {
  margin-right: 16px !important;
}
button,
html input[type='button'],
input[type='reset'],
input[type='submit'] {
  -webkit-appearance: button;
  cursor: pointer;
}
.cd-switch > input {
  display: none;
}

input[type='checkbox'],
input[type='radio'] {
  margin: 4px 0 0;
  margin-top: 1px\9;
  line-height: normal;
}
input[type='checkbox'],
input[type='radio'] {
  box-sizing: border-box;
  padding: 0;
}
.task-list-header__switch {
  position: absolute;
  top: 18px;
}

.cd-switch {
  position: relative;
  border-radius: 20px;
  height: 20px;
  width: 40px;
  background: #ccc;
  background: rgba(0, 0, 0, 0.4);
  transition: all 0.3s ease;
  display: inline-block;
  margin-bottom: 0;
}
.hidden {
  display: none !important;
}
label {
  display: inline-block;
  max-width: 100%;
  margin-bottom: 5px;
  font-weight: 700;
}
.task-list-header {
  position: relative;
  margin-bottom: 24px;
  padding: 0 6px 0 24px;
  height: 56px;
  line-height: 56px;
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 2px 2px 0 rgba(0, 0, 0, 0.06);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
  color: rgba(0, 0, 0, 0.56);
  font-size: 14px;
}

.task-list-header {
  padding-top: 7px;
  padding-bottom: 10px;
  font-size: 16px;
  line-height: 42px;
  background-color: #fff;
  margin-bottom: 18px;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>
