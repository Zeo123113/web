<template>
  <el-dialog :visible.sync="dialogScoreVisible" width="40%" @open="initScore" @close="close">
    <div id="myChart" :style="{width: '500px', height: '500px'}"></div>
  </el-dialog>
</template>
<script>
import assignRecordApi from '@/api/exambank/homework-record'
export default {
  props: {
    dialogScoreVisible: {
      type: Boolean,
      default: false
    },
    hwId: {
      type: Number,
      default: 0
    }
  },
  methods: {
    initScore(data) {
      assignRecordApi.getRecordByHwId(this.hwId).then(resp => {
        // 基于准备好的dom，初始化echarts实例
        const myChart = this.$echarts.init(document.getElementById('myChart'))
        // 绘制图表
        myChart.setOption({
          title: { text: '成绩分布' },
          tooltip: {},
          xAxis: {
            data: ['60分以下', '60-70', '70-80', '80-90', '90-100']
          },
          yAxis: {},
          series: [{
            name: '人数',
            type: 'bar',
            data: [resp.data.flunk, resp.data.pass, resp.data.medium, resp.data.good, resp.data.excellent]
          }]
        })
      })
    },
    close() {
      this.$emit('update:dialogScoreVisible', false)
    }
  }
}
</script>
