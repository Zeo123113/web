<template>
  <div class="cd-detailed-main">
    <div class="cd-main__body">
      <section v-loading="loading">
        <el-button type="text" icon="el-icon-d-arrow-left" @click="goback">返回列表</el-button>
        <div class="headerSelect">
          <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
            <el-form-item label prop="courseName">
              <el-select v-model="queryParams.isGrading" size="small" placeholder="请选择状态">
                <el-option
                  v-for="item in Corrected"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item label prop="courseName">
              <el-select v-model="queryParams.isHomework" size="small" placeholder="请选择关键字类型">
                <el-option
                  v-for="item in courseSelected"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item label prop="conditions">
              <el-input v-model="queryParams.conditions" placeholder="请输入关键字" size="small" />
            </el-form-item>
            <el-form-item>
              <el-button
                type="primary"
                icon="el-icon-search"
                size="mini"
                @click="handleCurrentChange"
              >搜索</el-button>
            </el-form-item>
          </el-form>
        </div>

        <!--  -->
        <ul class="homework-record-list">
          <li v-for="(item, index) in list" :key="index">
            <div class="assign-list-item">
              <el-row>
                <el-col :span="10">
                  <div class="assign_item_title" v-html="item.hwtitle"></div>起止时间：
                  <span>{{ item.startTime }} - {{ item.endTime }}</span>
                </el-col>
                <el-col :span="10">
                  <div>{{ item.realName }}</div>
                  <span>{{ item.createTime }}交卷</span>
                </el-col>
                <el-col :span="3">
                  <el-button
                    type="text"
                    class="assign-item-operation"
                    :style="{color: item.isGrading?'#E50112':'#FFA51F'}"
                    @click="openRecord(item)"
                  >{{ item.isGrading?'已批阅':'开始批阅' }}</el-button>
                </el-col>
              </el-row>
            </div>
          </li>
        </ul>
        <div class="nodata" :style="{display: list.length>0?'none':'block'}">
          <p>
            <svg class="icon icon-tishi" aria-hidden="true">
              <use xlink:href="#icon-tishi" />
            </svg>
          </p>
          <p>没有{{ queryParams.isGrading? '已批阅':'待批阅' }}的作业记录！</p>
        </div>
        <div class="page_box mt30 pt10 mb10 tac">
          <el-pagination
            v-if="total>0"
            :current-page="pageIndex"
            :page-size="pageSize"
            layout="prev, pager, next"
            :total="total"
            prev-text="上一页"
            next-text="下一页"
            @current-change="handleCurrentChange"
          ></el-pagination>
        </div>
      </section>
      <!--分页-->

    </div>

    <!--分页-->
  </div>
</template>

<script>
import assignApi from '@/api/exambank/homework-arrange'
export default {
  props: {
    courseScheme: {
      type: Object,
      required: true
    },
    hwId: {
      type: Number,
      required: true
    },
    showDetail: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      pageSize: 6,
      pageIndex: 1,
      total: 0,
      // 是试卷批阅还是作业批阅
      isall: false,
      queryParams: {
        isGrading: false,
        isHomework: 0,
        conditions: null,
        createBy: this.$store.getters.user.loginName
      },
      // 试卷或作业列表
      list: [],
      Corrected: [
        {
          value: false,
          label: '待批阅'
        },
        {
          value: true,
          label: '已批阅'
        }
      ],
      courseSelected: [
        {
          value: 0,
          label: '用户名'
        }
      ],
      loading: false
    }
  },
  mounted() {
    this.queryParams.courseSchemaId = this.courseScheme.schemeId
    this.queryParams.hwId = this.hwId
    this.selectHomeworkArrangeEndList(this.queryParams)
  },
  methods: {
    selectHomeworkArrangeEndList(queryParams) {
      assignApi.selectHomeworkArrangeEndList(queryParams, this.pageIndex, this.pageSize).then(resp => {
        this.list = resp.data.list
        this.total = resp.data.total
      })
    },
    handleCurrentChange() {
      this.selectHomeworkArrangeEndList(this.queryParams)
    },
    // 打开详情
    openRecord(current) {
      console.log(current)
      this.$router.push({
        path: `/homework-correct/${current.hwId}/${current.stuUserId}`
      })
    },
    // 关闭详情
    goback() {
      this.$emit('update:showDetail', false)
    }
  }
}
</script>

<style lang="scss" scoped>
p {
  text-indent: 2em;
}
.el-main {
  text-align: left;
}
.all {
  font-size: 16px;
  padding: 0 25px;
  height: 35px;
  line-height: 30px;
}
.el-pagination {
  text-align: center;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
  .el-button {
    color: black;
    background-color: transparent;
    border: 0;
  }
}
.all-background {
  color: #fff !important;
  background: #e50012 !important;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.el-form-item {
  margin-bottom: 0;
}
.headerSelect {
  background-color: #fafafa;
  border: 1px solid #f5f5f5;
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  box-shadow: none;
  padding: 9px;
  border-radius: 2px;
}
.cd-detailed-main {
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
  .cd-main__body {
    padding: 32px;
    min-height: 900px;
    .nodata {
      p {
        font-size: 16px;
        color: #9199a1;
        text-align: center;
        line-height: 24px;
        margin-bottom: 4px;
      }
    }
  }
  .cd-main__heading {
    padding: 24px 32px;
    box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
    .cd-main__title {
      font-size: 16px;
      color: rgba(0, 0, 0, 0.88);
      line-height: 1;
      margin: 0 auto;
      font-weight: 500;
    }
  }
}
.homework-record-list {
  .assign-list-item {
    padding: 20px;
    border: 1px solid #dddddd;
    border-radius: 5px;
    margin-top: 10px;
    position: relative;
    padding: 15px;
    background: #fff;
    cursor: pointer;
    border-radius: 5px;
    text-align: left;
    .assign_item_title {
      font-size: 14px;
    }
    span {
      color: #cccccc;
      line-height: 24px;
    }
    .assign-item-operation {
      color: #E50112 !important;
      font-size: 14px;
      cursor: pointer;
    }
  }
}
</style>
