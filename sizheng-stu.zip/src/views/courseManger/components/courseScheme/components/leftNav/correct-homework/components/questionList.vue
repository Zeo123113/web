<!--
@description 显示试题列表
@author cpy
-->
<template>
  <el-dialog :visible.sync="dialogListVisible" title="答题分布" width="60%" @open="getQuestionList" @close="close">
    <el-table
      :data="questionlist"
      row-key="tqSeq"
      border
      tooltip-effect="light"
      :tree-props="{children: 'materialQuestions'}"
      style="width: 100%"
    >
      <el-table-column prop="tqSeq" label="序号" align="center" min-width="50"></el-table-column>
      <el-table-column
        prop="tqTypeId"
        label="试题类型"
        align="center"
        :formatter="tqTypeFormatter"
        min-width="50"
      ></el-table-column>
      <el-table-column
        prop="title"
        label="题目内容"
        align="center"
        show-overflow-tooltip
        min-width="180"
      ></el-table-column>
      <el-table-column label="提交人数" prop="submitNum" align="center" min-width="50" />
      <el-table-column label="正确率" prop="correct" align="center" min-width="50" />
    </el-table>
  </el-dialog>
</template>
<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
import assignApi from '@/api/exambank/homework-arrange'
export default {
  name: 'QuestionList',
  props: {
    dialogListVisible: {
      type: Boolean,
      default: false
    },
    hwId: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      // 试题类型常量定义
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      MATERIAL: EXAMBANK_CONST.MATERIAL,
      PROG_FILLBLANK: EXAMBANK_CONST.PROG_FILLBLANK,

      // 填空题进行转换的中间使用变量
      content: [],
      options: [],
      // 加载
      loading: false,
      // 存在的试题类型
      questionOptions: [],
      // 试题类型
      questionTypeOptions: [],
      // 试题序号
      tqSeq: 1,
      questionlist: []
    }
  },
  created() {
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.questionTypeOptions = response.data
    })
  },
  methods: {
    // 获取试题列表
    getQuestionList() {
      assignApi.getQuestionByAssignIdForStatistic(this.hwId).then(resp => {
        if (resp.code === 0) {
          this.questionlist = this.setTqSeq(resp.data)
        }
      })
    },
    setTqSeq(questionlist) {
      questionlist.forEach(item => {
        if (item.materialQuestions  !== null) {
          item.materialQuestions.forEach(material => {
            material.tqSeq = item.tqSeq + '.' + material.tqSeq
          })
        }
      })
      return questionlist
    },
    // 试题类型翻译
    tqTypeFormatter(row) {
      return this.selectDictLabel(this.questionTypeOptions, row.tqTypeId.toString())
    },
    close() {
      this.$emit('update:dialogListVisible', false)
    }
  }
}
</script>
<style lang="scss" scoped>
.QuestionItem {
  border: 1px solid #e3e3e3;
  padding: 20px;
  margin-bottom: 15px;
}
.el-collapse-item__header {
  color: #606266;
}
.el-collapse {
  border: 0px;
}
.el-button--text[data-v-6bb6c0b9] {
  border-color: transparent;
  color: #999;
  padding: 0px;
  border-radius: 100%;
}
.el-collapse-item {
  .el-collapse-item__wrap {
    margin-left: 50px;
    border: 0px;
  }
}
.content {
  margin-left: 2em;
  p {
    padding: 0;
    margin: 0;
    -webkit-margin-before: 0em;
    -webkit-margin-after: 0em;
    -webkit-margin-start: 0px;
    -webkit-margin-end: 0px;
    span {
      font-size: 14px !important;
      font-family: 'Microsoft YaHei';
    }
  }
  span {
    font-family: 'Microsoft YaHei';
    font-size: 14px !important;
  }
}
</style>
<style scoped>
.el-collapse-item__header {
  border: 0px !important;
}
</style>
