<template>
  <div class="cd-main">
    <div v-if="!showDetail" v-loading="loading" class="content">
      <div class="cd-main__heading">
        <div class="cd-main__title">作业批阅</div>
      </div>
      <div v-if="statisticsList.length == 0" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>还没有需要批改的作业</p>
      </div>
      <div v-else class="cd-main__body">
        <div>
          <div
            v-for="(item,index) in statisticsList"
            :key="index"
            class="clearfix testpaper-mark-list"
          >
            <div class="testpaper-mark-info col-md-8">
              <div class="row">
                <div class="col-md-8">
                  <div
                    class="testpaper-mark-info__title text-overflow"
                    title="选修课时：ads"
                  >选修课时：{{ item.unitTitle }}</div>
                  <div class="testpaper-mark-info__name">
                    <div v-html="item.homeworkArrange.hwtitle"></div>

                  </div>
                  <div class="mbm color-gray">
                    <div class="hwobject">作业对象：{{ item.homeworkArrange.hwobject }}</div>
                    <span class="mrl">
                      起止时间：
                      {{ item.homeworkArrange.startTime }} - {{ item.homeworkArrange.endTime }}
                    </span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="testpaper-mark-operation">
                    <div class="col-xs-4 text-center mt10">
                      <el-tooltip content="成绩分布" placement="top" effect="light">
                        <el-button type="text" @click="openScore(item)">
                          <svg class="icon" aria-hidden="true">
                            <use xlink:href="#icon-zhuzhuangfenbu" />
                          </svg>
                        </el-button>
                      </el-tooltip>
                    </div>
                    <div class="col-xs-4 text-center mt10">
                      <el-tooltip content="答题分布" placement="top" effect="light">
                        <el-button type="text" @click="gotoQuestionList(item)">
                          <svg class="icon" aria-hidden="true">
                            <use xlink:href="#icon-kaoshitiliang" />
                          </svg>
                        </el-button>
                      </el-tooltip>
                    </div>
                    <div class="col-xs-4 text-center mt10">
                      <el-tooltip content="批阅" placement="top" effect="light">
                        <el-button type="text" @click="gotoexamines(item)">
                          <svg class="icon" aria-hidden="true">
                            <use xlink:href="#icon-piyue" />
                          </svg>
                        </el-button>
                      </el-tooltip>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="testpaper-mark-status col-md-4 text-center">
              <div class="row">
                <div class="col-xs-4 testpaper-mark-warning-status">
                  <span class="testpaper-mark-status__text">应交</span>
                  <br />
                  <p class="mtm pts">{{ item.required }}</p>
                </div>
                <div class="col-xs-4 testpaper-mark-success-status">
                  <span class="testpaper-mark-status__text">已交</span>
                  <br />
                  <p class="mtm pts">{{ item.submitted }}</p>
                </div>
                <div class="col-xs-4 testpaper-mark-danger-status">
                  <span class="testpaper-mark-status__text">未交</span>
                  <br />
                  <p class="mtm pts">{{ item.uncommitted }}</p>
                </div>
              </div>
            </div>
          </div>
          <nav class="text-center"></nav>
        </div>
        <!--分页-->
        <div v-if="statisticsList.length>0" class="page_box mt30 pt10 mb10 tac">
          <el-pagination
            :current-page="pageIndex"
            :page-size="pageSize"
            layout="prev, pager, next"
            :total="total"
            prev-text="上一页"
            next-text="下一页"
            @current-change="handleCurrentChange"
          ></el-pagination>
        </div>
      </div>
    </div>

    <Detailed v-if="showDetail" :course-scheme="courseScheme" :show-detail.sync="showDetail" :hw-id="hwId"></Detailed>
    <Score :dialog-score-visible.sync="dialogScoreVisible" :hw-id="hwId"></Score>
    <QuestionList :dialog-list-visible.sync="dialogListVisible" :hw-id="hwId" />
  </div>
</template>
<script>
import assignApi from '@/api/exambank/homework-arrange'
import Score from './components/Score'
import Detailed from './components/detailed'
import QuestionList from './components/questionList'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
export default {
  components: {
    Score, Detailed, QuestionList
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 统计列表
      statisticsList: [],
      // 成绩分布弹窗
      dialogScoreVisible: false,
      // 查看成绩分布的hwId
      hwId: null,
      pageSize: 10,
      pageIndex: 1,
      total: 0,
      // 是否显示未批阅列表
      showDetail: false,
      loading: false,
      // 答题分布弹窗
      dialogListVisible: false,
      // 分组列表
      courseMgOptions: []
    }
  },
  mounted() {
    this.getList()
    courseMemberGroupApi.getCourseMemberGroupBySchemeId(this.courseScheme.schemeId).then(response => {
      this.courseMgOptions = response.data
    })
  },
  methods: {
    getList() {
      this.loading = true
      assignApi.statisticsHomework(this.courseScheme.schemeId, this.pageIndex, this.pageSize).then(resp => {
        this.statisticsList = resp.data.list
        this.statisticsList.forEach(task => {
          task.homeworkArrange.hwobject = this.MgFormat(task.homeworkArrange.hwobject)
        })
        this.loading = false
      })
    },
    // 作业对象翻译
    MgFormat(hwobject) {
      return this.getMgFormat(hwobject, this.courseMgOptions)
    },
    getMgFormat(id, options) {
      for (let i = 0; i < options.length; i++) {
        if (id === options[i].id) {
          return options[i].label
        }
        if (options[i].children != null && options[i].children.length > 0) {
          this.getMgFormat(id, options[i].children)
        }
      }
    },
    openScore(item) {
      this.hwId = item.homeworkArrange.hwId
      this.dialogScoreVisible = true
    },
    // 打开批阅列表
    gotoexamines(item) {
      this.hwId = item.homeworkArrange.hwId
      console.log(this.hwId)
      this.showDetail = true
    },
    // 打开答题
    gotoQuestionList(item) {
      this.hwId = item.homeworkArrange.hwId
      console.log(this.hwId)
      this.dialogListVisible = true
    },
    // 换页
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    }
  }
}
</script>
<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
  .nodata {
    padding: 150px 0;
    text-align: center;
  }
  .content{
    min-height: 900px;
  }
  .nodata {
    p {
      font-size: 16px;
      color: #9199a1;
      text-align: center;
      line-height: 24px;
      margin-bottom: 4px;
    }
  }
  .hwobject {
    margin-bottom: 8px;
  }
  .cd-main__heading {
    padding: 24px 32px;
    box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
  }
  .cd-main__body {
    padding: 32px;
    min-height: 900px;
    .testpaper-mark-list {
      border-radius: 5px;
      padding-bottom: 0;
      border: 0;
      overflow: hidden;
      margin-bottom: 20px;
      .testpaper-mark-info {
        background-color: #fafafa;
        padding: 0 15px;
      }
      .testpaper-mark-status {
        padding: 40px 11px 35px;
        height: 140px;
        background-color: #f4f4f4;
        border-left: 1px dashed #dcdcdc;
      }
      .text-center {
        text-align: center !important;
        .icon {
          font-size: 24px;
          color: #616161;
        }
      }
      .row {
        margin-left: -10px;
        margin-right: -10px;
        .testpaper-mark-info__title {
          margin-top: 20px;
          margin-bottom: 10px;
          font-size: 18px;
          line-height: 1;
          font-weight: 500;
          color: #313131;
        }
        .testpaper-mark-info__name {
          height: 42px;
          color: #919191;
        }
        .mbm {
          margin-bottom: 10px !important;
        }
        .color-gray {
          color: #919191 !important;
        }
        .testpaper-mark-operation {
          height: 140px;
          padding: 40px 11px 35px;
        }
        .testpaper-mark-success-status {
          color: #43bc60;
        }
        .testpaper-mark-warning-status {
          color: #ffa51f;
        }
        .testpaper-mark-danger-status {
          color: #ed3e3e;
        }
        .testpaper-mark-status__text {
          padding-bottom: 10px;
          border-bottom: 1px solid;
        }
        .pts {
          padding-top: 5px !important;
        }
        .mtm {
          margin-top: 10px !important;
        }
      }
    }
  }
}
</style>
