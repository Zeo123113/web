<!--
@description 助教管理
@author zhaoshibin
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">助教管理</div>
    </div>
    <div class="cd-main__body">
      <!-- 下面是查询模块 -->
      <el-form :model="queryParams" :inline="true" class="form-inline">
        <el-form-item label="助理教师">
          <el-select v-model="queryParams.assistantId" placeholder="请选择授课教师" size="medium" filterable clearable>
            <!-- <el-option
              v-for="teacher in teacherOptions"
              :key="teacher.teacherId"
              :label="teacher.teacherName"
              :value="teacher.teacherId"
            /> -->
            <el-option
              v-for="userList in userListOptions"
              :key="userList.userId"
              :label="userList.realName"
              :value="userList.userId"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" size="small" @click="handleQuery">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" size="small" @click="handleAdd">新增</el-button>
        </el-form-item>
      </el-form>
      <!-- 下面是数据展示 -->
      <el-table :data="tableData" tooltip-effect="dark" style="width: 100%">
        <el-table-column label="编号" prop="taId" align="center" min-width="55" />
        <el-table-column label="授课教师" prop="teaId" align="center" min-width="150" :formatter="teaIdTypeFormat" />
        <el-table-column label="助理教师" prop="assistantId" align="center" min-width="150" :formatter="assistantIdTypeFormat" />
        <el-table-column label="创建时间" prop="createTime" align="center" sortable min-width="160" />
        <el-table-column label="操作" fixed="right" align="center" min-width="200">
          <template slot-scope="scope">
            <el-button type="success" size="mini" @click="handleUpdate(scope.row)">编辑</el-button>
            <el-button type="danger" size="mini" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 下面是分页插件 -->
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      ></pagination>
      <!-- 下面是新增修改助教信息弹出框 -->
      <el-dialog :title="title" :visible.sync="open" width="48%">
        <el-form ref="form" :model="form" :rules="rules" label-width="115px">
          <el-row>
            <el-col :span="12">
              <el-form-item label="授课教师" prop="teaId">
                <el-select v-model="form.teaId" placeholder="请选择授课教师" disabled>
                  <!-- <el-option
                    v-for="teacher in teacherOptions"
                    :key="teacher.teacherId"
                    :label="teacher.teacherName"
                    :value="teacher.teacherId"
                  /> -->
                  <el-option
                    v-for="userList in userListOptions"
                    :key="userList.userId"
                    :label="userList.realName"
                    :value="userList.userId"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="助理教师" prop="teaId">
                <el-select v-model="form.assistantId" placeholder="请选择助理教师" filterable clearable>
                  <el-option
                    v-for="userList in userListOptions"
                    :key="userList.userId"
                    :label="userList.realName"
                    :value="userList.userId"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="备注" prop="remark">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入内容"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" size="small" @click="submitForm">保存</el-button>
          <el-button size="small" @click="cancel">取消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
import userApi from '@/api/user/user'
import courseAssistantApi from '@/api/course/courseManage/courseAssistant'
import teacherTeamApi from '@/api/course/courseManage/teacherTeam'
export default {
  components: { pagination },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 分页记录总条数默认是1
      total: 1,
      // 默认从第一页开始
      pageNum: 1,
      // 默认每页显示的记录条数
      pageSize: USER_CONST.PAGESIZE,
      queryParams: {
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        assistantId: undefined
      },
      // 数据表格展示数据
      tableData: [],
      // 弹出框的标题
      title: '',
      // 弹出框默认关闭
      open: false,
      // 新增修改的弹框表单
      form: {},
      // 表单校验
      rules: {
        orgId: [{ required: true, message: '组织机构', trigger: 'blur' }],
        csId: [{ required: true, message: '课程设置编号不能为空', trigger: 'blur' }],
        ctId: [{ required: true, message: '课程学期编号不能为空', trigger: 'blur' }],
        schemeId: [{ required: true, message: '授课方案编号不能为空', trigger: 'blur' }],
        teaId: [{ required: true, message: '授课教师编号不能为空', trigger: 'blur' }],
        assistantId: [{ required: true, message: '助理教师编号不能为空', trigger: 'blur' }]
      },
      // 当前用户所在二级组织机构及以下的所有教师用户
      userListOptions: [],
      // 授课教师列表
      teacherOptions: []
    }
  },
  // 钩子函数页面加载时调用数据
  created() {
    // 获得教师团队
    teacherTeamApi.getTeacherTeamByCourseSetIdAndCourseTermId(this.courseScheme.csId, this.courseScheme.ctId).then(response => {
      this.teacherOptions = response.data
    })
    // 根据当前用户orgId获取当前用户所在二级组织机构及以下所有的教师用户
    userApi.getUserListByCurrentUserOrgId(this.$store.getters.user.orgId).then(response => {
      this.userListOptions = response.data
    })
    this.fetchData(this.queryParams, this.pageNum, this.pageSize)
  },
  methods: {
    // 授课教师表格数据展示格式化
    teaIdTypeFormat(row) {
      return this.teacherDataSwitch(this.userListOptions, row.teaId)
    },
    // 助理教师表格数据展示格式化
    assistantIdTypeFormat(row) {
      return this.userDataSwitch(this.userListOptions, row.assistantId)
    },
    // 通过teacherId找到老师姓名 供格式化数据使用
    teacherDataSwitch(datas, value) {
      var actions = []
      Object.keys(datas).map(key => {
        if (datas[key].userId === value) {
          actions.push(datas[key].realName)
          return false
        }
      })
      return actions.join('')
    },
    // 通过userId找到用户姓名 供格式化数据使用
    userDataSwitch(datas, value) {
      var actions = []
      Object.keys(datas).map(key => {
        if (datas[key].userId === value) {
          actions.push(datas[key].realName)
          return false
        }
      })
      return actions.join('')
    },
    // 获得tableData,带有分页
    fetchData(queryParams, pageNum, pageSize) {
      courseAssistantApi.listCourseAssistant(queryParams, pageNum, pageSize).then(response => {
        this.tableData = response.data.list
        this.total = response.data.total
      })
    },
    // 根据查询条件查询按钮
    handleQuery() {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    // 处理分页组件上面的操作
    pageQuery() {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    // 新增编辑表单重置
    reset() {
      this.form = {
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        teaId: this.$store.getters.user.userId,
        assistantId: undefined,
        remark: undefined
      }
      this.resetForm('form')
    },
    // 表单重置调用elementui函数
    resetForm(refName) {
      if (this.$refs[refName] !== undefined) {
        this.$refs[refName].resetFields()
      }
    },
    // 点击新增按钮
    handleAdd() {
      this.reset()
      this.open = true
      this.title = '添加助教'
    },
    // 点击编辑按钮
    handleUpdate(row) {
      // 相当于打开页面时加载数据
      this.form = row
      this.title = '修改助教'
      this.open = true
    },
    // 新增修改提交
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.form.taId !== undefined) {
            courseAssistantApi.updateCourseAssistant(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  type: 'success',
                  message: '修改成功'
                })
                this.open = false
                this.fetchData(this.queryParams, this.pageNum, this.pageSize)
              } else {
                this.$message({
                  message: response.msg,
                  type: 'error'
                })
              }
            })
          } else {
            courseAssistantApi.addCourseAssistant(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  type: 'success',
                  message: '新增成功'
                })
                this.open = false
                this.fetchData(this.queryParams, this.pageNum, this.pageSize)
              } else {
                this.$message({
                  message: response.msg,
                  type: 'error'
                })
              }
            })
          }
        }
      })
    },
    // 单条删除按钮
    handleDelete(row) {
      this.$confirm('是否确认删除助教编号为 "' + row.taId + '" 的数据项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return courseAssistantApi.delCourseAssistant(row.taId)
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '助教信息删除成功'
          })
          this.fetchData(this.queryParams, this.pageNum, this.pageSize)
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 点击取消保存按钮
    cancel() {
      this.open = false
    }
  }
}
</script>
<style lang="scss" scoped>
.btn-group {
  margin-bottom: 20px;
}
.el-form .el-form-item {
  margin-bottom: 15px;
}
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}

.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>
