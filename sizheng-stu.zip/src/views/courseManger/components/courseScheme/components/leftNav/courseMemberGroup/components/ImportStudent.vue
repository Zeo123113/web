<!--
@description 课程分组学员管理--新增与编辑窗口
@author cgy
-->
<template>
  <div class="outer-container">
    <!--begin of 新增与编辑窗口 -->
    <el-dialog
      width="55%"
      title="导入学员"
      :visible="isImportStudentDialogVisible"
      @close="closeDialog('form')"
      @open="openDialog()"
    >
      <el-form ref="form" :model="importStudentPara" :rules="rules" label-width="140px">
        <!-- <el-row>
          <el-col :span="12">
            <el-form-item label="学员所属组织机构" prop="userOrgId">
              <treeselect
                v-model="importStudentPara.userOrgId"
                :options="userOrgOptions"
                style="width:217px;"
                placeholder="请选择学员所属组织机构"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="课程名称" prop="csId">
              <el-select
                v-model="importStudentPara.csId"
                placeholder="请选择课程"
                @change="courseChange"
              >
                <el-option
                  v-for="course in courseOptions"
                  :key="course.csId"
                  :label="course.courseTitle"
                  :value="course.csId"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="课程学期" prop="ctId">
              <el-select
                v-model="importStudentPara.ctId"
                placeholder="请选择课程学期"
                @change="courseTermChange"
              >
                <el-option
                  v-for="courseTerm in courseTermOptions"
                  :key="courseTerm.ctId"
                  :label="courseTerm.courseTerm"
                  :value="courseTerm.ctId"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>-->
        <el-row>
          <!-- <el-col :span="12">
            <el-form-item label="授课方案" prop="schemeId">
              <el-select
                v-model="importStudentPara.schemeId"
                placeholder="请选择授课方案"
                @change="courseSchemeChange"
              >
                <el-option
                  v-for="shceme in courseSchemeOptions"
                  :key="shceme.schemeId"
                  :label="shceme.schemeTitle"
                  :value="shceme.schemeId"
                />
              </el-select>
            </el-form-item>
          </el-col>-->
          <el-col :span="12">
            <el-form-item label="学员所属组织机构" prop="userOrgId">
              <treeselect
                v-model="importStudentPara.userOrgId"
                :options="userOrgOptions"
                style="width:217px;"
                placeholder="请选择学员所属组织机构"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="分组名称" prop="mgId">
              <treeselect
                v-model="importStudentPara.mgId"
                :options="memberGroupOptions"
                style="width:217px;"
                placeholder="请选择分组名称"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="导入Excel文件" prop="excelfile">
          <el-upload
            ref="inputFileUpload"
            :action="inputFileUploadUrl"
            :data="importStudentPara"
            :before-upload="inputFileBeforeUpload"
            :on-success="inputFileUploadSuccess"
            :on-error="inputFileUploadError"
            :headers="headers"
            :auto-upload="false"
            :limit="1"
          >
            <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
            <div slot="tip" class="el-upload__tip">只能上传xls、xlsx文件，且不超过1Mb</div>
          </el-upload>
        </el-form-item>
        <el-form-item label="导入结果">
          <el-input v-model="importResult" type="textarea" :rows="5" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="inputFileSubmitUpload">上传到服务器</el-button>
        <el-button size="small" @click="cancel('form')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import COURSE_CONST from '@/constant/course-const'
import orgApi from '@/api/user/org'
import courseSetApi from '@/api/course/courseManage/courseSet'
import courseTermApi from '@/api/course/courseManage/courseTerm'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import { getToken } from '@/utils/auth'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'ImportStudentDialog',
  components: { Treeselect },
  props: {
    isImportStudentDialogVisible: {
      type: Boolean,
      required: true
    },
    importStudentPara: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      importResult: '',
      userOrgOptions: [],
      courseOptions: [],
      courseTermOptions: [],
      courseSchemeOptions: [],
      memberGroupOptions: [],
      // 文件上传额外参数设置
      inputFileUploadUrl: process.env.VUE_APP_BASE_API + '/course/course-member/importStudent',
      headers: {
        token: getToken()
      },
      rules: {
        userOrgId: [{ required: true, message: '请选择学员所属组织机构', trigger: 'blur' }],
        orgId: [{ required: true, message: '请选择课程所属组织机构', trigger: 'blur' }],
        csId: [{ required: true, message: '请选择课程', trigger: 'blur' }],
        ctId: [{ required: true, message: '请选择课程学期', trigger: 'blur' }],
        schemeId: [{ required: true, message: '请选择授课方案', trigger: 'blur' }],
        mgId: [{ required: true, message: '请选择分组名称', trigger: 'blur' }]
      }
    }
  },
  methods: {
    /** 组织机构选择发生变化时触发 */
    orgChange(value) {
      if (value != null && value !== '') {
        courseSetApi.getCourseListByOrgId(value).then(response => {
          this.courseOptions = response.data
          this.importStudentPara.csId = null
        })
      }
    },
    courseChange(value) {
      courseTermApi.getTermPageByCId(value, 1, 10).then(response => {
        this.courseTermOptions = response.data.list
        this.importStudentPara.ctId = null
      })
    },
    courseTermChange(value) {
      courseSchemeApi.getCourseSchemePageByCtId(value, 1, 10).then(response => {
        this.courseSchemeOptions = response.data.list
        this.importStudentPara.schemeId = null
      })
    },
    courseSchemeChange(value) {
      if (this.importStudentPara.groupType === COURSE_CONST.COURSE_GROUP) {
        courseMemberGroupApi.getCourseMemberGroupBySchemeId(value).then(response => {
          this.memberGroupOptions = response.data
          this.importStudentPara.mgId = null
        })
      }
      if (this.importStudentPara.groupType === COURSE_CONST.EXAM_GROUP) {
        courseMemberGroupApi.getExamMemberGroupBySchemeId(value).then(response => {
          this.memberGroupOptions = response.data
          this.importStudentPara.mgId = null
        })
      }
    },
    cancel(formName) {
      this.$emit('update:isImportStudentDialogVisible', false)
    },
    openDialog() {
      const user = this.$store.state.user.user
      const ancestors = user.org.ancestors.split(',')
      let orgId = 0
      if (ancestors.length === 1) {
        orgId = 100
      } else if (ancestors.length === 2) {
        orgId = user.orgId
      } else {
        orgId = ancestors[2]
      }
      // 获取当前用户的组织机构树
      orgApi.getOrgTreeByOrgId(orgId).then(result => {
        this.userOrgOptions = result.data
      })
      courseMemberGroupApi.getCourseMemberGroupBySchemeId(this.importStudentPara.schemeId).then(response => {
        this.memberGroupOptions = response.data
      })
      this.importResult = ''
      if (this.importStudentPara.groupType === COURSE_CONST.COURSE_GROUP) {
        this.inputFileUploadUrl = process.env.VUE_APP_BASE_API + '/course/course-member/importStudent'
      } else {
        this.inputFileUploadUrl = process.env.VUE_APP_BASE_API + '/course/exam-group-member/importStudent'
      }
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeDialog(formName) {
      this.$refs[formName].clearValidate()
      this.$emit('update:isImportStudentDialogVisible', false)
    },
    /** 上传之前检测文件类型及大小 */
    inputFileBeforeUpload: function(file) {
      this.importResult = ''
      const FileExt = file.name.replace(/.+\./, '')
      if (['xls', 'xlsx'].indexOf(FileExt.toLowerCase()) === -1) {
        this.$message({
          type: 'warning',
          message: '请上传后缀名为xls、xlsx的附件！'
        })
        return false
      }
      this.isLt2k = file.size / 1024 / 1024 <= 1 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过1Mb!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 文件上传成功时的勾子 */
    inputFileUploadSuccess: function(response, file, fileList) {
      this.$refs.inputFileUpload.clearFiles()
      if (response.code === 0) {
        this.importResult = response.data
      } else {
        this.importResult = response.msg
      }
    },
    /** 上传失败时的勾子 */
    inputFileUploadError: function(err, file, fileList) {
      this.$refs.inputFileUpload.clearFiles()
      this.$message({
        message: '上传文件失败!',
        type: 'error'
      })
      console.log(err)
    },
    /** 提交上传文件 */
    inputFileSubmitUpload() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.$refs.inputFileUpload.submit()
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
