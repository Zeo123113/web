<!--
@description 课程分组学员管理--新增与编辑窗口
@author cgy
-->
<template>
  <div class="outer-container">
    <!--begin of 新增与编辑窗口 -->
    <el-dialog
      width="65%"
      :title="title"
      :visible="isAddEditDialogVisible"
      @close="closeDialog('form')"
      @open="openDialog()"
    >
      <el-form ref="form" :model="courseGroupMember" :rules="rules" label-width="100px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="分组名称" prop="mgId">
              <treeselect
                v-model="courseGroupMember.mgId"
                :options="courseMemberGroupOptions"
                style="width:217px;"
                placeholder="请选择分组名称"
              />
            </el-form-item>
          </el-col>
          <el-col v-if="courseGroupMember.cmId < 0" :span="12">
            <el-form-item label="会员角色" prop="memberRole">
              <el-radio-group v-model="courseGroupMember.memberRole" @change="memberRoleChange">
                <el-radio
                  v-for="item in memberRoleOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学员状态" prop="memberStatus">
              <el-radio-group v-model="courseGroupMember.memberStatus">
                <el-radio
                  v-for="item in memberStatusOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="是否上锁" prop="isLocked">
              <el-switch v-model="courseGroupMember.isLocked"></el-switch>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="会员终止时间" prop="memberDeadline">
              <el-date-picker
                v-model="courseGroupMember.memberDeadline"
                type="datetime"
                placeholder="选择日期时间"
                value-format="yyyy-MM-dd HH:mm:ss"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="courseGroupMember.cmId < 0">
          <el-col :span="12">
            <el-form-item label="学员所属机构">
              <treeselect
                v-model="userOrgId"
                :options="userOrgOptions"
                style="width:217px;"
                placeholder="请选择学员所属机构"
                :disabled="selectUserDisabled"
                @input="userOrgChange"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="选择学员" prop="selectUsers">
              <el-select
                v-model="courseGroupMember.selectUsers"
                multiple
                filterable
                remote
                :remote-method="getUser"
                :loading="loading"
                :disabled="selectUserDisabled"
                placeholder="请选择学员"
                style="width:59%;"
              >
                <el-option
                  v-for="item in userOptions"
                  :key="item.userId"
                  :label="item.fullName"
                  :value="item.userId"
                ></el-option>
              </el-select>
              <el-button type="success" style="margin-left:10px" @click="addStudentUser">添加学员</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form v-if="isShowAddStudent" ref="addStuUser" :inline="true" :rules="addStudentRules" :model="studentUser" class="demo-form-inline" label-width="100px">
          <el-row>
            <el-col :span="12">
              <el-form-item label="登录名" prop="loginName">
                <el-input v-model="studentUser.loginName" placeholder="登录名"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="密码" prop="password">
                <el-input v-model="studentUser.password" placeholder="密码" show-password></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="真实名" prop="realName">
                <el-input v-model="studentUser.realName" placeholder="真实名"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="学号" prop="stuId">
                <el-row :gutter="10">
                  <el-col :span="19">
                    <el-input v-model="studentUser.stuId" placeholder="学号"></el-input>
                  </el-col>
                  <el-col :span="5">
                    <el-button type="primary" size="small" @click="SubmitAddStuUser('addStuUser')">保 存</el-button>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="courseGroupMember.remark"
            placeholder="请输入备注"
            type="textarea"
            :rows="4"
            clearable
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="submitForm">保 存</el-button>
        <el-button size="small" @click="cancel('form')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import orgApi from '@/api/user/org'
import userApi from '@/api/user/user'
// import courseSetApi from '@/api/course/courseManage/courseSet'
// import courseTermApi from '@/api/course/courseManage/courseTerm'
// import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import courseMemberApi from '@/api/course/courseManage/courseMember'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'EditDialog',
  components: { Treeselect },
  props: {
    title: {
      type: String,
      required: true
    },
    isAddEditDialogVisible: {
      type: Boolean,
      required: true
    },
    courseGroupMember: {
      type: Object,
      required: true
    },
    memberRoleOptions: {
      type: Array,
      required: true
    },
    memberStatusOptions: {
      type: Array,
      required: true
    },
    courseMemberGroupOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    // 验证登录账号字符串
    const validateLoginName = (rule, value, callback) => {
      if (value === null || value === '' || value === undefined) {
        return callback(new Error('登录名不能为空'))
      } else if (value.length < 3 || value.length > 30) {
        return callback(new Error('登录名长度在3-30个字符之间'))
      } else if (this.title.indexOf('添加') >= 0) {
        if (value === this.$store.getters.user.loginName) {
          return callback(new Error('名称重复,请重新输入'))
        }
      }
      userApi
        .checkLoginName({
          loginName: this.studentUser.loginName,
          userId: this.studentUser.userId
        })
        .then(function(resp) {
          if (resp.data) {
            callback()
          } else {
            callback(new Error('名称重复,请重新输入'))
          }
        })
    }
    return {
      loading: false,
      userOrgId: null,
      selectUserDisabled: false,
      userOrgOptions: [],
      userOptions: [],
      rules: {
        mgId: [{ required: true, message: '请选择分组名称', trigger: 'blur' }],
        selectUsers: [{ required: true, message: '请选择用户', trigger: 'blur' }]
      },
      addStudentRules: {
        loginName: [{ required: true, validator: validateLoginName, trigger: 'blur' }],
        password: [
          { required: true, message: '密码不能为空', trigger: 'blur' },
          { min: 6, max: 20, message: '密码长度在6-20个字符之间', trigger: 'blur' }
        ],
        stuId: [{ pattern: /^[1-9]\d{5,15}$/, message: '学号为6到15位的数字', trigger: 'change' }],
        realName: [{ min: 2, max: 20, message: '姓名长度在 2 到 20 个字符之间', trigger: 'change' }, { required: true, message: '真实名不能为空', trigger: 'blur' }]
      },
      isShowAddStudent: false,
      studentUser: {
        userId: null,
        loginName: '',
        password: '',
        userType: this.courseGroupMember.memberRole,
        realName: '',
        stuId: '',
        orgId: null
      },
      options: []
    }
  },
  methods: {
    initStudentUser() {
      this.studentUser = {
        loginName: '',
        password: '',
        userType: this.courseGroupMember.memberRole,
        realName: '',
        stuId: '',
        orgId: null,
        userId: null
      }
    },
    SubmitAddStuUser(formName) {
      if (!this.userOrgId) {
        this.$message.error('请选择学员所属组织结构')
        return false
      } else {
        this.studentUser.orgId = this.userOrgId
        this.studentUser.userType = this.courseGroupMember.memberRole
      }
      this.$refs[formName].validate(valid => {
        if (valid) {
          courseMemberApi.addStuUser(this.studentUser).then((result) => {
            if (result.code === 0) {
              this.courseGroupMember.selectUsers.push(result.data.userId)
              this.userOptions.push(result.data)
              this.options.push(result.data)
              this.userOptions.map(v => {
                v.fullName = v.stuId + '-' + v.realName
              })
              this.isShowAddStudent = false
              setTimeout(() => {
                this.initStudentUser
              }, 2000)
            }
          })
        }
      })
    },
    addStudentUser() {
      this.isShowAddStudent = !this.isShowAddStudent
      this.initStudentUser()
    },
    memberRoleChange() {
      if (!this.userOrgId) {
        this.userOptions = []
        return false
      }
      var user = {
        orgId: this.userOrgId,
        realName: '',
        userType: this.courseGroupMember.memberRole
      }
      userApi.getUserListByOrgIdAndRealName(user).then(response => {
        this.userOptions = [...response.data, ...this.options]
        this.userOptions.map(v => {
          v.fullName = v.stuId + '-' + v.realName
        })
      })
    },
    userOrgChange(value) {
      if (!value) {
        this.userOptions = []
        return false
      }
      var user = {
        orgId: value,
        realName: '',
        userType: this.courseGroupMember.memberRole
      }
      userApi.getUserListByOrgIdAndRealName(user).then(response => {
        this.userOptions = response.data
        this.userOptions = [...response.data, ...this.options]
        this.userOptions.map(v => {
          v.fullName = v.stuId + '-' + v.realName
        })
      })
    },
    // 远程搜索学员
    getUser(realName) {
      if (!this.userOrgId) {
        return false
      }
      if (realName !== '') {
        this.loading = true
        setTimeout(() => {
          var user = {
            orgId: this.userOrgId,
            realName: realName,
            userType: this.courseGroupMember.memberRole
          }
          userApi.getUserListByOrgIdAndRealName(user).then(response => {
            this.userOptions = [...response.data, ...this.userOptions]
            this.userOptions = this.userOptions.reduce(function(prev, element) {
              if (!prev.find(el => el.userId === element.userId)) {
                prev.push(element)
              }
              return prev
            }, [])
            this.userOptions.map(v => {
              v.fullName = v.stuId + '-' + v.realName
            })
            this.loading = false
          })
        }, 200)
      } else {
        var user = {
          orgId: this.userOrgId,
          realName: '',
          userType: this.courseGroupMember.memberRole
        }
        userApi.getUserListByOrgIdAndRealName(user).then(response => {
          this.userOptions = [...response.data, ...this.userOptions]
          this.userOptions = this.userOptions.reduce(function(prev, element) {
            if (!prev.find(el => el.userId === element.userId)) {
              prev.push(element)
            }
            return prev
          }, [])
          this.userOptions.map(v => {
            v.fullName = v.stuId + '-' + v.realName
          })
        })
      }
    },
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          const t = []
          this.courseGroupMember.selectUsers.map(v => {
            let i = 0
            for (i = 0; i < this.userOptions.length; i++) {
              console.log(v)
              if (v === this.userOptions[i].userId) {
                break
              }
            }
            const user = {}
            user.userId = this.userOptions[i].userId
            user.stuId = this.userOptions[i].stuId
            user.realName = this.userOptions[i].realName
            t.push(user)
          })
          this.courseGroupMember.selectUsers = JSON.stringify(t)
          this.$emit('submitForm', this.courseGroupMember)
          this.$emit('update:isAddEditDialogVisible', false)
        }
      })
    },
    cancel(formName) {
      this.$emit('update:isAddEditDialogVisible', false)
    },
    openDialog() {
      courseMemberGroupApi.getCourseMemberGroupBySchemeId(this.courseGroupMember.schemeId).then(response => {
        this.courseMemberGroupOptions = response.data
      })
      if (this.courseGroupMember.cmId > 0) {
        userApi.getUserListByOrgId(this.courseGroupMember.orgId).then(response => {
          this.userOptions = response.data
          this.userOptions.map(v => {
            v.fullName = v.stuId + '-' + v.realName
          })
        })
        this.courseGroupMember.selectUsers = []
        this.courseGroupMember.selectUsers[0] = this.courseGroupMember.userId
        this.selectUserDisabled = true
      } else {
        const user = this.$store.state.user.user
        const ancestors = user.org.ancestors.split(',')
        let orgId = 0
        if (ancestors.length === 1) {
          orgId = 100
        } else if (ancestors.length === 2) {
          orgId = user.orgId
        } else {
          orgId = ancestors[2]
        }
        // 获取当前用户的组织机构树
        orgApi.getOrgTreeByOrgId(orgId).then(result => {
          this.userOrgOptions = result.data
        })
        this.userOptions = []
        this.courseGroupMember.selectUsers = []
        this.selectUserDisabled = false
      }
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeDialog(formName) {
      this.$refs[formName].clearValidate()
      this.$emit('update:isAddEditDialogVisible', false)
      this.isShowAddStudent = false
      this.initStudentUser()
      this.userOrgId = null
      this.options = []
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
