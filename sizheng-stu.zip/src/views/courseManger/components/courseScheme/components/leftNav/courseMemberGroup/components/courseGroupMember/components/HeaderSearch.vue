<!--
@description 课程分组学员管理--头部搜索组件
@author cgy
-->
<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="姓名" prop="realName">
      <el-input
        v-model="queryParams.realName"
        size="small"
        style="width:200px;"
        placeholder="请输入真实姓名"
      />
    </el-form-item>
    <el-form-item label="学号" prop="stuId">
      <el-input v-model="queryParams.stuId" size="small" style="width:200px;" placeholder="请输入学号" />
    </el-form-item>
    <el-form-item style="margin-left:0%">
      <el-button
        size="small"
        type="primary"
        icon="el-icon-search"
        :disabled="!button.includes('course/courseMember/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button
        size="small"
        type="primary"
        icon="el-icon-plus"
        :disabled="!button.includes('course/courseMember/add')"
        @click="handleAdd"
      >新增</el-button>
      <el-button
        size="small"
        type="danger"
        icon="el-icon-delete"
        :disabled="ids.length===0 || !button.includes('course/courseMember/deletebatch')"
        @click="handleBatchDelete"
      >删除</el-button>
      <el-button
        size="small"
        type="warning"
        icon="el-icon-upload2"
        :disabled="!button.includes('course/courseMember/import')"
        @click="handleImport"
      >导入</el-button>
      <el-button
        size="small"
        type="info"
        icon="el-icon-upload2"
        :disabled="ids.length===0"
        @click="move"
      >移动</el-button>
      <el-link type="primary" style="margin-left:10px;" @click.prevent="handleDownload">下载导入模板</el-link>
    </el-form-item>
  </el-form>
</template>
<script>
import { downloadByLink } from '@/utils/index'
import userApi from '@/api/user/user'
// import courseSetApi from '@/api/course/courseManage/courseSet'
// import courseTermApi from '@/api/course/courseManage/courseTerm'
// import courseSchemeApi from '@/api/course/courseManage/courseScheme'
// import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
// import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'HeaderSearch',
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    ids: {
      type: Array,
      required: true
    },
    button: {
      type: Array,
      required: true
    },
    courseMemberGroupOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
    }
  },
  methods: {
    /** 搜索按钮操作 */
    handleQuery() {
      this.$emit('handleQuery', this.queryParams)
    },
    /** 点击了新增 */
    handleAdd() {
      this.$emit('handleAdd')
    },
    /** 点击了批量删除 */
    handleBatchDelete() {
      this.$emit('handleBatchDelete')
    },
    /** 点击了导入 */
    handleImport() {
      this.$emit('handleImport')
    },
    /**
     * 点击了移动
     */
    move() {
      this.$emit('move')
    },
    // 导入模块文件下载
    handleDownload() {
      userApi
        .downloadTemplate()
        .then(result => {
          if (result.code === 0) {
            downloadByLink(process.env.VUE_APP_FILE_SERVER, result.data, '导入模板.xlsx')
          }
        })
        .catch(() => {})
    }
  }
}
</script>
<style lang="scss" scoped>
.el-form .el-form-item {
  margin-bottom: 10px;
}
.vue-treeselect {
  height: 30px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 30px;
}
</style>
