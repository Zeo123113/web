<!--
@description 学员分组管理管理--分组复制与移动窗口
@author cgy
-->
<template>
  <div class="outer-container">
    <el-dialog
      title="移动学员"
      width="45%"
      :visible="isMoveMemberDialogVisible"
      @close="closeDialog('form')"
      @open="openDialog()"
    >
      <el-form ref="form" :model="moveMemberParam" :rules="rules" label-width="100px">
        <el-form-item label="源分组" prop="sourceGroupId">
          <treeselect
            v-model="moveMemberParam.sourceGroupId"
            :options="memberGroupOptions"
            style="width:217px;"
            placeholder="请选择目标分组"
            disabled
          />
        </el-form-item>
        <el-form-item label="目标分组">请在下面选择目标分组参数</el-form-item>
        <el-row>
          <el-col :span="12">
            <el-form-item label="目标分组" prop="targetGroupId">
              <treeselect
                v-model="moveMemberParam.targetGroupId"
                :options="memberGroupOptions"
                style="width:217px;"
                placeholder="请选择目标分组"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="submitForm">确 定</el-button>
        <el-button size="small" @click="cancel('form')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'CopyGroupDialog',
  components: { Treeselect },
  props: {
    isMoveMemberDialogVisible: {
      type: Boolean,
      required: true
    },
    moveMemberParam: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      courseOptions: [],
      courseTermOptions: [],
      courseSchemeOptions: [],
      memberGroupOptions: [],
      rules: {
        targetGroupId: [{ required: true, message: '请选择目标分组', trigger: 'blur' }]
      }
    }
  },
  methods: {
    submitForm() {
      if (this.moveMemberParam.sourceGroupId === this.moveMemberParam.targetGroupId) {
        this.$message({
          type: 'warning',
          message: '目标分组和源分组不可相同'
        })
        return false
      }
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.$emit('goMove', this.moveMemberParam)
          this.$emit('update:isMoveMemberDialogVisible', false)
        }
      })
    },
    cancel(formName) {
      this.$emit('update:isMoveMemberDialogVisible', false)
    },
    openDialog() {
      courseMemberGroupApi.getCourseMemberGroupByCtId(this.moveMemberParam.ctId).then(response => {
        this.memberGroupOptions = response.data
        this.moveMemberParam.targetGroupId = null
      })
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeDialog(formName) {
      this.$refs[formName].clearValidate()
      this.$emit('update:isMoveMemberDialogVisible', false)
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
