<!--
@description 学员分组管理管理--分组复制与移动窗口
@author cgy
-->
<template>
  <div class="outer-container">
    <el-dialog
      :title="copyGroupParams.copyOrMove==='copy'?'复制分组':'移动分组'"
      width="45%"
      :visible="isCopyGroupDialogVisible"
      @close="closeDialog('form')"
      @open="openDialog()"
    >
      <el-form ref="form" :model="copyGroupParams" :rules="rules" label-width="100px">
        <el-form-item label="源分组">
          <el-tag size="medium" effect="plain">{{ copyGroupParams.sourceGroupName }}</el-tag>
        </el-form-item>
        <el-form-item label="目标分组">请在下面选择目标分组参数</el-form-item>
        <el-row>
          <el-col :span="12">
            <el-form-item label="分组类型" prop="targetGroupType">
              <el-radio-group v-model="copyGroupParams.targetGroupType" @change="typeChange">
                <el-radio
                  v-for="item in groupTypeOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- <el-row>
          <el-col :span="12">
            <el-form-item label="课程名称" prop="csId">
              <el-select v-model="copyGroupParams.csId" placeholder="请选择课程" @change="courseChange">
                <el-option
                  v-for="course in courseOptions"
                  :key="course.csId"
                  :label="course.courseTitle"
                  :value="course.csId"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="课程学期" prop="ctId">
              <el-select
                v-model="copyGroupParams.ctId"
                placeholder="请选择课程学期"
                @change="courseTermChange"
              >
                <el-option
                  v-for="courseTerm in courseTermOptions"
                  :key="courseTerm.ctId"
                  :label="courseTerm.courseTerm"
                  :value="courseTerm.ctId"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row> -->
        <el-row>
          <!-- <el-col :span="12">
            <el-form-item label="授课方案" prop="schemeId">
              <el-select
                v-model="copyGroupParams.schemeId"
                placeholder="请选择授课方案"
                @change="courseSchemeChange"
              >
                <el-option
                  v-for="shceme in courseSchemeOptions"
                  :key="shceme.schemeId"
                  :label="shceme.schemeTitle"
                  :value="shceme.schemeId"
                />
              </el-select>
            </el-form-item>
          </el-col> -->
          <el-col :span="12">
            <el-form-item label="目标分组" prop="targetGroupId">
              <treeselect
                v-model="copyGroupParams.targetGroupId"
                :options="memberGroupOptions"
                style="width:217px;"
                placeholder="请选择目标分组"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="目标分组名" prop="targetGroupName">
          <el-input
            v-model="copyGroupParams.targetGroupName"
            style="width:100%"
            placeholder="请输入目标分组名称"
            clearable
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="submitForm">确 定</el-button>
        <el-button size="small" @click="cancel('form')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import COURSE_CONST from '@/constant/course-const'
// import courseSetApi from '@/api/course/courseManage/courseSet'
// import courseTermApi from '@/api/course/courseManage/courseTerm'
// import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'CopyGroupDialog',
  components: { Treeselect },
  props: {
    isCopyGroupDialogVisible: {
      type: Boolean,
      required: true
    },
    copyGroupParams: {
      type: Object,
      required: true
    },
    groupTypeOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    // 验证登录账号字符串
    // const validateMgName = (rule, value, callback) => {
    //   if (value === null || value === '' || value === undefined) {
    //     return callback(new Error('分组名不能为空'))
    //   } else if (value.length < 1 || value.length > 30) {
    //     return callback(new Error('分组名长度在1-30个字符之间'))
    //   }
    //   // courseMemberGroupApi
    //   //   .checkGroupName({
    //   //     mgName: this.copyGroupParams.targetGroupName,
    //   //     mgId: this.copyGroupParams.mgId,
    //   //     schemeId: this.copyGroupParams.schemeId,
    //   //     groupType: this.copyGroupParams.targetGroupType
    //   //   })
    //   //   .then(function(resp) {
    //   //     if (resp.data) {
    //   //       callback()
    //   //     } else {
    //   //       callback(new Error('名称重复,请重新输入'))
    //   //     }
    //   //   })
    // }
    return {
      courseOptions: [],
      courseTermOptions: [],
      courseSchemeOptions: [],
      memberGroupOptions: [],
      rules: {
        // targetGroupName: [{ required: true, validator: validateMgName, trigger: 'blur' }],
        // targetGroupId: [{ required: true, message: '请选择目标分组', trigger: 'blur' }]
      }
    }
  },
  methods: {
    // courseChange(value) {
    //   courseTermApi.getTermPageByCId(value, 1, 10).then(response => {
    //     this.courseTermOptions = response.data.list
    //     this.copyGroupParams.ctId = null
    //   })
    // },
    // courseTermChange(value) {
    //   courseSchemeApi.getCourseSchemeByCtId(value, 1, 10).then(response => {
    //     this.courseSchemeOptions = response.data.list
    //     this.copyGroupParams.schemeId = null
    //   })
    // },
    typeChange(value) {
      if (this.copyGroupParams.targetGroupType === COURSE_CONST.COURSE_GROUP) {
        courseMemberGroupApi.getCourseMemberGroupBySchemeId(value).then(response => {
          this.memberGroupOptions = response.data
          this.copyGroupParams.targetGroupId = null
        })
      }
      if (this.copyGroupParams.targetGroupType === COURSE_CONST.EXAM_GROUP) {
        courseMemberGroupApi.getExamMemberGroupBySchemeId(value).then(response => {
          this.memberGroupOptions = response.data
          this.copyGroupParams.targetGroupId = null
        })
      }
    },
    submitForm() {
      if (this.copyGroupParams.sourceGroupId === this.copyGroupParams.targetGroupId) {
        this.$message({
          type: 'warning',
          message: '目标分组和源分组不可相同'
        })
        return false
      }
      if (this.copyGroupParams.targetGroupType === COURSE_CONST.COURSE_GROUP && !this.copyGroupParams.targetGroupId) {
        this.$message({
          type: 'warning',
          message: '请选择目标分组'
        })
        return false
      }
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.$emit('handleCopyGroup', this.copyGroupParams)
          this.$emit('update:isCopyGroupDialogVisible', false)
        }
      })
    },
    cancel(formName) {
      this.$emit('update:isCopyGroupDialogVisible', false)
    },
    openDialog() {
      if (this.copyGroupParams.targetGroupType === COURSE_CONST.COURSE_GROUP) {
        courseMemberGroupApi.getCourseMemberGroupByCtId(this.copyGroupParams.ctId).then(response => {
          this.memberGroupOptions = response.data
          this.copyGroupParams.targetGroupId = null
        })
      }
      if (this.copyGroupParams.targetGroupType === COURSE_CONST.EXAM_GROUP) {
        courseMemberGroupApi.getExamMemberGroupByCtId(this.copyGroupParams.ctId).then(response => {
          this.memberGroupOptions = response.data
          this.copyGroupParams.targetGroupId = null
        })
      }
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeDialog(formName) {
      this.$refs[formName].clearValidate()
      this.$emit('update:isCopyGroupDialogVisible', false)
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
