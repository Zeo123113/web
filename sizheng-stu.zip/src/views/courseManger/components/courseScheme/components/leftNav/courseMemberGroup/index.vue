<!--
@description 分组分头管理
@author cgy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">学员管理</div>
    </div>
    <div class="cd-main__body">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane label="课程分组管理" name="first">
          <MemberGroup v-if="isMemberGroup" :course-scheme="courseScheme" />
        </el-tab-pane>
        <el-tab-pane label="课程分组学员管理" name="second">
          <CourseGroupMember v-if="isMember" :course-scheme="courseScheme" />
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
import MemberGroup from './components/memberGroup/index'
import CourseGroupMember from './components/courseGroupMember/index'
export default {
  components: {
    MemberGroup,
    CourseGroupMember
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      activeName: 'first',
      isMemberGroup: true,
      isMember: false
    }
  },
  methods: {
    handleClick(tab, event) {
      if (tab.name === 'first') {
        this.isMemberGroup = true
        this.isMember = false
      } else if (tab.name === 'second') {
        this.isMemberGroup = false
        this.isMember = true
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>
