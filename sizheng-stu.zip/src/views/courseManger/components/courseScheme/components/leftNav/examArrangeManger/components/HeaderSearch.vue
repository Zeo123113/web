<!--
@description 考试安排管理
@author zhaoshibin
-->
<template>
  <el-form ref="queryForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="考试简述" prop="examTitle">
      <el-input v-model="queryParams.examTitle" placeholder="请输入考试简述" size="small" clearable />
    </el-form-item>
    <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        size="small"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        unlink-panels
        :picker-options="pickerOptions"
        style="width:217px;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        icon="el-icon-search"
        size="small"
        :disabled="!button.includes('bank/arrange/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button
        type="primary"
        icon="el-icon-plus"
        size="small"
        :disabled="!button.includes('bank/arrange/add')"
        @click="handleAdd"
      >添加</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'HeaderSearch',
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    button: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      dateRange: ''
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  methods: {
    // 搜索按钮操作
    handleQuery() {
      this.$emit('handleQuery', this.queryParams)
    },
    // 点击了新增
    handleAdd() {
      this.$emit('handleAdd')
    }
  }
}
</script>
<style lang="scss" scope>

</style>
