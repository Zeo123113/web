<!--
@description 考试分组学员管理--新增与编辑窗口
@author cgy
-->
<template>
  <div class="outer-container">
    <!--begin of 新增与编辑窗口 -->
    <el-dialog
      width="50%"
      title="从学员分组添加"
      :visible="addByCourseGroupDialogVisible"
      @close="closeDialog('form')"
      @open="openDialog()"
    >
      <el-form ref="form" :model="examGroupMember" :rules="rules" label-width="100px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="授课方案">
              <el-select v-model="schemeId" placeholder="请选择授课方案" clearable @change="schemeChange">
                <el-option
                  v-for="shceme in courseSchemeOptions"
                  :key="shceme.schemeId"
                  :label="shceme.schemeTitle"
                  :value="shceme.schemeId"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="课程分组">
              <treeselect
                v-model="mgId"
                :options="courseMemberGroup"
                style="width:217px;"
                placeholder="请选择课程分组名称"
                @input="courseGroupChange"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="分组名称" prop="mgId">
              <treeselect
                v-model="examGroupMember.mgId"
                :options="examMemberGroupOptions"
                placeholder="请选择分组名称"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="学员列表">

          <el-table
            :data="courseMemberData"
            style="width: 73%"
            @select-all="select"
            @select="select"
          >
            <el-table-column type="selection" min-width="100" />
            <el-table-column
              prop="stuId"
              label="学号"
              width="200"
              align="center"
            >
            </el-table-column>
            <el-table-column
              prop="realName"
              label="姓名"
              width="200"
              align="center"
            >
            </el-table-column>
          </el-table>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="submitForm">保 存</el-button>
        <el-button size="small" @click="cancel('form')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import USER_CONST from '@/constant/user-const'
// import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import courseMemberApi from '@/api/course/courseManage/courseMember'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
export default {
  name: 'AddByCourseGroup',
  components: { Treeselect },
  props: {
    addByCourseGroupDialogVisible: {
      type: Boolean,
      required: true
    },
    examGroupMember: {
      type: Object,
      required: true
    },
    examMemberGroupOptions: {
      type: Array,
      required: true
    },
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      loading: false,
      userOrgId: null,
      userType: USER_CONST.STUDENT,
      selectUserDisabled: false,
      userOrgOptions: [],
      userOptions: [],
      rules: {
        mgId: [{ required: true, message: '请选择分组名称', trigger: 'blur' }]
      },
      courseSchemeOptions: [],
      courseMemberGroup: [],
      schemeId: null,
      mgId: null,
      courseMemberData: [],
      selectUsers: []
    }
  },
  created() {
    // 获取教学学期列表
    courseSchemeApi.getCourseSchemeByCourseTermId(this.courseTerm.ctId).then(response => {
      this.courseSchemeOptions = response.data
    })
  },
  methods: {
    schemeChange(value) {
      this.courseMemberGroup = []
      this.courseMemberData = []
      this.mgId = undefined
      if (!value) {
        return false
      }
      courseMemberGroupApi.getCourseMemberGroupBySchemeId(value).then(response => {
        this.courseMemberGroup = response.data
      })
    },
    courseGroupChange(value) {
      this.courseMemberData = []
      if (!value) {
        return false
      }
      courseMemberApi.getCourseMembersByMgId(value).then(response => {
        this.courseMemberData = response.data
      })
    },
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          const t = []
          this.selectUsers.map(v => {
            const user = {}
            user.userId = v.userId
            user.stuId = v.stuId
            user.realName = v.realName
            t.push(user)
          })
          this.examGroupMember.selectUsers = JSON.stringify(t)
          this.$emit('submitForm', this.examGroupMember)
          this.$emit('update:addByCourseGroupDialogVisible', false)
        }
      })
    },
    cancel(formName) {
      this.$emit('update:addByCourseGroupDialogVisible', false)
    },
    openDialog() {

    },
    select(selection) {
      this.selectUsers = selection.map(item => item)
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeDialog(formName) {
      this.$refs[formName].clearValidate()
      this.courseMemberGroup = []
      this.schemeId = null
      this.mgId = undefined
      this.courseMemberData = []
      this.$emit('update:addByCourseGroupDialogVisible', false)
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
