<!--
@description 学员分组管理--头部搜索组件
@author cgy
-->
<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <!-- <el-form-item label="授课方案" prop="schemeId">
      <el-select v-model="queryParams.schemeId" placeholder="请选择授课方案" clearable>
        <el-option
          v-for="shceme in courseSchemeOptions"
          :key="shceme.schemeId"
          :label="shceme.schemeTitle"
          :value="shceme.schemeId"
        />
      </el-select>
    </el-form-item> -->
    <el-form-item label="分组名称" prop="mgName">
      <el-input v-model="queryParams.mgName" size="medium" placeholder="请输入分组名称" clearable />
    </el-form-item>
    <el-form-item style="margin-left:0%">
      <el-button
        size="small"
        type="primary"
        icon="el-icon-search"
        :disabled="!button.includes('/course/courseTerm')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button
        size="small"
        icon="el-icon-refresh"
        @click="handleRecycleBin"
      >{{ queryParams.delFlag?'关闭回收站':'打开回收站' }}</el-button>
      <el-button
        size="small"
        type="primary"
        icon="el-icon-plus"
        :disabled="queryParams.delFlag || !button.includes('course/courseTerm/add')"
        @click="handleAdd"
      >新增</el-button>
      <el-button
        size="small"
        type="danger"
        :icon="queryParams.delFlag ? 'el-icon-refresh' : 'el-icon-delete'"
        :disabled="ids.length===0 || !button.includes('course/courseTerm/deletebatch')"
        @click="handleBatchDelete"
      >{{ queryParams.delFlag?'恢复': '删除' }}</el-button>
      <el-button
        size="small"
        type="danger"
        :disabled="!queryParams.delFlag || !button.includes('course/courseTerm/delempty')"
        @click="handleEmpty"
      >
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-qingkonghuancun" />
        </svg>&nbsp;清空
      </el-button>
    </el-form-item>
  </el-form>
</template>
<script>
// import Treeselect from '@riophae/vue-treeselect'
// import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'HeaderSearch',
  components: { },
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    ids: {
      type: Array,
      required: true
    },
    button: {
      type: Array,
      required: true
    },
    courseSchemeOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      courseOptions: [],
      courseTermOptions: []
    }
  },
  methods: {
    /** 搜索按钮操作 */
    handleQuery() {
      this.$emit('handleQuery', this.queryParams)
    },
    /** 点击了回收站 */
    handleRecycleBin() {
      this.queryParams.delFlag = !this.queryParams.delFlag
      this.$emit('handleRecycleBin', this.queryParams)
    },
    /** 点击了新增 */
    handleAdd() {
      this.$emit('handleAdd')
    },
    /** 点击了批量删除 */
    handleBatchDelete() {
      this.$emit('handleBatchDelete')
    },
    /** 点击了清空 */
    handleEmpty() {
      this.$emit('handleEmpty')
    }
  }
}
</script>
<style lang="scss" scoped>
.icon {
  color: #fff;
  width: 1.1em;
  height: 1.1em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
.el-form .el-form-item {
  margin-bottom: 15px;
}
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
