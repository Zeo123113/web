<template>
  <el-dialog
    :title="examation.examId ? '修改考试' : '添加考试'"
    :visible.sync="dialogFormVisible"
    @close="resetForm('examation')"
  >
    <el-form ref="examation" :model="examation" :rules="rules" label-width="100px">
      <el-row>
        <el-col :span="20">
          <el-form-item label="考试标题" prop="examTitle" :label-width="formLabelWidth">
            <el-input
              v-model="examation.examTitle"
              placeholder="请输入考试标题"
              autocomplete="off"
              clearable
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <el-form-item label="考试安排" prop="examArrangeId" :label-width="formLabelWidth">
            <el-select v-model="examation.examArrangeId" placeholder="请选择考试安排" clearable>
              <el-option
                v-for="examArrange in examArrangeOptions"
                :key="examArrange.roundId"
                :label="examArrange.examTitle"
                :value="examArrange.roundId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <!-- <el-col :span="12">
          <el-form-item label="开始考试" prop="isBeginExam" :label-width="formLabelWidth">
            <el-switch
              v-model="examation.isBeginExam"
              active-color="#13ce66"
              inactive-color="#ff4949"
            >
            </el-switch>
          </el-form-item>
        </el-col> -->
      </el-row>
      <el-row>
        <el-col :span="20">
          <el-form-item label="备注" prop="remark" :label-width="formLabelWidth">
            <el-input
              v-model="examation.remark"
              type="textarea"
              :rows="3"
              placeholder="请输入备注"
              controls-position="right"
              :min="1"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="mini" @click="saveScoreSetting('examation')">保存</el-button>
      <el-button size="mini" @click="resetForm('examation')">取消</el-button>
    </div>
  </el-dialog>
</template>
<script>
import examArrangeApi from '@/api/exambank/examArrange'
import examationApi from '@/api/course/courseManage/examation'
export default {
  components: {
  },
  props: {
    // 打开弹窗标志
    dialogFormVisible: {
      type: Boolean,
      default: false
    },
    // 考试
    examation: {
      type: Object,
      required: true
    },
    // 考试安排
    examArrangeOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      // 验证规则
      rules: {
        examArrangeId: [{ required: true, message: '请选择教学方案', trigger: 'blur' }],
        examTitle: [{ required: true, message: '考试题目不能为空', trigger: 'blur' }],
        orgId: [{ required: true, message: '组织机构不能为空', trigger: 'blur' }],
        limitTime: [{ required: true, message: '考试时间不能为空', trigger: 'blur' },
          { type: 'number', message: '考试时长必须是数字', trigger: 'blur' }]
      },
      // 表单属性宽度
      formLabelWidth: '80px'
    }
  },
  methods: {
    // 保存表单
    saveScoreSetting(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          examArrangeApi.getExamArrange(this.examation.examArrangeId).then(resp => {
            if (resp.code === 0) {
              this.examation.examStartTime = resp.data.startTime
              this.examation.limitTime = resp.data.duration
              if (!this.examation.examId) {
                this.examation.createOrgId = this.$store.getters.user.org.orgId
                this.examation.createBy = this.$store.getters.user.loginName
                examationApi.add(this.examation).then(resp => {
                  this.resetForm('examation')
                  if (resp.code === 0) {
                    this.$message({
                      type: 'success',
                      message: '考试保存成功'
                    })
                  } else {
                    this.$message({
                      message: resp.msg,
                      type: 'error'
                    })
                  }
                })
              } else {
                this.examation.updateBy = this.$store.getters.user.loginName
                examationApi.update(this.examation).then(resp => {
                  this.resetForm('examation')
                  if (resp.code === 0) {
                    this.$message({
                      type: 'success',
                      message: '考试修改成功'
                    })
                  } else {
                    this.$message({
                      message: resp.msg,
                      type: 'error'
                    })
                  }
                })
              }
            }
          })

          setTimeout(() => {
            this.$emit('reGetList')
          }, 1000)
        }
      })
    },
    // 重置表单
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.$emit('closeAdd')
    }
  }
}
</script>
<style lang="scss" scoped>
.el-dialog__wrapper >>> .el-dialog {
  width: 55%;
}
.el-dialog__wrapper {
  z-index: 1200 !important;
}
</style>
