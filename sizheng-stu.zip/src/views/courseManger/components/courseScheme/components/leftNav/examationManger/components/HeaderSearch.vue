<!--
@description 课程成绩设置管理
@author cuipengyuan
-->
<template>
  <div class="sort">
    <el-form ref="examationSelect" :inline="true" :model="examationSelect" class="demo-form-inline">
      <el-form-item label="考试安排" prop="examArrangeId">
        <el-select
          v-model="examationSelect.examArrangeId"
          placeholder="请选择考试安排"
          size="small"
          clearable
        >
          <el-option
            v-for="examArrange in examArrangeOptions"
            :key="examArrange.roundId"
            :label="examArrange.examTitle"
            :value="examArrange.roundId"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="考试标题" prop="examTitle">
        <el-input v-model="examationSelect.examTitle" placeholder="请输入考试标题" size="small" clearable />
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          size="small"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          unlink-panels
          :picker-options="pickerOptions"
          style="width:217px;"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="el-icon-search"
          size="small"
          :disabled="!button.includes('course/examation/list')"
          @click="onSubmit"
        >搜索</el-button>
        <!-- <el-button
          v-if="isUseAdd"
          type="primary"
          icon="el-icon-plus"
          size="small"
          :disabled="!button.includes('course/examation/add')"
          @click="add()"
        >添加</el-button> -->
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  components: {
  },
  props: {
    // 封装对象
    examationSelect: {
      type: Object,
      default: null
    },
    button: {
      type: Array,
      required: true
    },
    multselect: {
      type: Boolean,
      required: true
    },
    // 考试安排
    examArrangeOptions: {
      type: Array,
      required: true
    },
    coursedetail: {
      type: Object,
      required: true
    },
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 初始化日期快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      // 日期
      dateRange: '',
      // 课程
      courseOptions: [],
      // 课程学期
      courseTermOptions: [],
      isUseAdd: true
    }
  },
  /** 监听日期变化 */
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.examationSelect.beginTime = val[0]
        this.examationSelect.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  mounted() {
    if (JSON.parse(this.coursedetail.courseLeaders).indexOf(this.$store.state.user.user.userId) === -1 && this.courseTerm.examMode === 0) {
      this.isUseAdd = false
    }
  },
  methods: {
    /** 点击搜索 */
    onSubmit() {
      this.$emit('handleQuery', this.examationSelect)
    },
    /** 处理添加 */
    add() {
      this.$emit('add')
    }
  }
}
</script>
<style lang="sass" scoped>

</style>
