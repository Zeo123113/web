<template>
  <div>
    <el-table
      ref="multipleTable"
      :data="examLogData"
      tooltip-effect="light"
      style="width: 100%"
    >
      <!-- <el-table-column prop="examRecId" label="记录编号" align="center" min-width="100"></el-table-column> -->
      <!-- <el-table-column prop="roundId" label="场次编号" sortable align="center" min-width="180"></el-table-column>
        <el-table-column prop="paperId" label="试卷编号" sortable align="center" min-width="180"></el-table-column> -->
      <el-table-column prop="stuId" label="考生学号" sortable align="center" min-width="120"></el-table-column>
      <el-table-column prop="realName" label="考生姓名" sortable align="center" min-width="120"></el-table-column>
      <el-table-column prop="examStatus" label="考试状态" sortable align="center" min-width="100" :formatter="examStatusTypeFormat"></el-table-column>
      <el-table-column prop="remainTime" label="剩余时间(分钟)" sortable align="center" min-width="180"></el-table-column>
      <el-table-column prop="finishTime" label="完成考试时间" sortable align="center" min-width="180"></el-table-column>
      <el-table-column
        prop="firistLoginTime"
        label="首次登陆时间"
        sortable
        align="center"
        min-width="180"
      ></el-table-column>
      <el-table-column prop="firstLoginIp" label="首次登录IP" sortable align="center" min-width="180"></el-table-column>
      <el-table-column
        prop="firstLocation"
        label="首次登录地点"
        sortable
        align="center"
        min-width="180"
      ></el-table-column>
      <el-table-column prop="reloginTime" label="重登时间" sortable align="center" min-width="180"></el-table-column>
      <el-table-column prop="reloginIp" label="重登IP" sortable align="center" min-width="180"></el-table-column>
      <el-table-column
        prop="reloginLocation"
        label="重登地点"
        sortable
        align="center"
        min-width="180"
      ></el-table-column>
      <el-table-column prop="loginCount" label="登录次数" sortable align="center" min-width="180"></el-table-column>
      <el-table-column label="操作" align="center" min-width="100" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" content="延时" placement="top">
            <svg class="icon click" aria-hidden="true" @click="delay(scope.row)">
              <use xlink:href="#icon-shijian" />
            </svg>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog
      title="延时(分钟)"
      :visible.sync="timeVisible"
      width="30%"
    >
      <el-input-number v-model="num" :min="0" :step="1" style="margin-left:50px"></el-input-number>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="timeVisible = false">取 消</el-button>
        <el-button size="small" type="primary" @click="delayTime()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import ExamLogApi from '@/api/exambank/exam-record'
export default {
  name: 'ExamLogView',
  props: {
    examLog: {
      type: Object,
      required: true
    },
    // 考试状态数据字典
    examStatusTypeDict: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      examLogData: [],
      timer: '',
      num: 0,
      timeVisible: false,
      examLogObject: {}
    }
  },
  mounted() {
    this.getList()
    this.timer = setInterval(this.getList, 5000)
  },
  beforeDestroy() {
    clearInterval(this.timer)
  },
  destroyed() {
    clearInterval(this.timer)
  },
  methods: {
    getList() {
      ExamLogApi.getExamLogsByRoundIdAndExamtype(this.examLog).then(resp => {
        this.examLogData = resp.data
      })
    },
    /** 考试状态字典翻译 */
    examStatusTypeFormat(row) {
      return this.selectDictLabel(this.examStatusTypeDict, row.examStatus)
    },
    delay(row) {
      this.examLogObject = { ...row }
      this.timeVisible =  true
    },
    delayTime() {
      this.examLogObject.remainTime = this.examLogObject.remainTime + this.num
      ExamLogApi.update(this.examLogObject).then((result) => {
        if (result.code === 0) {
          this.getList()
          this.num = 0
          this.timeVisible =  false
          this.$message({
            type: 'success',
            message: '延时成功'
          })
        }
      })
    }

  }

}
</script>

<style lang="scss" scoped>
.click {
  cursor: pointer;
}
.icon {
  width: 1.2em;
  height: 1.55em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-left: 10px;
}
</style>
