<template>
  <div>
    <div class="h500">
      <div>
        <p class="fs mt30">考试分组学员数: {{ examGroupMemberCount }},学员提交数: {{ examLogCount }}</p>
        <p class="fs mt30">考试试卷列表:
          <ol>
            <li v-for="(paper,index) of paperList" :key="index" class="click" @click="getStuAnswer(paper)">{{ paper.paperTitle }}</li>
          </ol>
        </p>
        <div v-if="isClickPaper" class="mt20">
          <el-row>
            <el-col :span="6"> <div id="myChart" :style="{width: '300px', height: '300px'}"></div></el-col>

            <el-col :span="18">
              <div style="height:300px">
                <!--列表展示-->
                <el-table
                  :data="stuAnswerData"
                  tooltip-effect="dark"
                  max-height="300"
                >
                  <el-table-column fixed label="学生姓名" align="center" prop="realName" sortable min-width="100" />
                  <el-table-column fixed label="学生学号" align="center" prop="stuId" sortable min-width="100" show-overflow-tooltip />
                  <el-table-column label="单选题得分" align="center" prop="single" sortable min-width="120" />
                  <el-table-column label="多选题得分" align="center" prop="multi" sortable min-width="120" />
                  <el-table-column label="判断题得分" align="center" prop="judge" sortable min-width="120" />
                  <el-table-column label="填空题得分" align="center" prop="fillblank" sortable min-width="120" />
                  <el-table-column label="问答题得分" align="center" prop="subjective" sortable min-width="120" />
                  <el-table-column label="程序填空题得分" align="center" prop="progBillblank" sortable min-width="150" />
                  <el-table-column label="接口编程题得分" align="center" prop="progInterface" sortable min-width="150" />
                  <el-table-column label="文件上传题得分" align="center" prop="fileUpload" sortable min-width="150" />
                  <el-table-column label="编程题得分" align="center" prop="program" sortable min-width="120" />
                  <el-table-column label="总得分" align="center" prop="score" sortable min-width="100" />
                  <el-table-column
                    label="创建时间"
                    prop="createTime"
                    align="center"
                    show-overflow-tooltip
                    min-width="180"
                  />
                </el-table>
                <pagination
                  v-show="total > 0"
                  :total="total"
                  :page.sync="pageNum"
                  :limit.sync="pageSize"
                  @pagination="getList"
                />
              </div>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ExamLogApi from '@/api/exambank/exam-record'
import EXAMBANK_CONST from '@/constant/exambank-const'
import examArrangeApi from '@/api/exambank/examArrange'
import examGroupMemberApi from '@/api/course/courseManage/examGroupMember'
import paperApi from '@/api/exambank/paper.js'
import stuAnswerApi from '@/api/exambank/stu-answer.js'
import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
export default {
  name: 'ExamLogView',
  components: {
    pagination
  },
  props: {
    examArrangeId: {
      type: Number,
      required: true
    },
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      type: EXAMBANK_CONST.EXAM,
      // 考试记录个数
      examLogCount: 0,
      // 考试分组学员个数
      examGroupMemberCount: 0,
      paperList: [],
      stuAnswerList: [],
      one: [],
      two: [],
      three: [],
      four: [],
      five: [],
      myChart: null,
      stuAnswerData: [],
      queryParams: {
        paperId: null,
        roundId: null,
        courseId: null,
        termId: null,
        examType: EXAMBANK_CONST.EXAM,
        orgId: null
      },
      // 默认分页参数
      total: 1,
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      loading: false,
      isClickPaper: false
    }
  },
  mounted() {
    var examLog = {
      roundId: this.examArrangeId,
      examType: this.type
    }
    ExamLogApi.getExamLogCountByExamArrangeId(examLog).then((result) => {
      if (result.code === 0) {
        this.examLogCount = result.data
      }
    })
    var examArrange = {
      roundId: this.examArrangeId
    }
    examArrangeApi.getExamGroupIdByExamArrangeId(examArrange).then((result) => {
      if (result.code === 0) {
        examGroupMemberApi.getMemberCountByExamGroup(result.data).then((resp) => {
          this.examGroupMemberCount = resp.data
        })
      }
    })
    paperApi.getPaperListByExamArrangeId(this.examArrangeId).then((result) => {
      if (result.code === 0) {
        this.paperList = result.data
      }
    })
  },
  // beforeDestroy() {
  //   this.clear()
  // },
  methods: {
    clear() {
      this.examLogCount = 0
      this.examGroupMemberCount = 0
      this.paperList  = []
      this.one = []
      this.two = []
      this.three = []
      this.four = []
      this.five = []
      this.myChart.clear()
      this.isClickPaper = false
    },
    getStuAnswer(item) {
      this.isClickPaper = true
      var studentAnswer = {
        roundId: this.examArrangeId,
        paperId: item.paperId,
        examType: this.type
      }
      this.queryParams.paperId = item.paperId
      this.queryParams.roundId = this.examArrangeId
      this.queryParams.courseId = this.courseTerm.csId
      this.queryParams.termId = this.courseTerm.ctId
      this.queryParams.orgId = this.courseTerm.orgId
      this.getList()
      stuAnswerApi.getStuAnswerListByRoundIdANDPaperId(studentAnswer).then((result) => {
        if (result.code === 0) {
          this.stuAnswerList = result.data
          this.stuAnswerList.forEach(item => {
            if (item.score < 60) {
              this.one.push(item)
            } else if (item.score >= 60 && item.score < 70) {
              this.two.push(item)
            } else if (item.score >= 70 && item.score < 80) {
              this.three.push(item)
            } else if (item.score >= 80 && item.score < 90) {
              this.four.push(item)
            } else {
              this.five.push(item)
            }
          })
        }
      })
      setTimeout(() => {
        this.initScore()
      }, 1000)
    },
    initScore() {
      // 基于准备好的dom，初始化echarts实例
      this.myChart = this.$echarts.init(document.getElementById('myChart'))
      // 绘制图表
      this.myChart.setOption({
        title: { text: '成绩分布' },
        tooltip: {},
        xAxis: {
          data: ['60分以下', '60-70', '70-80', '80-90', '90-100']
        },
        yAxis: {},
        series: [{
          name: '成绩',
          type: 'bar',
          data: [this.one.length, this.two.length, this.three.length, this.four.length, this.five.length]
        }]
      })
    },
    getList() {
      this.loading = true
      stuAnswerApi
        .getList(this.queryParams, this.pageNum, this.pageSize)
        .then(response => {
          this.stuAnswerData = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    }
  }

}
</script>

<style lang="scss" scoped>
.h500{
    height: 500px;
}
.fs{
    font-size: 18px;
}
.mt30
{
    margin-top:30px
}
.click{
  cursor: pointer
}
ol{
    display: inline-block;
}
.mt20{
     margin-top:20px
}
</style>
