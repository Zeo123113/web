<template>
  <div>
    <div class="sort">
      <el-form ref="examationSelect" :inline="true" :model="examLog" class="demo-form-inline">
        <el-form-item label="考试状态" prop="examStatus">
          <el-select v-model="examLog.examStatus" size="small" placeholder="请选择考试状态" clearable>
            <el-option
              v-for="dict in examStatusTypeDict"
              :key="dict.dictValue"
              :label="dict.dictLabel"
              :value="dict.dictValue"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="学号" prop="stuId">
          <el-input v-model="examLog.stuId" placeholder="请输入学号" size="small" clearable />
        </el-form-item>
        <el-form-item>
          <el-button
            type="primary"
            icon="el-icon-search"
            size="small"
            @click="getList(pageNum, pageSize)"
          >搜索</el-button>
        </el-form-item>
      </el-form>
    </div>
    <el-table
      ref="multipleTable"
      v-loading="loading"
      :data="examLogData"
      tooltip-effect="light"
      style="width: 100%"
    >
      <!-- <el-table-column prop="examRecId" label="记录编号" align="center" min-width="100"></el-table-column> -->
      <!-- <el-table-column prop="roundId" label="场次编号" sortable align="center" min-width="180"></el-table-column>
        <el-table-column prop="paperId" label="试卷编号" sortable align="center" min-width="180"></el-table-column> -->
      <el-table-column prop="stuId" label="考生学号" sortable align="center" min-width="120"></el-table-column>
      <el-table-column prop="realName" label="考生姓名" sortable align="center" min-width="120"></el-table-column>
      <el-table-column prop="score" label="考生分数" sortable align="center" min-width="100" :formatter="scoreFormat"></el-table-column>
      <el-table-column prop="examStatus" label="考试状态" align="center" min-width="100" :formatter="examStatusTypeFormat"></el-table-column>
      <el-table-column prop="isGrading" label="阅卷完成" align="center" min-width="80" :formatter="isGradingFormat"></el-table-column>
      <!-- <el-table-column prop="loginCount" label="登录次数" sortable align="center" min-width="180"></el-table-column> -->
      <!-- <el-table-column prop="finishTime" label="完成考试时间" sortable align="center" min-width="180"></el-table-column> -->
      <!-- <el-table-column
        prop="firistLoginTime"
        label="首次登陆时间"
        sortable
        align="center"
        min-width="180"
      ></el-table-column>
      <el-table-column prop="firstLoginIp" label="首次登录IP" sortable align="center" min-width="180"></el-table-column>
      <el-table-column
        prop="firstLocation"
        label="首次登录地点"
        sortable
        align="center"
        min-width="180"
      ></el-table-column>
      <el-table-column prop="reloginTime" label="重登时间" sortable align="center" min-width="180"></el-table-column>
      <el-table-column prop="reloginIp" label="重登IP" sortable align="center" min-width="180"></el-table-column>
      <el-table-column
        prop="reloginLocation"
        label="重登地点"
        sortable
        align="center"
        min-width="180"
      ></el-table-column> -->
      <el-table-column label="操作" align="center" min-width="250" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" content="阅卷" placement="top">
            <svg v-if="scope.row.examStatus === TESTED" class="icon click" aria-hidden="true" @click="marke(scope.$index)">
              <use xlink:href="#icon-piyue1" />
            </svg>
          </el-tooltip>
          <el-tooltip class="item" effect="dark" content="标为缓考" placement="top">
            <svg class="icon click" aria-hidden="true" @click="makeDelayed(scope.row)">
              <use xlink:href="#icon-yanchi" />
            </svg>
          </el-tooltip>
          <el-tooltip class="item" effect="dark" content="标为作弊" placement="top">
            <svg class="icon click" aria-hidden="true" @click="makeCheat(scope.row)">
              <use xlink:href="#icon-zuobi" />
            </svg>
          </el-tooltip>
          <el-tooltip class="item" effect="dark" content="标为缺考" placement="top">
            <svg class="icon click" aria-hidden="true" @click="makeLacktest(scope.row)">
              <use xlink:href="#icon-quekao" />
            </svg>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="pageQuery"
    />
    <markeStuAnswer
      :dialog-object="dialogObject"
      @getList="getList1"
    >
    </markeStuAnswer>
  </div>
</template>

<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
import ExamLogApi from '@/api/exambank/exam-record'
import markeStuAnswer from './markeStuAnswer'
import COURSE_CONST from '@/constant/course-const'
import pagination from '@/components/Pagination/index'
export default {
  name: 'ExamLogView',
  components: {
    markeStuAnswer,
    pagination
  },
  props: {
    examLog: {
      type: Object,
      required: true
    },
    // 考试状态数据字典
    examStatusTypeDict: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      examLogData: [],
      TESTED: EXAMBANK_CONST.TESTED,
      dialogObject: {
        show: false,
        sindex: null,
        roundId: this.examLog.roundId,
        examType: this.examLog.examType
      },
      // 分页页数
      pageNum: 1,
      // 每页数据
      pageSize: COURSE_CONST.PAGESIZE,
      // 分页记录总条数
      total: 1,
      loading: true
    }
  },
  mounted() {
    this.getList(this.pageNum, this.pageSize)
  },
  methods: {
    getList(pageNum, pageSize) {
      this.loading = true
      ExamLogApi.getExamLogAndScoreByPage(this.examLog, pageNum, pageSize).then(resp => {
        this.examLogData = resp.data.list
        this.total = resp.data.total
        this.loading = false
      })
    },
    isGradingFormat(row) {
      if (row.isGrading) {
        return '是'
      } else {
        return '否'
      }
    },
    scoreFormat(row) {
      if (row.score) {
        return row.score
      } else {
        return '0'
      }
    },
    /** 处理分页查询 */
    pageQuery(pagePara) {
      this.getList(pagePara.page, pagePara.limit)
    },
    getList1() {
      this.getList(this.pageNum, this.pageSize)
    },
    /** 考试状态字典翻译 */
    examStatusTypeFormat(row) {
      return this.selectDictLabel(this.examStatusTypeDict, row.examStatus)
    },
    marke(index) {
      this.dialogObject.sindex = index
      this.dialogObject.show = true
    },
    makeDelayed(row) {
      this.$confirm('确定要标记学生 ' + row.realName + ' 为缓考?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        row.examStatus = EXAMBANK_CONST.DELAYED
        ExamLogApi.update(row).then((result) => {
          if (result.code === 0) {
            this.$message({
              type: 'success',
              message: '标记成功'
            })
          }
        })
      })
    },
    makeCheat(row) {
      this.$confirm('确定要标记学生 ' + row.realName + ' 为作弊?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        row.examStatus = EXAMBANK_CONST.CHEATING
        ExamLogApi.update(row).then((result) => {
          if (result.code === 0) {
            this.$message({
              type: 'success',
              message: '标记成功'
            })
          }
        })
      })
    },
    makeLacktest(row) {
      this.$confirm('确定要标记学生 ' + row.realName + ' 为缺考?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        row.examStatus = EXAMBANK_CONST.LACKTEST
        ExamLogApi.update(row).then((result) => {
          if (result.code === 0) {
            this.$message({
              type: 'success',
              message: '标记成功'
            })
          }
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.click {
  cursor: pointer;
}
.icon {
  width: 1.5em;
  height: 1.55em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-left: 10px;
}
#a:link{
  color:#fff;
}
</style>
<style scoped>
.el-dialog__wrapper /deep/ .el-dialog /deep/ .el-dialog__body {
  height: 80vh;
  overflow-y: auto;
}
.el-dialog__wrapper >>> .el-dialog {
    margin-bottom: 0px;
}
</style>

