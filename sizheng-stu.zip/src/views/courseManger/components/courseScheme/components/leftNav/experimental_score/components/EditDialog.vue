<template>
  <el-dialog
    :title="dialog.title"
    :visible.sync="dialog.show"
    width="65%"
    @close="close"
    @open="openDialog"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="授课单元" prop="unitId" :label-width="labelWidth">
            <el-select
              v-model="form.unitId"
              placeholder="请选择授课单元"
              clearable
              @change="courseUnitChange"
            >
              <el-option
                v-for="courseUnit in courseUnitOptions"
                :key="courseUnit.unitId"
                :label="courseUnit.unitTitle"
                :value="courseUnit.unitId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="学员分组" prop="mgId">
            <treeselect
              v-model="form.mgId"
              :options="courseMemberGroupOptions"
              style="width:217px;"
              placeholder="请选择学员分组"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="实验报告" prop="experId" :label-width="labelWidth">
            <el-select v-model="form.experId" placeholder="请选择实验报告" clearable>
              <el-option
                v-for="experimentTask in experimentTaskOptions"
                :key="experimentTask.experId"
                :label="experimentTask.experTitle"
                :value="experimentTask.experId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="用户" prop="reportUser" :label-width="labelWidth">
            <el-input
              v-model="form.reportUser"
              type="input"
              placeholder="请输入用户登录名"
              style="width:72%"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="实验报告" prop="experReport" :label-width="labelWidth">
            <el-upload
              ref="upload"
              :action="uploadUrl"
              :data="fileTag"
              :limit="1"
              :before-upload="beforeUpload"
              :on-success="uploadSuccess"
              :on-error="uploadError"
              :headers="headers"
              class="upload-button"
              :show-file-list="false"
            >
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="实验成绩" prop="experScore" :label-width="labelWidth">
            <el-input-number v-model="form.experScore" :min="1" :max="100" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="实验评价" prop="experEvaluation">
            <el-select v-model="form.experEvaluation" placeholder="请选择实验评价" clearable>
              <el-option
                v-for="dict in experEvaluationDict"
                :key="dict.dictvalue"
                :label="dict.dictLabel"
                :value="dict.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="报告评价" prop="reportEvaluation">
            <el-select v-model="form.reportEvaluation" placeholder="请选择报告评价" clearable>
              <el-option
                v-for="dict in reportEvaluationDict"
                :key="dict.dictvalue"
                :label="dict.dictLabel"
                :value="dict.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="提交时间" prop="submitTime" :label-width="labelWidth">
            <el-date-picker
              v-model="form.submitTime"
              type="datetime"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="请输入提交时间"
              align="right"
              clearable
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入备注"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit">保存</el-button>
      <el-button @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import experimentTaskApi from '@/api/course/courseTask/experimentTask'
import { getToken } from '@/utils/auth'
import userApi from '@/api/user/user'
import experimentReportApi from '@/api/course/courseTask/experimentReport'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import USER_CONST from '@/constant/user-const'
export default {
  name: 'EditDialog',
  components: {
    Treeselect
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      default: null
    },
    experEvaluationDict: {
      type: Array,
      required: true
    },
    reportEvaluationDict: {
      type: Array,
      required: true
    },
    courseUnitOptions: {
      type: Array,
      required: true
    },
    courseMemberGroupOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    var validateLoginName = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('用户名不能为空'))
      } else if (value.length < 2 || value.length > 100) {
        callback(new Error('长度在 2 到 50 个字符'))
      } else {
        userApi.checkUserByLoginName1(value).then(resp => {
          if (resp.msg !== '查找的用户不存在' || resp.data !== null) {
            this.form.userId = resp.data.userId
            this.form.stuId = resp.data.stuId
            this.form.realName = resp.data.realName
            callback()
          } else {
            callback(new Error(resp.msg))
          }
        })
      }
    }
    return {
      experimentTaskOptions: [],
      // 上传文件时文件标签
      fileTag: { fileTag: '' },
      headers: {
        token: getToken()
      },
      uploadUrl: process.env.VUE_APP_BASE_API + '/file/student-files/uploadfile',
      labelWidth: '120px',
      // 表单校验
      rules: {
        unitId: [{ required: true, message: '请选择授课单元', trigger: 'blur' }],
        experId: [{ required: true, message: '请选择实验任务', trigger: 'blur' }],
        experReport: [{ required: true, message: '请上传实验报告', trigger: 'blur' }],
        reportUser: [{ validator: validateLoginName, trigger: 'blur', required: true }]
      }
    }
  },
  methods: {
    /** 上传之前检测文件类型及大小 */
    beforeUpload: function(file) {
      this.fileTag.fileTag = '实验报告提交'
      this.isLt2k = file.size / 1024 / 1024 < 5 ? '1' : '0'
      if (this.isLt2k === '0') {
        this.$message({
          message: '上传文件大小不能超过5M!',
          type: 'error'
        })
      }
      return this.isLt2k === '1'
    },
    /** 文件上传成功时的勾子 */
    uploadSuccess: function(response, file, fileList) {
      this.$refs.upload.clearFiles()
      // console.log('response = ', response)
      if (response.code === 0) {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件成功！',
          type: 'success'
        })
        // {
        //         title:"实验1 报告", fileId:11, url:"file.docx"
        //      }
        const studentFile = response.data
        const experReport = {
          title: studentFile.fileName,
          fileId: studentFile.fileIdHexString,
          url: studentFile.fileUrl
        }
        this.form.experReport = JSON.stringify(experReport)
      } else {
        this.$message({
          dangerouslyUseHTMLString: true,
          message: '上传文件失败!' + response.msg,
          type: 'error'
        })
      }
    },
    /** 上传失败时的勾子 */
    uploadError: function(err, file, fileList) {
      this.$refs.upload.clearFiles()
      this.$message({
        message: '上传文件失败!',
        type: 'error'
      })
      console.log(err)
    },
    // 授课单元变化时触发
    courseUnitChange(value) {
      this.form.experId = null
      this.experimentTaskOptions = []
      if (value != null && value !== '' && value !== undefined) {
        // 根据授权单元unitId,查询实验任务
        experimentTaskApi.getExperimentTasksByUnitId(value).then(response => {
          this.experimentTaskOptions = response.data
        })
      } else {
        return
      }
    },
    openDialog() {
      if (this.form.ersId > 0) {
        this.courseSchemeChange(this.form.schemeId)
        this.courseUnitChange(this.form.unitId)
      }
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    /** 提交按钮 */
    submit: function() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          // this.form.experReport =
          //   '{"title":"J2RjJl5bAmuAFseWAAAK11EA0QI448.xml","fileid":{"timestamp":1583022698,"machineIdentifier":5423617,"processIdentifier":18764,"counter":475116,"time":1583022698000,"date":1583022698000,"timeSecond":1583022698},"url":"group1/M00/00/03/J2RjJl5bAmuAFseWAAAK11EA0QI448.xml"}'

          // console.log('this.form = ', this.form)
          if (this.dialog.title === '添加实验报告') {
            experimentReportApi
              .addexperimentReport(this.form)
              .then(result => {
                this.dialog.show = false
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
                this.$emit('getList', {}, 1, USER_CONST.PAGESIZE)
              })
              .catch(err => {
                console.log(err)
              })
          } else if (this.dialog.title === '修改实验报告') {
            experimentReportApi
              .updateexperimentReport(this.form)
              .then(result => {
                this.dialog.show = false
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                this.$emit('getList', {}, 1, USER_CONST.PAGESIZE)
              })
              .catch(err => {
                console.log(err)
              })
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
