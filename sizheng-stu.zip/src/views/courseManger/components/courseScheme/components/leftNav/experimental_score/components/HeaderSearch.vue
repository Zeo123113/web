<template>
  <el-form ref="searchForm" :model="queryParams" inline>
    <el-form-item label="授课单元" prop="unitId">
      <el-select
        v-model="queryParams.unitId"
        placeholder="请选择授课单元"
        clearable
        @change="courseUnitChange"
      >
        <el-option
          v-for="courseUnit in courseUnitOptions"
          :key="courseUnit.unitId"
          :label="courseUnit.unitTitle"
          :value="courseUnit.unitId"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="学员分组" prop="mgId">
      <treeselect
        v-model="queryParams.mgId"
        :options="courseMemberGroupOptions"
        style="width:217px;"
        placeholder="请选择学员分组"
      />
    </el-form-item>
    <el-form-item label="实验任务" prop="experId">
      <el-select v-model="queryParams.experId" placeholder="请选择实验任务" clearable>
        <el-option
          v-for="experimentTask in experimentTaskOptions"
          :key="experimentTask.experId"
          :label="experimentTask.experTitle"
          :value="experimentTask.experId"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="学生学号" prop="stuId">
      <el-input v-model="queryParams.stuId" placeholder="请输入学生学号" clearable style="width:217px;" />
    </el-form-item>
    <el-form-item label="学生姓名" prop="realName">
      <el-input
        v-model="queryParams.realName"
        placeholder="请输入学生姓名"
        clearable
        style="width:217px;"
      />
    </el-form-item>
    <el-form-item label="实验评价" prop="experEvaluation">
      <el-select v-model="queryParams.experEvaluation" placeholder="请选择实验评价" clearable>
        <el-option
          v-for="dict in experEvaluationDict"
          :key="dict.dictvalue"
          :label="dict.dictLabel"
          :value="dict.dictValue"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="报告评价" prop="reportEvaluation">
      <el-select v-model="queryParams.reportEvaluation" placeholder="请选择报告评价" clearable>
        <el-option
          v-for="dict in reportEvaluationDict"
          :key="dict.dictvalue"
          :label="dict.dictLabel"
          :value="dict.dictValue"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        unlink-panels
        :picker-options="pickerOptions"
        style="width:217px;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item style="margin-left:0%">
      <el-button
        type="primary"
        icon="el-icon-search"
        :disabled="!button.includes('course/experimentReport/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button icon="el-icon-refresh" @click="resetQuery('searchForm')">重置</el-button>
      <el-button
        type="primary"
        icon="el-icon-plus"
        :disabled="!button.includes('course/experimentReport/add')"
        @click="handleAdd"
      >新增</el-button>
      <el-button
        icon="el-icon-delete"
        size="medium"
        type="danger"
        :disabled="deldisabled || !button.includes('course/experimentReport/delete')"
        @click="handleDeleteMore"
      >删除</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import experimentTaskApi from '@/api/course/courseTask/experimentTask'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import USER_CONST from '@/constant/user-const'
export default {
  name: 'HeaderSearch',
  components: {
    Treeselect
  },
  props: {
    button: {
      type: Array,
      required: true
    },
    queryParams: {
      type: Object,
      required: true
    },
    experEvaluationDict: {
      type: Array,
      required: true
    },
    reportEvaluationDict: {
      type: Array,
      required: true
    },
    deldisabled: {
      type: Boolean,
      required: true
    },
    ids: {
      type: Array,
      required: true
    },
    courseUnitOptions: {
      type: Array,
      required: true
    },
    courseMemberGroupOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      experimentTaskOptions: [],
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      dateRange: ''
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  methods: {
    // 授课单元变化时触发
    courseUnitChange(value) {
      this.queryParams.experId = null
      this.experimentTaskOptions = []
      if (value != null && value !== '' && value !== undefined) {
        // 根据授权单元unitId,查询实验任务
        experimentTaskApi.getExperimentTasksByUnitId(value).then(response => {
          this.experimentTaskOptions = response.data
        })
      } else {
        return
      }
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.$emit('getList', this.queryParams, 1, USER_CONST.PAGESIZE)
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.$refs['searchForm'].resetFields()
      this.dateRange = ''
      this.queryParams.beginTime = ''
      this.queryParams.endTime = ''
      this.$emit('getList', {}, 1, USER_CONST.PAGESIZE)
    },
    /** 点击了新增 */
    handleAdd() {
      this.$emit('addexperimentReport')
    },
    /** 点击了批量删除 */
    handleDeleteMore() {
      this.$emit('handleDeleteMore', this.ids)
    }
  }
}
</script>

<style scoped>
.el-input {
  width: 130px;
}
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
