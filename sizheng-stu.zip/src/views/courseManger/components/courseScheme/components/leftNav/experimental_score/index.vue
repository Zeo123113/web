<!--
@description 实验报告管理
@author chengguangyuan
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">实验成绩</div>
    </div>
    <div class="cd-main__body">
      <!-- 搜索框 -->
      <header-search
        :query-params="queryParams"
        :button="button"
        :deldisabled="deldisabled"
        :ids="ids"
        :exper-evaluation-dict="experEvaluationDict"
        :report-evaluation-dict="reportEvaluationDict"
        :course-member-group-options="courseMemberGroupOptions"
        :course-unit-options="courseUnitOptions"
        @getList="getList"
        @addexperimentReport="addexperimentReport"
        @handleDeleteMore="handleDeleteMore"
      />

      <el-table
        v-loading="loading"
        :data="experimentReportData"
        tooltip-effect="light"
        row-key="ersId"
        @select="selectall"
        @select-all="selectall"
      >
        <el-table-column type="selection" align="center" width="50" />
        <el-table-column label="授课单元" :formatter="unitFormat" type="index" align="center" min-width="80" />
        <el-table-column label="学员分组" :formatter="MgFormat" prop="mgId" align="center" min-width="80" />
        <el-table-column label="实验报告" prop="experId" align="center" min-width="80" />
        <el-table-column label="用户编号" prop="userId" align="center" min-width="80" />
        <el-table-column label="学号" prop="stuId" align="center" min-width="80" />
        <el-table-column label="姓名" prop="realName" align="center" min-width="80" />
        <el-table-column label="实验成绩" prop="experScore" align="center" min-width="80" />
        <el-table-column label="实验评价" prop="experEvaluation" align="center" min-width="80" />
        <el-table-column label="报告评价" prop="reportEvaluation" align="center" min-width="80" />
        <el-table-column
          label="提交时间"
          prop="submitTime"
          align="center"
          sortable
          min-width="120"
          show-overflow-tooltip
        />
        <el-table-column label="操作" align="center" min-width="250" fixed="right" style="height:90px">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="success"
              :disabled="!button.includes('course/experimentReport/update')"
              @click="editexperimentReport(scope.row)"
            >编辑</el-button>
            <el-button
              size="mini"
              type="danger"
              :disabled="!button.includes('course/experimentReport/delete')"
              @click="handleDelete(scope.row)"
            >删除</el-button>
            <el-button size="mini" type="info" @click="handleExport(scope.row)">实验报告</el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      />
      <edit-dialog
        :form="experimentReport"
        :org-options="orgOptions"
        :dialog="dialog"
        :exper-evaluation-dict="experEvaluationDict"
        :report-evaluation-dict="reportEvaluationDict"
        :course-member-group-options="courseMemberGroupOptions"
        :course-unit-options="courseUnitOptions"
        @getList="getList"
      />
    </div>
  </div>
</template>
<script>
import { downloadByLink } from '@/utils/index'
import pagination from '@/components/Pagination/index'
import experimentReportApi from '@/api/course/courseTask/experimentReport'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import USER_CONST from '@/constant/user-const'
import { mapGetters } from 'vuex'
import courseUnitApi from '@/api/course/courseManage/courseUnit'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
export default {
  components: {
    EditDialog,
    HeaderSearch,
    pagination
  },
  props: {
    courseScheme: {
      type: Object,
      default: () => { return {} }
    }
  },
  data() {
    return {
      orgOptions: [],
      ids: [],
      experimentReportData: [],
      experimentReport: {
        reportUser: '',
        ersId: -1,
        csId: '',
        ctId: '',
        schemeId: '',
        mgId: null,
        experId: '',
        unitId: '',
        userId: '',
        stuId: '',
        realName: '',
        experReport: '',
        submitTime: '',
        experScore: '',
        experEvaluation: '',
        reportEvaluation: '',
        createOrgId: null,
        orgId: null,
        createTime: '',
        updateTime: '',
        createBy: '',
        updateBy: '',
        remark: ''
      },
      dialog: {
        title: '',
        show: false
      },
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      total: 1,
      queryParams: {
        ctId: null,
        orgId: null,
        csId: null,
        schemeId: null,
        reportEvaluation: null,
        experEvaluation: null,
        realName: '',
        stuId: '',
        experId: '',
        mgId: null,
        unitId: null
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // 数据字典
      experEvaluationDict: [],
      reportEvaluationDict: [],
      // 授课单元数组
      courseUnitOptions: [],
      // 学员分组数组
      courseMemberGroupOptions: []
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  created() {
    // 实验评价数据字典
    this.getDataByType('course_exper_evaluation').then(response => {
      this.experEvaluationDict = response.data
    })
    // 报告评价数据字典
    this.getDataByType('course_report_evaluation').then(response => {
      this.reportEvaluationDict = response.data
    })
    // 列表展示
    this.getList(this.queryParams, this.pageNum, this.pageSize)
    courseUnitApi.getRefUnitBySchemeId(this.courseScheme.schemeId).then(response => {
      this.courseUnitOptions = response.data
    })
    courseMemberGroupApi.getGroupBySchemeId(this.courseScheme.schemeId).then(response => {
      this.courseMemberGroupOptions = response.data
    })
  },
  methods: {
    unitFormat(row) {
      this.courseUnitOptions.forEach(item => {
        if (row.unitId === item.unitId) {
          return item.unitTitle
        }
      })
    },
    // 分组翻译
    MgFormat(row) {
      return this.getMgFormat(row.mgId, this.courseMemberGroupOptions)
    },
    getMgFormat(id, options) {
      for (let i = 0; i < options.length; i++) {
        if (id === options[i].id) {
          return options[i].label
        }
        if (options[i].children != null && options[i].children.length > 0) {
          this.getMgFormat(id, options[i].children)
        }
      }
    },
    /** 下载按钮操作 */
    handleExport(row) {
      const experReport = JSON.parse(row.experReport)
      downloadByLink(process.env.VUE_APP_FILE_SERVER, experReport.url, experReport.title)
    },
    // 表单重置
    reset() {
      this.experimentReport = {
        reportUser: '',
        ersId: -1,
        csId: '',
        ctId: '',
        schemeId: '',
        mgId: null,
        experId: '',
        unitId: '',
        userId: '',
        stuId: '',
        realName: '',
        experReport: '',
        submitTime: '',
        experScore: '',
        experEvaluation: '',
        reportEvaluation: '',
        createOrgId: null,
        orgId: null,
        createTime: '',
        updateTime: '',
        createBy: '',
        updateBy: '',
        remark: ''
      }
    },
    selectall(selection) {
      this.deldisabled = !this.deldisabled
      this.ids = selection.map(item => item.ersId)
    },
    addexperimentReport() {
      this.reset()
      this.dialog.title = '添加实验报告'
      this.dialog.show = true
    },
    editexperimentReport(row) {
      this.reset()
      this.experimentReport = { ...row }
      this.dialog.title = '修改实验报告'
      this.dialog.show = true
    },
    /** 处理分页查询 */
    pageQuery() {
      this.getList(this.queryParams, this.pageNum, this.pageSize)
    },
    resetForm() {
      this.search()
    },
    getList(param, pageNum, pageSize) {
      this.loading = true
      experimentReportApi
        .getexperimentReportList(param, pageNum, pageSize)
        .then(response => {
          this.experimentReportData = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 批量删除
    handleDeleteMore(ids) {
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          // console.log('this.ids = ', ids)
          return experimentReportApi.delexperimentReport(this.ids.toString())
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
          // this.$message.error(err.msg)
        })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return experimentReportApi.delexperimentReport(row.ersId)
        })
        .then(() => {
          this.$message({
            showClose: true,
            message: '删除成功',
            duration: 3000,
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 800px;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>

