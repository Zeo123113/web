<!--
@description 知识点管理
@author zhaoshibin
-->
<template>
  <el-form ref="queryForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="章节名称" prop="chapterId">
      <treeselect
        v-model="queryParams.chapterId"
        :options="chapterTreeOptions"
        style="width:217px;"
        placeholder="请选择所属章节"
      />
    </el-form-item>
    <el-form-item label="知识点名称" prop="knowledgeName">
      <el-input v-model="queryParams.knowledgeName" placeholder="请输入知识点名称" clearable />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" icon="el-icon-search" @click="handleQuery">搜索</el-button>
      <el-button icon="el-icon-refresh" @click="resetQuery">重置</el-button>
    </el-form-item>
    <el-button type="primary" icon="el-icon-plus" @click="handleAdd">新增</el-button>
    <el-button
      type="danger"
      icon="el-icon-delete"
      :disabled="deldisabled"
      @click="handleBatchDelete(ids)"
    >删除</el-button>
  </el-form>
</template>
<script>
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'HeaderSearch',
  components: {
    Treeselect
  },
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    deldisabled: {
      type: Boolean,
      default: false
    },
    chapterTreeOptions: {
      type: Array,
      default: () => {
        return []
      }
    }
  },
  data() {
    return {
      // 选中删除的列表
      ids: [],
      // 查询条件课程列表
      courseOptions: []
    }
  },
  methods: {
    // 搜索按钮操作
    handleQuery() {
      this.$emit('handleQuery', this.queryParams)
    },
    // 点击重置查询条件按钮
    resetQuery() {
      this.$emit('resetQuery')
    },
    // 新增按钮
    handleAdd() {
      this.$emit('handleAdd')
    },
    // 批量删除按钮
    handleBatchDelete() {
      this.$emit('handleBatchDelete')
    }
  }
}
</script>
<style lang="sass" scope>

</style>
