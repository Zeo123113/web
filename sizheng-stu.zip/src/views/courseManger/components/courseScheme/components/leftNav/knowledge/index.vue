<!--
@description 知识点管理
@author zhaoshibin
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">课程知识点</div>
    </div>
    <div class="cd-main__body">
      <!-- 下面是引入查询子组件 -->
      <header-search
        :query-params="queryParams"
        :deldisabled="deldisabled"
        :chapter-tree-options="chapterTreeOptions"
        @handleQuery="handleQuery"
        @resetQuery="resetQuery"
        @handleAdd="handleAdd"
        @handleBatchDelete="handleBatchDelete"
      ></header-search>
      <!-- 下面是数据展示 -->
      <el-table
        ref="multipleTable"
        v-loading="loading"
        :default-sort="{prop: 'date', order: 'descending'}"
        :data="tableData"
        tooltip-effect="light"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column type="index" label="编号" align="center" min-width="120" />
        <el-table-column
          prop="chapterSeq"
          :formatter="chapterFormat"
          label="所属章节"
          align="left"
          sortable
          show-overflow-tooltip
          min-width="100"
        />
        <el-table-column
          prop="knowledgeName"
          label="内容"
          align="left"
          min-width="300"
          show-overflow-tooltip
        />
        <el-table-column
          prop="seq"
          label="序号"
          align="center"
          min-width="100"
        />
        <!-- <el-table-column prop="seq" label="显示顺序" align="center" min-width="100" /> -->
        <el-table-column label="操作" fixed="right" align="center" min-width="70">
          <template slot-scope="scope">
            <el-tooltip content="编辑" placement="top" effect="light">
              <el-button type="text" size="mini" icon="el-icon-edit" @click="handleUpdate(scope.row)"></el-button>
            </el-tooltip>
            <el-tooltip content="删除" placement="top" effect="light">
              <el-button type="text" size="mini" icon="el-icon-delete" @click="handleDelete(scope.row)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
      <!-- 下面是分页插件 -->
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      ></pagination>
      <!-- 下面是新增修改知识点弹出框 -->
      <el-dialog :title="title" :visible.sync="open" width="60%">
        <el-form ref="form" :model="form" :rules="rules" label-width="120px">
          <el-row>
            <el-col :span="12">
              <el-form-item label="章节名称" prop="chapterId">
                <treeselect
                  v-model="form.chapterId"
                  :options="chapterTreeOptions"
                  style="width:217px;"
                  placeholder="请选择所属章节"
                />
              </el-form-item>
            </el-col>
            <!-- <el-col :span="12">
              <el-tooltip class="item" effect="light" content="角色显示的先后顺序" placement="top-start">
                <el-form-item label="显示顺序:" prop="seq">
                  <el-input-number v-model="form.seq" controls-position="right" :min="1"></el-input-number>
                </el-form-item>
              </el-tooltip>
            </el-col>-->
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="知识点内容" prop="knowledgeName">
                <el-input v-model="form.knowledgeName" type="textarea" placeholder="请输入知识点名称"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="备注">
                <el-input v-model="form.remark" type="textarea" placeholder="请输入备注内容"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" size="small" @click="submitForm">保存</el-button>
          <el-button size="small" @click="cancelOpen">取消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import knowledgeApi from '@/api/exambank/knowledge'
import chapterApi from '@/api/exambank/chapter'
import HeaderSearch from './components/HeaderSearch'
import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
export default {
  components: { HeaderSearch, pagination, Treeselect },
  data() {
    return {
      // 章节树形选项
      chapterOptions: [],
      // 是否显示加载遮罩层加载
      loading: false,
      // 弹出层标题
      title: '',
      // 课程列表
      courseOptions: [],
      // 选中删除的列表
      ids: [],
      // 根据条件查询
      queryParams: {
        orgId: undefined,
        courseId: undefined,
        knowledgeName: undefined,
        beginTime: undefined,
        endTime: undefined
      },
      // 批量删除按钮是否处于可用状态
      deldisabled: true,
      // 分页记录总条数
      total: 1,
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // table数据展示部分
      tableData: [],
      // 新增或修改知识点弹出框
      open: false,
      // 新增修改知识点表单
      form: {},
      // 表单校验
      rules: {
        orgId: [{ required: true, message: '组织机构不能为空', trigger: 'change' }],
        courseId: [{ required: true, message: '课程名称不能为空', trigger: 'change' }],
        chapterId: [{ required: true, message: '章节名称不能为空', trigger: 'change' }],
        knowledgeName: [{ required: true, message: '知识点名称不能为空', trigger: 'change' }]
      },
      // 树形章节
      chapterTreeOptions: []
    }
  },
  // 钩子函数，页面加载的时候就调用查询全部数据
  created() {
    // 回显章节
    chapterApi.getChapterListByCourseId(this.$route.params.csId).then(response => {
      this.chapterOptions = response.data
    })
    // 树形章节
    chapterApi.getChapterTreeByCourseId(this.$route.params.csId).then(response => {
      this.chapterTreeOptions = response.data
    })
    this.$nextTick(() => {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    })
  },
  methods: {
    /** 章节名称翻译 */
    chapterFormat(row) {
      row.chapterSeq = this.getChapterFormat(row.chapterId, this.chapterOptions)
      return row.chapterSeq
    },
    getChapterFormat(id, options) {
      for (let i = 0; i < options.length; i++) {
        if (id === options[i].chapterId) {
          return options[i].chapterSeq + ' ' + options[i].chapterName
        }
        if (options[i].children != null && options[i].children.length > 0) {
          const returnFlag = this.getChapterFormat(id, options[i].children)
          if (returnFlag != null) return returnFlag
        }
      }
    },
    // 单条删除按钮
    handleDelete(row) {
      this.$confirm('是否确认删除名称为 "' + row.knowledgeName + '" 的数据项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return knowledgeApi.delKnowledge(row.knowledgeId)
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '知识点删除成功'
          })
          this.fetchData(this.queryParams, this.pageNum, this.pageSize)
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 选中多个id
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.roleId)
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        this.deldisabled = false // 删除按钮可用状态
      }
    },
    // 取消按钮
    cancelOpen() {
      this.open = false
    },
    // 根据条件查询
    handleQuery(param) {
      this.fetchData(param, this.pageNum, this.pageSize)
    },
    // 分页查询，处理分页组件上的操作
    pageQuery(pagePara) {
      this.fetchData(this.queryParams, pagePara.page, pagePara.limit)
    },
    // 分页查询全部的数据
    fetchData(param, pageNum, pageSize) {
      this.loading = true
      param.courseId = this.$route.params.csId
      param.orgId = this.$store.getters.user.orgId
      knowledgeApi.listKnowledge(param, pageNum, pageSize).then(response => {
        this.tableData = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    },
    // 表单重置调用elementui
    resetForm(refName) {
      if (this.$refs[refName] !== undefined) {
        this.$refs[refName].resetFields()
      }
    },
    // 表单重置提供函数调用
    reset() {
      this.form = {
        orgId: undefined,
        knowledgeId: undefined,
        courseId: undefined,
        chapterId: undefined,
        knowledgeName: undefined,
        seq: 1,
        remark: undefined
      }
      this.resetForm('form')
    },
    // 新增按钮
    handleAdd() {
      this.reset()
      this.open = true
      this.title = '添加知识点'
    },
    // 批量删除
    handleBatchDelete(ids) {
      this.$confirm('您确定要批量删除已选定的数据项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return knowledgeApi.batchDelete(ids)
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '批量删除知识点成功'
          })
          this.fetchData(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true // 删除按钮处于禁用状态
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 新增修改提交
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.form.knowledgeId !== undefined) {
            knowledgeApi.updateKnowledge(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  type: 'success',
                  message: '修改成功'
                })
                this.open = false
                this.fetchData(this.queryParams, this.pageNum, this.pageSize)
              } else {
                this.$message({
                  message: response.msg,
                  type: 'error'
                })
              }
            })
          } else {
            this.form.orgId = this.$store.getters.user.orgId
            this.form.courseId = this.$route.params.csId
            knowledgeApi.addKnowledge(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  type: 'success',
                  message: '新增成功'
                })
                this.open = false
                this.fetchData(this.queryParams, this.pageNum, this.pageSize)
              } else {
                this.$message({
                  message: response.msg,
                  type: 'error'
                })
              }
            })
          }
        }
      })
    },
    // 修改知识点
    handleUpdate(row) {
      this.form = row
      this.title = '修改知识点'
      this.open = true
    },
    // 重置搜索表单
    resetQuery() {
      this.queryParams = {
        orgId: undefined,
        courseId: undefined,
        knowledgeName: undefined,
        beginTime: undefined,
        endTime: undefined
      }
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    }
  }
}
</script>
<style scoped>
.btn-group {
  margin-bottom: 20px;
}
</style>
