<!--
@description 学员管理
@author cgy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-main-header">
      <div class="cd-main__title">学员管理</div>
      <div class="course-main-header__operation">
        <a
          id="student-add-btn"
          class="cd-btn cd-btn-info cd-btn-sm mhs"
          disabled
          data-toggle="tooltip"
          data-placement="top"
          title
          data-original-title="计划未发布，不可添加学员"
        >
          <i class="glyphicon glyphicon-plus"></i> 添加学员
        </a>
        <a
          class="cd-btn cd-btn-info cd-btn-sm mhs"
          disabled
          data-toggle="tooltip"
          data-placement="top"
          title
          data-original-title="计划未发布,不可导入学员"
        >
          <i class="glyphicon glyphicon-import"></i> 批量导入
        </a>
        <a
          class="cd-btn mhs cd-btn-info cd-btn-sm js-export-btn"
          href="javascript:;"
          data-try-url="/try/export/course-students"
          data-url="/export/course-students"
          data-pre-url="/pre/export/course-students"
          data-loading-text="正在导出..."
          data-target-form="#course-students-export"
        >
          <i class="es-icon es-icon-filedownload cd-text-sm"></i>
          导出学员
        </a>

        <div id="export-modal" class="hide">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" data-success="文件下载完成">文件下载中</h4>
              </div>
              <div class="modal-body">
                <div class="progress progress-striped active">
                  <div
                    id="progress-bar"
                    class="progress-bar progress-bar-success"
                    style="width: 0%"
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <form id="course-students-export" class="hide">
          <input type="hidden" name="courseSetId" value="40" />
          <input type="hidden" name="courseId" value="40" />
        </form>
      </div>
    </div>
    <div class="cd-main__body">
      <div id="student-table-container" role="course-manage-student-index">
        <ul class="cd-tabs mbl">
          <li :class="{'li_active': active == '0'}">
            <a @click="active='0'">正式学员</a>
          </li>
          <li :class="{'li_active': active == '1'}">
            <a @click="active='1'">加入记录</a>
          </li>
          <li :class="{'li_active': active == '2'}">
            <a @click="active='2'">退出记录</a>
          </li>
        </ul>
        <form class="form-inline well well-sm">
          <div class="form-group col-md-7">
            <input class="form-control" type="text" style="width:45%" placeholder="请输入用户名/邮箱/手机号" />
            <button type="submit" class="cd-btn cd-btn-primary">搜索</button>
          </div>
          <div class="clearfix"></div>
        </form>
        <table id="course-student-list" class="table table-striped">
          <thead>
            <tr>
              <th>
                <input type="checkbox" autocomplete="off" data-role="batch-select" />
              </th>
              <th width="23%">学员</th>
              <th width="23%">学员</th>
              <th width="18%">学习进度</th>
              <th width="17%">加入时间</th>
              <th width="17%">学习有效期</th>
              <th width="25%">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr class="empty">
              <td colspan="20">暂无学员记录</td>
            </tr>
            <tr v-for="(courseMember,index) of courseMembers" :key="index">
              <td colspan="20">{{ courseMember.realName }}</td>
            </tr>
          </tbody>
        </table>
        <nav class="text-center"></nav>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'MemberGroup',
  components: {
  },
  data() {
    return {
      active: '0'
    }
  },
  methods: {
  }
}
</script>
<style lang="scss" scoped>
.table-striped > tbody > tr:nth-of-type(odd) {
  background-color: #f9f9f9;
}

.empty {
  text-align: center;
  color: #c1c1c1;
  padding: 20px 0;
}
.table > tbody > tr > td,
.table > tbody > tr > th,
.table > tfoot > tr > td,
.table > tfoot > tr > th,
.table > thead > tr > td,
.table > thead > tr > th {
  padding: 10px 15px;
}

.table > tbody > tr > td,
.table > tbody > tr > th,
.table > tfoot > tr > td,
.table > tfoot > tr > th,
.table > thead > tr > td,
.table > thead > tr > th {
  padding: 8px;
  line-height: 1.42857143;
  vertical-align: top;
  border-top: 1px solid #ddd;
}
.table td {
  word-wrap: break-word;
  word-break: break-all;
  font-size: 14px;
}
.form-control {
  color: #616161;
  border-color: #e1e1e1;
  margin-right: 1rem;
}

.form-control {
  width: 100%;
  height: 34px;
  padding: 6px 12px;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-transition: border-color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.form-control,
output {
  display: block;
  font-size: 14px;
  line-height: 1.42857143;
  color: #919191;
}
.form-inline .form-control {
  display: inline-block;
  width: auto;
  vertical-align: middle;
}
// TODO: 绿色下划线
.li_active {
  border-bottom: 2px solid #E50112;
}
.cd-tabs > li > a {
  color: rgba(0, 0, 0, 0.56);
  display: block;
  padding-bottom: 16px;
  position: relative;
  font-weight: 500;
  font-size: 14px;
}

a {
  text-decoration: none;
}
.cd-tabs > li + li {
  margin-left: 40px;
}
.cd-tabs > li {
  cursor: pointer;
  float: left;
  list-style: none;
}
#student-table-container ul {
  height: 30px;
}
.text-center {
  text-align: center !important;
}
table {
  background-color: transparent;
}

table {
  border-collapse: collapse;
  border-spacing: 0;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

.cd-btn.cd-btn-primary {
  color: #fff;
  background: #E50112;
  border-color: #E50112;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
button,
html input[type='button'],
input[type='reset'],
input[type='submit'] {
  -webkit-appearance: button;
  cursor: pointer;
}
button,
input,
select,
textarea {
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}
button,
html input[type='button'],
input[type='reset'],
input[type='submit'] {
  -webkit-appearance: button;
  cursor: pointer;
}
.form-control {
  width: 100%;
  height: 34px;
  padding: 6px 12px;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-transition: border-color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.form-control,
output {
  display: block;
  font-size: 14px;
  line-height: 1.42857143;
  color: #919191;
}
.well {
  background-color: #fafafa;
  border: 1px solid #f5f5f5;
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  box-shadow: none;
}

.well-sm {
  padding: 9px;
  border-radius: 2px;
}
.well {
  min-height: 20px;
  padding: 19px;
  margin-bottom: 20px;
  background-color: #f5f5f5;
  border: 1px solid #e3e3e3;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
}
.cd-tabs > li > a {
  color: rgba(0, 0, 0, 0.56);
  display: block;
  padding-bottom: 16px;
  position: relative;
  font-weight: 500;
  font-size: 14px;
}

a {
  text-decoration: none;
}
.cd-tabs > li {
  float: left;
  list-style: none;
}
.cd-tabs {
  padding-left: 0;
  margin-bottom: 24px;
  line-height: 1;
}

.mbl {
  margin-bottom: 20px !important;
}
ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.cd-btn.cd-btn-info {
  color: #fff;
  background: #278bf5;
  border-color: #278bf5;
}

.cd-btn.cd-btn-info,
.cd-btn.cd-btn-primary:active {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn[disabled] {
  opacity: 0.4;
  cursor: not-allowed;
}
.cd-btn.cd-btn-sm {
  font-size: 12px;
  padding: 7px 10px;
  border-radius: 4px;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.mhs {
  margin-left: 5px !important;
  margin-right: 5px !important;
}
a {
  text-decoration: none;
}
.course-main-header__operation {
  position: absolute;
  top: 17px;
  right: 32px;
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}

.course-main-header {
  position: relative;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>
