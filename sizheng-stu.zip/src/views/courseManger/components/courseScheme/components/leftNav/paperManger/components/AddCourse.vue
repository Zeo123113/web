<!--
@description 试卷管理 添加/修改 课程和课程学期
@author CPY
-->
<template>
  <div>
    <!--选择课程和学期-->
    <el-dialog title="选择机构、课程和学期" :visible.sync="dialogFormVisible" @open="open" @close="resetForm('paper')">
      <el-form ref="paper" :model="paper" :rules="rules" label-width="100px">
        <el-form-item label="组织机构" prop="orgId">
          <treeselect
            v-model="paper.orgId"
            :options="orgOptions"
            style="width:217px;"
            placeholder="请选择所属组织机构"
            clearable
            @input="orgChange"
          />
        </el-form-item>
        <el-form-item label="课程所属" prop="courseId">
          <el-select v-model="paper.courseId" filterable clearable placeholder="请选择课程" @change="courseChange">
            <el-option
              v-for="item in courseOptions"
              :key="item.csId"
              :label="item.courseTitle"
              :value="item.csId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="课程学期" prop="termId">
          <el-select v-model="paper.termId" placeholder="请选择课程学期" clearable>
            <el-option
              v-for="item in courseTermOptions"
              :key="item.ctId"
              :label="item.courseTerm"
              :value="item.ctId"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="nextStep('paper')">下一步</el-button>
        <el-button size="mini" @click="resetForm('paper')">取消</el-button>
      </div>
    </el-dialog>
    <!--结束选择课程和学期-->
    <!--详细信息-->
    <AddDialog :dialog-base-visible.sync="dialogBaseVisible" :paper="paper" @closeAddDialog="closeAddDialog()" @reGetList="reGetList()"></AddDialog>
  </div>
</template>
<script>
import AddDialog from './AddDialog'
import orgApi from '@/api/user/org'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import courseSetApi from '@/api/course/courseManage/courseSet'
import courseTermApi from '@/api/course/courseManage/courseTerm'
export default {
  components: {
    AddDialog,
    Treeselect
  },
  props: {
    // 打开弹窗标志
    dialogFormVisible: {
      type: Boolean,
      default: false
    },
    // 试卷对象
    paper: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 详细信息弹窗
      dialogBaseVisible: false,
      // 验证规则
      rules: {
        // 课程编号
        orgId: [{ required: true, message: '请选择组织机构', trigger: 'blur' }],
        // 课程编号
        courseId: [{ required: true, message: '请选择课程', trigger: 'blur' }],
        // 课程学期号
        termId: [{ required: true, message: '请选择课程学期', trigger: 'blur' }]
      },
      orgOptions: [],
      courseTermOptions: [],
      courseOptions: []
    }
  },
  mounted() {
    // 获取当前用户的组织机构树
    orgApi.getOrgTreeByCurrentUser().then(result => {
      this.orgOptions = result.data
    })
  },
  methods: {
    open() {
      if (this.paper.paperId) {
        orgApi.getOrgTreeByCurrentUser().then(result => {
          this.orgOptions = result.data
        })
        courseSetApi.getCourseListByOrgId(this.paper.orgId).then(response => {
          this.courseOptions = response.data
        })
        courseTermApi.getTermPageByCId(this.paper.courseId, 1, 10).then(response => {
          this.courseTermOptions = response.data.list
        })
      }
    },
    // 下一步
    nextStep(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$emit('update:dialogFormVisible', false)
          this.dialogBaseVisible = true
        }
      })
    },
    /** 组织机构选择发生变化时触发 */
    orgChange(value) {
      this.paper.courseId = ''
      this.paper.termId = null
      if (value != null && value !== '' && value !== undefined) {
        courseSetApi.getCourseListByOrgId(value).then(response => {
          this.courseOptions = response.data
        })
      }
    },
    courseChange(value) {
      this.paper.termId = null
      if (value != null && value !== '' && value !== undefined) {
        courseTermApi.getTermPageByCId(value, 1, 10).then(response => {
          this.courseTermOptions = response.data.list
        })
      } else {
        return
      }
    },
    // 重置表单
    resetForm(formName) {
      this.$emit('closeAdd')
    },
    closeAddDialog() {
      this.resetForm('paper')
    },
    // 重新获取试卷列表
    reGetList() {
      this.$emit('reGetList')
    }
  }
}
</script>
<style scoped>
/* .el-dialog__wrapper >>> .el-dialog {
    width: 55%;
} */
.el-dialog__wrapper>>>.el-dialog{
  width:35%;
}
</style>
