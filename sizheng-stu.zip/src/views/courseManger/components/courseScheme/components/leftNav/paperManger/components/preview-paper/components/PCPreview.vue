<!--
@description 试卷管理预览试题列表+
5
@author CPY
-->
<template>
  <div class="preview-content-area">
    <el-row class="container">
      <!--左侧时间/题卡-->
      <el-col :span="5" class="left">
        <!--试卷名称-->
        <p>{{ previewPaper.paperTitle }}</p>
        <el-divider></el-divider>
        <!--考试剩余时间/题数-->
        <strong class="time-left">{{ minute }}:{{ second }}</strong>
        <div class="time-main">
          <svg class="icon incontest" aria-hidden="true">
            <use xlink:href="#iconicon-test" />
          </svg>
          总剩余时间
          <div class="page">总题数：{{ questionlist.length }}</div>
        </div>
        <el-divider></el-divider>
        <!--结束考试剩余时间/题数-->
        <!--题卡-->
        <div class="question-lists">
          <b>题卡</b>
          <ul>
            <li
              v-for="question in questionlist"
              :key="question.tqSeq"
              :style="{border:current != question.tqSeq?'1px solid #bbb':'1px solid #36aafd',background:question.answer? '#36aafd':'#ffffff',color:question.answer?'#ffffff':'#333'}"
              @click="current = question.tqSeq"
            >{{ question.tqSeq }}</li>
          </ul>
        </div>
        <!--尾部提示-->
        <div class="metas-footer">
          <span style="cursor:pointer">
            更多设置
            <el-divider direction="vertical"></el-divider>
          </span>
          <span>
            已做
            <el-checkbox checked></el-checkbox>
          </span>
          <span>
            未作
            <el-checkbox disabled></el-checkbox>
          </span>
        </div>
      </el-col>
      <!--结束左侧时间题卡-->
      <!--中间试题列表-->
      <el-col :span="13">
        <div class="doexam-main">
          <div
            v-for="(question,index) in questionlist"
            :key="index"
            :style="current == question.tqSeq? equalCurrent:NotCurrent"
            class="row-box"
          >
            <div v-if="question.tqSeq == current">
              <span class="span1">{{ question.tqSeq }}.</span>
              <span v-for="(type,typeIndex) in questionTypeOptions" :key="typeIndex">
                <span
                  v-show="type.dictValue == question.tqTypeId"
                  class="span1"
                >[{{ type.dictLabel }}]</span>
              </span>
              <div
                v-if="question.tqTypeId.toString()!==PROG_FILLBLANK"
                class="content"
                v-html="question.content"
              ></div>
              <!--单选题/判断题-->
              <el-radio-group
                v-if="question.tqTypeId.toString()===SINGLE || question.tqTypeId.toString()===JUDGEMENT"
                v-model="question.answer"
              >
                <el-radio
                  v-for="item in question.options"
                  :key="item.value"
                  :label="item.value"
                  style="margin-top:10px;display:block;"
                >
                  <span v-html="item.label"></span>
                </el-radio>
              </el-radio-group>
              <!--多选题-->
              <el-checkbox-group
                v-if="question.tqTypeId.toString()===MULTIPLE"
                v-model="question.answer"
              >
                <el-checkbox
                  v-for="item in question.options"
                  :key="item.value"
                  style="margin-top:10px;display:block;"
                >
                  <span v-html="item.label"></span>
                </el-checkbox>
              </el-checkbox-group>
              <!--填空题-->
              <div v-if="question.tqTypeId.toString()===FILLBLANK">
                <tinymce
                  v-if="question.tqTypeId.toString()==PROG_FILLBLANK"
                  v-model="question.code"
                  plugins="codesample"
                  toolbar="false"
                  menubar="false"
                  inline="true"
                  :height="400"
                />
                <div v-for="item in question.options" :key="item">
                  <el-row>
                    <el-col :span="1" style="margin-top:20px;">{{ item }}.</el-col>
                    <el-col :span="15">
                      <el-input style="margin-top:10px;" placeholder="请输入内容"></el-input>
                    </el-col>
                  </el-row>
                </div>
              </div>
              <!--简答题/编程题-->
              <div
                v-if="question.tqTypeId.toString() === ESSAY_QUESTION || question.tqTypeId.toString() == PROGRAMME"
              >
                <tinymce
                  ref="content"
                  v-model="question.answer"
                  :save-flag="saveFlag"
                  :height="250"
                />
              </div>
              <!--上传题-->
              <div v-if="question.tqTypeId.toString() === FILE_UPLOAD">
                <el-button size="small" type="primary">点击上传</el-button>
              </div>
              <!--材料题-->
              <div v-if="question.tqTypeId.toString() === MATERIAL">
                <div
                  v-for="(master,masterIndex) in question.materialQuestions"
                  :key="masterIndex"
                  style="margin-left:2em;margin-top:1em"
                >
                  <span class="span1">{{ question.tqSeq }}.{{ masterIndex+1 }}</span>
                  <span v-for="(type,typeIndex) in questionTypeOptions" :key="typeIndex">
                    <span
                      v-show="type.dictValue == master.tqTypeId"
                      class="span1"
                    >[{{ type.dictLabel }}]</span>
                  </span>
                  <!-- <div class="content" v-html="master.content"></div> -->
                  <SelectQuestionPreview
                    v-if="master.tqTypeId.toString() !== MATERIAL&&master.tqTypeId.toString()!==PROG_FILLBLANK"
                    ref="SelectQuestionPreview"
                    :question="master"
                    @saveQuestion="saveQuestion($event)"
                  ></SelectQuestionPreview>
                </div>
              </div>
              <!--程序填空题-->
              <ProFillBlankPreview
                v-if="question.tqTypeId.toString() === PROG_FILLBLANK"
                :question="question"
              ></ProFillBlankPreview>
              <!--接口编程题-->
              <div v-if="question.tqTypeId.toString() === INTERFACE">
                <tinymce
                  ref="content"
                  v-model="question.answer"
                  :save-flag="saveFlag"
                  :height="250"
                />
              </div>
              <!--选项结束-->
            </div>
          </div>
        </div>
        <el-row>
          <el-col :span="23" class="submit-buttons">
            <el-button
              v-show="current != 1"
              :style="{display:current == 1? 'none':'block' }"
              @click="currentPrevious()"
            >上一题</el-button>
            <el-button
              v-show="current != questionlist.length"
              :style="{padding:current == 1? '10px 130px' :'10px 65px' }"
              type="primary"
              @click="currentNext()"
            >下一题</el-button>
            <el-button
              v-show="current == questionlist.length"
              type="primary"
              @click="submitPaper()"
            >交 卷</el-button>
          </el-col>
        </el-row>
      </el-col>
      <!--结束中间试题列表-->
      <el-col :span="6">
        <div class="right">
          <ul>
            <li>姓名：张三</li>
            <li>学号：4161090701xx</li>
            <li>班级：4161090502</li>
          </ul>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
import Tinymce from '@/components/Tinymce'
import ProFillBlankPreview from './ProgFillBlankPreview'
import SelectQuestionPreview from './SelectQuestionPreview'
export default {
  components: { Tinymce, ProFillBlankPreview, SelectQuestionPreview },
  props: {
    questionlist: {
      type: Array,
      required: true
    },
    previewPaper: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 时间
      minutes: 30,
      seconds: 0,
      // 试题类型
      questionTypeOptions: [],
      // 当前试题
      current: 1,
      // 试题类型常量定义
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      ESSAY_QUESTION: EXAMBANK_CONST.ESSAY_QUESTION,
      PROGRAMME: EXAMBANK_CONST.PROGRAMME,
      FILE_UPLOAD: EXAMBANK_CONST.FILE_UPLOAD,
      MATERIAL: EXAMBANK_CONST.MATERIAL,
      PROG_FILLBLANK: EXAMBANK_CONST.PROG_FILLBLANK,
      INTERFACE: EXAMBANK_CONST.INTERFACE,
      content: [],
      options: [],
      selectValue: [],
      // 富文本标志
      saveFlag: false,
      // 样式绑定
      equalCurrent: {
        display: 'block'
      },
      NotCurrent: {
        display: 'none'
      },
      // 做过的题
      selected: {
        'background-color': '#36aafd',
        color: '#ffffff'
      },
      // 未做过的题
      notSelected: {
        background: '#ffffff'
      },
      // 程序编程题code
      code: '',
      // 材料题子题列表
      masterialQuestion: {},
      // 材料题
      masterialList: [],
      init: {
        language_url: 'tinymce/langs/zh_CN.js',
        language: 'zh_CN',
        skin_url: 'tinymce/skins/ui/oxide',
        max_height: 650,
        min_height: 400,
        plugins: 'codesample',
        toolbar: false,
        inline: true,
        menubar: false
      }
    }
  },
  computed: {
    second: function() {
      return this.num(this.seconds)
    },
    minute: function() {
      return this.num(this.minutes)
    }
  },
  watch: {
    second: {
      handler(newVal) {
        this.num(newVal)
      }
    },
    minute: {
      handler(newVal) {
        this.num(newVal)
      }
    }
  },
  mounted() {
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.questionTypeOptions = response.data
    })
    // 开始计时
    this.add()
    this.openDialog(this.questionlist)
    this.questionlist.forEach(item => {
      if (item.tqTypeId.toString() === this.MATERIAL) {
        this.openDialog(item.materialQuestions)
      }
    })
  },
  methods: {
    // 渲染试题
    openDialog(list) {
      list.forEach(question => {
        if (question.tqTypeId.toString() === this.SINGLE || question.tqTypeId.toString() === this.JUDGEMENT) {
          this.selectValue = ''
        } else if (question.tqTypeId.toString() === this.MULTIPLE) {
          this.selectValue = []
        } else {
          this.selectValue = []
          this.content = []
          this.options = []
        }
        const dom = this.collectionToArray(this.parseDom(question.content))
        for (let i = 0; i < dom.length; i++) {
          if (dom[i].nodeName === '#text' || (dom[i].nodeName === 'P' && dom[i].innerText.trim() === '')) {
            dom.splice(i, 1)
            i--
          }
        }

        if (
          question.tqTypeId.toString() === this.SINGLE ||
          question.tqTypeId.toString() === this.JUDGEMENT ||
          question.tqTypeId.toString() === this.MULTIPLE
        ) {
          let ol_pos = -1
          for (let i = 0; i < dom.length; i++) {
            if (dom[i].nodeName === 'OL') {
              ol_pos = i
            }
          }
          if (ol_pos > 0) {
            const ol = dom[ol_pos]
            dom.splice(ol_pos, 1)
            let str = ''
            for (let i = 0; i < dom.length; i++) {
              str += dom[i].innerHTML + '<br/>'
            }
            question.content = '<p>' + str + '</p>'
            str = ''
            for (let i = 0; i < ol.children.length; i++) {
              const index = String.fromCharCode(i + 65)
              const item = {}
              item.value = index
              item.label = ol.children[i].innerHTML
              this.options[i] = item
            }
            question.options = this.options
          } else {
            this.content = []
            this.options = []
          }
        } else {
          let k = 1
          for (let i = 0; i < dom.length; i++) {
            this.content[i] = dom[i].innerHTML
            let index = this.content[i].indexOf('&lt;blank&gt;', 0)
            while (index >= 0) {
              const str = ' ( ' + k + ' ) '
              k++
              this.content[i] = this.content[i].replace('&lt;blank&gt;', str)
              index = this.content[i].indexOf('&lt;blank&gt;', index + 7)
            }
            var objE = document.createElement('p')
            objE.innerHTML = this.content[i]
            this.content[i] = objE.outerHTML
          }
          let str = ''
          for (let i = 0; i < this.content.length; i++) {
            str += this.content[i]
          }
          this.content = str
          this.options = []
          for (let i = 0; i < k - 1; i++) {
            this.options[i] = i + 1
          }
          question.options = this.options
          question.content = this.content
        }
        this.options = []
        this.content = ''
      })
    },
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    },
    // 保存材料子题
    saveQuestion(master) {},
    // 交卷
    submitPaper() {
      this.$confirm('再次确定是否交卷, 交卷后将不能继续答题！', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '提交成功!'
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消提交'
          })
        })
    },
    // 上一道
    currentPrevious() {
      this.current--
    },
    // 下一道
    currentNext() {
      this.current++
    },
    num(n) {
      return n < 10 ? '0' + n : '' + n
    },
    add() {
      var _this = this
      var time = window.setInterval(() => {
        if (_this.seconds === 0 && _this.minutes !== 0) {
          _this.seconds = 59
          _this.minutes -= 1
        } else if (_this.minutes === 0 && _this.seconds === 0) {
          _this.seconds = 0
          window.clearInterval(time)
        } else {
          _this.seconds -= 1
        }
      }, 1000)
    }
  }
}
</script>
<style scoped>
.preview-content-area {
  height: 960px;
  margin-top: 46px;
  margin-left: 20px;
  margin-right: 20px;
  height: 800px;
  display: block;
}
.container {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
.left {
  background-color: #ffffff;
  text-align: center;
  padding: 10px;
  min-height: 575px;
}
.content >>> p {
  line-height: 20px;
}
.left > p {
  padding-top: 11px;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  white-space: normal;
}
.time-left {
  font-size: 34px;
  color: #36aafd;
  font-weight: 400;
}
.incontest {
  width: 1.5em;
  height: 1.5em;
}
.time-left .time-main {
  margin: 25px 0;
  font-size: 18px;
  color: #333;
}
.page {
  margin: 25px 0;
  font-size: 18px;
  color: #333;
}
.row-box span[data-v-3cafcba0] {
  color: #333;
}
.question-lists {
  padding: 0px 8px 0px 0px;
}
.question-lists li {
  font-size: 12px;
  display: block;
  padding: 4px 0;
  border: 1px solid #bbb;
  border-radius: 2px;
  float: left;
  margin-right: 8px;
  margin-bottom: 9px;
  min-width: 25px;
  color: #666;
  cursor: pointer;
}
.question-lists ul {
  padding: 0;
  overflow: hidden;
}
.questions-lists li.selected,
.questions-lists li:hover {
  background-color: #36aafd;
  color: #fff;
  border: 1px solid #36aafd;
}
.metas-footer {
  line-height: 40px;
  background-color: #f6f6f6;
  font-size: 14px;
}
.metas-footer span {
  color: #aaa;
  margin-right: 5px;
}
.doexam-main {
  background-color: #fff;
  min-height: 575px;
  padding-bottom: 100px;
  margin-left: 20px;
  padding-top: 10px;
}
.row-box {
  background-color: #fff;
  margin: 0;
  margin-bottom: 10px;
  margin: 20px;
  margin-top: 0px;
  padding: 10px;
  animation: currentSelect 2s;
}
.span1 {
  color: #36aafd !important;
}
@keyframes currentSelect {
  from {
    box-shadow: 0 2px 12px 0 #36aafd;
  }
  to {
    box-shadow: 0;
  }
}
.submit-buttons {
  position: absolute;
  background-color: #fff;
  padding: 40px 80px 50px;
  margin-bottom: 0;
  bottom: 0;
  text-align: right;
  display: table;
  margin-left: 20px;
}
.el-button--medium {
  padding: 10px 65px;
  font-size: 14px;
  border-radius: 4px;
}
.right {
  margin-left: 20px;
  min-height: 575px;
  background-color: #ffffff;
  padding: 10px;
}
.right ul li {
  line-height: 2em;
}
.el-dialog__wrapper {
  z-index: 1200 !important;
}
</style>
