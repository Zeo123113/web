<!--
@description 试卷管理预览头部
@author CPY
-->
<template>
  <el-row class="container">
    <el-col :span="24">
      <!--提示头部-->
      <div class="header">
        <span>
          <i class="el-icon-warning-outline"></i>&emsp;提示：预览过程中只看效果，不保存数据
        </span>
        <div class="preview-nav-center">
          <svg class="icon" aria-hidden="true">
            <use xlink:href="#iconcomputer_icon" />
          </svg>
          电脑预览
        </div>
      </div>
      <!--结束提示头部-->
      <!--pcd端预览-->
      <PCPreview :questionlist="questionlist" :preview-paper="previewPaper"></PCPreview>
    </el-col>
  </el-row>
</template>
<script>
import PCPreview from './components/PCPreview'
import { mapGetters } from 'vuex'
export default {
  components: {
    PCPreview
  },
  computed: {
    ...mapGetters({
      // 预览的试卷实体
      previewPaper: 'paper',
      // 试题列表
      questionlist: 'questionlist'
    })
  }
}
</script>
<style scoped>
.container {
  margin-top: 0px;
  min-height: 600px;
  background-color: #f3f4f8;
}
.header span {
  font-size: 16px;
  color: red;
  margin-left: 1%;
}
.preview-nav-center {
  float: right;
  margin-left: 15%;
  width: 50%;
}
.header {
  background-color: #ffffff;
  padding: 25px 20px 25px 20px;
}
</style>
