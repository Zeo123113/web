<!--
  @description: 试卷管理
  @author: cpy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">试卷管理</div>
    </div>
    <div class="cd-main__body">
      <!-- 搜索框 -->
      <HeaderSearch
        ref="sort"
        :paper-select="paperSelect"
        :button="button"
        :multselect="multselect"
        @handleQuery="handleQuery"
        @addPaper="addPaper"
        @deleteBatch="deleteBatch"
        @handleEmpty="handleEmpty"
      ></HeaderSearch>
      <!-- 结束表格外按钮组 -->
      <!-- 表格 -->
      <el-table
        v-loading="loading"
        :data="paperList"
        row-key="userId"
        tooltip-effect="light"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" min-width="50" />
        <el-table-column label="序号" type="index" align="center" min-width="40" />
        <el-table-column
          label="试卷名称"
          prop="paperTitle"
          align="center"
          show-overflow-tooltip
          min-width="150"
        />
        <el-table-column
          label="共享"
          prop="isShare"
          :formatter="isShareFormat"
          align="center"
          min-width="50"
        ></el-table-column>
        <el-table-column
          label="试卷描述"
          prop="description"
          align="center"
          show-overflow-tooltip
          min-width="170"
        ></el-table-column>
        <el-table-column label="操作" min-width="100" align="center" fixed="right" style="height:90px">
          <template slot-scope="scope">
            <el-tooltip content="编辑" placement="top" effect="light">
              <el-button
                type="text"
                size="mini"
                icon="el-icon-edit"
                :disabled="!button.includes('bank/paper/update')"
                @click="handleUpdate(scope.row)"
              ></el-button>
            </el-tooltip>
            <el-tooltip content="试题管理" placement="top" effect="light">
              <el-button
                type="text"
                size="mini"
                @click="questionManager(scope.row)"
              >
                <svg class="icon" aria-hidden="true">
                  <use xlink:href="#icon-shitiguanli" />
                </svg>
              </el-button>
            </el-tooltip>
            <el-tooltip :content="scope.row.delFlag?'恢复': '删除'" placement="top" effect="light">
              <el-button
                type="text"
                size="mini"
                icon="el-icon-delete"
                @click="handleDelete(scope.row)"
              ></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
      <!--结束表格-->
      <!--添加弹窗-->
      <AddDialog :dialog-base-visible.sync="dialogBaseVisible" :question-manger="questionManger" :course-term="courseTerm" :paper="paper" @reGetList="getList()"></AddDialog>
      <!--添加试题列表弹窗-->
      <!-- <AddQuestionList :add-question-type="addQuestionType" :is-preview="isPreview" :paper-id="paperId" @savePaper="savePaper()" @closeAddQuestion="closeAddQuestion()"></AddQuestionList> -->
      <!--试卷预览-->
      <!-- <PreviewDialog :preview-dialog-visible="previewDialogVisible" :paper="prePaper" @closeQuestionPreview="closeQuestionPreview()"></PreviewDialog> -->
      <!--分页-->
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageIndex"
        :limit.sync="pageNum"
        @pagination="pageQuery"
      />
    </div>
  </div>
</template>
<script>
import HeaderSearch from './components/HeaderSearch'
import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
import { mapGetters } from 'vuex'
import paperApi from '@/api/exambank/paper.js'
import AddDialog from './components/AddDialog'
export default {
  components: {
    HeaderSearch,
    pagination,
    AddDialog
  },
  props: {
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 显示列表
      paperList: [],
      // 是否显示加载遮罩层加载
      loading: false,
      // 条件查询封装对象
      paperSelect: {
        paperTitle: '',
        courseId: this.courseTerm.csId,
        termId: this.courseTerm.ctId,
        delFlag: false,
        beginTime: '',
        orgId: this.courseTerm.orgId,
        endTime: '',
        isShare: false,
        createBy: ''
      },
      // 当前页
      pageIndex: 1,
      // 页数限制
      pageNum: USER_CONST.PAGESIZE,
      // 总记录数
      total: 0,
      // 批量操作数组
      multipleSelection: [],
      // 批量按钮状态
      multselect: true,
      // 批量删除Ids数组
      paperIds: [],
      // 显示添加弹窗
      dialogFormVisible: false,
      // 添加/编辑试卷实体
      paper: {
        paperId: 0,
        paperTitle: '',
        courseId: this.courseTerm.csId,
        keepsecret: false,
        isShare: '',
        termId: this.courseTerm.ctId,
        createBy: '',
        description: ''
      },
      // 试题列表中的试卷试题
      listPaper: {},
      // 添加试题列表弹窗
      addQuestionType: false,
      // 添加试题列表时的试卷Id
      paperId: 0,
      // 试卷预览
      previewDialogVisible: false,
      // 添加/编辑
      dialogBaseVisible: false,

      // 预览时的试题列表
      previewList: [],
      // 是否预览标志位
      isPreview: false,
      // 预览的试题列表
      questionlist: [],
      questionManger: false
    }
  },
  // 从状态管理器获取按钮权限数组button
  computed: {
    ...mapGetters({
      button: 'button',
      user: 'user'
    })
  },
  /**
   *监听多选数组，
   * 控制批量删除按钮
   * val > 1 可用
   * val == 0 不可用
   */
  watch: {
    multipleSelection(val) {
      this.multselect = false
      if (val.length === 0) {
        this.multselect = true
      }
    }
  },
  // 初始化数据
  created() {
    // 获取列表信息
    this.getList()
    console.log(this.courseTerm)
  },
  methods: {
    // 初始化试卷
    initPaper() {
      this.paper = {
        paperId: 0,
        paperTitle: '',
        courseId: this.courseTerm.csId,
        keepsecret: false,
        isShare: '',
        termId: this.courseTerm.ctId,
        createBy: '',
        description: ''
      }
    },
    // 初始化获取数据
    getList() {
      this.loading = true
      this.paperSelect.createBy = this.user.loginName
      paperApi.listPaper(this.paperSelect, this.pageIndex, this.pageNum).then(response => {
        this.paperList = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    },
    // 搜索处理
    handleQuery(param) {
      this.getList(param, this.pageIndex, this.pageSize)
    },

    // 分页查询
    pageQuery(pagePara) {
      this.getList(this.queryParams, pagePara.page, pagePara.limit)
    },
    // 当选择项发生变化时，赋值多选数组
    handleSelectionChange(val) {
      this.multipleSelection = val
      this.paperIds = val.map(item => item.paperId)
    },
    questionManager(row) {
      this.paper = { ...row }
      this.dialogBaseVisible = true
      this.questionManger = true
    },
    // 处理编辑
    handleUpdate(row) {
      this.paper = { ...row }
      this.dialogBaseVisible = true
      this.questionManger = false
    },
    // 处理添加
    addPaper() {
      this.initPaper()
      this.questionManger = false
      this.dialogBaseVisible = true
    },
    /** 是否共享字典翻译 */
    isShareFormat(row) {
      if (row.isShare) {
        return '是'
      } else {
        return '否'
      }
    },
    /** 是否共享保密翻译 */
    keepsecretFormat(row) {
      if (row.keepsecret) {
        return '是'
      } else {
        return '否'
      }
    },
    /**
     *处理删除
     */
    handleDelete(row) {
      if (!row.delFlag) {
        this.$confirm(`确定要删除这条记录吗?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            paperApi.deletePaper(row.paperId).then(resp => {
              if (resp.code === 0) {
                this.$message({
                  message: '删除成功',
                  type: 'success'
                })
              } else {
                this.$message({
                  message: resp.msg,
                  type: 'error'
                })
              }
              this.getList()
            }).catch(err => {
              console.log(err)
            })
          })
      } else {
        this.$confirm(`确定要恢复这条记录吗?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            paperApi.deletePaper(row.paperId).then(resp => {
              if (resp.code === 0) {
                this.$message({
                  message: '恢复成功',
                  type: 'success'
                })
              } else {
                this.$message({
                  message: resp.msg,
                  type: 'error'
                })
              }
              this.getList()
            }).catch(err => {
              console.log(err)
            })
          })
      }
    },
    /**
     *批量删除试卷
     * */
    deleteBatch() {
      if (!this.paperSelect.delFlag) {
        this.$confirm('确定要删除所选记录吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            paperApi.deletebatch(this.paperIds.toString()).then(resp => {
              if (resp.code === 0) {
                this.$message({
                  type: 'success',
                  message: '删除成功!'
                })
                this.getList()
              }
            }).catch(err => {
              console.log(err)
            })
          })
      } else {
        this.$confirm('确定要恢复所选记录吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            paperApi.deletebatch(this.paperIds.toString()).then(resp => {
              if (resp.code === 0) {
                this.$message({
                  type: 'success',
                  message: '恢复成功!'
                })
                this.getList()
              }
            }).catch(err => {
              console.log(err)
            })
          })
      }
    },
    /** 清空回收站数据 */
    handleEmpty() {
      paperApi.delectEmpty(this.paperSelect).then(resp => {
        if (resp.code === 0) {
          this.$message({
            message: '清空成功',
            type: 'success'
          })
        } else {
          this.$message({
            message: '清空失败',
            type: 'error'
          })
        }
        this.getList()
      })
    },
    /** 关闭试卷 */
    closeAdd() {
      this.dialogFormVisible = false
    },
    // /** 打开添加试题 */
    // addQuestion(row) {
    //   this.paperId = row.paperId
    //   this.listPaper = row
    //   this.addQuestionType = true
    // },
    /** 关闭添加试题 */
    closeAddQuestion() {
      this.addQuestionType = false
    },
    /** 打开预览试卷 */
    previewPaper(row) {
      this.previewDialogVisible = true
      paperApi.getQuestionByPaperId(row.paperId).then(resp => {
        if (resp.code === 0) {
          this.questionlist = resp.data
          this.$store.commit('bank/SET_PAPER', row)
          this.$store.commit('bank/SET_QUESTIONLIST', this.questionlist)
          this.$router.push({
            name: 'paperPreview'
          })
        }
      })
    },
    /** 关闭试卷预览 */
    closeQuestionPreview() {
      this.previewDialogVisible = false
    },
    // 更新试卷信息
    savePaper() {
      this.listPaper.updateBy = this.$store.getters.user.loginName
      paperApi.editPaper(this.listPaper).then(resp => {
        if (resp.code === 0) {
          console.log('success')
        } else {
          console.log(resp)
        }
      })
    }
  }
}
</script>
<style lang="scss" scpoed>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
</style>
