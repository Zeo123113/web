<template>
  <div>
    <el-dialog
      :title="dialog.title"
      :visible.sync="dialog.isEditDialogVisiable"
      width="60%"
      @close="close"
      @open="open"
    >
      <el-form ref="popupQuestion" :model="popupQuestion" :rules="rules" label-width="100px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="排序" prop="seq">
              <el-input-number
                v-model="popupQuestion.seq"
                :min="1"
                :max="9999999999"
              ></el-input-number>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="驻点时间" prop="stagnationTime">
              <el-input
                v-model="popupQuestion.stagnationTime"
                placeholder="请输入内容"
                style="width:80%"
                disabled
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="popupQuestion.remark"
            type="textarea"
            :rows="4"
            placeholder="请输入内容"
            style="width:90%"
          />
        </el-form-item>
        <el-divider>请在下面添加本次弹题</el-divider>
        <div>
          <el-button type="text" style="width:100%;" @click="AddQuestion">十 添加弹题</el-button>
          <QuestionList
            ref="questionList"
            :question-type-options="questionTypeOptions"
            :questionlist="questionlist"
          ></QuestionList>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="submit('popupQuestion')">保 存</el-button>
        <el-button size="small" @click="dialog.isEditDialogVisiable = false">取 消</el-button>
      </div>
    </el-dialog>
    <!--题库选题-->
    <QuestionBank
      ref="questionBank"
      :course-id="Number(this.$route.params.csId)"
      :question-ids="questionIds"
      :dialog-base-visible.sync="SelectdialogBaseVisible"
      @saveQuestion="saveQuestion"
      @saveMATERIALQuestion="saveMATERIALQuestion"
    ></QuestionBank>
  </div>
</template>

<script>
import popupQuestionApi from '@/api/course/other/popupQuestion'
import QuestionList from './components/AddQuestionList'
import QuestionBank from './components/question-bank/index.vue'
import EXAMBANK_CONST from '@/constant/exambank-const'
import bankApi from '@/api/exambank/bank'
export default {
  name: 'PopupQuestionDialog',
  components: {
    QuestionBank,
    QuestionList
  },
  props: {
    dialog: {
      type: Object,
      required: true
    },
    popupQuestion: {
      type: Object,
      required: true
    },
    material: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      rules: {

      },
      courseOptions: [],
      courseTermOptions: [],
      schemeOptions: [],
      courseUnitOptions: [],
      // 试题类型弹窗
      SelectdialogBaseVisible: false,
      // 选择试题类型
      selectedRadio: '',
      // 试题类型列表
      questionTypeOptions: [],
      // 试题列表
      questionlist: [],
      // 定义试题类型常量
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      ESSAY_QUESTION: EXAMBANK_CONST.ESSAY_QUESTION,
      // 已有试题列表
      questionIds: null
    }
  },
  created() {
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      response.data.forEach(element => {
        if (element.dictValue === this.SINGLE || element.dictValue === this.MULTIPLE || element.dictValue === this.JUDGEMENT) {
          this.questionTypeOptions.push(element)
        }
      })
    })
  },
  methods: {
    open() {
      if (this.popupQuestion.vpId !== null) {
        JSON.parse(this.popupQuestion.questionIds).forEach(item => {
          bankApi.getQbById(item.id).then(response => {
            this.questionlist.push(response.data)
          })
        })
      }
    },
    close() {
      this.questionlist = []
      this.$refs['popupQuestion'].clearValidate()
    },
    /** 添加试题 */
    AddQuestion() {
      this.SelectdialogBaseVisible = true
      this.selectedRadio = '0'
    },
    // 保存试题列表
    saveQuestion(list) {
      this.questionlist = this.questionlist.concat(list)
      console.log('this.questionlist = ', this.questionlist)
      list.forEach(item => {
        this.questionIds = this.questionIds + ',' + item.tqId
      })
    },
    saveMATERIALQuestion() {},
    // 点击确定
    submit(popupQuestion) {
      this.$refs[popupQuestion].validate(valid => {
        if (valid) {
          this.popupQuestion.questionIds = []
          this.questionlist.forEach(item => {
            this.popupQuestion.questionIds.push({ id: item.tqId, content: item.content, title: item.title, tqTypeId: item.tqTypeId })
          })
          this.popupQuestion.questionIds = JSON.stringify(this.popupQuestion.questionIds)
          if (this.popupQuestion.vpId === null) {
            popupQuestionApi.add(this.popupQuestion)
              .then(result => {
                if (result.code === 0) {
                  this.$message({
                    type: 'success',
                    message: '添加成功'
                  })
                } else {
                  this.$message({
                    type: 'error',
                    message: '添加失败'
                  })
                }
                this.$emit('reset')
                this.dialog.isEditDialogVisiable = false
              })
          } else {
            popupQuestionApi.update(this.popupQuestion)
              .then(result => {
                if (result.code === 0) {
                  this.$message({
                    type: 'success',
                    message: '修改成功'
                  })
                } else {
                  this.$message({
                    type: 'error',
                    message: '修改失败'
                  })
                }
                this.$emit('reset')
                this.dialog.isEditDialogVisiable = false
              })
          }
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style>
</style>
