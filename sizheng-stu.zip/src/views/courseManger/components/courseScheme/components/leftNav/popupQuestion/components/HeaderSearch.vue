<!--
@description 课程资源文件管理--头部搜索组件
@author zhouhuan
-->
<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="授课单元" prop="unitId">
      <el-select v-model="queryParams.unitId" placeholder="请选择授课单元" clearable>
        <el-option
          v-for="courseUnit in courseUnitOptions"
          :key="courseUnit.unitId"
          :label="courseUnit.unitTitle"
          :value="courseUnit.unitId"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="标题">
      <el-input v-model="queryParams.materialTitle" placeholder="请输入资料标题" clearable></el-input>
    </el-form-item>
    <!-- <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange.time"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        :picker-options="pickerOptions"
        style="width:217px;"
      ></el-date-picker>
    </el-form-item> -->
  </el-form>
</template>
<script>
import courseUnitApi from '@/api/course/courseManage/courseUnit'
// import Treeselect from '@riophae/vue-treeselect'
// import '@riophae/vue-treeselect/dist/vue-treeselect.css'

export default {
  name: 'HeaderSearch',
  components: {  },
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    dateRange: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      courseUnitOptions: [],
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      }
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange.time = ''
      }
    }
  },
  created() {
    courseUnitApi.getRefUnitBySchemeId(this.queryParams.schemeId).then(response => {
      this.courseUnitOptions = response.data
    })
  },
  methods: {
    // /** 组织机构选择发生变化时触发 */
    // orgChange(value) {
    //   this.queryParams.csId = null
    //   this.queryParams.ctId = null
    //   this.queryParams.schemeId = null
    //   this.queryParams.unitId = null
    //   if (value != null && value !== '') {
    //     courseSetApi.getCourseListByOrgId(value).then(response => {
    //       this.courseOptions = response.data
    //     })
    //   }
    // },
    // /** 课程选择发生变化时触发 */
    // courseChange(value) {
    //   this.queryParams.ctId = null
    //   this.queryParams.schemeId = null
    //   this.queryParams.unitId = null
    //   if (value != null && value !== '') {
    //     courseTermApi.getCourseTermByCourseSetId(value).then(response => {
    //       this.courseTermOptions = response.data
    //     })
    //   }
    // },
    // /** 课程学期选择发生变化时触发 */
    // courseTermChange(value) {
    //   this.queryParams.schemeId = null
    //   this.queryParams.unitId = null
    //   if (value != null && value !== '') {
    //     courseSchemeApi.getCourseSchemeByCourseTermId(value).then(response => {
    //       this.courseSchemeOptions = response.data
    //     })
    //   }
    // },
    // /** 教学方案选择发生变化时触发 */
    // courseSchemeChange(value) {
    //   this.queryParams.unitId = null
    //   if (value != null && value !== '') {
    //     courseUnitApi.getRefUnitBySchemeId(value).then(response => {
    //       this.courseUnitOptions = response.data
    //     })
    //   }
    // }
  }
}
</script>
<style scoped>

</style>
