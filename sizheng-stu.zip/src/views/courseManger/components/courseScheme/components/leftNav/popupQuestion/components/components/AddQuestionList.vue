<!--
@description 试卷管理编辑显示试题列表
@author cpy
-->
<template>
  <div>
    <el-table
      :data="questionlist"
      border
      default-expand-all
      tooltip-effect="light"
      style="width: 100%"
      row-key="groupSeq"
    >
      <el-table-column type="index" label="序号" align="center" min-width="70"></el-table-column>
      <el-table-column
        prop="tqTypeId"
        label="试题类型"
        align="center"
        :formatter="tqTypeFormatter"
        min-width="100"
      ></el-table-column>
      <el-table-column
        prop="title"
        label="题目"
        align="center"
        show-overflow-tooltip
        min-width="180"
      ></el-table-column>
      <!-- <el-table-column prop="value" label="分值" align="center" min-width="140">
        <template slot-scope="scope">
          <el-input-number
            v-model="questionlist[scope.$index].value"
            :precision="1"
            :step="0.5"
            :max="10"
            placeholder="请输入内容"
          ></el-input-number>
        </template>
      </el-table-column> -->
      <el-table-column label="操作" align="center" min-width="50">
        <template slot-scope="scope">
          <el-button
            :disabled="scope.row.seq != null"
            type="text"
            size="small"
            @click="deleteQuestion(scope.row)"
          >移除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import EXAMBANK_CONST from '@/constant/exambank-const'
export default {
  name: 'QuestionList',
  props: {
    questionlist: {
      type: Array,
      default: null
    },
    questionTypeOptions: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      // 试题类型常量定义
      SINGLE: EXAMBANK_CONST.SINGLE,
      MULTIPLE: EXAMBANK_CONST.MULTIPLE,
      JUDGEMENT: EXAMBANK_CONST.JUDGEMENT,
      FILLBLANK: EXAMBANK_CONST.FILLBLANK,
      MATERIAL: EXAMBANK_CONST.MATERIAL,
      PROG_FILLBLANK: EXAMBANK_CONST.PROG_FILLBLANK,

      // 填空题进行转换的中间使用变量
      content: [],
      options: [],
      // 加载
      loading: false,
      // 存在的试题类型
      questionOptions: [],
      // 试题序号
      tqSeq: 1
    }
  },
  created() {
    this.openDialog()
  },
  methods: {
    getQuestionList() {
      console.log('questionlist-----value = ', this.questionlist)
      this.tqSeq = 1
      this.questionlist.forEach((item, index) => {
        item.tqSeq = this.tqSeq
        this.tqSeq++
      })
    },
    // 试题类型翻译
    tqTypeFormatter(row) {
      return this.selectDictLabel(this.questionTypeOptions, row.tqTypeId.toString())
    },
    openDialog() {
      this.$nextTick(() => {
        this.getQuestionList()
      })
    },
    // 移除选择项
    deleteQuestion(paperItem) {
      if (this.questionlist.length <= 1) {
        this.$message({
          message: '弹题的试题数必须大于1',
          type: 'error'
        })
      } else {
        this.questionlist.splice(paperItem.tqSeq - 1, 1)
      }
    },
    // 外部嵌套div
    parseDom(arg) {
      var objE = document.createElement('div')
      objE.innerHTML = arg
      return objE.childNodes
    },
    // 将内容转化为字符串数组
    collectionToArray(collection) {
      var ary = []
      for (let i = 0, len = collection.length; i < len; i++) {
        ary.push(collection[i])
      }
      return ary
    },
    // 清空试题列表
    resetQuestionList() {
      this.questionlist = []
      this.questionOptions = []
    }
  }
}
</script>
<style lang="scss" scoped>
.QuestionItem {
  border: 1px solid #e3e3e3;
  padding: 20px;
  margin-bottom: 15px;
}
.el-collapse-item__header {
  color: #606266;
}
.el-collapse {
  border: 0px;
}
.el-button--text[data-v-6bb6c0b9] {
  border-color: transparent;
  color: #999;
  padding: 0px;
  border-radius: 100%;
}
.el-collapse-item {
  .el-collapse-item__wrap {
    margin-left: 50px;
    border: 0px;
  }
}
.content {
  margin-left: 2em;
  p {
    padding: 0;
    margin: 0;
    -webkit-margin-before: 0em;
    -webkit-margin-after: 0em;
    -webkit-margin-start: 0px;
    -webkit-margin-end: 0px;
    span {
      font-size: 14px !important;
      font-family: 'Microsoft YaHei';
    }
  }
  span {
    font-family: 'Microsoft YaHei';
    font-size: 14px !important;
  }
}
</style>
<style scoped>
.el-collapse-item__header {
  border: 0px !important;
}
</style>
