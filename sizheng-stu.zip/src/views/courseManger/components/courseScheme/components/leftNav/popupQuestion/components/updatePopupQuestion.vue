<template>
  <!--播放器放置区域-->
  <div class="b3">
    <el-row>
      <el-col :span="15">
        <video id="my-video" class="video-js vjs-big-play-centered" controls preload="auto">
          <!-- <source id="video" :src="Material.fileUrl" type="application/x-mpegURL" /> -->
        </video>
      </el-col>
      <el-col :span="9">
        <el-table
          v-loading="loading"
          :data="popupQuestionData"
          row-key="vpId"
          tooltip-effect="light"
          style="margin-top:20px"
          @select="handleSelectionChange"
          @select-all="handleSelectionChange"
        >
          <!-- <el-table-column type="selection" align="center" min-width="50" /> -->
          <el-table-column label="排序" prop="seq" align="center" min-width="120" />
          <el-table-column label="驻点时间" prop="stagnationTime" align="center" min-width="120" />
          <!-- <el-table-column
            label="问题内容"
            prop="questionIds"
            align="center"
            min-width="120"
            show-overflow-tooltip
          /> -->
          <el-table-column label="操作" fixed="right" align="center" min-width="150">
            <template slot-scope="scope">
              <el-button
                type="success"
                size="mini"
                @click="handleUpdate(scope.row)"
              >试题管理</el-button>
              <el-button
                type="danger"
                size="mini"
                @click="handleDelete(scope.row)"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <div v-if="total!==0" class="page_box mt30 pt10 mb10 tac">
          <el-pagination
            :current-page="pageNum"
            :page-size="pageSize"
            layout="prev, pager, next"
            :total="total"
            prev-text="上一页"
            next-text="下一页"
            @current-change="handleCurrentChange"
          ></el-pagination>
        </div>
      </el-col>
      <el-button
        type="primary"
        size="mini"
        @click="add()"
      >增加</el-button>
    </el-row>
    <div id="timescale" style="height:200px"> </div>
    <!-- 新增框 更新框-->
    <edit-dialog
      :popup-question="popupQuestion"
      :dialog="dialog"
      :material="Material"
      @reset="search"
    ></edit-dialog>
  </div>
  <!--播放器放置区域-->
</template>
<script>
import popupQuestionApi from '@/api/course/other/popupQuestion'
import courseMaterialApi from '@/api/course/courseManage/courseMaterial'
import videojs from 'video.js'
import 'videojs-contrib-hls'
import EditDialog from './EditDialog'
export default {
  name: 'Video',
  components: {
    EditDialog
  },
  props: {

  },
  data() {
    return {
      // M3U8URL: '/api/group2/M00/00/00/J2KSql7pykiAPT6yAAAGCKIylpE15.m3u8',
      myPlayer: null,
      Material: {},
      // 时间轴对象
      timeLine: null,
      mediaLength: 0,
      // 查询弹题列表条件
      queryParams: {},
      pageNum: 1, // 初始页
      pageSize: 5, // 每页的数据
      total: 0,
      loading: false,
      // 弹题题目列表
      popupQuestionData: [],
      popupQuestion: {},
      dialog: {
        // 弹出框标题
        title: '',
        // 是否显示弹出框
        isEditDialogVisiable: false
      },
      ids: []
    }
  },
  destroyed() {
    this.myPlayer.dispose()
  },
  created() {
  },
  mounted() {
    courseMaterialApi.getById(this.$route.params.MaterialId).then((result) => {
      this.Material  = result.data
      this.queryParams = {
        orgId: this.Material.orgId,
        csId: this.Material.csId,
        ctId: this.Material.ctId,
        schemeId: this.Material.schemeId,
        unitId: this.Material.unitId,
        mediaId: this.Material.fileId
      }
      this.getList(this.queryParams, this.pageNum, this.pageSize)
      this.initVideo()
      this.delayinitTimescale()
      this.myPlayer.src({ src: '/api/' + this.Material.fileUrl, type: 'application/x-mpegURL' })
      // this.myPlayer.play()
    })
  },
  methods: {
    /**
     *初始化弹题对象
     */
    initPopupQuestion() {
      this.popupQuestion = {
        vpId: null,
        orgId: this.Material.orgId,
        csId: this.Material.csId,
        ctId: this.Material.ctId,
        schemeId: this.Material.schemeId,
        unitId: this.Material.unitId,
        mediaId: this.Material.fileId,
        seq: 0,
        stagnationTime: this.formatSeconds(this.myPlayer.currentTime()),
        questionIds: '',
        remark: ''
      }
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.search()
    },
    add() {
      this.initPopupQuestion()
      console.log(this.popupQuestion)
      this.myPlayer.pause()
      this.dialog.title = '增加视频弹题'
      this.dialog.isEditDialogVisiable = true
    },
    handleUpdate(row) {
      this.popupQuestion = { ...row }
      this.dialog.title = '修改视频弹题'
      this.dialog.isEditDialogVisiable = true
    },
    handleDelete(row) {
      this.$confirm('您确定要删除所选的视频弹题?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        popupQuestionApi.delete(row.vpId.toString()).then(response => {
          if (response.code === 0) {
            this.getList(this.queryParams, this.pageNum, this.pageSize)
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }
        })
      })
    },
    /** 查询弹题列表 */
    getList(param, pageNum, pageSize) {
      this.loading = true
      popupQuestionApi.getList(param, pageNum, pageSize).then(response => {
        this.popupQuestionData = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    },
    search() {
      this.getList(this.queryParams, this.pageNum, this.pageSize)
    },
    initVideo() {
      const options = {
        // 确定播放器是否具有用户可以与之交互的控件。没有控件，启动视频播放的唯一方法是使用autoplay属性或通过Player API。
        controls: true,
        // 自动播放属性,muted:静音播放
        autoplay: false,
        // 视频一结束是否就重新开始播放
        loop: false,
        // 建议浏览器是否应在<video>加载元素后立即开始下载视频数据。
        preload: 'auto',
        // 播放器宽度:获取浏览器窗口文档显示区域的宽度，不包括滚动条
        width: document.documentElement.clientWidth * 0.6,
        // 播放器高度:获取浏览器窗口文档显示区域的高度，不包括滚动条
        height: document.documentElement.clientHeight * 0.74,
        // 播放速度
        playbackRates: [0.7, 1.0, 1.5, 2.0],
        language: 'zh-CN',
        // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
        // aspectRatio: '16:9',
        // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
        fluid: false,
        // 允许覆盖Video.js无法播放媒体源时显示的默认信息。
        notSupportedMessage: '此视频暂无法播放，请稍后再试',
        bigPlayButton: false,
        textTrackDisplay: false,
        posterImage: true,
        errorDisplay: false,
        controlBar: {
          timeDivider: true,
          durationDisplay: true,
          remainingTimeDisplay: true,
          fullscreenToggle: true  // 全屏按钮
        },
        hls: {
          withCredentials: true
        }
      }
      this.myPlayer = videojs('my-video', options,
        function() {
          // this.play()
          this.myPlayer.on('play', () => {
            this.timeLine.play()
          })
          this.myPlayer.on('pause', () => {
            this.timeLine.pause()
          })
        }
      )
    },
    /** 处理多选按钮 */
    handleSelectionChange(selection, row) {
      this.ids = selection.map(item => item.vpId)
    },
    // 进度条跟踪
    barProgress() {
      var time = this.myPlayer.currentTime()
      this.timeLine.seekTo(1, time * 1000)
    },
    // 延迟加载时间轴
    delayinitTimescale() {
      this.myPlayer.setTimeout(() => {
        this.mediaLength = (this.myPlayer.duration() * 1000)
        this.initTimescale()
      }, 200)
    },
    formatSeconds(value) {
      var theTime = parseInt(value)
      var theTime1 = 0
      var theTime2 = 0

      if (theTime >= 60) {
        theTime1 = parseInt(theTime / 60)
        theTime = parseInt(theTime % 60)
        if (theTime1 >= 60) {
          theTime2 = parseInt(theTime1 / 60)
          theTime1 = parseInt(theTime1 % 60)
        }
      }
      if (theTime < 10) {
        theTime = '0' + parseInt(theTime)
      }
      var result = '' + theTime + ''
      if (theTime1 >= 0) {
        if (theTime1 < 10) {
          theTime1 = '0' + parseInt(theTime1)
        }
        result = '' + theTime1 + ':' + result
      }
      if (theTime2 >= 0) {
        if (theTime2 < 10) {
          theTime2 = '0' + parseInt(theTime2)
        }
        result = '' + theTime2 + ':' + result
      }
      return result
    },
    // 初始化时间轴
    initTimescale() {
      var sectionArr = [{
        id: 1, // 视频id,唯一标识
        duration: this.mediaLength, // 当前视频的时长
        status: true // 表示该视频是否存在
      }]
      this.timeLine = timescale.render({
        ele: 'timescale', // 插件要渲染的元素的id
        sectionArr: sectionArr, // 视频片段信息
        // clipsArr: clipsArr, //视频剪辑片段信息
        // showSectionStatus: true, //是否显示视频的状态
        indexEnable: false // 是否开启索引功能
        // clipEnable: true, //是否开启剪辑功能
        // backgroundColor: '#a0a0a0', //插件背景颜色（可选）
        // fontColor: '#333', //插件字体颜色（可选）
        // iconColor: '#333', //插件图标颜色和刻度颜色（可选）
        // cursorColor: '#FF6600' //插件游标的颜色（可选）
      })

      this.myPlayer.on('timeupdate', () => {
        this.barProgress()
      })
      this.timeLine.on('play', () => {
        this.myPlayer.play()
      })
      this.timeLine.on('pause', () => {
        this.myPlayer.pause()
      })
      this.timeLine.on('seekTo', (time) => {
        // console.log(time); //游标移动之后的时间
        this.timeLine.pause()
        this.myPlayer.pause()
        this.myPlayer.currentTime((time.time) / 1000)
        // var time  = ((time.time) / 1000)
        // this.isstart ?  this.starttime = this.$FormatTime.formatTime(time, time) : this.endtime =  this.$FormatTime.formatTime(time, time)
        /*
         time: {
           id: 1, //视频的唯一标志
           time: 1000, //相对于当前视频的时间点
           absTime: 2000 //相对于所有视频的时间点
          }
        */
      })
      // this.timeLine.on('createIndex', (time) => {
      //   console.log(time.time)
      //   // var playertime =  this.$FormatTime.formatTime((time.time / 1000), (time.time / 1000))
      //   // console.log(playertime)
      //   // console.log(this.videotimeArry)
      //   // console.log('将此处设为分段时间点') // 所创建的索引信息
      // })
    }
    // 将秒转化为时间

  }
}
</script>
<style lang="scss" scoped>
.video-js .vjs-icon-placeholder {
  width: 100%;
  height: 100%;
  display: block;
}
#my-video {
  width: 944px;
  height: 461px;
}
</style>
