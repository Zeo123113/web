<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">弹题管理</div>
    </div>
    <div class="cd-main__body">
      <!--搜索框-->
      <header-search :query-params="queryParams" :date-range="dateRange"></header-search>
      <!-- 结束搜索框 -->
      <!--表格外按钮组-->
      <div class="btn-group">
        <el-button type="primary" icon="el-icon-search" @click="handleQuery">搜索</el-button>
      </div>
      <!--结束表格外按钮组-->
      <!-- 表格展示 -->
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        style="width: 100%"
      >
        <el-table-column label="编号" prop="materialId" align="center" min-width="50"></el-table-column>
        <el-table-column
          label="资料标题"
          prop="materialTitle"
          align="center"
          min-width="150"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          label="文件存储URL"
          prop="fileUrl"
          align="center"
          min-width="200"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          label="文件名称"
          prop="fileName"
          align="center"
          min-width="200"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          label="文件MIME"
          prop="fileMime"
          align="center"
          min-width="150"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column label="文件大小" prop="fileSize" align="center" min-width="120" sortable></el-table-column>
        <el-table-column
          label="是否公开"
          prop="isPublic"
          align="center"
          min-width="80"
          :formatter="isPublicTypeFormat"
        ></el-table-column>
        <el-table-column
          label="是否可下载"
          prop="isCanDownload"
          align="center"
          min-width="100"
          :formatter="isCanDownloadTypeFormat"
        ></el-table-column>
        <el-table-column label="创建者" prop="createBy" align="center" min-width="100" />
        <el-table-column label="创建时间" prop="createTime" align="center" sortable min-width="160" />
        <el-table-column
          label="备注"
          align="center"
          prop="remark"
          min-width="200"
          :show-overflow-tooltip="true"
        />
        <el-table-column label="操作" fixed="right" align="center" min-width="100">
          <template slot-scope="scope">
            <el-button
              type="success"
              size="mini"
              @click="handlePopupQuestion(scope.row)"
            >编辑弹题</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 表格结束 -->
      <!-- 分页控件-->
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      ></pagination>
    </div>
  </div>
</template>

<script>
import courseMaterialApi from '@/api/course/courseManage/courseMaterial'
import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
import HeaderSearch from './components/HeaderSearch'
export default {
  name: 'PopupQuestion',
  components: { HeaderSearch, pagination },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 分页记录总条数默认是1
      total: 1,
      // 默认从第一页开始
      pageNum: 1,
      // 默认每页显示的记录条数
      pageSize: USER_CONST.PAGESIZE,
      // 查询条件
      queryParams: {
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: undefined,
        materialTitle: undefined,
        beginTime: undefined,
        endTime: undefined,
        fileMime: 'mp4'
      },
      // 查询时间范围
      dateRange: {
        time: ''
      },
      // 数据表格展示数据
      tableData: []
    }
  },
  created() {
    this.fetchData(this.queryParams, this.pageNum, this.pageSize)
  },
  methods: {
    // 获得tableData,带有分页
    fetchData(queryParams, pageNum, pageSize) {
      courseMaterialApi.listCourseMaterial(queryParams, pageNum, pageSize).then(response => {
        this.tableData = response.data.list
        this.total = response.data.total
      })
    },
    // 根据查询条件查询按钮
    handleQuery() {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    // 是否公开数据字典翻译
    isPublicTypeFormat(row) {
      return row.isPublic === true ? '是' : '否'
    },
    // 是否可下载数据字典翻译
    isCanDownloadTypeFormat(row) {
      return row.isCanDownload === true ? '是' : '否'
    },
    // 处理分页组件上面的操作
    pageQuery() {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    handlePopupQuestion(row) {
      this.$router.push({  // 核心语句
        path: `/popupQuestion/${row.materialId}/${this.courseScheme.csId}`   // 跳转的路径
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
</style>
