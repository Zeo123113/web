<template lang="html">
  <div class="wrap">
    <router-view></router-view>
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
.wrap {
  height: 100%;
}
</style>
