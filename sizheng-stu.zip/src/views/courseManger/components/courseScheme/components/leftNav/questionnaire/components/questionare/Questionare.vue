<template>
  <div>
    <!-- 问卷列表开始 -->
    <div class="wrap">
      <table v-if="qnData.length !== 0" class="table">
        <thead>
          <th class="pb20"></th>
          <th class="pb20">问卷名</th>
          <th class="pb20">结束时间</th>
          <th class="pb20">状态</th>
          <th class="pb20">操作</th>
        </thead>
        <tbody>
          <!-- 问卷列表 -->
          <tr v-for="qn in qnData" :key="qn.qnId">
            <td>
              <span class="iconfont" @click="toggleSelected(qn.qnId)">
                <img :src="inArray(qnSelected, qn.qnId) ? selectedHTML : unSelectedHTML" alt="" width="25px">
              </span>
            </td>
            <td>{{ qn.title }}</td>
            <td><time class="time" :class="filterClass(qn)">{{ qn.expires }}</time></td>
            <td><span class="status" :class="filterClass(qn)">{{ judgeStatus(qn) }}</span></td>
            <td>
              <div class="tools">
                <span @click="deleteBtnClickHandler(qn)">
                  <img src="@/assets/images/delete.png" alt="" width="20px" title="删除">
                </span>
                <span style="margin-left:20px;" @click="editQn(qn)">
                  <img src="@/assets/images/edit.png" alt="" width="20px" title="编辑">
                </span>
              </div>
            </td>
          </tr>
        <!-- 问卷列表 end -->
        </tbody>
      </table>
      <div v-if="qnData.length !== 0" class="btn-group">
        <button class="btn" style="border-right: 1px solid #FEF0F0;" @click="selectAll">{{ isSelectAll ? '全选' : '全不选' }}</button>
        <button class="btn" style="border-left: 1px solid #FEF0F0;" @click="deleteSelectedBtnHandler">删除</button>
      </div>
      <div v-else class="tips">
        <div class="content">
          <p><span class="iconfont">&#xe608;</span></p>
          <p>你还没添加任何问卷</p>
        </div>
      </div>
      <!-- 删除一份问卷 -->
      <modal
        :show.sync="showDeleteModal"
        cancel-text="取消"
        ok-text="确定"
        :callback="deleteQnModalHandler"
        title="提示"
      >
        <div slot="modal-body">
          <p>你确定要删除 <span :style="{ color: '#999' }">{{ qnTitleIfDelete }}</span> 这份问卷吗？</p>
        </div>
      </modal>
      <!-- 删除一份问卷 end -->
      <!-- 删除多份问卷 -->
      <modal
        :show.sync="showDeleteSelectedModal"
        cancel-text="取消"
        ok-text="确定"
        :callback="deleteSelectedHandler"
        title="提示"
      >
        <div slot="modal-body">
          <p>你确定要删除这 <span :style="{ color: '#999' }">{{ qnSelected.length }}</span> 份问卷吗？</p>
        </div>
      </modal>
    <!-- 删除多份问卷 end -->
    </div>
  <!-- 问卷列表结束 -->
  </div>
</template>

<script>
import Modal from '../common/Modal'
export default {
  components: {
    Modal
  },
  data() {
    return {
      qnData: [
        { qnId: 1, title: '第一份问卷', expires: '1.13' }
      ],
      unSelectedHTML: require('@/assets/images/select.png'),
      selectedHTML: require('@/assets/images/selected.png'),
      qnSelected: [],
      showDeleteModal: false,
      qnTitleIfDelete: '',
      qnIdIfDelete: -1,
      showDeleteSelectedModal: false
    }
  },
  computed: {
    isSelectAll() {
      return this.qnSelected.length !== this.qnData.length
    }
  },
  created() {
    this.getQnData()
  },
  methods: {
    getQnData() {
      window.fetch('/getUserQnData', {
        method: 'GET',
        credentials: 'same-origin'
      })
        .then(response => {
          return response.json()
        })
        .then(result => {
          if (result.code === 0) {
            this.qnData = result.data
          }
          if (result.code === -2) {
            this.$route.router.go({ path: '/login' })
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    inArray(arr, val) {
      return arr.some(item => item === val)
    },
    // 选中某个问卷
    addSelected(qnId) {
      this.qnSelected.push(qnId)
    },
    // 取消选中某个问卷
    deleteSelected(qnId) {
      this.qnSelected.some((item, itemIndex) => {
        if (item === qnId) {
          this.qnSelected.splice(itemIndex, 1)
          return true
        }
      })
    },
    toggleSelected(qnId) {
      if (this.inArray(this.qnSelected, qnId)) {
        this.deleteSelected(qnId)
      } else {
        this.addSelected(qnId)
      }
    },
    // 点击删除某个问卷的按钮
    deleteBtnClickHandler(qn) {
      this.showDeleteModal = true
      this.qnTitleIfDelete = qn.title
      this.qnIdIfDelete = qn.qnId
    },
    // 确定删除某个问卷
    deleteQnModalHandler() {
      this.showDeleteModal = false
      this.deleteQn(this.qnIdIfDelete)
    },
    // 点击删除多个问卷按钮
    deleteSelectedBtnHandler() {
      if (this.qnSelected.length !== 0) {
        this.showDeleteSelectedModal = true
      }
    },
    // 确定删除多个问卷
    deleteSelectedHandler() {
      this.showDeleteSelectedModal = false
      this.deleteAll()
    },
    deleteQn(qnId) {
      window.fetch('/deleteUserQn', {
        method: 'post',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `qnId=${qnId}`,
        credentials: 'same-origin'
      })
        .then(res => {
          return res.json()
        })
        .then(result => {
          if (result.code === 1) {
            this.getQnData()
            this.qnSelected = []
          }
        })
    },
    selectAll() {
      if (this.qnSelected.length === this.qnData.length) {
        this.qnSelected = []
      } else {
        this.qnSelected = []
        const len = this.qnData.length
        let i = 0
        while (i < len) {
          this.qnSelected.push(this.qnData[i].qnId)
          i++
        }
      }
    },
    deleteAll() {
      window.fetch('/deleteUserQn', {
        method: 'post',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `qnList=${JSON.stringify(this.qnSelected)}`,
        credentials: 'same-origin'
      })
        .then(res => {
          return res.json()
        })
        .then(result => {
          if (result.code === 0) {
            this.getQnData()
            // 隐藏 Modal
            this.qnSelected = []
          }
        })
    },
    editQn(qn) {
      window.sessionStorage.setItem('edit-mode', 'modify')
      window.sessionStorage.setItem('current-qn-id', qn.qnId)
      this.$route.router.go({ path: '/platform/new/edit' })
    },
    judgeStatus(qn) {
      const qnExpires = new Date(qn.expires).getTime()
      if (qnExpires < new Date().getTime()) {
        return '已过期'
      } else if (qn.publish) {
        return '已发布'
      }
      return '未发布'
    },
    filterClass(qn) {
      return {
        'overdue': this.judgeStatus(qn) === '已过期',
        'published': this.judgeStatus(qn) === '已发布',
        'unpublished': this.judgeStatus(qn) === '未发布'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.table{
  margin-top: 2rem;
  font-size: 16px;
  th,td{
    text-align: center;
  }
}
.iconfont{
  margin-left: 10px;
}
td{
  padding-left:100px ;
}
.btn-group{
  // border: 1px solid #ED5460;
  // border-radius: 3px;
  margin:0 20px;
  .btn{
    padding: 5px 10px;
    background-color:#ED5460 ;
    outline: none;    //消除默认点击蓝色边框效果
    color: #fff;
  }

}
</style>
