<!--
@description 调查阅卷管理
@author cgy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">我的问卷</div>
    </div>
    <QuestionnaireContent />
    <div class="cd-main__body">
      <!-- <el-form ref="form" :rules="rules" class="form-horizontal"></el-form> -->
      <div>
        <div class="title">
          <input value="问卷标题" class="inputtitle" type="text">
        </div>
        <div class="subtitle">
          <textarea name="" cols="30" rows="2" maxlength="100" class="inputsubtitle">为了给您提供更好的服务，希望您能抽出几分钟时间，将您的感受和建议告诉我们，我们非常重视每位用户的宝贵意见，期待您的参与！现在我们就马上开始吧！</textarea>
        </div>

        <div style="text-align: left;margin-bottom: 10px;">
          <!-- <div class="single" ></div> -->
          <center>
            <el-button-group style="margin-top:10px;">
              <el-button type="danger" plain @click="addSingleChoice()">新增单选题</el-button>
              <el-button type="danger" plain @click="addMultipleChoice()">新增多选题</el-button>
              <el-button type="danger" plain @click="addCompletion()">新增填空题</el-button>
              <el-button type="danger" plain @click="addEssayQuestion()">新增问答题</el-button>
            </el-button-group>
          </center>
          <div>
            <div v-if="isShow===1" class="modal">111
              <!-- <form class="form">
                <label class="form-item"><br>
                  <span class="lable-text">姓名：</span>
                  <input v-model="modalData.name" type="text" class="form-input">
                </label>
                <label class="form-item"><br>
                  <span class="lable-text">外号：</span>
                  <input v-model="modalData.nickName" type="text" class="form-input">
                </label>
                <div class="form-item text-center">
                  <input type="button" class="btn btn-blue" value="提交" @click="submitSingleChoice">
                  <input type="button" class="btn btn-gray" value="取消" @click="cancel">
                </div>
              </form> -->
            </div>
            <div v-else-if="isShow===2">

            </div>
            <div v-else-if="isShow===3">

            </div>
            <div v-else-if="isShow===4">

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import QuestionnaireContent from './components/questionare/Questionare'
export default {
  name: 'Questionnaire',
  components: {
    QuestionnaireContent
  },
  // props: {
  //   courseScheme: {
  //     type: Object,
  //     required: true
  //   }
  // },
  data() {
    return {
      modalData: {},
      // 表单属性宽度
      formLabelWidth: '100px',
      rules: {
      },
      isShow: 0
    }
  },
  created() {
  },
  methods: {
    addSingleChoice() {
      this.isShow = 1
    },
    addMultipleChoice() {
      this.isShow = 2
    },
    addCompletion() {
      this.isShow = 3
    },
    addEssayQuestion() {
      this.isShow = 4
    },
    submitSingleChoice() {
      const { name, nickName } = this.modalData
      if (!name) {
        alert('请输入姓名')
        return
      } else if (!nickName) {
        alert('请输入外号')
        return
      }
      if (this.userIndex === -1) {
        this.modalData = {
          ...this.modalData,
          id: Date.now
        }
        this.userList.unshift(this.modalData)
      } else { this.userList.splice(this.userIndex, 1, this.modalData) }
      this.cancel()
    },
    cancel() {
      this.isShow = 0
      this.modalData = {}
      this.userIndex = -1
    }

  }
}
</script>
<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}

.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}

.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.inputtitle{
  background:none;
  outline:none;
  border:0px;
  width: 100%;
  height: 40px;
  font-size: 25px;
  text-align: center;
}
.inputsubtitle{
  background:none;
  outline:none;
  resize:none;
  border:0px;
  width: 100%;
  height: 40px;
  font-size: 14px;
  text-align: center;
}
.inputtitle[type="text"]:focus,
.inputtitle[type="password"]:focus {
  border: 1px solid #ddd;
  background: #fff;
  outline: none;
  font-size: 25px;
  text-align: center;
}
.inputsubtitle[type="text"]:focus,
.inputsubtitle[type="password"]:focus {
  border: 1px solid #ddd;
  background: #fff;
  outline: none;
  resize:none;
  font-size: 14px;
  text-align: center;
}
.title{
  border: 1px solid #eee;
  background-color: rgb(250, 250, 250);
  padding: 10px 30px;
}
.subtitle{
  border: 1px solid #eee;
  background-color: rgb(250, 250, 250);
  padding: 10px 30px;
}
.title:hover,.title:focus{
  border: 1px solid #eee;
  padding: 10px 30px;
  background-color: rgb(250, 250, 250);
}
.subtitle:hover,.subtitle:focus{
  border: 1px solid #eee;
  padding: 10px 30px;
  background-color: rgb(250, 250, 250);
}
.single{
  margin-top: 10px;
  border-radius: 5px;
  background: rgb(229,1,18);
  width: 100px;
  height: 30px;
  line-height: 30px;
  font-size: 16px;
  /* font-weight: bold; */
  text-align: center;
  color: #fff;
}
.modal{
    /*相对于浏览器窗口进行定位 */
    position: fixed;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
}

</style>
