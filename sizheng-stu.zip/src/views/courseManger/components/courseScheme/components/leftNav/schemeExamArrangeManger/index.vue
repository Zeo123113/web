<!--
@description 考试安排管理
@author zhaoshibin
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">考试管理</div>
    </div>
    <div class="cd-main__body">
      <!-- 下面是引入查询子组件 -->
      <header-search
        :query-params="queryParams"
        :button="button"
        @handleQuery="handleQuery"
        @handleAdd="handleAdd"
      ></header-search>
      <!-- 下面是数据展示 -->
      <section v-if="tableData !== null || tableData.size !== 0" v-loading="loading" class="plea_box" style="text-align:left">
        <ol class="db">
          <li v-for="(examArrange,index) of tableData" :key="index" class="zo">
            <div class="mt20 my_exam_area">
              <div class="fr w137 tac" style="margin-top:48px">
                <!-- <p class="fz20 fwb cor_ff8">{{ courseExamStatusFormat(test) }}</p> -->
                <!--右侧按钮（未开始）-->
                <el-tooltip content="编辑考试安排" placement="bottom" effect="light">
                  <svg class="icon" aria-hidden="true" @click="editExamArange(examArrange)">
                    <use xlink:href="#icon-bianji" />
                  </svg>
                </el-tooltip>

                <el-tooltip content="删除考试安排" placement="bottom" effect="light">
                  <svg class="icon" aria-hidden="true" @click="deleteExamArange(examArrange)">
                    <use xlink:href="#icon-shanchu" />
                  </svg>
                </el-tooltip>
              </div>

              <div class="ov">
                <p class>
                  <i class="ico_examination_subjects"></i>
                  <span class="ml20 fz22">{{ examArrange.examTitle }}</span>
                </p>
                <div class="mt15 cf">
                  <div class="fl w350">
                    <p class="fz15 lh30">
                      <span class="cor_bdb">开始时间</span>
                      <span class="ml25">{{ examArrange.startTime }}</span>
                    </p>
                    <p class="fz15 lh30">
                      <span class="cor_bdb">考试对象</span>
                      <span class="ml25">{{ examArrange.examGroupTitle }}</span>
                    </p>
                  <!-- <p class="fz15 lh30">
                    <span class="cor_bdb">对应课程</span>
                    <span class="ml25">{{ test.courseTitle }}</span>
                  </p> -->
                  </div>
                  <div class="ov">
                    <p class="fz15 lh30">
                      <span class="cor_bdb">考试时长(分钟)</span>
                      <span class="ml25">{{ examArrange.duration }}</span>
                    </p>
                    <p class="fz15 lh30">
                      <span class="cor_bdb">考试用卷</span>
                      <span class="ml25">{{ examArrange.paperTitle }}</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <!-- 按钮组 -->

            <!-- <div class="course-button">
              <el-tooltip content="编辑考试安排" placement="bottom" effect="light">
                <svg class="icon" aria-hidden="true" @click="editExamArange(examArrange)">
                  <use xlink:href="#icon-bianji" />
                </svg>
              </el-tooltip>

              <el-tooltip content="删除考试安排" placement="bottom" effect="light">
                <svg class="icon" aria-hidden="true" @click="deleteExamArange(examArrange)">
                  <use xlink:href="#icon-shanchu" />
                </svg>
              </el-tooltip> -->

            <!-- <el-dropdown>
              <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-shenglvehao" />
              </svg>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>编辑安排</el-dropdown-item>
              </el-dropdown-menu>
              <el-dropdown-menu v-if="scheme.schemeStatus !== '1'" slot="dropdown">
                <el-dropdown-item>预览计划</el-dropdown-item>
                <el-dropdown-item>
                  <a @click="publishCourse(scheme, '1')">发布计划</a>
                </el-dropdown-item>
                <el-dropdown-item>复制</el-dropdown-item>
                <el-dropdown-item>
                  <a @click="fakeDelete(scheme.schemeId)">删除</a>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown> -->
            <!-- </div> -->
          </li>
        </ol>
        <div v-if="tableData.length===0" class="nodata">
          <p>
            <svg class="icon icon-tishi" aria-hidden="true">
              <use xlink:href="#icon-tishi" />
            </svg>
          </p>
          <p>您还没有考试安排可管理，请先添加考试安排</p>
        </div>
      </section>
      <div v-if="total!==0" class="page_box mt30 pt10 mb10 tac">
        <el-pagination
          :current-page="pageNum"
          :page-size="pageSize"
          layout="prev, pager, next"
          :total="total"
          prev-text="上一页"
          next-text="下一页"
          @current-change="handleCurrentChange"
        ></el-pagination>
      </div>
      <!-- 下面是新增修改考试安排弹出框 -->
      <el-dialog :title="title" :visible.sync="open" width="55%" @open="openDialog">
        <el-form ref="form" :model="form" :rules="rules" label-width="130px">
          <el-row>
            <el-col :span="12">
              <el-form-item label="考试对象" prop="examObject">
                <treeselect
                  v-model="form.examObject"
                  :options="courseMemberGroupOptions"
                  placeholder="请选择考试对象"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="开始时间" prop="startTime">
                <el-date-picker
                  v-model="form.startTime"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  type="datetime"
                  placeholder="选择日期时间"
                  :disabled="form.roundId!==undefined && form.startTime < currentTime"
                >
                </el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="考试简述:" prop="examTitle">
            <el-input v-model="form.examTitle" placeholder="请输入考试简述"></el-input>
          </el-form-item>
          <el-row>
            <el-col :span="12">
              <el-form-item label="试卷分发策略" prop="strategy">
                <el-select
                  v-model="form.strategy"
                  placeholder="试卷分发策略"
                  clearable
                >
                  <el-option
                    v-for="item in strategyOptions"
                    :key="item.dictValue"
                    :label="item.dictLabel"
                    :value="item.dictValue"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="选择试卷" prop="paperId">
                <el-select
                  v-model="form.paperId"
                  placeholder="请选择试卷"
                  clearable
                >
                  <el-option
                    v-for="item in paperOptions"
                    :key="item.paperId"
                    :label="item.paperTitle"
                    :value="item.paperId"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>

          <el-form-item label="持续时长(分钟):" prop="duration">
            <el-input v-model="form.duration" placeholder="请输入持续时长单位为分钟数据为整数"></el-input>
          </el-form-item>
          <el-row>
            <el-col :span="8">
              <el-form-item label="关闭在线学习:" prop="isCloseStudy">
                <el-switch
                  v-model="form.isCloseStudy"
                  active-value="true"
                  inactive-value="false"
                >
                </el-switch>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="关闭在线作业:" prop="isCloseHw">
                <el-switch
                  v-model="form.isCloseHw"
                  active-value="true"
                  inactive-value="false"
                >
                </el-switch>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="关闭在线练习:" prop="isCloseExer">
                <el-switch
                  v-model="form.isCloseExer"
                  active-value="true"
                  inactive-value="false"
                >
                </el-switch>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="换机登录需要密码:" prop="isNeedPassword">
                <el-switch
                  v-model="form.isNeedPassword"
                  active-value="true"
                  inactive-value="false"
                >
                </el-switch>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="显示所有信息:" prop="isDispAllinfo">
                <el-switch
                  v-model="form.isDispAllinfo"
                  active-value="true"
                  inactive-value="false"
                >
                </el-switch>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="备注:">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入备注内容"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" size="small" @click="submitForm">保存</el-button>
          <el-button size="small" @click="cancelOpen">取消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import examArrangeApi from '@/api/exambank/examArrange'
import { mapGetters } from 'vuex'
import HeaderSearch from './components/HeaderSearch'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
// import orgApi from '@/api/user/org'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import paperApi from '@/api/exambank/paper'
import examPaperApi from '@/api/exambank/examPaper'
import EXAMBANK_CONST from '@/constant/exambank-const'
export default {
  components: { HeaderSearch,  Treeselect },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    var startTimeValidate = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请选择开始时间'))
      } else {
        var nowTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
        if (nowTime >= value) {
          callback(new Error('开始时间不能早于当前时间'))
        }
        callback()
      }
    }
    return {
      // 是否显示加载遮罩层加载
      loading: false,
      // 弹出层标题
      title: '',
      // 选中删除的列表
      ids: [],
      // 根据条件查询
      queryParams: {
        examTitle: undefined,
        beginTime: undefined,
        endTime: undefined,
        delFlag: false, // 代表数据存在
        orgId: this.courseScheme.orgId,
        termId: this.courseScheme.ctId,
        courseId: this.courseScheme.csId,
        examType: EXAMBANK_CONST.TEST
      },
      // 分页记录总条数
      total: 1,
      // 默认分页参数
      pageNum: 1,
      pageSize: 4,
      // table数据展示部分
      tableData: [],
      // 添加或修改考试安排弹出框
      open: false,
      // 试卷分发策略从数据字典获得
      strategyOptions: [],
      // 保存课程发生变化后的courseId
      changeCourseId: undefined,
      // 新闻修改考试安排表单
      form: {},
      // 学员分组列表用于考试对象选择
      courseMemberGroupOptions: [],
      // 试卷列表
      paperOptions: [],
      // 考试安排与试卷关联对象
      examPaper: {},
      // 表单校验
      rules: {
        examTitle: [
          { required: true, message: '考试简述不能为空', trigger: 'change' },
          {
            min: 2,
            message: '长度要大于2个字符',
            trigger: 'change'
          }
        ],
        strategy: [{ required: true, message: '试卷分发策略不能为空', trigger: 'change' }],
        examObject: [{ required: true, message: '考试对象不能为空', trigger: 'change' }],
        startTime: [{ validator: startTimeValidate, trigger: 'change' }],
        duration: [{ required: true, message: '持续时间不能为空', trigger: 'change' }],
        paperId: [{ required: true, message: '请选择试卷', trigger: 'change' }]
      },
      currentTime: null
    }
  },
  // 引入了状态管理菜单
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  // 钩子函数，页面加载的时候就调用查询全部数据
  created() {
    console.log(this.courseScheme)
    // 试卷分发策略从数据字典获得
    this.getDataByType('exambank_distribute_strategy').then(response => {
      this.strategyOptions = response.data
    })
    courseMemberGroupApi.getExamMemberGroupBySchemeId(this.courseScheme.schemeId).then(response => {
      this.courseMemberGroupOptions = response.data
    })
    // 通过课程编号 课程学期编号 查询对应的考试试卷
    paperApi.getPapersByCourseAndTerm(this.courseScheme.csId, this.courseScheme.ctId).then(response => {
      this.paperOptions = response.data
    })
    this.fetchData(this.queryParams, this.pageNum, this.pageSize)
  },
  methods: {
    openDialog() {
      this.currentTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
    },
    // 试卷分发策略字典翻译
    strategyFormat(row) {
      return this.selectDictLabel(this.strategyOptions, row.strategy)
    },
    // 删除按钮操作
    deleteExamArange(row) {
      // 处理删除操作
      this.$confirm('是否确认删除考试简述为 "' + row.examTitle + '" 的数据项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return examArrangeApi.delExamArrange(row.roundId)
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '考试安排删除成功'
          })
          this.fetchData(this.queryParams, this.pageNum, this.pageSize)
        })
        .catch(err => {
          console.log(err)
        })
    },
    /**
     * 获取当前时间
     */
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    },
    // 取消按钮
    cancelOpen() {
      this.open = false
    },
    // 根据条件查询
    handleQuery(param) {
      this.fetchData(param, this.pageNum, this.pageSize)
    },
    // 分页查询，处理分页组件上的操作
    pageQuery(pagePara) {
      this.fetchData(this.queryParams, pagePara.page, pagePara.limit)
    },
    // 分页查询全部的数据
    fetchData(param, pageNum, pageSize) {
      this.loading = true
      examArrangeApi.getExamArrangeList(param, pageNum, pageSize).then(response => {
        this.tableData = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    },
    // 表单重置调用elementui
    resetForm(refName) {
      if (this.$refs[refName] !== undefined) {
        this.$refs[refName].resetFields()
      }
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    // 表单重置提供函数调用
    reset() {
      this.form = {
        roundId: undefined,
        examTitle: undefined,
        strategy: undefined,
        examObject: undefined,
        startTime: undefined,
        duration: undefined,
        examType: EXAMBANK_CONST.TEST,
        isCloseStudy: undefined,
        isCloseHw: undefined,
        isCloseExer: undefined,
        isNeedPassword: undefined,
        isDispAllinfo: undefined,
        courseId: this.courseScheme.csId,
        termId: this.courseScheme.ctId,
        orgId: this.courseScheme.orgId,
        remark: undefined,
        paperId: undefined
      }
      this.resetForm('form')
    },
    // 新增按钮
    handleAdd() {
      this.reset()
      this.open = true
      this.title = '添加考试安排'
    },
    // 提交按钮
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.form.roundId !== undefined) {
            examArrangeApi.updateExamArrange(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  type: 'success',
                  message: '修改成功'
                })
                this.open = false
                this.fetchData(this.queryParams, this.pageNum, this.pageSize)
              } else {
                this.$message({
                  message: response.msg,
                  type: 'error'
                })
              }
            })
          } else {
            examArrangeApi.addExamArrange(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  type: 'success',
                  message: '新增成功'
                })
                this.open = false
                this.fetchData(this.queryParams, this.pageNum, this.pageSize)
              } else {
                this.$message({
                  message: response.msg,
                  type: 'error'
                })
              }
            })
          }
        }
      })
    },
    // 修改考试安排
    editExamArange(row) {
      // 相当于打开页面时渲染数据
      console.log(row)
      courseMemberGroupApi.getExamMemberGroupByCtId(row.termId).then(response => {
        this.courseMemberGroupOptions = response.data
      })
      paperApi.getPapersByCourseAndTerm(row.courseId, row.termId).then(response => {
        this.paperOptions = response.data
      })

      examPaperApi.getPaperIdByRoundId(row.roundId).then(response => {
        this.examPaper = response.data
        this.form.paperId = this.examPaper.paperId
      })
      this.form = { ...row }
      console.log(this.form)
      this.title = '修改考试安排'

      this.open = true
    }
  }
}
</script>
<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.icon {
  cursor: pointer;
}
.course-price {
  color: #ed3e3e;
  font-size: 14px;
  width: 1rem;
  height: 1rem;
}
.course-info {
  width: 10rem;
  margin-left: 1rem;
  height: 26px;
}
.course-title {
  width: 50rem;
  height: 26px;
  padding-top: 0.5rem;
}
.course-cover {
  width: 10rem;
  margin-left: 1rem;
  height: 26px;
}
.course-cover img {
  float: left;
  margin-left: 0;
  width: 10rem;
  height: 6rem;
  margin-top: -1.2rem;
  border-radius: 10%;
}
.course-left {
  width: 80%;
  float: left;
}
.course-button {
  margin-left: 60rem;
  /* // width: 20rem; */
  display: inline-block;
}
/* // .el-main {
//   width: 80%;
//   // height: 500px;
//   margin: 0 auto;
// } */
.all {
  font-size: 16px;
  padding: 0 25px;
  height: 35px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  color: #fff;
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  padding: 32px;
  margin: 0 32px;
  margin-bottom: 18px;
  background: #fff;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 20px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  margin-top: -42px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
.course-publish-status--unpublished {
  background-color: #707070;
}
.course-publish-status {
  position: absolute;
  left: -6px;
  top: 28px;
  padding: 9px 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
}
.icon {
  width: 2.5em;
  height: 2.55em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-left: 20px;
}
a {
  text-decoration: none;
}
.course-manage-header-info__title {
  margin-top: 4px;
  margin-bottom: 0;
  min-height: 5px;
  font-size: 16px;
  line-height: 1;
  font-weight: 500;
  width: 250px;
}
.ellipsis,
.text-overflow {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}
.course-manage-header-info {
  float: left;
  margin-left: 71px;
}
.course-publish-status--published {
  background-color: #18ad3b;
}

.course-publish-status {
  position: absolute;
  left: -6px;
  top: 28px;
  padding: 9px 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
}
.courses-manage-item .course-manage-header {
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 2px 2px 0 rgba(0, 0, 0, 0.06);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
}

.course-manage-header {
  position: relative;
  margin-bottom: 0;
  padding: 20px 32px 20px 24px;
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 0 2px 0 rgba(0, 0, 0, 0.06),
    0 0 2px 0 rgba(0, 0, 0, 0.1);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 0 2px 0 rgba(0, 0, 0, 0.06), 0 0 2px 0 rgba(0, 0, 0, 0.1);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 0 2px 0 rgba(0, 0, 0, 0.06), 0 0 2px 0 rgba(0, 0, 0, 0.1);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  background-color: #fff;
}
.cd-mb24 {
  margin-bottom: 24px !important;
}
.courses-manage-list {
  padding-left: 6px;
  list-style: none;
}

ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.cd-select .select-options > li:first-child {
  border-radius: 4px 4px 0 0;
}

.cd-select .select-options > li.checked,
.cd-select .select-options > li.checked:hover {
  background: #fafafa;
}
.cd-select .select-options > li {
  position: relative;
  padding: 16px;
  line-height: 1;
  color: rgba(0, 0, 0, 0.88);
  background: none;
  white-space: nowrap;
  display: block;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-select .select-options {
  top: 100%;
  left: 0;
  right: 0;
  z-index: 1000;
  display: none;
  border: none;
  text-align: left;
  padding: 0;
  margin: 0;
  max-height: 220px;
  overflow-x: hidden;
  overflow-y: auto;
  -webkit-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01),
    0 8px 8px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01),
    0 8px 8px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01), 0 8px 8px 0 rgba(0, 0, 0, 0.04);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  font-size: 12px;
  background-color: #fff;
  opacity: 0;
}

.cd-select .select-options,
.cd-select .select-value:after {
  position: absolute;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-select .select-value {
  padding: 5px 0 4px;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.88);
  border-bottom: 1px solid rgba(0, 0, 0, 0.16);
  padding-bottom: -1px;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.teaching-type-select {
  width: 276px;
  height: 34px;
}

.cd-select {
  position: relative;
  height: 30px;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.hide {
  display: none !important;
}
.cd-btn.cd-btn-default {
  color: rgba(0, 0, 0, 0.88);
  background: #ececec;
  border-color: #ececec;
}

.cd-btn.cd-btn-default,
.cd-btn.cd-btn-warning:active {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.cd-ml16 {
  margin-left: 16px !important;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

.cd-btn.cd-btn-primary {
  color: #fff;
  background: #E50112;
  border-color: #E50112;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
a {
  text-decoration: none;
}
a {
  color: #E50112;
}
.pull-right {
  float: right !important;
}
.cd-mb24 {
  margin-bottom: 24px !important;
}
.courseset-manage-padding {
  padding: 32px 0;
}

.courseset-manage-body {
  margin-top: 1px !important;
  min-height: 550px;
  background-color: #fff;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-content {
  position: relative;
  border-radius: 4px;
  margin-top: 24px;
  margin-bottom: 24px;
}
.course_content {
  padding-left: 0;
  padding-right: 0;
  // padding-right: 12px;
  margin: 0 auto;
  position: relative;
  border-radius: 4px;
  margin-top: 10px;
  margin-bottom: 24px;
}
.icon{
  width:2em;
  height:2em
}
.w350{
  width:350px;
}
</style>
