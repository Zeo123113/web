<!--
@description 学员分组管理--新增与编辑窗口
@author cgy
-->
<template>
  <div class="outer-container">
    <!--begin of 新增与编辑窗口 -->
    <el-dialog
      width="65%"
      :title="title"
      :visible="isAddEditDialogVisible"
      @close="closeDialog('form')"
      @open="openDialog()"
    >
      <el-form ref="form" :model="courseMemberGroup" :rules="rules" label-width="100px">
        <el-row>
          <el-col :span="12">
            <el-form-item v-if="courseMemberGroup.parentId!==0" label="父分组">
              <el-input v-model="parentGroup.mgName" disabled clearable />
            </el-form-item>
          </el-col>
          <!-- <el-col :span="12">
            <el-form-item label="分组类型" prop="groupType">
              <el-radio-group v-model="courseMemberGroup.groupType">
                <el-radio
                  v-for="item in groupTypeOptions"
                  :key="item.dictValue"
                  :label="item.dictValue"
                >{{ item.dictLabel }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col> -->
          <!-- <el-col :span="12">
            <el-form-item label="授课方案" prop="schemeId">
              <el-select v-model="courseMemberGroup.schemeId" placeholder="请选择授课方案" :disabled="courseMemberGroup.parentId!==0">
                <el-option
                  v-for="shceme in courseSchemeOptions"
                  :key="shceme.schemeId"
                  :label="shceme.schemeTitle"
                  :value="shceme.schemeId"
                />
              </el-select>
            </el-form-item>
          </el-col> -->
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="分组名称" prop="mgName">
              <el-input v-model="courseMemberGroup.mgName" clearable />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="最大学员数" prop="maxMembers">
              <el-tooltip content="0 代表没有学员人数限制" placement="bottom" effect="light">
                <el-input-number v-model="courseMemberGroup.maxMembers" :min="0" :max="200"></el-input-number>
              </el-tooltip>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="允许加入组" prop="isAllowJoin">
              <el-switch v-model="courseMemberGroup.isAllowJoin"></el-switch>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="允许退出组" prop="isAllowExit">
              <el-switch v-model="courseMemberGroup.isAllowExit"></el-switch>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <!-- <el-col :span="12">
              <el-form-item label="是否删除" prop="delFlag">
                <el-switch v-model="courseMemberGroup.delFlag"></el-switch>
              </el-form-item>
            </el-col> -->
          <el-col :span="12">
            <el-form-item label="教务系统编号" prop="tmisGroupId">
              <el-input v-model="courseMemberGroup.tmisGroupId" clearable />
            </el-form-item>
          </el-col>
        </el-row>
        <div v-if="courseMemberGroup.mgId>0">
          <!-- <el-form-item label="分组二维码" prop="classQrcode">
            <el-input v-model="courseMemberGroup.classQrcode" clearable />
          </el-form-item> -->
          <el-form-item label="分组邀请码" prop="invitationCode">
            <el-input v-model="courseMemberGroup.invitationCode" clearable />
          </el-form-item>
        </div>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="courseMemberGroup.remark"
            placeholder="请输备注"
            type="textarea"
            :rows="4"
            clearable
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="submitForm">保 存</el-button>
        <el-button size="small" @click="cancel('form')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
export default {
  name: 'EditDialog',
  components: { },
  props: {
    title: {
      type: String,
      required: true
    },
    isAddEditDialogVisible: {
      type: Boolean,
      required: true
    },
    courseMemberGroup: {
      type: Object,
      required: true
    },
    groupTypeOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    // 验证学员分组数量
    const validateMaxMember = (rule, value, callback) => {
      courseMemberGroupApi
        .checkGroupMemberCountLegal({
          parentId: this.courseMemberGroup.parentId,
          maxMembers: this.courseMemberGroup.maxMembers,
          groupType: this.courseMemberGroup.groupType
        })
        .then(function(resp) {
          if (resp.data) {
            callback()
          } else {
            callback(new Error('最大学员数量不合法'))
          }
        })
    }
    return {
      courseOptions: [],
      courseTermOptions: [],
      rules: {
        mgName: [{ required: true, message: '请填写分组名称', trigger: 'blur' }],
        schemeId: [{ required: true, message: '请选择教学方案', trigger: 'blur' }],
        maxMembers: [{ required: true, validator: validateMaxMember, trigger: 'blur' }]
      },
      parentGroup: {}
    }
  },
  methods: {
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.$emit('submitForm', this.courseMemberGroup)
          this.$emit('update:isAddEditDialogVisible', false)
        }
      })
    },
    cancel(formName) {
      this.$emit('update:isAddEditDialogVisible', false)
    },
    openDialog() {
      if (this.courseMemberGroup.parentId !== 0) {
        courseMemberGroupApi.getGroupById(this.courseMemberGroup.parentId).then((result) => {
          this.parentGroup = result.data
          this.courseMemberGroup.schemeId = this.parentGroup.schemeId
          console.log(this.parentGroup)
        })
      }
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeDialog(formName) {
      this.$refs[formName].clearValidate()
      this.$emit('update:isAddEditDialogVisible', false)
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
