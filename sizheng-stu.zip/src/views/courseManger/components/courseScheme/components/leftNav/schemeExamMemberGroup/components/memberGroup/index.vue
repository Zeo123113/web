<!--
@description 学员分组管理
@author cgy
-->
<template>
  <div class="outer-container">
    <!--搜索框-->
    <header-search
      :query-params="queryParams"
      :button="button"
      :ids="ids"
      :course-scheme-options="courseSchemeOptions"
      @handleQuery="handleQuery"
      @handleRecycleBin="handleRecycleBin"
      @handleAdd="handleAdd"
      @handleBatchDelete="handleBatchDelete"
      @handleEmpty="handleEmpty"
    ></header-search>

    <!--表格展示-->
    <el-table
      ref="table"
      v-loading="loading"
      :data="courseMemberGroupList"
      lazy
      :load="load"
      tooltip-effect="light"
      row-key="mgId"
      @select-all="checkboxSelectAll"
      @select="checkboxSelect"
    >
      <el-table-column type="selection" align="center" min-width="50" />
      <el-table-column
        label="分组名称"
        prop="mgName"
        align="left"
        min-width="200"
        show-overflow-tooltip
      />
      <!-- <el-table-column
        label="分组类型"
        prop="groupType"
        :formatter="groupTypeFormat"
        align="center"
        min-width="80"
      /> -->
      <el-table-column label="最大学员数量" prop="maxMembers" align="center" min-width="120" :formatter="maxMembersFormat" />
      <el-table-column
        label="是否允许加入"
        prop="isAllowJoin"
        :formatter="isAllowJoinFormat"
        align="center"
        min-width="110"
      />
      <el-table-column
        label="是否允许退出"
        prop="isAllowExit"
        :formatter="isAllowExitFormat"
        align="center"
        min-width="110"
      />
      <!-- <el-table-column
        label="分组二维码"
        prop="classQrcode"
        align="center"
        min-width="100"
        show-overflow-tooltip
      /> -->
      <el-table-column
        label="分组邀请码"
        prop="invitationCode"
        align="center"
        min-width="100"
        show-overflow-tooltip
      />
      <el-table-column label="操作" align="center" min-width="300" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-plus"
            :disabled="queryParams.delFlag || !button.includes('course/courseMemberGroup/add')"
            @click="handleTableAdd(scope.row)"
          >新增</el-button>
          <el-button
            type="text"
            size="mini"
            icon="el-icon-edit"
            :disabled="queryParams.delFlag || !button.includes('course/courseMemberGroup/update')"
            @click="handleUpdate(scope.row)"
          >编辑</el-button>
          <el-button
            type="text"
            size="mini"
            icon="el-icon-delete"
            :disabled="!button.includes('course/courseMemberGroup/delete')"
            @click="handleDelete(scope.row)"
          >{{ queryParams.delFlag?'恢复': '删除' }}</el-button>
          <el-button
            type="text"
            size="mini"
            icon="el-icon-document-copy"
            :disabled="queryParams.delFlag || !button.includes('course/courseMemberGroup/add')"
            @click="handleCopy(scope.row)"
          >复制</el-button>
          <el-button
            type="text"
            size="mini"
            icon="el-icon-scissors"
            :disabled="queryParams.delFlag || !button.includes('course/courseMemberGroup/add')"
            @click="handleMove(scope.row)"
          >移动</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--结束表格展示-->
    <!-- 分页控件-->
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="pageQuery"
    />
    <!--新增或修改题库的对话框-->
    <edit-dialog
      :title="title"
      :is-add-edit-dialog-visible.sync="isAddEditDialogVisible"
      :course-member-group="courseMemberGroup"
      :group-type-options="groupTypeOptions"
      @submitForm="submitForm"
    />
    <!-- 复制、移动分组对话框 -->
    <copy-group-dialog
      :is-copy-group-dialog-visible.sync="isCopyGroupDialogVisible"
      :copy-group-params="copyGroupParams"
      :group-type-options="groupTypeOptions"
      @handleCopyGroup="handleCopyGroup"
    />
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import COURSE_CONST from '@/constant/course-const'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import CopyGroupDialog from './components/CopyGroupDialog'
// import orgApi from '@/api/user/org'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import pagination from '@/components/Pagination/index'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
export default {
  name: 'CourseMemberGroup',
  components: { HeaderSearch, pagination, EditDialog, CopyGroupDialog },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 初始HeaderSearch的查询参数
      queryParams: {
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        mgName: '',
        createBy: null,
        delFlag: false,
        groupType: COURSE_CONST.EXAM_GROUP
      },
      groupTypeOptions: [],
      // 保存用户选择的记录ID
      ids: [],
      // 保存父节点的ID
      parentIDs: [],
      // 是否显示加载遮罩层
      loading: false,
      // 分页记录总条数
      total: 1,
      // 默认分页参数
      pageNum: 1,
      pageSize: COURSE_CONST.PAGESIZE,
      // 表格数据
      courseMemberGroupList: [],
      // 保存表格异步数据
      maps: new Map(),
      selectCurrentRow: null,
      // 是否勾选表格全选复选框
      isSelectAll: false,
      // 用于向新增编辑对话框传参
      courseMemberGroup: {},
      // 新增编辑对话框标题
      title: '',
      // 新增和编辑窗口是否可见
      isAddEditDialogVisible: false,
      // 分组复制移动窗口是否可见
      isCopyGroupDialogVisible: false,
      // 用于向分组复制移动对话框传参
      copyGroupParams: {},
      // 教学方案列表
      courseSchemeOptions: []
    }
  },
  /**
   *从状态管理器获取按钮权限数组button
   */
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },

  // 初始化
  created() {
    // 分组类型字典获取
    this.getDataByType('course_member_group_type').then(response => {
      this.groupTypeOptions = response.data
    })
    // 查询数据
    this.getList(this.queryParams, this.pageNum, this.pageSize)

    // 获取教学学期列表
    courseSchemeApi.getCourseSchemeByCourseTermId(this.courseScheme.ctId).then(response => {
      this.courseSchemeOptions = response.data
    })
  },
  methods: {
    /** 最大学员数量翻译翻译 */
    maxMembersFormat(row) {
      if (row.maxMembers === 0) {
        return '不限'
      } else {
        return row.maxMembers
      }
    },
    /** 初始化学员分组对象 */
    initCourseMemberGroup() {
      this.courseMemberGroup = {
        mgId: -1,
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        parentId: 0,
        groupType: COURSE_CONST.EXAM_GROUP,
        mgName: '',
        maxMembers: 0,
        tmisGroupId: '',
        isAllowJoin: true,
        isAllowExit: false,
        classQrcode: '',
        invitationCode: '',
        delFlag: false,
        createOrgId: null,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: ''
      }
    },
    initCopyGroupParams() {
      this.copyGroupParams = {
        sourceGroupType: '0',
        sourceGroupId: null,
        sourceGroupName: '',
        targetGroupId: null,
        targetGroupName: '',
        targetGroupType: '0',
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        copyOrMove: 'copy'
      }
    },
    /** 分组类型字典翻译 */
    groupTypeFormat(row) {
      return this.selectDictLabel(this.groupTypeOptions, row.groupType)
    },
    /** 是否允许加入字典翻译 */
    isAllowJoinFormat(row) {
      if (row.isAllowJoin) {
        return '是'
      } else {
        return '否'
      }
    },
    /** 是否允许退出字典翻译 */
    isAllowExitFormat(row) {
      if (row.isAllowExit) {
        return '是'
      } else {
        return '否'
      }
    },

    /** 分页查询,处理分页组件上的操作 */
    pageQuery(pagePara) {
      this.getList(this.queryParams, pagePara.page, pagePara.limit)
    },
    /** 查询操作，处理条件查询操作 */
    handleQuery(param) {
      this.getList(param, this.pageNum, this.pageSize)
    },
    /** 处理点击回收站操作 */
    handleRecycleBin(param) {
      this.getList(param, this.pageNum, this.pageSize)
    },
    /** 查询列表 */
    getList(param, pageNum, pageSize) {
      this.loading = true
      courseMemberGroupApi.listCourseMemberGroup(param, pageNum, pageSize).then(response => {
        this.courseMemberGroupList = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    },
    /** 表格复选框选择操作 */
    checkboxSelect(selection) {
      this.isSelectAll = false
      this.ids = []
      this.parentIDs = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].mgId)
        if (!this.parentIDs.includes(selection[i].parentId)) {
          this.parentIDs.push(selection[i].parentId)
        }
      }
    },
    /** 表格复选框全选操作 */
    checkboxSelectAll(selection) {
      this.ids = []
      this.parentIDs = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].mgId)
        if (!this.parentIDs.includes(selection[i].parentId)) {
          this.parentIDs.push(selection[i].parentId)
        }
      }
      if (selection.length === 0) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.initCourseMemberGroup()
      if (this.courseMemberGroup.parentId === 0) {
        this.title = '添加顶级考试分组'
      } else {
        this.title = '添加考试分组'
      }
      this.isAddEditDialogVisible = true
    },
    /** 新增按钮操作 */
    handleTableAdd(row) {
      this.initCourseMemberGroup()
      this.courseMemberGroup.parentId = row.mgId
      this.title = '添加考试分组'
      this.isAddEditDialogVisible = true
      this.selectCurrentRow = row
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.courseMemberGroup = { ...row }
      this.isAddEditDialogVisible = true
      this.title = '修改考试分组'
    },
    // 处理新增编辑窗口的提交动作
    submitForm(courseMemberGroup) {
      if (courseMemberGroup.mgId === -1) {
        courseMemberGroupApi.addEntry(courseMemberGroup).then(response => {
          const { parentId } = courseMemberGroup
          if (parentId === 0) {
            this.getList(this.queryParams, this.pageNum, this.pageSize)
          } else {
            if (this.maps.has(parentId)) {
              const { row, treeNode, resolve } = this.maps.get(parentId)
              this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
              this.load(row, treeNode, resolve)
            } else {
              this.selectCurrentRow.hasChildren = true
            }
          }
          this.$message({
            type: 'success',
            message: '增加学员分组成功!'
          })
        })
      } else {
        courseMemberGroupApi.updateEntry(courseMemberGroup).then(response => {
          const { parentId } = courseMemberGroup
          if (parentId === 0) {
            this.getList(this.queryParams, this.pageNum, this.pageSize)
          } else {
            if (this.maps.has(parentId)) {
              const { row, treeNode, resolve } = this.maps.get(parentId)
              this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
              this.load(row, treeNode, resolve)
            } else {
              this.selectCurrentRow.hasChildren = true
            }
          }
          this.$message({
            type: 'success',
            message: '更新成功!'
          })
        })
      }
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      // 处理删除
      if (!this.queryParams.delFlag) {
        this.$confirm('您确定要删除所选学员分组?', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(function() {
            return courseMemberGroupApi.batchDelete(row.mgId.toString())
          })
          .then(() => {
            this.$message({
              type: 'success',
              message: '学员分组删除成功'
            })
            const { parentId } = row
            if (parentId === 0) {
              this.getList(this.queryParams, this.pageNum, this.pageSize)
            } else {
              const { row, treeNode, resolve } = this.maps.get(parentId)
              this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
              this.load(row, treeNode, resolve)
            }
          })
          .catch(err => {
            console.log(err)
          })
      } else {
        // 处理恢复
        this.$confirm('您确定要还原所选学员分组?', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(function() {
            return courseMemberGroupApi.batchRecall(row.mgId.toString())
          })
          .then(() => {
            this.$message({
              type: 'success',
              message: '学员分组还原成功'
            })
            const { parentId } = row
            if (parentId === 0) {
              this.getList(this.queryParams, this.pageNum, this.pageSize)
            } else {
              if (this.maps.has(parentId)) {
                const { row, treeNode, resolve } = this.maps.get(parentId)
                this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
                this.load(row, treeNode, resolve)
              } else {
                this.getList(this.queryParams, this.pageNum, this.pageSize)
              }
            }
          })
          .catch(err => {
            console.log(err)
          })
      }
    },
    /** 批量删除/批量还原 */
    handleBatchDelete() {
      // 处理删除
      if (!this.queryParams.delFlag) {
        this.$confirm('您确定要删除所选学员分组?', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            if (this.isSelectAll) {
              return courseMemberGroupApi.batchDeleteByCriteria(this.queryParams)
            } else {
              return courseMemberGroupApi.batchDelete(this.ids.toString())
            }
          })
          .then(() => {
            this.$emit('getList')
            this.$message({
              type: 'success',
              message: '学员分组删除成功'
            })
            if (!this.isSelectAll && this.parentIDs.length > 0) {
              this.parentIDs.forEach(parentId => {
                if (parentId === 0) {
                  this.getList(this.queryParams, this.pageNum, this.pageSize)
                } else {
                  if (this.maps.has(parentId)) {
                    const { row, treeNode, resolve } = this.maps.get(parentId)
                    this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
                    this.load(row, treeNode, resolve)
                  } else {
                    this.getList(this.queryParams, this.pageNum, this.pageSize)
                  }
                }
              })
            } else {
              this.getList(this.queryParams, this.pageNum, this.pageSize)
            }

            this.ids = []
          })
          .catch(err => {
            console.log(err)
          })
      } else {
        // 处理恢复
        this.$confirm('您确定要还原所选学员分组?', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            if (this.isSelectAll) {
              return courseMemberGroupApi.batchRecallByCriteria(this.queryParams)
            } else {
              return courseMemberGroupApi.batchRecall(this.ids.toString())
            }
          })
          .then(() => {
            this.$message({
              type: 'success',
              message: '学员分组还原成功'
            })
            if (!this.isSelectAll && this.parentIDs.length > 0) {
              this.parentIDs.forEach(parentId => {
                if (parentId === 0) {
                  this.getList(this.queryParams, this.pageNum, this.pageSize)
                } else {
                  if (this.maps.has(parentId)) {
                    const { row, treeNode, resolve } = this.maps.get(parentId)
                    this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
                    this.load(row, treeNode, resolve)
                  } else {
                    this.getList(this.queryParams, this.pageNum, this.pageSize)
                  }
                }
              })
            } else {
              this.getList(this.queryParams, this.pageNum, this.pageSize)
            }

            this.ids = []
          })
          .catch(err => {
            console.log(err)
          })
      }
    },
    /** 清空回收站 */
    handleEmpty() {
      if (this.isSelectAll) {
        if (!this.queryParams.orgId) {
          this.$message({
            type: 'info',
            message: '条件删除至少要选择数据所属组织机构'
          })
          return
        }
        this.$confirm('您确定要清空回收站?', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            return courseMemberGroupApi.realDeleteByCriteria(this.queryParams)
          })
          .then(() => {
            this.$message({
              type: 'success',
              message: '清空回收站成功'
            })

            this.getList(this.queryParams, this.pageNum, this.pageSize)
            this.ids = []
          })
          .catch(err => {
            console.log(err)
          })
      } else {
        if (this.ids.length === 0) {
          this.$message({
            type: 'info',
            message: '请先选择要从回收站中清空的分组'
          })
          return
        }
        this.$confirm('您确定要从回收站中清空选项?', '警告', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            return courseMemberGroupApi.realDelete(this.ids.toString())
          })
          .then(() => {
            this.$message({
              type: 'success',
              message: '清空回收站成功'
            })
            if (!this.isSelectAll && this.parentIDs.length > 0) {
              this.parentIDs.forEach(parentId => {
                if (parentId === 0) {
                  this.getList(this.queryParams, this.pageNum, this.pageSize)
                } else {
                  if (this.maps.has(parentId)) {
                    const { row, treeNode, resolve } = this.maps.get(parentId)
                    this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
                    this.load(row, treeNode, resolve)
                  } else {
                    this.getList(this.queryParams, this.pageNum, this.pageSize)
                  }
                }
              })
            } else {
              this.getList(this.queryParams, this.pageNum, this.pageSize)
            }
            this.ids = []
          })
          .catch(err => {
            console.log(err)
          })
      }
    },
    /** 表格节点数据懒加载 */
    load(row, treeNode, resolve) {
      const id = row.mgId
      this.maps.set(id, { row, treeNode, resolve })
      courseMemberGroupApi.getCourseMemberGroupListByParentId(id, row.delFlag).then(response => {
        resolve(response.data)
      })
    },
    /** 复制分组 */
    handleCopy(row) {
      this.initCopyGroupParams()
      this.copyGroupParams.sourceGroupType = row.groupType
      this.copyGroupParams.sourceGroupId = row.mgId
      this.copyGroupParams.sourceGroupName = row.mgName
      this.copyGroupParams.copyOrMove = 'copy'
      this.isCopyGroupDialogVisible = true
      this.selectCurrentRow = row
    },
    /** 移动分组 */
    handleMove(row) {
      this.initCopyGroupParams()
      this.copyGroupParams.sourceGroupType = row.groupType
      this.copyGroupParams.sourceGroupId = row.mgId
      this.copyGroupParams.sourceGroupName = row.mgName
      this.copyGroupParams.copyOrMove = 'move'
      this.isCopyGroupDialogVisible = true
      this.selectCurrentRow = row
    },
    /** 处理复制移动分组事件 */
    handleCopyGroup(copyGroupParams) {
      courseMemberGroupApi.copyMoveGroup(copyGroupParams).then(response => {
        this.$message({
          type: 'success',
          message: '操作成功！'
        })

        const { parentId } = this.selectCurrentRow
        if (parentId > 0 && copyGroupParams.copyOrMove === 'move') {
          const { row, treeNode, resolve } = this.maps.get(parentId)
          this.$set(this.$refs.table.store.states.lazyTreeNodeMap, parentId, [])
          this.load(row, treeNode, resolve)
        }
        const { targetGroupId } = copyGroupParams
        if (targetGroupId && this.maps.has(targetGroupId)) {
          const { row, treeNode, resolve } = this.maps.get(targetGroupId)
          this.$set(this.$refs.table.store.states.lazyTreeNodeMap, targetGroupId, [])
          this.load(row, treeNode, resolve)
        } else if (targetGroupId === null) {
          this.getList(this.queryParams, this.pageNum, this.pageSize)
        } else {
          courseMemberGroupApi.getGroupById(targetGroupId).then(resp => {
            if (resp.data.parentId === 0) {
              this.getList(this.queryParams, this.pageNum, this.pageSize)
            } else {
              const { row, treeNode, resolve } = this.maps.get(resp.data.parentId)
              this.$set(this.$refs.table.store.states.lazyTreeNodeMap, targetGroupId, [])
              this.load(row, treeNode, resolve)
            }
          })
        }
        if ((parentId === 0 && copyGroupParams.copyOrMove === 'move') || !targetGroupId) {
          this.getList(this.queryParams, this.pageNum, this.pageSize)
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
