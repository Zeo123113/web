<template>
  <el-dialog
    :close-on-click-modal="false"
    :title="dialog.title"
    :visible.sync="dialog.show"
    width="800px"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="公告标题" prop="noticeTitle" :label-width="labelWidth">
            <el-input v-model="form.noticeTitle" type="input" placeholder="请输入公告标题"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="公告内容" prop="noticeContent" :label-width="labelWidth">
            <tinymce
              ref="noticeContent"
              v-model="form.noticeContent"
              :save-flag="saveFlag"
              :height="250"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="发布时间" prop="startTime" :label-width="labelWidth">
            <el-date-picker
              v-model="form.startTime"
              type="datetime"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="请输入发布时间"
              align="right"
              clearable
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入备注"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit">保存</el-button>
      <el-button size="small" @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import Tinymce from '@/components/Tinymce'
import courseNoticeApi from '@/api/course/courseManage/courseNotice'
// import USER_CONST from '@/constant/user-const'
export default {
  name: 'EditDialog',
  components: {
    Tinymce
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      default: null
    },
    noticeTypeDict: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      startEndTime: '',
      labelWidth: '120px',
      // 表单校验
      rules: {
        noticeTitle: [
          { required: true, message: '公告标题不能为空', trigger: 'blur' },
          { min: 3, max: 200, message: '长度在 3 到 200 个字符', trigger: 'blur' }
        ],
        noticeContent: [
          { required: true, message: '公告内容不能为空', trigger: 'blur' }
        ],
        startTime: [{ required: true, message: '请输入发布时间', trigger: 'blur' }]
      },
      courseNoticeOptions: [],
      // 富文本开启标志
      saveFlag: false,
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      }
    }
  },
  watch: {
    startEndTime: function(val) {
      // console.log('val = ', val)
      if (val != null) {
        this.form.startTime = val[0]
        this.form.stopTime = val[1]
      } else {
        this.startEndTime = ''
      }
    }
  },
  methods: {
    /** 打开弹窗放入富文本内容 */
    open() {
      this.saveFlag = true
      this.editsaveFlag()
    },
    editsaveFlag() {
      setTimeout(() => {
        this.saveFlag = !this.saveFlag
      }, 500)
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    /** 提交按钮 */
    submit: function() {
      this.form.noticeType = '0'
      this.$refs['form'].validate(valid => {
        if (valid) {
          // console.log('this.form = ', this.form)
          if (this.dialog.title === '添加课程公告') {
            courseNoticeApi
              .addcourseNotice(this.form)
              .then(result => {
                this.dialog.show = false
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          } else if (this.dialog.title === '修改课程公告') {
            courseNoticeApi
              .updatecourseNotice(this.form)
              .then(result => {
                this.dialog.show = false
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          }
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
