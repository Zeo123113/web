<!--
@description 课程公告管理
@author chengguangyuan
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">课程公告</div>
    </div>
    <div class="cd-main__body">
      <!-- 搜索框 -->
      <header-search
        :query-params="queryParams"
        :button="button"
        :deldisabled="deldisabled"
        :ids="ids"
        @search="search"
        @addcourseNotice="addcourseNotice"
        @handleDeleteMore="handleDeleteMore"
      />

      <el-table
        v-loading="loading"
        :data="courseNoticeData"
        tooltip-effect="light"
        row-key="noticeId"
        @select="selectall"
        @select-all="selectall"
      >
        <el-table-column type="selection" align="center" width="50" />
        <el-table-column type="index" label="序号" align="center" width="50" />
        <el-table-column
          label="公告标题"
          prop="noticeTitle"
          show-overflow-tooltip
          align="center"
          min-width="80"
        />
        <el-table-column
          label="开始时间"
          prop="startTime"
          align="center"
          min-width="120"
          show-overflow-tooltip
        />
        <el-table-column
          label="创建时间"
          prop="createTime"
          align="center"
          sortable
          min-width="120"
          show-overflow-tooltip
        />
        <el-table-column
          label="状态"
          prop="noticeType"
          align="center"
          min-width="120"
          :formatter="noticeTypeFormat"
        />
        <el-table-column
          label="操作"
          align="center"
          min-width="300"
          fixed="right"
          style="height:90px"
        >
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="success"
              :disabled="!button.includes('course/courseNotice/update')"
              @click="editcourseNotice(scope.row)"
            >编辑</el-button>
            <el-button
              type="warning"
              size="mini"
              :disabled="scope.row.status === '2'"
              @click="handleStatus(scope.row)"
            >{{ getStatus(scope.row.status) }}</el-button>
            <el-button
              size="mini"
              type="danger"
              :disabled="!button.includes('course/courseNotice/delete')"
              @click="handleDelete(scope.row)"
            >删除</el-button>
            <el-button type="info" size="mini" @click="handleDetail(scope.row)">预览</el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="search"
      />
      <!--详情弹窗-->
      <el-dialog
        :title="courseNotice.noticeTitle"
        :visible.sync="centerDialogVisible"
        width="50%"
        center
        @close="centerDialogVisible = false"
      >
        <div class="editor-content" v-html="courseNotice.noticeContent" />
      </el-dialog>
      <edit-dialog
        :form="courseNotice"
        :notice-type-dict="noticeTypeDict"
        :dialog="dialog"
        @search="search"
      />
    </div>
  </div>
</template>
<script>
import userApi from '@/api/user/user'
import pagination from '@/components/Pagination/index'
import courseNoticeApi from '@/api/course/courseManage/courseNotice'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import USER_CONST from '@/constant/user-const'
import { mapGetters } from 'vuex'
import NOTICECONST from '@/constant/notice-const'

export default {
  components: {
    EditDialog,
    HeaderSearch,
    pagination
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      ids: [],
      courseNoticeData: [],
      courseNotice: {
        noticeId: '',
        ctId: this.courseScheme.ctId,
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        schemeId: this.courseScheme.schemeId,
        noticeType: '',
        publishUserId: '',
        noticeTitle: '',
        noticeContent: '',
        stopTime: '',
        startTime: '',
        createOrgId: null,
        createTime: '',
        updateTime: '',
        createBy: '',
        updateBy: '',
        remark: '',
        publishUser: ''
      },
      dialog: {
        title: '',
        show: false
      },
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      total: 1,
      queryParams: {
        noticeTitle: null,
        publishUser: null,
        ctId: this.courseScheme.ctId,
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        schemeId: this.courseScheme.schemeId,
        beginTime: null,
        endTime: null
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      // 显示公告详情
      centerDialogVisible: false,
      // 公告类型数据字典
      noticeTypeDict: []
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  created() {
    // 公告状态数据字典获取
    this.getDataByType('course_notice_status').then(response => {
      this.statusValue = response.data
    })
    // 列表展示
    this.getList(this.queryParams, this.pageNum, this.pageSize)
  },
  methods: {
    noticeTypeFormat(row) {
      return this.selectDictLabel(this.statusValue, row.status)
    },
    getStatus(status) {
      if (status === '0') {
        return '发布'
      } else if (status === '1') {
        return '下线'
      } else if (status === '2') {
        return '下线'
      }
    },
    // 上下线
    handleStatus(row) {
      this.courseNotice = { ...row }
      if (this.courseNotice.status === NOTICECONST.NORMAL) {
        this.courseNotice.status = NOTICECONST.OFFLINE
      } else {
        this.courseNotice.status = NOTICECONST.NORMAL
      }
      this.$confirm('此操作将修改该公告状态, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        courseNoticeApi.updatecourseNotice(this.courseNotice).then(resp => {
          row.status = this.courseNotice.status
          this.$message({
            type: 'success',
            message: '修改成功!'
          })
          this.search()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消修改'
        })
      })
    },
    /**
     *查看详情
     **/
    handleDetail(row) {
      this.courseNotice.noticeContent = row.noticeContent
      this.courseNotice.noticeTitle = row.noticeTitle
      this.centerDialogVisible = true
    },
    // 表单重置
    reset() {
      this.courseNotice = {
        noticeId: '',
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        noticeType: '',
        publishUserId: '',
        noticeTitle: '',
        noticeContent: '',
        stopTime: '',
        startTime: '',
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createTime: '',
        updateTime: '',
        createBy: '',
        updateBy: '',
        remark: '',
        publishUser: ''
      }
    },
    selectall(selection) {
      this.deldisabled = !this.deldisabled
      this.ids = selection.map(item => item.noticeId)
    },
    addcourseNotice() {
      this.reset()
      this.dialog.title = '添加课程公告'
      this.dialog.show = true
    },
    editcourseNotice(row) {
      this.reset()
      this.courseNotice = { ...row }
      this.courseNotice.status = '0'
      if (row.publishUserId !== null && row.publishUserId !== undefined && row.publishUserId !== '') {
        // 根据publishUserId，查询publishUserName
        userApi.getUser(row.publishUserId).then(resp => {
          if (resp.code === 0 && resp.msg !== '查找的用户不存在') {
            this.courseNotice.publishUser = resp.data.loginName
          }
        })
      }
      this.dialog.title = '修改课程公告'
      this.dialog.show = true
    },
    /** 处理搜索 */
    search() {
      this.getList(this.queryParams, this.pageNum, this.pageSize)
    },
    resetForm() {
      this.search()
    },
    getList(param, pageNum, pageSize) {
      this.loading = true
      courseNoticeApi
        .getcourseNoticeList(param, pageNum, pageSize)
        .then(response => {
          this.courseNoticeData = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 批量删除
    handleDeleteMore(ids) {
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          // console.log('ids = ', this.ids)
          if (ids.size === 0) {
            return false
          }
          return courseNoticeApi.delcourseNotice(ids.toString())
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
          // this.$message.error(err.msg)
        })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return courseNoticeApi.delcourseNotice(row.noticeId)
        })
        .then(() => {
          this.$message({
            showClose: true,
            message: '删除成功',
            duration: 3000,
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>
<style lang="scss" scoped>
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>
<style scoped>
.editor-content >>> ol {
  margin-left: 32px;
}
.editor-content >>> ol li{
  list-style-type: upper-alpha;
}
</style>
