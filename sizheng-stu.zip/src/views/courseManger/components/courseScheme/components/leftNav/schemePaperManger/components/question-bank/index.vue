<!--
@description 试卷管理题库选题试题列表
@author CPY
-->
<template>
  <div>
    <!--试题列表预览-->
    <el-dialog
      title="题库"
      :visible.sync="listDialogVisible"
      width="60%"
      @open="getQuestionList"
      @close="closeQuestion"
    >
      <!--搜索框-->
      <header-search
        :query-params="bankSelect"
        :course-options="courseOptions"
        :course-scheme="courseScheme"
        @handleQuery="handleQuery"
      ></header-search>
      <!--试题展示-->
      <el-main v-loading="loading">
        <div v-for="(item,index) in bankList" :key="index">
          <!--选择框-->
          <el-checkbox-group v-model="checkList" style="display:inline;" @change="handleCheckAllChange">
            <el-checkbox :label="item"> {{ index+1 }}
            </el-checkbox>
          </el-checkbox-group>
          <div class="QuestionItem">
            <div class="contentItem">
              <!--题号/题型-->
              <span class="tqIdTotal">{{ index+1 }}/{{ bankList.length }}</span>&nbsp;
              <span v-for="(type,typeIndex) in questionTypeOptions" :key="typeIndex">
                <span v-if="type.dictValue == item.tqTypeId" class="tqIdTotal"><b>{{ type.dictLabel }}</b></span>
              </span>
              <span v-for="(diff,diffIndex) in diffLevelOptions" :key="diffIndex">&nbsp;
                <span v-if="diff.dictValue == item.diffLevel" class="tqIdTotal">
                  {{ diff.dictLabel }}
                </span>
              </span>
              <span v-if="questionType!=MATERIAL" class="question-value">
                分值：<el-input-number v-model="item.value" controls-position="right" :min="1" :max="20" size="mini"></el-input-number>
              </span>
              <span v-if="item.tqTypeId == MATERIAL" style="float:right">
                <el-button type="text" @click="item.arrow = !item.arrow">
                  <i v-if="item.arrow" class="el-icon-arrow-up">收起</i>
                  <i v-if="!item.arrow" class="el-icon-arrow-down">展开</i>
                </el-button></span>
              <!--题干-->
              <span class="editor-content" v-html="item.content" />
              <!--材料题子题-->
              <div v-if="item.tqTypeId == MATERIAL&&item.arrow" class="MATERIALItem">
                <div v-for="(questionItem,itemIndex) in item.materialQuestionList" :key="itemIndex" class="MItem">
                  <el-checkbox-group v-model="item.checkList" style="display:inline;" @change="handleCheckAllChangeItem">
                    <el-checkbox :label="questionItem">
                      <span class="tqIdTotal">{{ itemIndex+1 }}/{{ item.materialQuestionList.length }}</span>
                    </el-checkbox>
                  </el-checkbox-group>
                  &nbsp;
                  <span v-for="(type2,typeIndex2) in questionTypeOptions" :key="typeIndex2">
                    <span v-if="type2.dictValue == questionItem.tqTypeId" class="tqIdTotal"><b>{{ type2.dictLabel }}</b></span>
                  </span>
                  <span v-for="(diff2,diffIndex2) in diffLevelOptions" :key="diffIndex2">&nbsp;
                    <span v-if="diff2.dictValue == questionItem.diffLevel" class="tqIdTotal">
                      {{ diff2.dictLabel }}
                    </span>
                  </span>
                  <span class="question-value">
                    分值：<el-input-number v-model="questionItem.value" controls-position="right" :min="1" :max="20" size="mini"></el-input-number>
                  </span>
                  <!--题干-->
                  <span class="editor-content" v-html="questionItem.content" />
                  <span style="color:#1890FF;"> 正确答案：{{ questionItem.answer }}</span>
                </div>
              </div>
              <span v-if="questionType!=MATERIAL" style="color:#1890FF;"> <strong>正确答案：{{ item.answer }}</strong></span><br>
              <!--尾部-->
              <span class="question-footer">
                {{ item.createBy }} &emsp;| &emsp;更新于{{ item.updateTime? item.updateTime :item.createTime }}
              </span>
            </div>
          </div>
        </div>
      </el-main>
      <!-- 分页控件-->
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      />
      <span slot="footer" class="dialog-footer">
        <el-button v-if="questionType.toString() !== MATERIAL" type="primary" size="mini" @click="saveQuestion()">保存</el-button>
        <el-button v-if="questionType.toString() === MATERIAL" type="primary" size="mini" @click="saveMATERIALQuestion()">保存</el-button>
        <el-button size="mini" @click="closeQuestion()">取消</el-button>
      </span>
    </el-dialog>
    <!--结束试题列表-->
  </div>
</template>
<script>
import paperApi from '@/api/exambank/paper'
import bankApi from '@/api/exambank/bank'
import HeaderSearch from './components/HeaderSearch'
import TypeNumber from '@/constant/question-type-const'
import pagination from '@/components/Pagination/index'
import EXAMBANK_CONST from '@/constant/exambank-const'
import QUESTIONTYPE from '@/constant/question-type-const'
import { mapGetters } from 'vuex'
export default {
  components: { HeaderSearch, pagination },
  props: {
    // 试卷Id
    paperId: {
      type: Number,
      default: 0
    },
    questionType: {
      type: Number,
      default: 0
    },
    listMethod: {
      type: Number,
      default: 2
    },
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 试题列表
      bankList: [],
      // 选择试题列表
      checkedQuestions: [],
      // 添加试题
      addQuestionType: false,
      // 是否预览
      IsPreview: true,
      // 富文本
      saveFlag: false,
      loading: false,
      // 选中试题存储
      checkList: [],
      // 分页记录总条数
      total: 1,
      // 默认分页参数
      pageNum: 1,
      // 条数限制
      pageSize: EXAMBANK_CONST.PAGESIZE,
      // 试题类型
      MATERIAL: QUESTIONTYPE.MATERIAL,
      // 材料子题存放数组
      MATERIALItem: [],
      // 查找对象
      bankSelect: {
        courseId: this.courseScheme.csId,
        tqTypeId: null,
        title: null,
        createBy: null,
        beginTime: null,
        endTime: null,
        chapterId: null,
        knowledgeId: null,
        diffLevel: null,
        isShare: false
      },
      // 课程
      courseOptions: [],
      // 难度数据字典
      diffLevelOptions: [],
      // 试题类型数据字典
      questionTypeOptions: [],
      // 打开题库弹窗
      listDialogVisible: false,
      // 选中的试题列表
      multipleSelection: []
    }
  },
  // 从状态管理器获取按钮权限数组button
  computed: {
    ...mapGetters({
      button: 'button',
      user: 'user'
    })
  },
  created() {
    this.QuestTypeList = TypeNumber
    // 课程名称获取
    bankApi.getCourseList().then(result => {
      this.courseOptions = result.data
    })
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.questionTypeOptions = response.data
    })
    // 试题难度数据字典获取
    this.getDataByType('exambank_diff_level').then(response => {
      this.diffLevelOptions = response.data
    })
    this.getQuestionList()
  },
  methods: {
    /** 课程编号字典翻译 */
    courseIdFormat(row) {
      for (let i = 0; i < this.courseOptions.length; i++) {
        if (this.courseOptions[i].courseId === row.courseId) {
          return this.courseOptions[i].courseName
        }
      }
    },
    // 打开题库
    openQuestionBankDialog() {
      this.listDialogVisible = true
    },
    // 获取试卷列表
    getQuestionList() {
      this.loading = true
      this.bankSelect.tqTypeId = this.questionType
      this.bankSelect.createBy = this.user.loginName
      if (this.questionType.toString() === this.MATERIAL) {
        paperApi.listQuestions(this.bankSelect, this.pageNum, this.pageSize).then(response => {
          if (response.code === 0) {
            this.bankList = response.data
            this.loading = false
          }
        })
      } else {
        paperApi.list(this.bankSelect, this.pageNum, this.pageSize).then(response => {
          if (response.code === 0) {
            this.bankList = response.data.list
            this.total = response.data.total
            this.loading = false
          }
        })
      }
    },
    // 关闭题库
    closeQuestion() {
      this.listDialogVisible = false
    },
    /** 关闭添加试题 */
    closeAddQuestion() {
      this.addQuestionType = false
      this.closeQuestion()
    },
    /** 打开添加试题 */
    addQuestion() {
      this.addQuestionType = true
    },
    /** 查询操作，处理条件查询操作 */
    handleQuery() {
      this.getQuestionList()
    },
    // 分页查询
    pageQuery(pagePara) {
      this.getList(this.queryParams, pagePara.page, pagePara.limit)
    },
    /** 保存试题列表 */
    saveQuestion() {
      this.closeQuestion()
      this.multipleSelection.forEach((item, index) => {
        item.paperId = this.paperId
        item.amount = 1
        this.checkedQuestions.push(item)
      })
      paperApi.addQuestionList(this.checkedQuestions, this.listMethod.toString()).then(resp => {
        this.checkedQuestions = []
        this.checkList = []
        if (resp.code === 0) {
          this.$emit('getQuestionList')
          this.$message({
            message: '保存成功',
            type: 'success'
          })
        } else {
          this.$message({
            message: '保存失败',
            type: 'error'
          })
        }
      })
    },
    // 材料题保存
    saveMATERIALQuestion() {
      this.closeQuestion()
      this.bankList.forEach(item => {
        if (item.checkList.length > 0) {
          item.paperId = this.paperId
          item.amount = 1
          this.checkedQuestions.push(item)
        }
      })
      paperApi.addMaterial(this.checkedQuestions).then(resp => {
        this.checkedQuestions = []
        this.checkList = []
        if (resp.code === 0) {
          this.$emit('getQuestionList')
          this.$message({
            message: '保存成功',
            type: 'success'
          })
        } else {
          this.$message({
            message: '保存失败',
            type: 'error'
          })
        }
      })
    },
    // 多选改变
    handleCheckAllChange(val) {
      this.multipleSelection = val
      val.forEach(item => {
        item.checkList = item.materialQuestionList
      })
    },
    // 材料子题多选
    handleCheckAllChangeItem(val) {
      this.bankList.forEach(item => {
        if (val.tqId === item.tqId) {
          item.checkList = val
        }
      })
    }
  }
}
</script>
<style scoped>
.QuestionItem{
  border: 1px solid #E3E3E3;
  padding: 20px;
  margin-bottom: 15px;
  width: 100%;
}
.contentItem{
  margin-bottom: 10px;
}
.deletebutton{
  float: right;
}
.el-main {
    padding: 0px;
}
.tqIdTotal{
  border: 1px solid #1890FF;
  color: #1890FF;
  padding: 0 5px;
  border-radius: 10%;
}
.question-footer{
  padding: 0;
  border: none;
  line-height: 30px;
  color: #999;
  font-size: 14px;
  cursor: pointer;
}
.question-value{
  float:right;
}
.MItem{
  margin-left: 2em;
  border-bottom: solid 1px #ccc;
  padding-bottom: 1em;
  margin-bottom: 1em;
}
.MATERIALItem{
  width:100%;
  min-height: 100px;
}
</style>
<style scoped>
.editor-content >>> ol {
  margin-left: 32px;
}
.editor-content >>> ol li{
  list-style-type: upper-alpha;
}
</style>
