<template>
  <el-table :data="examInfoList" style="width: 100%">
    <el-table-column prop="stuId" align="center" label="学号" min-width="120"></el-table-column>
    <el-table-column prop="realName" align="center" label="姓名" min-width="120"></el-table-column>
    <el-table-column v-for="(item,index) in examStatisticalDetail.statisticsItemList" :key="index" align="center" :label="item.idTitle" min-width="120">
      <template slot-scope="scope">
        {{ scope.row.scoreLists[index].score ? scope.row.scoreLists[index].score:'0.0' }}
      </template>
    </el-table-column>
    <el-table-column prop="scoresum" align="center" label="总分" min-width="120"></el-table-column>
    <!-- <el-table-column fixed="right" align="center" label="操作" min-width="120">
      <template slot-scope="scope">
        <el-button
          type="text"
          size="small"
          @click.native.prevent="deleteRow(scope.$index, tableData)"
        >移除</el-button>
      </template>
    </el-table-column> -->
  </el-table>
</template>
<script>
// import stuAnswerApi from '@/api/exambank/stu-answer'
export default {
  props: {
    examInfoList: {
      type: Array,
      default: () => {
        return []
      }
    },
    examStatisticalDetail: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  data() {
    return {
      lookInfo: false
    }
  },
  methods: {
    // 打开考试统计详情
    gotoExamInfo(item) {
      console.log(item)
    // this.lookInfo = true
    // if (this.examStatistical.ids && this.examStatistical.ids.length > 0) {
    //   this.current = 'examStatistical'
    //   stuAnswerApi.statisticsInfo(this.examStatistical.ids).then(resp => {
    //     this.examInfoList = resp.data
    //   })
    // } else {
    //   this.$message({
    //     type: 'error',
    //     message: '抱歉，还没有学生考试记录!'
    //   })
    // }
    }
  }
}
</script>
