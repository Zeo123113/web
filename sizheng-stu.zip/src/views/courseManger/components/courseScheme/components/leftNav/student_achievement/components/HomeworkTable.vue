<template>
  <el-table :data="homeworkInfoList" style="width: 100%">
    <el-table-column prop="stuId" align="center" label="学号" min-width="120"></el-table-column>
    <el-table-column prop="realName" align="center" label="姓名" min-width="120"></el-table-column>
    <el-table-column v-for="(item,index) in homeworkStatisticalDetail.statisticsItemList" :key="index" align="center" :label="item.idTitle" min-width="120">
      <template slot-scope="scope">
        {{ scope.row.scoreLists[index].score ? scope.row.score[index]:'0.0' }}
      </template>
    </el-table-column>
    <el-table-column prop="scoresum" align="center" label="总分" min-width="120"></el-table-column>
    <!-- <el-table-column fixed="right" align="center" label="操作" min-width="120">
      <template slot-scope="scope">
        <el-button
          type="text"
          size="small"
          @click.native.prevent="deleteRow(scope.$index, tableData)"
        >移除</el-button>
      </template>
    </el-table-column> -->
  </el-table>
</template>
<script>
export default {
  props: {
    homeworkInfoList: {
      type: Array,
      default: () => {
        return []
      }
    },
    homeworkStatisticalDetail: {
      type: Object,
      default: () => {
        return {}
      }
    }
  }
}
</script>
