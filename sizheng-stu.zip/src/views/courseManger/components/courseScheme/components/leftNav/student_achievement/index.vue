<!--
    学员成绩
    @author:cpy
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading">
      <div class="cd-main__title">学员成绩</div>
    </div>
    <div class="cd-main__body">
      <div class="course-statictics">
        <!-- 概览 -->
        <div class="dashboard row">
          <div class="col-xs-4 item bottom-border" @click="openhomeworkList()">
            <span class="number">作业</span>
            <div
              class="title"
            >共 {{ homeworkStatistical? homeworkStatistical.length: '0' }} 个班次</div>
          </div>
          <div class="col-xs-4 item bottom-border" @click="openTestList()">
            <span class="number">测试</span>
            <div
              class="title"
            >共 {{ testStatistical.length }}  个班次</div>
          </div>
          <div class="col-xs-4 item bottom-border no-right-border" @click="openExamList()">
            <span class="number">考试</span>
            <div class="title">
              共 {{ examStatistical.length }} 个班次
              <span
                class="link-medium es-icon es-icon-help ml5"
                data-container="body"
                data-toggle="popover"
                data-trigger="hover"
                data-placement="top"
                data-content="观看免费任务和试看视频的总次数"
                data-original-title
                title
              ></span>
            </div>
          </div>
          <div class="col-xs-4 item">
            <span class="number">实验</span>
            <div class="title">共 0 个班次</div>
          </div>
          <div class="col-xs-4 item">
            <span class="number">考勤</span>
            <div class="title">共 0 个班次</div>
          </div>
          <!-- <div class="col-xs-4 item no-right-border">
            <span class="number">平时</span>
            <div class="title">共 0 次 平均 0 分</div>
          </div>-->
        </div>
        <!--分班列表-->
        <div v-if="opencurrenttable != '' && current == null" class="course-manage-subltitle cd-mb40">分组成绩</div>
        <el-table
          v-if="opencurrenttable != '' && current == null"
          :data="currenttableData"
          style="width: 100%"
        >
          <el-table-column
            fixed
            prop="mgName"
            label="分组"
            align="center"
            min-width="150"
          >
          </el-table-column>
          <el-table-column
            prop="submitNum"
            label="数量"
            align="center"
            min-width="120"
          >
          </el-table-column>
          <el-table-column
            prop="average"
            align="center"
            label="平均分"
            min-width="120"
          >
          </el-table-column>
          <el-table-column
            fixed="right"
            label="操作"
            align="center"
            min-width="120"
          >
            <template slot-scope="scope">
              <el-button
                v-if="opencurrenttable == 'homeworkStatistical'"
                type="text"
                size="small"
                @click="gotoHomeworkInfo(scope.row)"
              >
                查看详情
              </el-button>
              <el-button
                v-if="opencurrenttable == 'testStatistical'"
                type="text"
                size="small"
                @click="gotoTestInfo(scope.row)"
              >
                查看详情
              </el-button>
              <el-button
                v-if="opencurrenttable == 'examStatistical'"
                type="text"
                size="small"
                @click="gotoExamInfo(scope.row)"
              >
                查看详情
              </el-button>
            </template>
          </el-table-column>
        </el-table>
        <!--分班后成绩详情-->
        <div v-if="current" class="course-manage-subltitle cd-mb40">成绩详情</div>
        <ExamTestTable v-if="current&&'examStatistical' == current" :exam-info-list="examInfoList" :exam-statistical-detail="examStatisticalDetail"></ExamTestTable>
        <TestTable v-if="current&&'testStatistical' == current" :test-info-list="testInfoList" :test-statistical-detail="testStatisticalDetail"></TestTable>
        <HomeworkTable v-if="current&&'homeworkStatistical' == current" :homework-info-list="homeworkInfoList" :homework-statistical-detail="homeworkStatisticalDetail"></HomeworkTable>
      </div>
    </div>
  </div>
</template>
<script>
import assignApi from '@/api/exambank/homework-arrange'
import examArrangeApi from '@/api/exambank/examArrange'
import EXAMBANKCONST from '@/constant/exambank-const'
import stuAnswerApi from '@/api/exambank/stu-answer'
import homeworkRecordApi from '@/api/exambank/homework-record'
import ExamTestTable from './components/ExamTestTable'
import TestTable from './components/TestTable'
import HomeworkTable from './components/HomeworkTable'
export default {
  components: {
    ExamTestTable,
    TestTable,
    HomeworkTable
  },
  props: {
    courseScheme: {
      type: Object,
      default: () => { return {} }
    }
  },
  data() {
    return {
      // 作业统计对象
      homeworkStatistical: {},
      // 分班后的作业详情统计对象
      homeworkStatisticalDetail: {},
      // 分班后的测试详情统计对象
      testStatisticalDetail: {},
      // 分班后的考试详情统计对象
      examStatisticalDetail: {},
      // 考试的查询参数对象
      examSelect: {},
      // 测试的查询参数对象
      testSelect: {},
      // 考试统计对象
      examStatistical: [],
      // 测试统计对象
      testStatistical: [],
      // 考试详情对象列表
      examInfoList: [],
      // 测试详情对象列表
      testInfoList: [],
      // 作业详情对象列表
      homeworkInfoList: [],
      // 当前显示哪部分成绩
      current: null,
      // 当前分头的成绩列表
      currenttableData: [],
      // 显示哪个的分班列表
      opencurrenttable: ''
    }
  },
  mounted() {
    this.getHomework()
    this.getExam()
    this.getTest()
  },
  methods: {
    /** 显示按头分的成绩列表 */
    openhomeworkList() {
      if (this.currenttableData === this.homeworkStatistical) {
        this.currenttableData = null
        this.opencurrenttable = ''
        this.current = null
      } else {
        this.currenttableData = this.homeworkStatistical
        this.opencurrenttable = 'homeworkStatistical'
      }
    },
    /** 显示按头分的测试列表 */
    openTestList() {
      if (this.currenttableData === this.testStatistical) {
        this.currenttableData = null
        this.opencurrenttable = ''
        this.current = null
      } else {
        this.currenttableData = this.testStatistical
        this.opencurrenttable = 'testStatistical'
      }
    },
    /** 显示按头分的考试列表 */
    openExamList() {
      if (this.currenttableData === this.examStatistical) {
        this.currenttableData = null
        this.opencurrenttable = ''
        this.current = null
      } else {
        this.currenttableData = this.examStatistical
        this.opencurrenttable = 'examStatistical'
      }
    },
    /** 获取作业统计结果 */
    getHomework() {
      assignApi.statistics(this.courseScheme.schemeId).then(resp => {
        this.homeworkStatistical = resp.data
      })
    },
    /** 获取考试统计结果 */
    getExam() {
      this.examSelect.courseId = this.courseScheme.csId
      this.examSelect.termId = this.courseScheme.ctId
      this.examSelect.examType = EXAMBANKCONST.EXAM
      examArrangeApi.statistics(this.examSelect).then(resp => {
        this.examStatistical = resp.data
      })
    },
    /** 获取测试统计结果 */
    getTest() {
      this.testSelect.courseId = this.courseScheme.csId
      this.testSelect.termId = this.courseScheme.ctId
      this.testSelect.examType = EXAMBANKCONST.TEST
      examArrangeApi.statistics(this.testSelect).then(resp => {
        this.testStatistical = resp.data
      })
    },
    // 打开作业统计详情
    gotoHomeworkInfo(row) {
      if (row && row.statisticsItemList.length > 0) {
        this.homeworkInfoList = []
        this.homeworkStatisticalDetail = row
        this.current = 'homeworkStatistical'
        homeworkRecordApi.statisticsInfo(row.statisticsItemList).then(resp => {
          this.homeworkInfoList = resp.data
        })
      } else {
        this.$message({
          type: 'error',
          message: '抱歉，还没有学生作业记录!'
        })
      }
    },
    // 打开考试统计详情
    gotoExamInfo(row) {
      if (row && row.statisticsItemList.length > 0) {
        this.examInfoList = []
        this.examStatisticalDetail = row
        this.current = 'examStatistical'
        stuAnswerApi.statisticsInfo(row.statisticsItemList).then(resp => {
          this.examInfoList = resp.data
        })
      } else {
        this.$message({
          type: 'error',
          message: '抱歉，还没有学生考试记录!'
        })
      }
    },
    // 打开测试统计详情
    gotoTestInfo(row) {
      if (row && row.statisticsItemList.length > 0) {
        this.testInfoList = []
        this.testStatisticalDetail = row
        this.current = 'testStatistical'
        stuAnswerApi.statisticsInfo(row.statisticsItemList).then(resp => {
          this.testInfoList = resp.data
        })
      } else {
        this.$message({
          type: 'error',
          message: '抱歉，还没有学生测试记录!'
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
  .cd-main__heading {
    padding: 24px 32px;
    box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
    .cd-main__title {
      font-size: 16px;
      color: rgba(0, 0, 0, 0.88);
      line-height: 1;
      margin: 0 auto;
      font-weight: 500;
    }
  }
  .cd-main__body {
    padding: 32px;
    min-height: 900px;
    .course-manage-subltitle {
      padding: 9px 0 9px 32px;
      font-size: 14px;
      font-weight: 500;
      line-height: 1;
      color: rgba(0, 0, 0, 0.8);
      background-color: rgba(0, 0, 0, 0.04);
    }

    .cd-mb40 {
      margin-bottom: 40px !important;
    }
    .course-statictics {
      .dashboard {
        background: #fff;
        box-shadow: 0 0 30px 0 rgba(0, 0, 0, 0.03);
        border-radius: 4px;
        margin: 10px;
        text-align: center;
        margin-bottom: 20px;
        .item {
          padding-top: 30px;
          height: 120px;
          border-right: 1px solid rgba(0, 0, 0, 0.06);
          cursor: pointer;
          .number {
            position: relative;
            opacity: 0.88;
            font-size: 32px;
            color: #000;
            letter-spacing: 1px;
            line-height: 32px;
          }
          .title {
            opacity: 0.56;
            font-size: 12px;
            color: #000;
            letter-spacing: 0;
            line-height: 12px;
            padding-top: 10px;
          }
        }
        .bottom-border {
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
        }
        .no-right-border {
          border-right: none;
        }
      }
    }

    .statictic-body {
      margin: 0 10px 20px;
    }
  }
}
</style>
