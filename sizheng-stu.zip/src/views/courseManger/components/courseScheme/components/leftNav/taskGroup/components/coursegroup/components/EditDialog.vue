<template>
  <el-dialog :title="dialog.title" :visible.sync="dialog.show" width="60%">
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="学员分组" prop="mgId" :label-width="labelWidth">
            <treeselect
              v-model="form.mgId"
              :options="courseMemberGroupOptions"
              style="width:217px;"
              placeholder="请选择学员分组"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="小组名称" prop="groupName" :label-width="labelWidth">
            <el-input
              v-model="form.groupName"
              type="input"
              placeholder="请输入小组名称"
              style="width:217px;"
            />
          </el-form-item>
        </el-col>
        <el-col :span="22">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入备注"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit">保存</el-button>
      <el-button @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import taskGroupApi from '@/api/course/regularGrade/taskGroup'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
// import USER_CONST from '@/constant/user-const'
export default {
  name: 'EditDialog',
  components: {
    Treeselect
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseMemberGroupOptions: {
      type: Array,
      required: true
    },
    form: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      labelWidth: '120px',
      // 表单校验
      rules: {
        mgId: [{ required: true, message: '请选择学员分组', trigger: 'blur' }],
        groupName: [
          { required: true, message: '小组名称不能为空', trigger: 'blur' },
          { min: 3, max: 200, message: '长度在 3 到 200 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    /** 提交按钮 */
    submit: function() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.dialog.title === '添加课程小组') {
            taskGroupApi
              .addEntry(this.form)
              .then(result => {
                this.close()
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          } else if (this.dialog.title === '修改课程小组') {
            taskGroupApi
              .updateEntry(this.form)
              .then(result => {
                this.close()
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          }
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
