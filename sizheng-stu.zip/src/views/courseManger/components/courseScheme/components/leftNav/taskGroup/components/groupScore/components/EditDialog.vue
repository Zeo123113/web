<template>
  <el-dialog :title="dialog.title" :visible.sync="dialog.show" width="60%" @open="open()">
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="授课单元" prop="unitId" :label-width="labelWidth">
            <el-select v-model="form.unitId" clearable>
              <el-option
                v-for="courseUnit in courseUnitOptions"
                :key="courseUnit.unitId"
                :label="courseUnit.unitTitle"
                :value="courseUnit.unitId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="课程小组" prop="cgroupId" :label-width="labelWidth">
            <el-select v-model="form.cgroupId" clearable>
              <el-option
                v-for="courseGroup in courseGroupOptions"
                :key="courseGroup.cgroupId"
                :label="courseGroup.groupName"
                :value="courseGroup.cgroupId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="分组任务" prop="gtId" :label-width="labelWidth">
            <el-select v-model="form.gtId" clearable>
              <el-option
                v-for="groupTask in groupTaskOptions"
                :key="groupTask.gtId"
                :label="groupTask.gtTitle"
                :value="groupTask.gtId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="分数" prop="score">
            <el-input v-model="form.score" placeholder="请输入分数" style="width:80%" clearable />
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入备注" style="width:92%" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit">保存</el-button>
      <el-button @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import groupScoreApi from '@/api/course/regularGrade/groupScore'
export default {
  name: 'EditDialog',
  components: {
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseUnitOptions: {
      type: Array,
      required: true
    },
    groupTaskOptions: {
      type: Array,
      required: true
    },
    courseGroupOptions: {
      type: Array,
      required: true
    },
    form: {
      type: Object,
      default: null
    },
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      labelWidth: '120px',
      // 表单校验
      rules: {
        unitId: [{ required: true, message: '请选择授课单元', trigger: 'blur' }],
        cgroupId: [{ required: true, message: '请选择课程小组', trigger: 'blur' }],
        gtId: [{ required: true, message: '请选择分组任务', trigger: 'blur' }],
        score: [{ pattern: /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/, message: '请输入正确的分数', trigger: 'blur' }]
      }
    }
  },
  methods: {
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    open() {
      this.courseSchemeChange(this.courseScheme.schemeId)
    },
    /** 提交按钮 */
    submit: function() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.dialog.title === '添加小组任务成绩') {
            groupScoreApi
              .addEntry(this.form)
              .then(result => {
                this.close()
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          } else if (this.dialog.title === '修改小组任务成绩') {
            groupScoreApi
              .updateEntry(this.form)
              .then(result => {
                this.close()
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          }
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
