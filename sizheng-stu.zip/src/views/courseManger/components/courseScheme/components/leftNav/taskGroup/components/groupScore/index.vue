<!--
@description 小组任务成绩管理
@author chengguangyuan
-->
<template>
  <div class="outer-container">
    <!-- 搜索框 -->
    <header-search
      :query-params="queryParams"
      :button="button"
      :deldisabled="deldisabled"
      :ids="ids"
      :course-unit-options="courseUnitOptions"
      :group-task-options="groupTaskOptions"
      :course-group-options="courseGroupOptions"
      @search="search"
      @addgroupScore="addgroupScore"
      @handleDeleteMore="handleDeleteMore"
    />

    <el-table
      v-loading="loading"
      :data="groupScoreData"
      tooltip-effect="light"
      row-key="cgtId"
      @select="selectall"
      @select-all="selectall"
    >
      <el-table-column type="selection" align="center" width="50" />
      <el-table-column label="课程设置" prop="csId" align="center" min-width="80" />
      <el-table-column label="课程学期" prop="ctId" align="center" min-width="80" />
      <el-table-column label="教学方案" prop="schemeId" align="center" min-width="80" />
      <el-table-column label="授课单元" prop="unitId" align="center" min-width="80" />
      <el-table-column label="课程小组" prop="cgroupId" align="center" min-width="80" />
      <el-table-column label="分组任务" prop="gtId" align="center" min-width="80" />
      <el-table-column label="分数" prop="score" align="center" sortable min-width="80" />

      <el-table-column label="创建者机构" prop="createOrgId" align="center" sortable min-width="120" />
      <el-table-column label="机构编号" prop="orgId" sortable align="center" min-width="100" />
      <el-table-column label="创建者" prop="createBy" align="center" sortable min-width="100" />
      <el-table-column
        label="创建时间"
        prop="createTime"
        align="center"
        sortable
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column label="更新者" prop="updateBy" align="center" min-width="100" />
      <el-table-column
        label="更新时间"
        prop="updateTime"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column label="操作" align="center" min-width="220" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="success"
            :disabled="!button.includes('course/groupScore/update')"
            @click="editgroupScore(scope.row)"
          >编辑</el-button>
          <el-button
            size="mini"
            type="danger"
            :disabled="!button.includes('course/groupScore/delete')"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="search"
    />
    <edit-dialog
      :form="groupScore"
      :dialog="dialog"
      :course-scheme="courseScheme"
      :course-unit-options="courseUnitOptions"
      :group-task-options="groupTaskOptions"
      :course-group-options="courseGroupOptions"
      @search="search"
    />
  </div>
</template>
<script>
import courseUnitApi from '@/api/course/courseManage/courseUnit'
import groupTaskApi from '@/api/course/regularGrade/groupTask'
import taskGroupApi from '@/api/course/regularGrade/taskGroup'
import pagination from '@/components/Pagination/index'
import groupScoreApi from '@/api/course/regularGrade/groupScore'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import USER_CONST from '@/constant/user-const'
import { mapGetters } from 'vuex'

export default {
  components: {
    EditDialog,
    HeaderSearch,
    pagination
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      ids: [],
      groupScoreData: [],
      groupScore: {
        cgtId: '',
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        cgroupId: null,
        gtId: null,
        score: '',
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createTime: '',
        updateTime: '',
        createBy: '',
        updateBy: '',
        remark: ''
      },
      dialog: {
        title: '',
        show: false
      },
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      total: 1,
      queryParams: {
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      courseUnitOptions: [],
      groupTaskOptions: [],
      courseGroupOptions: []
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  created() {
    // 列表展示
    this.getList(this.queryParams, this.pageNum, this.pageSize)
    this.courseSchemeChange(this.courseScheme.schemeId)
  },
  methods: {
    courseSchemeChange(value) {
      if (value !== null && value !== '' && value !== undefined) {
        courseUnitApi.getRefUnitBySchemeId(value).then(response => {
          this.courseUnitOptions = response.data
        })
        taskGroupApi.getCourseGroupsBySchemeId(value).then(response => {
          this.courseGroupOptions = response.data
        })
        groupTaskApi.getGroupTasksBySchemeId(value).then(response => {
          this.groupTaskOptions = response.data
        })
      }
    },
    // 表单重置
    reset() {
      this.groupScore = {
        cgtId: '',
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        cgroupId: null,
        gtId: null,
        score: '',
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createTime: '',
        updateTime: '',
        createBy: '',
        updateBy: '',
        remark: ''
      }
    },
    selectall(selection) {
      this.deldisabled = !this.deldisabled
      this.ids = selection.map(item => item.cgtId)
    },
    addgroupScore() {
      this.reset()
      this.dialog.title = '添加小组任务成绩'
      this.dialog.show = true
    },
    editgroupScore(row) {
      this.reset()
      this.groupScore = { ...row }
      this.dialog.title = '修改小组任务成绩'
      this.dialog.show = true
    },
    /** 处理搜索 */
    search() {
      this.getList(this.queryParams, this.pageNum, this.pageSize)
    },
    resetForm() {
      this.search()
    },
    getList(param, pageNum, pageSize) {
      this.loading = true
      groupScoreApi
        .listgroupScore(param, pageNum, pageSize)
        .then(response => {
          this.groupScoreData = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 批量删除
    handleDeleteMore(ids) {
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          // console.log('this.ids = ', ids)
          return groupScoreApi.batchDelete(this.ids.toString())
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return groupScoreApi.batchDelete(row.cgtId)
        })
        .then(() => {
          this.$message({
            showClose: true,
            message: '删除成功',
            duration: 3000,
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
