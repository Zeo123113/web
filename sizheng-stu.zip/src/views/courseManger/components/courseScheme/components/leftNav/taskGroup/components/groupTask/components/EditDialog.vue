<template>
  <el-dialog :title="dialog.title" :visible.sync="dialog.show" width="65%">
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="授课单元" prop="unitId" :label-width="labelWidth">
            <el-select v-model="form.unitId" clearable>
              <el-option
                v-for="courseUnit in courseUnitOptions"
                :key="courseUnit.unitId"
                :label="courseUnit.unitTitle"
                :value="courseUnit.unitId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="学员分组" prop="mgId" :label-width="labelWidth">
            <treeselect
              v-model="form.mgId"
              :options="courseMemberGroupOptions"
              style="width:217px;"
              placeholder="请选择学员分组"
              @select="courseMemberGroupChange"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="任务标题" prop="gtTitle" :label-width="labelWidth">
            <el-input
              v-model="form.gtTitle"
              type="input"
              placeholder="请输入分组任务标题"
              style="width:217px;"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="课程小组编号" :label-width="labelWidth">
            <el-button type="primary" @click="taskGroup">任务分组</el-button>
          </el-form-item>
        </el-col>
        <el-col :span="22">
          <el-form-item label="任务内容" prop="gtContent" :label-width="labelWidth">
            <tinymce ref="gtContent" v-model="form.gtContent" :save-flag="saveFlag" :height="250" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="教师评价" prop="teacherEvaluation" :label-width="labelWidth">
            <el-input
              v-model="form.teacherEvaluation"
              placeholder="请输入教师评价分数"
              maxlength="3"
              style="width:82%"
              clearable
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="组间评价" prop="groupEvaluation" :label-width="labelWidth">
            <el-input
              v-model="form.groupEvaluation"
              placeholder="请输入组间评价分数"
              maxlength="3"
              style="width:78%"
              clearable
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="任务时长" prop="taskTime" :label-width="labelWidth">
            <el-input-number v-model="form.taskTime" controls-position="right" :min="0" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="分数" prop="score" :label-width="labelWidth">
            <el-input
              v-model="form.score"
              placeholder="请输入分数"
              maxlength="3"
              style="width:78%"
              clearable
            />
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入备注" style="width:90%" />
          </el-form-item>
        </el-col>
      </el-row>
      <group-dialog
        :dialog="groupdialog"
        :course-group-options="courseGroupOptions"
        @setGtIds="setGtIds"
      />
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit">保存</el-button>
      <el-button @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import taskGroupApi from '@/api/course/regularGrade/taskGroup'
import GroupDialog from './GroupDialog'
import Tinymce from '@/components/Tinymce'
import groupTaskApi from '@/api/course/regularGrade/groupTask'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
// import USER_CONST from '@/constant/user-const'
export default {
  name: 'EditDialog',
  components: {
    Treeselect,
    Tinymce,
    GroupDialog
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseUnitOptions: {
      type: Array,
      required: true
    },
    courseMemberGroupOptions: {
      type: Array,
      required: true
    },
    form: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      groupdialog: {
        title: '',
        show: false
      },
      courseGroupOptions: [],
      labelWidth: '120px',
      // 表单校验
      rules: {
        unitId: [{ required: true, message: '请选择授课单元', trigger: 'blur' }],
        mgId: [{ required: true, message: '请选择学员分组', trigger: 'blur' }],
        gtTitle: [{ min: 3, max: 200, message: '长度在 3 到 200 个字符', trigger: 'blur' }],
        gtContent: [{ min: 3, max: 500, message: '长度在 3 到 500 个字符', trigger: 'blur' }],
        teacherEvaluation: [
          { pattern: /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/, message: '请输入正确的教师评价', trigger: 'blur' }
        ],
        groupEvaluation: [
          { pattern: /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/, message: '请输入正确的组间评价', trigger: 'blur' }
        ],
        score: [{ pattern: /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/, message: '请输入正确的分数', trigger: 'blur' }]
      },
      // 富文本开启标志
      saveFlag: false
    }
  },
  methods: {
    // 课程分组编号列表赋值
    setGtIds(value) {
      // console.log('setGtIds--value = ', value)
      this.form.gtIds = value.toString()
      // console.log('this.form = ', this.form)
    },
    // 任务分组弹窗
    taskGroup() {
      this.groupdialog.title = '任务分组'
      this.groupdialog.show = true
    },
    courseMemberGroupChange(value) {
      this.courseGroupOptions = []
      if (value != null && value !== '' && value !== undefined) {
        taskGroupApi.getCourseGroupsByMgId(value.id).then(response => {
          this.courseGroupOptions = response.data
        })
      }
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    /** 提交按钮 */
    submit: function() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.dialog.title === '添加分组任务') {
            groupTaskApi
              .addEntry(this.form)
              .then(result => {
                this.close()
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          } else if (this.dialog.title === '修改分组任务') {
            groupTaskApi
              .updateEntry(this.form)
              .then(result => {
                this.close()
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                this.$emit('getList')
              })
              .catch(err => {
                console.log(err)
              })
          }
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
