<template>
  <el-dialog :title="dialog.title" :visible.sync="dialog.show" width="50%">
    <el-form ref="form" label-width="120px">
      <el-row>
        <el-col v-if="group === '0'" :span="24">
          <el-form-item>
            <el-radio v-model="group" label="1">固定分组</el-radio>
            <el-radio v-model="group" label="2">随机分组</el-radio>
          </el-form-item>
        </el-col>

        <el-col v-if="group === '1'" :span="24">
          <el-form-item label="固定分组">
            <el-select v-model="form" multiple placeholder="请选择要分配任务的小组" clearable>
              <el-option
                v-for="courseGroup in courseGroupOptions"
                :key="courseGroup.cgroupId"
                :label="courseGroup.groupName"
                :value="courseGroup.cgroupId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="group === '2'" :span="24">
          <el-form-item label="随机分组">
            <el-input-number v-model="form" controls-position="right" :min="0" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="setGtIds">确定</el-button>
      <el-button @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
export default {
  name: 'EditDialog',
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseGroupOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      form: [],
      group: '0'
    }
  },
  methods: {
    // 课程分组编号列表赋值
    setGtIds() {
      this.$emit('setGtIds', this.form)
      this.close()
    },
    close() {
      this.$refs['form'].clearValidate()
      this.group = '0'
      this.form = []
      this.dialog.show = false
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
