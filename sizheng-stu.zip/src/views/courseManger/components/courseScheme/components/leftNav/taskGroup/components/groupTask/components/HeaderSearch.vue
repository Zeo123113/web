<template>
  <el-form ref="searchForm" :model="queryParams" inline>
    <el-form-item label="授课单元" prop="unitId">
      <el-select v-model="queryParams.unitId" placeholder="请选择授课单元" size="small" clearable>
        <el-option
          v-for="courseUnit in courseUnitOptions"
          :key="courseUnit.unitId"
          :label="courseUnit.unitTitle"
          :value="courseUnit.unitId"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="学员分组" prop="mgId">
      <treeselect
        v-model="queryParams.mgId"
        :options="courseMemberGroupOptions"
        style="width:200px;line-height: 25px;margin-top:3px"
        placeholder="请选择学员分组"
      />
    </el-form-item>
    <el-form-item label="分组任务" prop="gtTitle">
      <el-input
        v-model="queryParams.gtTitle"
        type="input"
        size="medium"
        placeholder="请输入分组任务标题"
        style="width:217px;"
      />
    </el-form-item>
    <el-form-item label="小组分数" prop="score">
      <el-input
        v-model="queryParams.score"
        placeholder="请输入分数"
        size="small"
        style="width:220px"
        clearable
      />
    </el-form-item>
    <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        size="small"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        unlink-panels
        :picker-options="pickerOptions"
        style="width:217px;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item style="margin-left:0%">
      <el-button
        type="primary"
        icon="el-icon-search"
        size="small"
        :disabled="!button.includes('course/taskGroup/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button icon="el-icon-refresh" size="small" @click="resetQuery('searchForm')">重置</el-button>
    </el-form-item>

    <el-form-item>
      <el-button
        type="primary"
        icon="el-icon-plus"
        size="small"
        :disabled="!button.includes('course/taskGroup/add')"
        @click="handleAdd"
      >新增</el-button>
    </el-form-item>
    <el-form-item>
      <el-button
        icon="el-icon-delete"
        size="small"
        type="danger"
        :disabled="deldisabled || !button.includes('course/taskGroup/delete')"
        @click="handleDeleteMore"
      >删除</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
// import USER_CONST from '@/constant/user-const'
export default {
  name: 'HeaderSearch',
  components: {
    Treeselect
  },
  props: {
    button: {
      type: Array,
      required: true
    },
    courseUnitOptions: {
      type: Array,
      required: true
    },
    courseMemberGroupOptions: {
      type: Array,
      required: true
    },
    queryParams: {
      type: Object,
      required: true
    },
    deldisabled: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      dateRange: ''
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  methods: {
    /** 搜索按钮操作 */
    handleQuery() {
      this.$emit('search')
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.$refs['searchForm'].resetFields()
      this.dateRange = ''
      // this.queryParams.orgId = null
      // this.queryParams.ctId = null
      // this.queryParams.csId = null
      // this.queryParams.schemeId = null
      this.queryParams.mgId = null
      this.queryParams.score = null
      this.queryParams.createBy = ''
      this.queryParams.gtTitle = ''
      this.queryParams.beginTime = ''
      this.queryParams.endTime = ''
      this.$emit('search')
    },
    /** 点击了新增 */
    handleAdd() {
      this.$emit('addgroupTask')
    },
    /** 点击了批量删除 */
    handleDeleteMore() {
      this.$emit('handleDeleteMore', this.ids)
    }
  }
}
</script>

<style lang="scss" scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
