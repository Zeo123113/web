<!--
@description 小组任务管理
@author chengguangyuan
-->
<template>
  <div class="outer-container">
    <!-- 搜索框 -->
    <header-search
      :query-params="queryParams"
      :button="button"
      :deldisabled="deldisabled"
      :ids="ids"
      :course-unit-options="courseUnitOptions"
      :course-member-group-options="courseMemberGroupOptions"
      @search="search"
      @addgroupTask="addgroupTask"
      @handleDeleteMore="handleDeleteMore"
    />

    <el-table
      v-loading="loading"
      :data="groupTaskData"
      tooltip-effect="light"
      row-key="gtId"
      @select="selectall"
      @select-all="selectall"
    >
      <el-table-column type="selection" align="center" width="50" />
      <el-table-column label="课程设置" prop="csId" align="center" min-width="80" />
      <el-table-column label="课程学期" prop="ctId" align="center" min-width="80" />
      <el-table-column label="教学方案" prop="schemeId" align="center" min-width="80" />
      <el-table-column label="授课单元" prop="unitId" align="center" min-width="80" />
      <el-table-column label="学员分组" prop="mgId" align="center" min-width="80" />
      <el-table-column
        label="分组任务标题"
        prop="gtTitle"
        align="center"
        show-overflow-tooltip
        min-width="120"
      />
      <el-table-column
        label="课程小组编号列表"
        prop="gtIds"
        align="center"
        show-overflow-tooltip
        min-width="150"
      />
      <el-table-column label="教师评价" prop="teacherEvaluation" align="center" min-width="100" />
      <el-table-column label="组间评价" prop="groupEvaluation" align="center" min-width="100" />
      <el-table-column label="任务时长" prop="taskTime" align="center" min-width="100" />
      <el-table-column label="分数" prop="score" align="center" min-width="100" />

      <el-table-column
        label="创建时间"
        prop="createTime"
        align="center"
        sortable
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column
        label="更新时间"
        prop="updateTime"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column label="操作" align="center" min-width="220" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="success"
            :disabled="!button.includes('course/groupTask/update')"
            @click="editgroupTask(scope.row)"
          >编辑</el-button>
          <el-button
            size="mini"
            type="danger"
            :disabled="!button.includes('course/groupTask/delete')"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="search"
    />
    <edit-dialog
      :form="groupTask"
      :dialog="dialog"
      :course-unit-options="courseUnitOptions"
      :course-member-group-options="courseMemberGroupOptions"
      @search="search"
    />
  </div>
</template>
<script>
import courseUnitApi from '@/api/course/courseManage/courseUnit'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import pagination from '@/components/Pagination/index'
import groupTaskApi from '@/api/course/regularGrade/groupTask'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import USER_CONST from '@/constant/user-const'
import { mapGetters } from 'vuex'

export default {
  components: {
    EditDialog,
    HeaderSearch,
    pagination
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      ids: [],
      groupTaskData: [],
      groupTask: {
        gtId: '',
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        mgId: null,
        gtTitle: null,
        gtContent: null,
        gtIds: null,
        teacherEvaluation: null,
        groupEvaluation: null,
        taskTime: null,
        score: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createTime: null,
        updateTime: null,
        createBy: null,
        updateBy: null,
        remark: null
      },
      dialog: {
        title: '',
        show: false
      },
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      total: 1,
      queryParams: {
        ctId: null,
        orgId: null,
        csId: null,
        schemeId: null,
        mgId: null,
        gtTitle: '',
        score: null
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      courseUnitOptions: [],
      courseMemberGroupOptions: []
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  created() {
    // 列表展示
    this.getList(this.queryParams, this.pageNum, this.pageSize)
    this.courseSchemeChange(this.courseScheme.schemeId)
  },
  methods: {
    courseSchemeChange(value) {
      if (value !== null && value !== '' && value !== undefined) {
        courseUnitApi.getRefUnitBySchemeId(value).then(response => {
          this.courseUnitOptions = response.data
        })
        courseMemberGroupApi.getCourseMemberGroupBySchemeId(value).then(response => {
          this.courseMemberGroupOptions = response.data
        })
      }
    },
    // 表单重置
    reset() {
      this.groupTask = {
        gtId: '',
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: null,
        mgId: null,
        gtTitle: null,
        gtContent: null,
        gtIds: null,
        teacherEvaluation: null,
        groupEvaluation: null,
        taskTime: null,
        score: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createTime: null,
        updateTime: null,
        createBy: null,
        updateBy: null,
        remark: null
      }
    },
    selectall(selection) {
      this.deldisabled = !this.deldisabled
      this.ids = selection.map(item => item.gtId)
    },
    addgroupTask() {
      this.reset()
      this.dialog.title = '添加分组任务'
      this.dialog.show = true
    },
    editgroupTask(row) {
      this.reset()
      this.groupTask = { ...row }
      this.dialog.title = '修改分组任务'
      this.dialog.show = true
    },
    /** 处理搜索 */
    search() {
      this.getList(this.queryParams, this.pageNum, this.pageSize)
    },
    resetForm() {
      this.search()
    },
    getList(param, pageNum, pageSize) {
      this.loading = true
      groupTaskApi
        .listgroupTask(param, pageNum, pageSize)
        .then(response => {
          this.groupTaskData = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 批量删除
    handleDeleteMore(ids) {
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return groupTaskApi.batchDelete(this.ids.toString())
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return groupTaskApi.batchDelete(row.gtId)
        })
        .then(() => {
          this.$message({
            showClose: true,
            message: '删除成功',
            duration: 3000,
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
