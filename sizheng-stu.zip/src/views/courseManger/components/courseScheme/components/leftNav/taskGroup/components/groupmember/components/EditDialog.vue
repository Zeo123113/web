<!--
@description 小组成员管理--新增与编辑窗口
@author chengguangyuan
-->
<template>
  <div class="outer-container">
    <!--begin of 新增与编辑窗口 -->
    <el-dialog
      width="46%"
      :title="title"
      :visible="isAddEditDialogVisible"
      @close="closeDialog('form')"
    >
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="用户" prop="taskGroupMemberUser" :label-width="labelWidth">
              <el-input v-model="form.taskGroupMemberUser" type="input" placeholder="请输入用户登录名" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="学号" prop="stuId" :label-width="labelWidth">
              <el-input v-model="form.stuId" disabled />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="submitForm">保 存</el-button>
        <el-button size="small" @click="cancel('form')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import taskGroupApi from '@/api/course/regularGrade/taskGroup'
import userApi from '@/api/user/user'
export default {
  name: 'EditDialog',
  props: {
    title: {
      type: String,
      required: true
    },
    isAddEditDialogVisible: {
      type: Boolean,
      required: true
    },
    form: {
      type: Object,
      required: true
    }
  },
  data() {
    var validateLoginName = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('用户名不能为空'))
      } else if (value.length < 2 || value.length > 100) {
        callback(new Error('长度在 2 到 50 个字符'))
      } else {
        userApi.checkUserByLoginName1(value).then(resp => {
          if (resp.msg !== '查找的用户不存在' || resp.data !== null) {
            this.form.userId = resp.data.userId
            this.form.stuId = resp.data.stuId
            this.form.realName = resp.data.realName
            callback()
          } else {
            callback(new Error(resp.msg))
          }
        })
      }
    }
    var validatecgroupId = (rule, value, callback) => {
      if (value != null && value === '') {
        callback(new Error('小组编号不能为空'))
      } else {
        taskGroupApi.getById(value).then(resp => {
          if (resp.msg !== '查找的课程小组不存在' || resp.data !== null) {
            this.form.cgroupId = resp.data.cgroupId
            callback()
          } else {
            callback(new Error(resp.msg))
          }
        })
      }
    }
    return {
      labelWidth: '120px',
      rules: {
        taskGroupMemberUser: [{ validator: validateLoginName, trigger: 'blur', required: true }],
        cgroupId: [{ validator: validatecgroupId, trigger: 'blur', required: true }]
      }
    }
  },
  methods: {
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.$emit('submitForm', this.form)
          this.$emit('update:isAddEditDialogVisible', false)
        }
      })
    },
    cancel(formName) {
      this.$emit('update:isAddEditDialogVisible', false)
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeDialog(formName) {
      this.$refs[formName].clearValidate()
      this.$emit('update:isAddEditDialogVisible', false)
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
