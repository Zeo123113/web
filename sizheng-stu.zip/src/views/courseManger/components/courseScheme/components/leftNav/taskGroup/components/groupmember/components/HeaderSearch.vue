<!--
@description 小组成员管理--头部搜索组件
@author chengguangyuan
-->
<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="小组名称" prop="groupName">
      <el-input
        v-model="queryParams.groupName"
        placeholder="请输入小组名称"
        size="medium"
        style="width:180px;"
        clearable
      />
    </el-form-item>
    <el-form-item label="学生学号" prop="stuId">
      <el-input
        v-model="queryParams.stuId"
        placeholder="请输入学生学号"
        size="medium"
        style="width:180px;"
        clearable
      />
    </el-form-item>
    <el-form-item label="学生姓名" prop="realName">
      <el-input
        v-model="queryParams.realName"
        placeholder="请输入学生姓名"
        size="medium"
        style="width:180px;"
        clearable
      />
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        icon="el-icon-search"
        size="small"
        :disabled="!button.includes('course/taskGroupMember/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button icon="el-icon-refresh" size="small" @click="resetQuery('searchForm')">重置</el-button>
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        icon="el-icon-plus"
        size="small"
        :disabled="!button.includes('course/taskGroupMember/add')"
        @click="handleAdd"
      >新增</el-button>
      <el-button
        type="danger"
        icon="el-icon-delete"
        size="small"
        :disabled="ids.length === 0 || !button.includes('course/taskGroupMember/deletebatch')"
        @click="handleBatchDelete"
      >删除</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
export default {
  name: 'HeaderSearch',
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    button: {
      type: Array,
      required: true
    },
    ids: {
      type: Array,
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    /** 搜索按钮操作 */
    handleQuery() {
      this.$emit('handleQuery', this.queryParams)
    },
    /** 点击了新增 */
    handleAdd() {
      this.$emit('handleAdd')
    },
    /** 点击了批量删除 */
    handleBatchDelete() {
      this.$emit('handleBatchDelete', this.ids)
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.$refs['searchForm'].resetFields()
      this.$emit('handleQuery')
    }
  }
}
</script>
<style lang="scss" scoped>
.el-form .el-form-item {
  margin-bottom: 15px;
}
.el-form-item__content {
  width: 10rem;
}
</style>
