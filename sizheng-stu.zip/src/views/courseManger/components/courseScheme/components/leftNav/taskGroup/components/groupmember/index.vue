<!--
@description 小组成员管理
@author chengguangyuan
-->
<template>
  <div class="outer-container">
    <!--搜索框-->
    <header-search
      :query-params="queryParams"
      :button="button"
      :ids="ids"
      @handleQuery="handleQuery"
      @handleAdd="handleAdd"
      @handleBatchDelete="handleBatchDelete"
    ></header-search>

    <!--表格展示-->
    <el-table
      ref="table"
      v-loading="loading"
      :data="taskGroupMemberList"
      tooltip-effect="light"
      row-key="cgmId"
      @select-all="checkboxSelectAll"
      @select="checkboxSelect"
    >
      <el-table-column type="selection" align="center" min-width="50" />
      <el-table-column label="用户ID" prop="userId" sortable align="center" min-width="90" />
      <el-table-column label="学号" prop="stuId" sortable align="center" min-width="150" />
      <el-table-column label="姓名" prop="realName" align="center" min-width="100" />
      <el-table-column label="操作" align="center" min-width="150" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button
            type="success"
            size="mini"
            :disabled="!button.includes('course/taskGroupMember/update')"
            @click="handleUpdate(scope.row)"
          >编辑</el-button>
          <el-button
            type="danger"
            size="mini"
            :disabled="!button.includes('course/taskGroupMember/delete')"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--结束表格展示-->
    <!-- 分页控件-->
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="pageQuery"
    />
    <!--新增或修改题库的对话框-->
    <edit-dialog
      :title="title"
      :is-add-edit-dialog-visible.sync="isAddEditDialogVisible"
      :form="taskGroupMember"
      @submitForm="submitForm"
    />
  </div>
</template>
<script>
import userApi from '@/api/user/user'
import { mapGetters } from 'vuex'
import COURSE_CONST from '@/constant/course-const'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import taskGroupMemberApi from '@/api/course/regularGrade/taskGroupMember'
import pagination from '@/components/Pagination/index'
export default {
  components: { HeaderSearch, pagination, EditDialog },
  data() {
    return {
      // 初始HeaderSearch的查询参数
      queryParams: {
        stuId: '',
        groupName: '',
        realName: ''
      },
      // 保存用户选择的记录ID
      ids: [],
      // 是否显示加载遮罩层
      loading: false,
      // 分页记录总条数
      total: 1,
      // 默认分页参数
      pageNum: 1,
      pageSize: COURSE_CONST.PAGESIZE,
      // 表格数据
      taskGroupMemberList: [],
      // 是否勾选表格全选复选框
      isSelectAll: false,
      // 用于向新增编辑对话框传参
      taskGroupMember: {},
      // 新增编辑对话框标题
      title: '',
      // 新增和编辑窗口是否可见
      isAddEditDialogVisible: false
    }
  },
  /**
   *从状态管理器获取按钮权限数组button
   */
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  // 初始化
  created() {
    // 查询数据
    this.getList(this.queryParams, this.pageNum, this.pageSize)
  },
  methods: {
    /** 初始化小组成员任务对象 */
    inittaskGroupMember() {
      this.taskGroupMember = {
        cgmId: -1,
        cgroupId: null,
        userId: null,
        stuId: '',
        realName: '',
        taskGroupMemberUser: ''
      }
    },
    /** 分页查询,处理分页组件上的操作 */
    pageQuery(pagePara) {
      this.getList(this.queryParams, pagePara.page, pagePara.limit)
    },
    /** 查询操作，处理条件查询操作 */
    handleQuery(param) {
      this.getList(param, this.pageNum, this.pageSize)
    },
    /** 查询列表 */
    getList(param, pageNum, pageSize) {
      this.loading = true
      taskGroupMemberApi.listtaskGroupMember(param, pageNum, pageSize).then(response => {
        this.taskGroupMemberList = response.data.list
        this.total = response.data.total
        this.loading = false
        this.ids = []
      })
    },
    /** 表格复选框选择操作 */
    checkboxSelect(selection) {
      this.isSelectAll = false
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].cgmId)
      }
    },
    /** 表格复选框全选操作 */
    checkboxSelectAll(selection) {
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].cgmId)
      }
      if (selection.length === 0) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.inittaskGroupMember()
      this.title = '添加小组成员'
      this.isAddEditDialogVisible = true
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.taskGroupMember = { ...row }
      if (row.userId !== null && row.userId !== undefined && row.userId !== '') {
        // 根据publishUserId，查询publishUserName
        userApi.getUser(row.userId).then(resp => {
          if (resp.code === 0 && resp.msg !== '查找的用户不存在') {
            this.taskGroupMember.taskGroupMemberUser = resp.data.loginName
          }
        })
      }
      this.isAddEditDialogVisible = true
      this.title = '修改小组成员'
    },
    // 处理新增编辑窗口的提交动作
    submitForm(taskGroupMember) {
      console.log('taskGroupMember = ', taskGroupMember)
      if (taskGroupMember.cgmId === -1 || taskGroupMember.cgmId === 0) {
        taskGroupMemberApi.addEntry(taskGroupMember).then(response => {
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.$message({
            type: 'success',
            message: '添加成功!'
          })
        })
      } else {
        taskGroupMemberApi.updateEntry(taskGroupMember).then(response => {
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.$message({
            type: 'success',
            message: '更新成功!'
          })
        })
      }
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('您确定要删除所选项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return taskGroupMemberApi.batchDelete(row.cgmId.toString())
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 批量删除/批量还原 */
    handleBatchDelete() {
      if (this.ids.length === 0) {
        this.$message({
          type: 'info',
          message: '请先选择要删除的条目！'
        })
        return
      }
      this.$confirm('您确定要删除所选欺项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          if (this.isSelectAll) {
            return taskGroupMemberApi.batchDeleteByCriteria(this.queryParams)
          } else {
            return taskGroupMemberApi.batchDelete(this.ids.toString())
          }
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.ids = []
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
