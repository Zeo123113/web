<template>
  <el-dialog :title="dialog.title" :visible.sync="dialog.show" width="65%">
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="学员分组" prop="mgId" :label-width="labelWidth">
            <treeselect
              v-model="form.mgId"
              :options="courseMemberGroupOptions"
              style="width:217px;"
              placeholder="请选择学员分组"
              @input="courseMemberGroupChange"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="学员姓名" prop="realName">
            <el-select
              v-model="form.realName"
              placeholder="请选择学员"
              clearable
              @change="courseMemberChange"
            >
              <el-option
                v-for="courseMember in courseMemberOptions"
                :key="courseMember.userId"
                :label="courseMember.realName"
                :value="courseMember"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="学号" prop="stuId">
            <el-input v-model="form.stuId" style="width:76%" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="用户Id" prop="userId">
            <el-input v-model="form.userId" style="width:76%" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="原始成绩列表" prop="originScore">
            <el-input v-model="form.originScore" style="width:200px;" placeholder="请输入内容70,90" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="小组成绩" prop="tgsScore" :label-width="labelWidth">
            <el-input
              v-model="form.tgsScore"
              placeholder="请输入任务小组成绩"
              clearable
              style="width:217px;"
            />
          </el-form-item>
        </el-col>
        <el-col :span="22">
          <el-form-item label="备注" prop="remark" :label-width="labelWidth">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入备注"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit">保存</el-button>
      <el-button @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import courseMemberApi from '@/api/course/courseManage/courseMember'
// import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import taskGroupScoreApi from '@/api/course/regularGrade/taskGroupScore'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
// import USER_CONST from '@/constant/user-const'
export default {
  name: 'EditDialog',
  components: {
    Treeselect
  },
  props: {
    dialog: {
      type: Object,
      default: null
    },
    courseMemberGroupOptions: {
      type: Array,
      default: null
    },
    form: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      labelWidth: '120px',
      courseMemberOptions: [],
      // 表单校验
      rules: {
        mgId: [{ required: true, message: '请选择学员分组', trigger: 'blur' }],
        realName: [{ required: true, message: '请选择学员', trigger: 'blur' }],
        groupName: [{ min: 3, max: 200, message: '长度在 3 到 200 个字符', trigger: 'blur' }],
        score: [
          { pattern: /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/, message: '请输入正确的分数', trigger: 'blur' }
        ],
        originScore: [{ required: true, message: '请填写原始成绩列表', trigger: 'blur' }]
      }
    }
  },
  methods: {
    /** 学员改变时触发 */
    courseMemberChange(value) {
      // console.log('value = ', value)
      this.form.realName = ''
      this.form.userId = null
      this.form.stuId = ''
      if (value !== null && value !== '' && value !== undefined) {
        this.form.realName = value.realName
        this.form.stuId = value.stuId
        this.form.userId = value.userId
      }
    },
    /** 学员分组变化时触发 */
    courseMemberGroupChange(value) {
      this.form.realName = null
      this.courseMemberOptions = []
      this.courseMemberChange(null)
      if (value != null && value !== '' && value !== undefined) {
        courseMemberApi.getCourseMemberListByMgId(value).then(response => {
          this.courseMemberOptions = response.data
        })
      } else {
        return
      }
    },
    close() {
      this.$refs['form'].clearValidate()
      this.dialog.show = false
    },
    /** 提交按钮 */
    submit: function() {
      this.$refs['form'].validate(valid => {
        const originScore = '[' + this.form.originScore + ']'
        this.form.originScore = JSON.stringify(originScore)
        // console.log('this.form.originScore = ', this.form.originScore)
        if (valid) {
          if (this.dialog.title === '添加课程小组') {
            taskGroupScoreApi
              .addEntry(this.form)
              .then(result => {
                this.close()
                this.$message({
                  message: '保存成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          } else if (this.dialog.title === '修改课程小组') {
            taskGroupScoreApi
              .updateEntry(this.form)
              .then(result => {
                this.close()
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                this.$emit('search')
              })
              .catch(err => {
                console.log(err)
              })
          }
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
