<template>
  <el-form ref="searchForm" :model="queryParams" inline>
    <el-form-item label="学员分组" prop="mgId">
      <treeselect
        v-model="queryParams.mgId"
        :options="courseMemberGroupOptions"
        style="width:200px;line-height:25px;margin-top:3px"
        placeholder="请选择学员分组"
        @select="courseMemberGroupChange"
      />
    </el-form-item>
    <el-form-item label="学员姓名" prop="userId">
      <el-select v-model="queryParams.userId" placeholder="请选择学员" size="medium" clearable>
        <el-option
          v-for="courseMember in courseMemberOptions"
          :key="courseMember.userId"
          :label="courseMember.realName"
          :value="courseMember.userId"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="小组成绩" prop="tgsScore">
      <el-input v-model="queryParams.tgsScore" placeholder="请输入任务小组的成绩" size="medium" clearable />
    </el-form-item>
    <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        size="medium"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        unlink-panels
        :picker-options="pickerOptions"
        style="width:200px;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item style="margin-left:0%">
      <el-button
        type="primary"
        icon="el-icon-search"
        size="small"
        :disabled="!button.includes('course/taskGroupScore/list')"
        @click="handleQuery"
      >搜索</el-button>
      <el-button icon="el-icon-refresh" size="small" @click="resetQuery('searchForm')">重置</el-button>
      <el-button
        type="primary"
        icon="el-icon-plus"
        size="small"
        :disabled="!button.includes('course/taskGroupScore/add')"
        @click="handleAdd"
      >新增</el-button>
      <el-button
        icon="el-icon-delete"
        size="small"
        type="danger"
        :disabled="deldisabled || !button.includes('course/taskGroupScore/delete')"
        @click="handleDeleteMore"
      >删除</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import courseMemberApi from '@/api/course/courseManage/courseMember'
// import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
// import USER_CONST from '@/constant/user-const'
export default {
  name: 'HeaderSearch',
  components: {
    Treeselect
  },
  props: {
    button: {
      type: Array,
      required: true
    },
    courseMemberGroupOptions: {
      type: Array,
      required: true
    },
    queryParams: {
      type: Object,
      required: true
    },
    deldisabled: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      courseMemberOptions: [],
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      dateRange: ''
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  methods: {
    /** 学员分组变化时触发 */
    courseMemberGroupChange(value) {
      this.queryParams.userId = null
      this.courseMemberOptions = []
      if (value != null && value !== '' && value !== undefined) {
        courseMemberApi.getCourseMemberListByMgId(value.id).then(response => {
          this.courseMemberOptions = response.data
        })
      } else {
        return
      }
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.$emit('search')
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.$refs['searchForm'].resetFields()
      this.dateRange = ''
      this.queryParams.mgId = null
      this.queryParams.userId = null
      this.queryParams.tgsScore = null
      this.queryParams.createBy = ''
      this.queryParams.beginTime = ''
      this.queryParams.endTime = ''
      this.$emit('search')
    },
    /** 点击了新增 */
    handleAdd() {
      this.$emit('addtaskGroupScore')
    },
    /** 点击了批量删除 */
    handleDeleteMore() {
      this.$emit('handleDeleteMore', this.ids)
    }
  }
}
</script>

<style lang="scss" scoped>
.vue-treeselect {
  height: 34px;
}
.el-form-item--medium .el-form-item__content {
  line-height: 34px;
}
</style>
