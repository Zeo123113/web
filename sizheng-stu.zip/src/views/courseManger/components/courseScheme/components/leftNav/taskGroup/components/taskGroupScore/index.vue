<!--
@description 任务小组成绩管理
@author chengguangyuan
-->
<template>
  <div class="outer-container">
    <!-- 搜索框 -->
    <header-search
      :query-params="queryParams"
      :button="button"
      :deldisabled="deldisabled"
      :ids="ids"
      :course-member-group-options="courseMemberGroupOptions"
      @search="search"
      @addtaskGroupScore="addtaskGroupScore"
      @handleDeleteMore="handleDeleteMore"
    />

    <el-table
      v-loading="loading"
      :data="taskGroupScoreData"
      tooltip-effect="light"
      row-key="tgsId"
      @select="selectall"
      @select-all="selectall"
    >
      <el-table-column type="selection" align="center" width="50" />
      <el-table-column label="学员分组" prop="mgId" align="center" min-width="80" />
      <el-table-column label="用户ID" prop="userId" sortable align="center" min-width="90" />
      <el-table-column label="学号" prop="stuId" sortable align="center" min-width="150" />
      <el-table-column label="姓名" prop="realName" align="center" min-width="100" />
      <el-table-column label="原始成绩列表" prop="originScore" align="center" min-width="120" />
      <el-table-column label="任务小组成绩" prop="tgsScore" align="center" min-width="120" />

      <el-table-column
        label="创建时间"
        prop="createTime"
        align="center"
        sortable
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column
        label="更新时间"
        prop="updateTime"
        align="center"
        min-width="120"
        show-overflow-tooltip
      />
      <el-table-column label="操作" align="center" min-width="220" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="success"
            :disabled="!button.includes('course/taskGroupScore/update')"
            @click="edittaskGroupScore(scope.row)"
          >编辑</el-button>
          <el-button
            size="mini"
            type="danger"
            :disabled="!button.includes('course/taskGroupScore/delete')"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="search"
    />
    <edit-dialog
      :form="taskGroupScore"
      :dialog="dialog"
      :course-member-group-options="courseMemberGroupOptions"
      @search="search"
    />
  </div>
</template>
<script>
import pagination from '@/components/Pagination/index'
import taskGroupScoreApi from '@/api/course/regularGrade/taskGroupScore'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import USER_CONST from '@/constant/user-const'
import { mapGetters } from 'vuex'

export default {
  components: {
    EditDialog,
    HeaderSearch,
    pagination
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      ids: [],
      taskGroupScoreData: [],
      taskGroupScore: {
        taskGroupScoreUser: '',
        tgsId: '',
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        mgId: null,
        userId: null,
        stuId: null,
        realName: null,
        originScore: null,
        tgsScore: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createTime: null,
        updateTime: null,
        createBy: null,
        updateBy: null,
        remark: null
      },
      dialog: {
        title: '',
        show: false
      },
      // 是否显示加载遮罩层
      loading: false,
      // 批量删除标记
      deldisabled: true,
      total: 1,
      queryParams: {
        ctId: this.courseScheme.ctId,
        orgId: this.courseScheme.orgId,
        csId: this.courseScheme.csId,
        schemeId: this.courseScheme.schemeId,
        mgId: null,
        userId: null,
        tgsScore: null
      },
      // 默认分页参数
      pageNum: 1,
      pageSize: USER_CONST.PAGESIZE,
      courseMemberGroupOptions: []
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  created() {
    // 列表展示
    this.getList(this.queryParams, this.pageNum, this.pageSize)
    this.courseSchemeChange(this.courseScheme.schemeId)
  },
  methods: {
    courseSchemeChange(value) {
      if (value !== null && value !== '' && value !== undefined) {
        courseMemberGroupApi.getCourseMemberGroupBySchemeId(value).then(response => {
          this.courseMemberGroupOptions = response.data
        })
      }
    },
    // 表单重置
    reset() {
      this.taskGroupScore = {
        taskGroupScoreUser: '',
        tgsId: '',
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        mgId: null,
        userId: null,
        stuId: null,
        realName: null,
        originScore: null,
        tgsScore: null,
        createOrgId: null,
        orgId: this.courseScheme.orgId,
        createTime: null,
        updateTime: null,
        createBy: null,
        updateBy: null,
        remark: null
      }
    },
    selectall(selection) {
      this.deldisabled = !this.deldisabled
      this.ids = selection.map(item => item.tgsId)
    },
    addtaskGroupScore() {
      this.reset()
      this.dialog.title = '添加课程小组'
      this.dialog.show = true
    },
    edittaskGroupScore(row) {
      this.reset()
      this.taskGroupScore = { ...row }
      this.dialog.title = '修改课程小组'
      this.dialog.show = true
    },
    /** 处理搜索 */
    search() {
      this.getList(this.queryParams, this.pageNum, this.pageSize)
    },
    resetForm() {
      this.search()
    },
    getList(param, pageNum, pageSize) {
      this.loading = true
      taskGroupScoreApi
        .listTaskGroupScore(param, pageNum, pageSize)
        .then(response => {
          this.taskGroupScoreData = response.data.list
          this.total = response.data.total
          this.loading = false
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 批量删除
    handleDeleteMore(ids) {
      this.$confirm('确定要删除所选记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return taskGroupScoreApi.batchDelete(this.ids.toString())
        })
        .then(() => {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return taskGroupScoreApi.batchDelete(row.tgsId)
        })
        .then(() => {
          this.$message({
            showClose: true,
            message: '删除成功',
            duration: 3000,
            type: 'success'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
