<!--
@description 任务小组管理
@author chengguangyuan
-->
<template>
  <div class="cd-main">
    <div class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">学员管理</div>
    </div>
    <div class="cd-main__body">
      <el-tabs v-model="activeName" type="card">
        <el-tab-pane label="课程小组管理" name="first">
          <CourseGroup :course-scheme="courseScheme" />
        </el-tab-pane>
        <el-tab-pane label="小组成员管理" name="second">
          <GroupMember :course-scheme="courseScheme" />
        </el-tab-pane>
        <el-tab-pane label="分组任务管理" name="three">
          <GroupTask :course-scheme="courseScheme" />
        </el-tab-pane>
        <el-tab-pane label="小组任务成绩管理" name="four">
          <GroupScore :course-scheme="courseScheme" />
        </el-tab-pane>
        <el-tab-pane label="任务小组成绩管理" name="five">
          <TaskGroupScore :course-scheme="courseScheme" />
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
// import orgApi from '@/api/user/org'
import CourseGroup from './components/coursegroup/index'
import GroupMember from './components/groupmember/index'
import GroupTask from './components/groupTask/index'
import GroupScore from './components/groupScore/index'
import TaskGroupScore from './components/taskGroupScore/index'

export default {
  components: {
    CourseGroup,
    GroupMember,
    GroupTask,
    GroupScore,
    TaskGroupScore
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      activeName: 'first'
    }
  },
  created() {
  }
}
</script>
<style lang="scss" scoped>
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
</style>
