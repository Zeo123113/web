<!--
@description 考试分组学员管理--新增与编辑窗口
@author cgy
-->
<template>
  <div class="outer-container">
    <!--begin of 新增与编辑窗口 -->
    <el-dialog
      width="65%"
      :title="title"
      :visible="isAddEditDialogVisible"
      @close="closeDialog('form')"
      @open="openDialog()"
    >
      <el-form ref="form" :model="examGroupMember" :rules="rules" label-width="100px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="分组名称" prop="mgId">
              <treeselect
                v-model="examGroupMember.mgId"
                :options="examMemberGroupOptions"
                style="width:217px;"
                placeholder="请选择分组名称"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学员所属机构">
              <treeselect
                v-model="userOrgId"
                :options="userOrgOptions"
                style="width:217px;"
                placeholder="请选择学员所属机构"
                :disabled="selectUserDisabled"
                @select="userOrgChange"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="选择学员" prop="selectUsers">
              <el-select
                v-model="examGroupMember.selectUsers"
                multiple
                filterable
                :disabled="selectUserDisabled"
                placeholder="请选择学员"
                style="width:100%;"
              >
                <el-option
                  v-for="item in userOptions"
                  :key="item.userId"
                  :label="item.fullName"
                  :value="item.userId"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="examGroupMember.remark"
            placeholder="请输入备注"
            type="textarea"
            :rows="4"
            clearable
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="submitForm">保 存</el-button>
        <el-button size="small" @click="cancel('form')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
// import orgApi from '@/api/user/org'
// import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import userApi from '@/api/user/user'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'EditDialog',
  components: { Treeselect },
  props: {
    title: {
      type: String,
      required: true
    },
    isAddEditDialogVisible: {
      type: Boolean,
      required: true
    },
    examGroupMember: {
      type: Object,
      required: true
    },
    examMemberGroupOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      userOrgId: null,
      selectUserDisabled: false,
      userOrgOptions: [],
      userOptions: [],
      rules: {
        mgId: [{ required: true, message: '请选择分组名称', trigger: 'blur' }],
        selectUsers: [{ required: true, message: '请选择用户', trigger: 'blur' }]
      }
    }
  },
  methods: {
    userOrgChange(value) {
      userApi.getUserListByOrgId(value.id).then(response => {
        this.userOptions = response.data
        this.userOptions.map(v => {
          v.fullName = v.stuId + '-' + v.realName
        })
      })
    },
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          const t = []
          this.examGroupMember.selectUsers.map(v => {
            let i = 0
            for (i = 0; i < this.userOptions.length; i++) {
              if (v === this.userOptions[i].userId) {
                break
              }
            }
            const user = {}
            user.userId = this.userOptions[i].userId
            user.stuId = this.userOptions[i].stuId
            user.realName = this.userOptions[i].realName
            t.push(user)
          })
          this.examGroupMember.selectUsers = JSON.stringify(t)
          this.$emit('submitForm', this.examGroupMember)
          this.$emit('update:isAddEditDialogVisible', false)
        }
      })
    },
    cancel(formName) {
      this.$emit('update:isAddEditDialogVisible', false)
    },
    openDialog() {
      if (this.examGroupMember.egmId > 0) {
        userApi.getUserListByOrgId(this.examGroupMember.orgId).then(response => {
          this.userOptions = response.data
          this.userOptions.map(v => {
            v.fullName = v.stuId + '-' + v.realName
          })
        })
        this.examGroupMember.selectUsers = []
        this.examGroupMember.selectUsers[0] = this.examGroupMember.userId
        this.selectUserDisabled = true
      } else {
        // const user = this.$store.state.user.user
        // const ancestors = user.org.ancestors.split(',')
        // this.examGroupMember.selectUsers = []
        // this.selectUserDisabled = false
      }
    },
    /** 关闭编辑窗口时，告诉父窗口子窗口已关闭 */
    closeDialog(formName) {
      this.$refs[formName].clearValidate()
      this.$emit('update:isAddEditDialogVisible', false)
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
