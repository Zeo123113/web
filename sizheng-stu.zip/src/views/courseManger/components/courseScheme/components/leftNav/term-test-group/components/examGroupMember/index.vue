<!--
@description 考试分组学员管理
@author cgy
-->
<template>
  <div class="outer-container">
    <!--搜索框-->
    <header-search
      :query-params="queryParams"
      :button="button"
      :ids="ids"
      :exam-member-group-options="examMemberGroupOptions"
      @handleQuery="handleQuery"
      @handleAdd="handleAdd"
      @handleBatchDelete="handleBatchDelete"
      @handleImport="handleImport"
    ></header-search>
    <!--表格展示-->
    <el-table
      ref="table"
      v-loading="loading"
      :data="examGroupMemberList"
      tooltip-effect="light"
      row-key="cmId"
      @select-all="checkboxSelectAll"
      @select="checkboxSelect"
    >
      <el-table-column type="selection" align="center" min-width="50" />
      <el-table-column
        label="分组名称"
        prop="mgName"
        align="left"
        min-width="150"
        show-overflow-tooltip
      />
      <el-table-column label="学号" prop="stuId" align="center" min-width="100" />
      <el-table-column label="姓名" prop="realName" align="center" min-width="100" />
      <el-table-column label="用户ID" prop="userId" align="center" min-width="100" />
      <el-table-column label="操作" align="center" min-width="130" fixed="right" style="height:90px">
        <template slot-scope="scope">
          <el-button
            type="text"
            size="mini"
            icon="el-icon-edit"
            :disabled="!button.includes('course/courseMember/update')"
            @click="handleUpdate(scope.row)"
          >编辑</el-button>
          <el-button
            type="text"
            size="mini"
            icon="el-icon-delete"
            :disabled="!button.includes('course/courseMember/delete')"
            @click="handleDelete(scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--结束表格展示-->
    <!-- 分页控件-->
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="pageNum"
      :limit.sync="pageSize"
      @pagination="pageQuery"
    />
    <!--新增或修改题库的对话框-->
    <edit-dialog
      :title="title"
      :is-add-edit-dialog-visible.sync="isAddEditDialogVisible"
      :exam-group-member="examGroupMember"
      :exam-member-group-options="examMemberGroupOptions"
      @submitForm="submitForm"
    />
    <!--导入学员的对话框-->
    <import-student
      :is-import-student-dialog-visible.sync="isImportStudentDialogVisible"
      :import-student-para="importStudentPara"
    />
  </div>
</template>
<script>
import courseMemberGroupApi from '@/api/course/courseManage/courseMemberGroup'
import { mapGetters } from 'vuex'
import COURSE_CONST from '@/constant/course-const'
import EditDialog from './components/EditDialog'
import HeaderSearch from './components/HeaderSearch'
import ImportStudent from '../ImportStudent'
// import orgApi from '@/api/user/org'
import examGroupMemberApi from '@/api/course/courseManage/examGroupMember'
import pagination from '@/components/Pagination/index'
export default {
  name: 'ExamGroupMember',
  components: { HeaderSearch, pagination, EditDialog, ImportStudent },
  props: {
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 初始HeaderSearch的查询参数
      queryParams: {
        orgId: this.courseTerm.orgId,
        csId: this.courseTerm.csId,
        ctId: this.courseTerm.ctId,
        schemeId: null,
        mgId: null,
        createBy: null
      },
      examMemberGroupOptions: [],
      // 保存用户选择的记录ID
      ids: [],
      // 是否显示加载遮罩层
      loading: false,
      // 分页记录总条数
      total: 1,
      // 默认分页参数
      pageNum: 1,
      pageSize: COURSE_CONST.PAGESIZE,
      // 表格数据
      examGroupMemberList: [],
      // 是否勾选表格全选复选框
      isSelectAll: false,
      // 用于向新增编辑对话框传参
      examGroupMember: {},
      // 新增编辑对话框标题
      title: '',
      // 新增和编辑窗口是否可见
      isAddEditDialogVisible: false,
      // 导入学员变量定义
      isImportStudentDialogVisible: false,
      importStudentPara: {}
    }
  },
  /**
   *从状态管理器获取按钮权限数组button
   */
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  // 初始化
  created() {
    courseMemberGroupApi.getExamMemberGroupBySchemeId(this.courseTerm.schemeId).then(response => {
      this.examMemberGroupOptions = response.data
    })
  },
  methods: {
    /** 初始化学员分组对象 */
    initExamGroupMember() {
      this.examGroupMember = {
        egmId: -1,
        mgId: null,
        orgId: this.courseTerm.orgId,
        csId: this.courseTerm.csId,
        ctId: this.courseTerm.ctId,
        schemeId: null,
        userId: null,
        stuId: '',
        realName: '',
        selectUsers: '',
        createOrgId: null,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: ''
      }
    },
    /** 初始化导入学员对象 */
    initImportStudent() {
      this.importStudentPara = {
        userOrgId: null,
        orgId: this.courseTerm.orgId,
        csId: this.courseTerm.csId,
        ctId: this.courseTerm.ctId,
        schemeId: null,
        mgId: null,
        groupType: '1'
      }
    },
    /** 分页查询,处理分页组件上的操作 */
    pageQuery(pagePara) {
      this.getList(this.queryParams, pagePara.page, pagePara.limit)
    },
    /** 查询操作，处理条件查询操作 */
    handleQuery(param) {
      this.getList(param, this.pageNum, this.pageSize)
    },
    /** 查询列表 */
    getList(param, pageNum, pageSize) {
      // 清空map缓存
      this.loading = true
      examGroupMemberApi.listExamGroupMember(param, pageNum, pageSize).then(response => {
        this.examGroupMemberList = response.data.list
        this.total = response.data.total
        this.loading = false
      })
    },
    /** 表格复选框选择操作 */
    checkboxSelect(selection) {
      this.isSelectAll = false
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].egmId)
      }
    },
    /** 表格复选框全选操作 */
    checkboxSelectAll(selection) {
      this.ids = []
      for (let i = 0; i < selection.length; i++) {
        this.ids.push(selection[i].egmId)
      }
      if (selection.length === 0) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.initExamGroupMember()
      this.title = '添加分组学员'
      this.isAddEditDialogVisible = true
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.examGroupMember = { ...row }
      this.isAddEditDialogVisible = true
      this.title = '修改分组学员'
    },
    // 处理新增编辑窗口的提交动作
    submitForm(examGroupMember) {
      if (examGroupMember.egmId === -1) {
        examGroupMemberApi.addEntry(examGroupMember).then(response => {
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.$message({
            type: 'success',
            message: response.data
          })
        })
      } else {
        examGroupMemberApi.updateEntry(examGroupMember).then(response => {
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.$message({
            type: 'success',
            message: '更新成功!'
          })
        })
      }
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('您确定要删除所选学员?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return examGroupMemberApi.batchDelete(row.egmId.toString())
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '学员删除成功'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 批量删除/批量还原 */
    handleBatchDelete() {
      if (this.ids.length === 0) {
        this.$message({
          type: 'info',
          message: '请先选择要删除的条目！'
        })
        return
      }
      this.$confirm('您确定要删除所选学员?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          if (this.isSelectAll) {
            return examGroupMemberApi.batchDeleteByCriteria(this.queryParams)
          } else {
            return examGroupMemberApi.batchDelete(this.ids.toString())
          }
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '学员删除成功'
          })
          this.getList(this.queryParams, this.pageNum, this.pageSize)
          this.ids = []
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 导入操作 */
    handleImport() {
      this.initImportStudent()
      this.isImportStudentDialogVisible = true
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
