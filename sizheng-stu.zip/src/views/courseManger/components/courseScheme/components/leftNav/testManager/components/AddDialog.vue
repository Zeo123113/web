<template>
  <el-dialog
    title="修改测验"
    :visible.sync="dialogFormVisible"
  >
    <el-form ref="testTask" :model="testTask" :rules="rules" label-width="220px">
      <el-row>
        <el-col :span="21">
          <el-form-item label="测验标题" prop="examTitle" :label-width="formLabelWidth">
            <el-input
              v-model="testTask.examTitle"
              placeholder="请输入测验标题"
              autocomplete="off"
              clearable
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <el-form-item label="测验安排" prop="examArrangeId" :label-width="formLabelWidth">
            <el-select v-model="testTask.examArrangeId" placeholder="请选择测验安排" clearable style="width:220px">
              <el-option
                v-for="examArrange in examArrangeOptions"
                :key="examArrange.roundId"
                :label="examArrange.examTitle"
                :value="examArrange.roundId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="所需学分" prop="requireCredit" :label-width="formLabelWidth">
            <el-input-number
              v-model="testTask.requireCredit"
              controls-position="right"
              :step="1"
              :min="0"
              :max="10"
              style="width:220px"
            ></el-input-number>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <el-form-item label="重做间隔(分钟）" prop="redoInterval" :label-width="formLabelWidth">
            <el-input-number
              v-model="testTask.redoInterval"
              controls-position="right"
              :step="10"
              :min="10"
              :max="240"
              style="width:220px"
            ></el-input-number>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="测验类型" prop="testType" :label-width="formLabelWidth">
            <el-select v-model="testTask.testType" placeholder="请选择测验类型">
              <el-option
                v-for="dict in testTypeOptions"
                :key="dict.dictvalue"
                :label="dict.dictLabel"
                :value="dict.dictValue"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <!-- <el-col :span="12">
          <el-form-item label="开始测验" prop="isBeginExam" :label-width="formLabelWidth">
            <el-switch
              v-model="testTask.isBeginExam"
              active-color="#13ce66"
              inactive-color="#ff4949"
            ></el-switch>
          </el-form-item>
        </el-col> -->
      </el-row>
      <el-row>
        <el-col :span="21">
          <el-form-item label="备注" prop="remark" :label-width="formLabelWidth">
            <el-input
              v-model="testTask.remark"
              type="textarea"
              :rows="3"
              placeholder="请输入备注"
              controls-position="right"
              :min="1"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="mini" @click="saveScoreSetting('testTask')">保存</el-button>
      <el-button size="mini" @click=" resetForm('testTask') ">取消</el-button>
    </div>
  </el-dialog>
</template>
<script>
import examArrangeApi from '@/api/exambank/examArrange'
import testTaskApi from '@/api/course/courseTask/testTask.js'
export default {
  components: {
  },
  props: {
    // 打开弹窗标志
    dialogFormVisible: {
      type: Boolean,
      default: false
    },
    // 考试
    testTask: {
      type: Object,
      required: true
    },
    // 考试安排
    examArrangeOptions: {
      type: Array,
      required: true
    },
    testTypeOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      // 验证规则
      rules: {
        examArrangeId: [{ required: true, message: '请选择教学方案', trigger: 'blur' }],
        examTitle: [{ required: true, message: '考试题目不能为空', trigger: 'blur' }],
        limitTime: [{ required: true, message: '考试时间不能为空', trigger: 'blur' },
          { type: 'number', message: '考试时长必须是数字', trigger: 'blur' }]
      },
      // 表单属性宽度
      formLabelWidth: '80px'
    }
  },
  methods: {
    // 保存表单
    saveScoreSetting(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          examArrangeApi.getExamArrange(this.testTask.examArrangeId).then(resp => {
            if (resp.code === 0) {
              this.testTask.examStartTime = resp.data.startTime
              this.testTask.limitTime = resp.data.duration
              if (!this.testTask.ttaskId) {
                this.testTask.createOrgId = this.$store.getters.user.org.orgId
                this.testTask.createBy = this.$store.getters.user.loginName
                testTaskApi.add(this.testTask).then(resp => {
                  if (resp.code === 0) {
                    this.$message({
                      type: 'success',
                      message: '保存成功'
                    })
                    this.resetForm('testTask')
                  } else {
                    this.$message({
                      message: resp.msg,
                      type: 'error'
                    })
                  }
                })
              } else {
                this.testTask.updateBy = this.$store.getters.user.loginName
                testTaskApi.update(this.testTask).then(resp => {
                  if (resp.code === 0) {
                    this.$message({
                      type: 'success',
                      message: '修改成功'
                    })
                    this.resetForm('testTask')
                  } else {
                    this.$message({
                      message: resp.msg,
                      type: 'error'
                    })
                  }
                })
              }
            }
          })
          setTimeout(() => {
            this.$emit('reGetList')
          }, 1000)
        }
      })
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.$emit('closeAdd')
    }
  }
}
</script>
<style lang="scss" scoped>
.el-dialog__wrapper >>> .el-dialog {
  width: 55%;
}
.el-dialog__wrapper {
  z-index: 1200 !important;
}
</style>
