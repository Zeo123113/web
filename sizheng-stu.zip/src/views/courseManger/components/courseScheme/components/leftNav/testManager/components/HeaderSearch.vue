<!--
@description 课程成绩设置管理
@author cuipengyuan
-->
<template>
  <div class="sort">
    <el-form
      ref="testTaskSelect"
      :inline="true"
      :model="testTaskSelect"
      class="demo-form-inline"
    >
      <el-form-item label="考试安排" prop="examArrangeId">
        <el-select v-model="testTaskSelect.examArrangeId" placeholder="请选择考试安排" clearable>
          <el-option
            v-for="examArrange in examArrangeOptions"
            :key="examArrange.roundId"
            :label="examArrange.examTitle"
            :value="examArrange.roundId"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="考试标题" prop="examTitle">
        <el-input v-model="testTaskSelect.examTitle" placeholder="请输入考试标题" clearable />
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          unlink-panels
          :picker-options="pickerOptions"
          style="width:217px;"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="el-icon-search"
          size="small"
          :disabled="!button.includes('course/examation/list')"
          @click="onSubmit"
        >搜索</el-button>
        <!-- <el-button
          type="primary"
          icon="el-icon-plus"
          size="small"
          :disabled="!button.includes('course/examation/add')"
          @click="add()"
        >添加</el-button> -->

      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  components: {
  },
  props: {
    // 封装对象
    testTaskSelect: {
      type: Object,
      default: null
    },
    button: {
      type: Array,
      required: true
    },
    // 考试安排
    examArrangeOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      // 初始化日期快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      // 日期
      dateRange: '',
      // 课程
      courseOptions: [],
      // 课程学期
      courseTermOptions: [],
      ctId: 1
    }
  },
  /** 监听日期变化 */
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.testTaskSelect.beginTime = val[0]
        this.testTaskSelect.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  created() {
    console.log(this.examArrangeOptions)
  },
  methods: {
    /** 点击搜索 */
    onSubmit() {
      this.$emit('handleQuery', this.testTaskSelect)
    },
    /** 处理添加 */
    add() {
      this.$emit('add')
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
