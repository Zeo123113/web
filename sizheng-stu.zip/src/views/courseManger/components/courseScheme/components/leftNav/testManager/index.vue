<!--
@description 考试管理
@author cpy
-->
<template>
  <div class="cd-main">
    <div v-if="main" class="cd-main__heading course-manage-info__title">
      <div class="cd-main__title">测验管理</div>
    </div>
    <div v-if="markingKey" class="cd-main__heading course-manage-info__title">
      <el-page-header content="阅卷" @back="markingToMain">
      </el-page-header>
    </div>
    <div v-if="examLogViewKey" class="cd-main__heading course-manage-info__title">
      <el-page-header content="学生答卷详情" @back="examLogViewToMain">
      </el-page-header>
    </div>
    <div v-if="examStatisticalKey" class="cd-main__heading course-manage-info__title">
      <el-page-header content="考试统计" @back="examStatisticalToMain">
      </el-page-header>
    </div>
    <div class="cd-main__body">
      <div v-if="main">
        <!-- 搜索框 -->
        <HeaderSearch
          ref="sort"
          :test-task-select="testTaskSelect"
          :exam-arrange-options="examArrangeOptions"
          :button="button"
          @handleQuery="handleQuery"
          @add="add"
        ></HeaderSearch>
        <!-- 下面是数据展示 -->
        <section v-if="testTaskList !== null || testTaskList.size !== 0" v-loading="loading" class="plea_box" style="text-align:left">
          <ol class="db">
            <li v-for="(test,index) of testTaskList" :key="index" class="zo">
              <div class="">
                <div class="mt20 my_exam_area">
                  <!-- 按钮组 -->
                  <div class="cf">
                    <div class="fr w137 tac">
                      <p class="fz20 fwb cor_ff8">{{ courseExamStatusFormat(test) }}</p>
                      <el-dropdown style="margin-top:18px">
                        <svg class="icon" aria-hidden="true">
                          <use xlink:href="#icon-shenglvehao" />
                        </svg>
                        <el-dropdown-menu slot="dropdown">
                          <el-dropdown-item>
                            <a v-if="test.isEnd !== true && test.isStart===true && test.examStatus === NOTSTART" style="color:#000" @click="startTest(test)">开始考试</a>
                            <a v-if=" !test.isEnd && test.isStart && test.examStatus !== NOTSTART" style="color:#000" @click="examLogView(test)">查看详情</a>
                          </el-dropdown-item>
                          <el-dropdown-item>
                            <a v-if="test.examStatus === COMPIETED || test.isEnd || test.examStatus === REVIEWING" style="color:#000" @click="marking(test)">开始阅卷</a>
                          </el-dropdown-item>
                          <el-dropdown-item>
                            <a v-if="test.isStart && test.examStatus == TESTING " style="color:#000" @click="ExamFinish(test)">考试结束</a>
                          </el-dropdown-item>
                          <el-dropdown-item>
                            <a style="color:#000" @click="deleteExam(test)">删除考试</a>
                          </el-dropdown-item>
                          <!-- <el-dropdown-item>
                      <a v-if="exam.examStatus === COMPIETED || exam.isEnd" style="color:#000" @click="examStatistical(exam)">考试统计</a>
                    </el-dropdown-item> -->
                          <el-dropdown-item>
                            <a v-if="test.examStatus === REVIEWING || test.isEnd" style="color:#000" @click="examReviewFinish(test)">评阅完成</a>
                          </el-dropdown-item>
                          <el-dropdown-item>
                            <a v-if="test.examStatus === WAITERESULT || test.isEnd" style="color:#000" @click="examPublish(test)">发布成绩</a>
                          </el-dropdown-item>
                        </el-dropdown-menu>
                      </el-dropdown>
                    </div>

                    <div class="ov">
                      <p class>
                        <i class="ico_examination_subjects"></i>
                        <span class="ml20 fz22">{{ test.examTitle }}</span>
                      </p>
                      <div class="mt15 cf">
                        <!-- 课程标题展示 -->
                        <div class="fl w270">
                          <p class="fz15 lh30">
                            <span class="cor_bdb">开始时间</span>
                            <span class="ml25">{{ test.examStartTime }}</span>
                          </p>
                        </div>
                        <div>
                          <p class="fz15 lh30">
                            <span class="cor_bdb">考试时长(分钟)</span>
                            <span class="ml25">{{ test.limitTime }}</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ol>
          <div v-if="testTaskList.length===0" class="nodata">
            <p>
              <svg class="icon icon-tishi" aria-hidden="true">
                <use xlink:href="#icon-tishi" />
              </svg>
            </p>
            <p>您还没有考试可管理，请先添加考试</p>
          </div>
        </section>
        <!--添加弹窗-->
        <AddDialog
          ref="addeditDialog"
          :dialog-form-visible="dialogFormVisible"
          :test-task="testTask"
          :exam-arrange-options="examArrangeOptions"
          :test-type-options="testTypeOptions"
          @closeAdd="dialogFormVisible = false"
          @reGetList="getList()"
        ></AddDialog>
        <!--分页-->
        <div v-if="total!==0" class="page_box mt30 pt10 mb10 tac">
          <el-pagination
            :current-page="pageIndex"
            :page-size="pageNum"
            layout="prev, pager, next"
            :total="total"
            prev-text="上一页"
            next-text="下一页"
            @current-change="handleCurrentChange"
          ></el-pagination>
        </div>
      </div>
      <div v-if="examLogViewKey">
        <examLogView
          :exam-log="examLog"
          :exam-status-type-dict="examStatusTypeDict"
        ></examLogView>
      </div>
      <div v-if="markingKey">
        <markingList
          :exam-log="examLog"
          :exam-status-type-dict="examStatusTypeDict"
        ></markingList>
      </div>
      <div v-if="examStatisticalKey">
        <examStatistical
          :exam-arrange-id="examArrangeId"
          :course-scheme="courseScheme"
        ></examStatistical>
      </div>

    </div>
  </div>
</template>
<script>
import HeaderSearch from './components/HeaderSearch'
import { mapGetters } from 'vuex'
import examationApi from '@/api/course/courseManage/examation.js'
import AddDialog from './components/AddDialog'
import examLogView from './components/examLogView'
import markingList from './components/markingList'
import testTaskApi from '@/api/course/courseTask/testTask.js'
import EXAMBANK_CONST from '@/constant/exambank-const'
import COURSE_CONST from '@/constant/course-const'
import ExamLogApi from '@/api/exambank/exam-record'
import examStatistical from './components/examStatistical'
export default {
  components: {
    HeaderSearch,
    AddDialog,
    examLogView,
    markingList,
    examStatistical
  },
  props: {
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 显示列表
      testTaskList: [],
      // 是否显示加载遮罩层加载
      loading: false,
      // 条件查询封装对象
      testTaskSelect: {
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        examArrangeId: '',
        orgId: this.courseScheme.orgId,
        examTitle: '',
        beginTime: '',
        endTime: ''
      },
      // 当前页
      pageIndex: 1,
      // 页数限制
      pageNum: 10,
      // 总记录数
      total: 0,
      // 批量操作数组
      multipleSelection: [],
      // 批量按钮状态
      multselect: true,
      // 在线状态数据字典
      statusValue: [],
      // 显示添加弹窗
      dialogFormVisible: false,
      // 添加/编辑成绩设置实体
      testTask: {},
      // 编辑弹窗
      editDialog: false,
      // 考试安排
      examArrangeOptions: [],
      // 考试记录对象
      examLog: {
        roundId: null,
        examType: EXAMBANK_CONST.TEST
      },
      // 考试状态数据字典
      examStatusTypeDict: [],
      testTypeOptions: [],
      // 考试状态数据字典
      courseExamStatusTypeDict: [],
      NOTSTART: COURSE_CONST.NOTSTART,
      TESTING: COURSE_CONST.TESTING,
      COMPIETED: COURSE_CONST.COMPIETED,
      REVIEWING: COURSE_CONST.REVIEWING,
      WAITERESULT: COURSE_CONST.WAITERESULT,
      PUBLISHED: COURSE_CONST.PUBLISHED,
      main: true,
      examLogViewKey: false,
      markingKey: false,
      examStatisticalKey: false,
      examArrangeId: null
    }
  },
  // 从状态管理器获取按钮权限数组button
  computed: {
    ...mapGetters({
      button: 'button',
      user: 'user'
    })
  },
  // 初始化数据
  created() {
    console.log(this.courseScheme)
    this.getList()
    this.getDataByType('course_testtask_testtype').then(response => {
      this.testTypeOptions = response.data
    })
    this.getDataByType('exambank_exam_status').then(response => {
      this.examStatusTypeDict = response.data
    })
    // 考试状态数据字典获取
    this.getDataByType('course_exam_status').then(response => {
      this.courseExamStatusTypeDict = response.data
    })
  },
  mounted() {
  },
  methods: {
    examLogViewToMain() {
      this.examLogViewKey = false
      this.main = true
    },
    markingToMain() {
      this.markingKey = false
      this.main = true
    },
    examStatisticalToMain() {
      this.examStatisticalKey = false
      this.main = true
    },
    // 初始化获取数据
    getList() {
      this.loading = true
      testTaskApi.list(this.testTaskSelect, this.pageIndex, this.pageNum).then(response => {
        this.testTaskList = response.data.list
        this.testTaskList.forEach(item => {
          var nowTime = this.format(new Date(), 'yyyy-MM-dd HH:mm:ss')
          var remainTime =  this.GetDateDiff(nowTime, item.examStartTime, 'second')
          if (remainTime + item.limitTime * 60 < 0) {
            this.$set(item, 'isEnd', true)
          } else {
            this.$set(item, 'isEnd', false)
          }
          if (remainTime > 0) {
            this.$set(item, 'isStart', false)
          } else {
            this.$set(item, 'isStart', true)
          }
        })
        this.total = response.data.total
        this.loading = false
      })
      examationApi.examArrangeList(this.courseScheme.csId, this.courseScheme.ctId).then(response => {
        console.log(response.data)
        this.examArrangeOptions = response.data
      })
    },
    // 搜索处理
    handleQuery(param) {
      this.getList(param, this.pageIndex, this.pageSize)
    },
    /** 课程考试状态类型类型字典翻译 */
    courseExamStatusFormat(row) {
      return this.selectDictLabel(this.courseExamStatusTypeDict, row.examStatus)
    },
    initTestTask() {
      this.testTask = {
        csId: this.courseScheme.csId,
        ctId: this.courseScheme.ctId,
        schemeId: this.courseScheme.schemeId,
        unitId: '',
        examArrangeId: '',
        requireCredit: '',
        redoInterval: '',
        limitTime: '',
        ttaskId: '',
        testType: '',
        orgId: this.courseScheme.orgId,
        examTitle: '',
        beginTime: '',
        endTime: '',
        createOrgId: '',
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: ''
      }
    },
    // 处理添加
    add() {
      this.initTestTask()
      this.dialogFormVisible = true
    },
    // 处理开始考试
    startTest(test) {
      this.$confirm('确定要开始测验吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        test.isBeginExam = true
        test.examStatus = this.TESTING
        var data = {
          roundId: test.examArrangeId,
          examType: EXAMBANK_CONST.TEST,
          courseId: this.courseScheme.csId,
          termId: this.courseScheme.ctId,
          courseSchemaId: this.courseScheme.schemeId
        }
        ExamLogApi.addExamLog(data)
        testTaskApi.update(test).then(resp => {
          if (resp.code === 0) {
            this.$message({
              type: 'success',
              message: '测验开始'
            })
            this.examLog.roundId = test.examArrangeId
            this.examLog.termId = this.courseScheme.ctId
            this.main = false
            this.examLogViewKey = true
          } else {
            this.$message({
              message: resp.msg,
              type: 'error'
            })
          }
        })
      })
    },
    examLogView(test) {
      this.main = false
      this.examLogViewKey = true
      this.examLog.roundId = test.examArrangeId
    },
    // 处理编辑
    editTest(row) {
      this.testTask = { ...row }
      examationApi.examArrangeList(row.csId, row.ctId).then(response => {
        this.examArrangeOptions = response.data
      })
      this.dialogFormVisible = true
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    },
    /**
     *处理删除
     */
    deleteTest(row) {
      this.$confirm('确定要删除这条记录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        testTaskApi
          .delete(row.ttaskId)
          .then(resp => {
            if (resp.code === 0) {
              this.$message({
                message: '删除成功',
                type: 'success'
              })
            } else {
              this.$message({
                message: resp.msg,
                type: 'error'
              })
            }
            this.getList()
          })
          .catch(err => {
            console.log(err)
          })
      })
    },
    /**
     * 处理成绩发布
     */
    testPublish(test) {
      this.$confirm('确定要发布成绩吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        test.examStatus = this.PUBLISHED
        testTaskApi.update(test).then(resp => {
          if (resp.code === 0) {
            this.getList()
          }
        })
      })
    },
    marking(test) {
      if (test.examStatus === this.REVIEWING) {
        this.examLog.roundId = test.examArrangeId
        this.main = false
        this.markingKey = true
      } else {
        test.examStatus = this.REVIEWING
        testTaskApi.update(test).then(resp => {
          if (resp.code === 0) {
            this.examLog.roundId = test.examArrangeId
            this.main = false
            this.markingKey = true
          }
        })
      }
    },
    /**
     * 处理统计
     */
    testStatistical(test) {
      this.examStatisticalKey = true
      this.main = false
      this.examArrangeId = test.examArrangeId
    },

    /**
     * 评阅完成
     */
    testReviewFinish(test) {
      this.$confirm('阅卷已完成?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        test.examStatus = this.WAITERESULT
        testTaskApi.update(test).then(resp => {
          if (resp.code === 0) {
            this.getList()
          }
        })
      })
    },
    /**
     * 测验完成
     */
    testFinish(test) {
      this.$confirm('确定要结束测验吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        test.examStatus = this.COMPIETED
        testTaskApi.update(test).then(resp => {
          if (resp.code === 0) {
            this.getList()
          }
        })
      })
    },
    /**
     * 计算考试开始时间和当前时间相差数
     */
    GetDateDiff(startTime, endTime, diffType) {
      startTime = startTime.replace(/\-/g, '/')
      endTime = endTime.replace(/\-/g, '/')
      diffType = diffType.toLowerCase()
      var sTime = new Date(startTime)    // 开始时间
      var eTime = new Date(endTime)  // 结束时间</font>
      // 作为除数的数字
      var divNum = 1
      switch (diffType) {
        case 'second':
          divNum = 1000
          break
        case 'minute':
          divNum = 1000 * 60
          break
        case 'hour':
          divNum = 1000 * 3600
          break
        case 'day':
          divNum = 1000 * 3600 * 24
          break
        default:
          break
      }
      return parseInt((eTime.getTime() - sTime.getTime()) / parseInt(divNum))
    },
    /**
     * 获取当前时间
     */
    format(date, fmt) {
      const o = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'H+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        'S': date.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      for (const k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
      return fmt
    }
  }
}
</script>
<style lang="scss" scoped>
.cd-main {
  margin-left: 200px;
  background: #fff;
  border-radius: 0 4px 4px 0;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-main__heading {
  padding: 24px 32px;
  box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.08);
}
.cd-main__heading .cd-main__title {
  font-size: 16px;
  color: rgba(0, 0, 0, 0.88);
  line-height: 1;
  margin: 0 auto;
  font-weight: 500;
}
.cd-main__body {
  padding: 32px;
  min-height: 900px;
}
.icon {
  cursor: pointer;
}
.course-price {
  color: #ed3e3e;
  font-size: 14px;
  width: 1rem;
  height: 1rem;
}
.course-info {
  width: 10rem;
  margin-left: 1rem;
  height: 26px;
}
.course-title {
  width: 50rem;
  height: 26px;
  padding-top: 0.5rem;
}
.course-cover {
  width: 10rem;
  margin-left: 1rem;
  height: 26px;
}
.course-cover img {
  float: left;
  margin-left: 0;
  width: 10rem;
  height: 6rem;
  margin-top: -1.2rem;
  border-radius: 10%;
}
.course-left {
  width: 80%;
  float: left;
}
.course-button {
  margin-left: 60rem;
  /* // width: 20rem; */
  display: inline-block;
}
/* // .el-main {
//   width: 80%;
//   // height: 500px;
//   margin: 0 auto;
// } */
.all {
  font-size: 16px;
  padding: 0 25px;
  height: 35px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  color: #fff;
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  margin-bottom: 18px;
  padding: 50px;
  background: #fff;
  margin: 0 32px;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 20px;
  font-weight: 700;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
  margin-top: -42px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.ml124 {
  margin-left: 124px;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
.course-publish-status--unpublished {
  background-color: #707070;
}
.course-publish-status {
  position: absolute;
  left: -6px;
  top: 28px;
  padding: 9px 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
}
.icon {
  width: 2.5em;
  height: 2.55em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-left: 20px;
}
a {
  text-decoration: none;
}
.course-manage-header-info__title {
  margin-top: 4px;
  margin-bottom: 0;
  min-height: 5px;
  font-size: 16px;
  line-height: 1;
  font-weight: 500;
  width: 250px;
}
.ellipsis,
.text-overflow {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}
.course-manage-header-info {
  float: left;
  margin-left: 71px;
}
.course-publish-status--published {
  background-color: #18ad3b;
}

.course-publish-status {
  position: absolute;
  left: -6px;
  top: 28px;
  padding: 9px 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
}
.courses-manage-item .course-manage-header {
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 2px 2px 0 rgba(0, 0, 0, 0.06);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
}

.course-manage-header {
  position: relative;
  margin-bottom: 0;
  padding: 20px 32px 20px 24px;
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 0 2px 0 rgba(0, 0, 0, 0.06),
    0 0 2px 0 rgba(0, 0, 0, 0.1);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 0 2px 0 rgba(0, 0, 0, 0.06), 0 0 2px 0 rgba(0, 0, 0, 0.1);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 0 2px 0 rgba(0, 0, 0, 0.06), 0 0 2px 0 rgba(0, 0, 0, 0.1);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  background-color: #fff;
}
.cd-mb24 {
  margin-bottom: 24px !important;
}
.courses-manage-list {
  padding-left: 6px;
  list-style: none;
}

ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.cd-select .select-options > li:first-child {
  border-radius: 4px 4px 0 0;
}

.cd-select .select-options > li.checked,
.cd-select .select-options > li.checked:hover {
  background: #fafafa;
}
.cd-select .select-options > li {
  position: relative;
  padding: 16px;
  line-height: 1;
  color: rgba(0, 0, 0, 0.88);
  background: none;
  white-space: nowrap;
  display: block;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-select .select-options {
  top: 100%;
  left: 0;
  right: 0;
  z-index: 1000;
  display: none;
  border: none;
  text-align: left;
  padding: 0;
  margin: 0;
  max-height: 220px;
  overflow-x: hidden;
  overflow-y: auto;
  -webkit-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01),
    0 8px 8px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01),
    0 8px 8px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01), 0 8px 8px 0 rgba(0, 0, 0, 0.04);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  font-size: 12px;
  background-color: #fff;
  opacity: 0;
}

.cd-select .select-options,
.cd-select .select-value:after {
  position: absolute;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-select .select-value {
  padding: 5px 0 4px;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.88);
  border-bottom: 1px solid rgba(0, 0, 0, 0.16);
  padding-bottom: -1px;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.teaching-type-select {
  width: 276px;
  height: 34px;
}

.cd-select {
  position: relative;
  height: 30px;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.hide {
  display: none !important;
}
.cd-btn.cd-btn-default {
  color: rgba(0, 0, 0, 0.88);
  background: #ececec;
  border-color: #ececec;
}

.cd-btn.cd-btn-default,
.cd-btn.cd-btn-warning:active {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.cd-ml16 {
  margin-left: 16px !important;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

.cd-btn.cd-btn-primary {
  color: #fff;
  background: #43bc60;
  border-color: #43bc60;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
a {
  text-decoration: none;
}
a {
  color: #43bc60;
}
.pull-right {
  float: right !important;
}
.cd-mb24 {
  margin-bottom: 24px !important;
}
.courseset-manage-padding {
  padding: 32px 0;
}

.courseset-manage-body {
  margin-top: 1px !important;
  min-height: 550px;
  background-color: #fff;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-content {
  position: relative;
  border-radius: 4px;
  margin-top: 24px;
  margin-bottom: 24px;
}
.course_content {
  padding-left: 0;
  padding-right: 0;
  // padding-right: 12px;
  margin: 0 auto;
  position: relative;
  border-radius: 4px;
  margin-top: 10px;
  margin-bottom: 24px;
}
.icon{
  width:2em;
  height:2em
}
</style>
