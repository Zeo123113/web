<template>
  <el-dialog
    :title="dialog.title"
    :visible.sync="dialog.show"
    width="60%"
    @close="close"
    @open="open"
  >
    <el-form ref="courseScheme" :model="courseScheme" :rules="rules" label-width="150px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="课程学期" prop="ctId">
            <el-select v-model="courseScheme.ctId" placeholder="请选择学期" @change="selectCourseTerm">
              <el-option
                v-for="term in courseTerms"
                :key="term.ctId"
                :label="term.courseTerm"
                :value="term.ctId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="20">
          <el-form-item label="标题" prop="schemeTitle">
            <el-input v-model="courseScheme.schemeTitle" placeholder="请输入标题" clearable />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="学习模式" prop="learnMode">
            <el-radio-group v-model="courseScheme.learnMode">
              <el-radio
                v-for="dict in learnModeOptions"
                :key="dict.dictvalue"
                :label="dict.dictValue"
              >{{ dict.dictLabel }}</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="是默认教学计划" prop="isDefaultScheme">
            <el-switch v-model="courseScheme.isDefaultScheme"></el-switch>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="small" @click="submit('courseScheme')">保 存</el-button>
      <el-button size="small" @click="dialog.show = false">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { mapGetters } from 'vuex'
import courseTermApi from '@/api/course/courseManage/courseTerm'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
export default {
  name: 'AddSchemeDialog',
  components: {
  },
  props: {
    coursedetail: {
      type: Object,
      required: true
    },
    dialog: {
      type: Object,
      required: true
    },
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    // 验证计划标题是否唯一
    const validateSchemeTitle = (rule, value, callback) => {
      console.log('value = ', value)
      if (value === null || value === '' || value === undefined) {
        return callback(new Error('授课方案标题不能为空'))
      } else if (value.length < 3 || value.length > 20) {
        return callback(new Error('字符长度在 3 到 20 个字符'))
      }
      this.courseScheme.schemeTitle = value
      courseSchemeApi
        .validateSchemeTitle(this.courseScheme)
        .then(function(resp) {
          console.log('resp = ', resp)
          if (resp.data < 1) {
            callback()
          } else {
            callback(new Error('学期名已存在,请重新输入'))
          }
        })
    }
    return {
      rules: {
        schemeTitle: [{ validator: validateSchemeTitle, trigger: 'blur' }]
      },
      learnModeOptions: [],
      courseTerms: [],
      courseTerm: {}
    }
  },
  // 从状态管理器获取按钮权限数组user
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  methods: {
    validateCtId() {
      // 多教师情况下只有负责人能创建
      if (this.courseTerm.teachingMode === '1') {
        // 判断是否为负责人(负责人默认为一个)
        const courseLeaders = JSON.parse(this.coursedetail.courseLeaders)
        // 且判断该学期下是否有默认计划
        if (this.user.userId !== courseLeaders[0]) {
          this.close()
          // 不可以创建方案
          this.$message({
            message: '只有课程负责人能创建授课计划',
            type: 'warning'
          })
          return
        }
      }
    },
    // 课程学期变化后触发
    selectCourseTerm(val) {
      if (val == null || val === undefined) {
        return
      }
      console.log('val = ', val)
      courseTermApi.getCourseTermById(val).then(response => {
        this.courseTerm = response.data
        this.validateCtId()
      })
    },
    open() {
      // 学习模式字典获取
      this.getDataByType('course_learn_mode').then(response => {
        this.learnModeOptions = response.data
      })
      this.getList()
    },
    // 获取课程学期列表
    getList() {
      // 获取课程设置详情
      const csId = parseInt(this.$route.params.csId)
      // 根据课程设置ID获取课程学期列表
      courseTermApi.getTermPageByCId(csId, 1, 10).then(resp => {
        this.courseTerms = resp.data.list
      })
    },
    close() {
      this.$refs['courseScheme'].clearValidate()
      this.dialog.show = false
    },
    // 点击确定
    submit(courseScheme) {
      this.$refs[courseScheme].validate(valid => {
        if (valid) {
          this.courseScheme.teacherIds = '[]'
          courseSchemeApi.add(this.courseScheme)
            .then(result => {
              if (result.code === 0) {
                this.$message({
                  type: 'success',
                  message: '添加成功'
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '添加失败'
                })
              }
              this.close()
              this.$emit('getList')
            })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
.input {
  width: 80%;
}
.el-dialog__body {
  padding-right: 81px;
}
</style>
