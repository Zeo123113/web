<template>
  <el-dialog
    :title="dialog.title"
    :visible.sync="dialog.show"
    width="60%"
    @close="close"
    @open="open"
  >
    <el-form ref="courseScheme" :model="courseScheme" :rules="rules" label-width="150px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="课程学期" prop="ctId">
            <el-select v-model="courseScheme.ctId" placeholder="请选择学期" clearable>
              <el-option
                v-for="courseTerm in courseTerms"
                :key="courseTerm.ctId"
                :label="courseTerm.courseTerm"
                :value="courseTerm.ctId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="20">
          <el-form-item label="标题" prop="schemeTitle">
            <el-input v-model="courseScheme.schemeTitle" placeholder="请输入标题" clearable />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button v-if="!hold" type="primary" size="small" @click="submit('courseScheme')">保 存</el-button>
      <el-button
        v-if="hold"
        type="primary"
        class="course-btn-submit"
        size="small"
        disabled
      >正 在 保 存 ...</el-button>
      <el-button size="small" @click="dialog.show = false">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
// import Treeselect from '@riophae/vue-treeselect'
// import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import courseTermApi from '@/api/course/courseManage/courseTerm'
export default {
  name: 'AddSchemeDialog',
  components: {
  },
  props: {
    dialog: {
      type: Object,
      required: true
    },
    courseScheme: {
      type: Object,
      required: true
    }
  },
  data() {
    // 验证计划标题是否唯一
    const validateSchemeTitle = (rule, value, callback) => {
      console.log('value = ', value)
      if (value === null || value === '' || value === undefined) {
        return callback(new Error('授课方案标题不能为空'))
      } else if (value.length < 3 || value.length > 20) {
        return callback(new Error('字符长度在 3 到 20 个字符'))
      }
      this.courseScheme.schemeTitle = value

      const courseScheme = { ...this.courseScheme }
      courseScheme.schemeId = null
      courseSchemeApi
        .validateSchemeTitle(courseScheme)
        .then(function(resp) {
          console.log('resp = ', resp)
          if (resp.data < 1) {
            callback()
          } else {
            callback(new Error('学期名已存在,请重新输入'))
          }
        })
    }
    return {
      // 正在保存
      hold: false,
      rules: {
        ctId: [{ required: true, message: '请选择学期', trigger: 'blur' }],
        schemeTitle: [{ validator: validateSchemeTitle, trigger: 'blur' }]
      },
      learnModeOptions: [],
      courseTerms: []
    }
  },
  created() {
  },
  methods: {
    open() {
      // 学习模式字典获取
      this.getDataByType('course_learn_mode').then(response => {
        this.learnModeOptions = response.data
      })
      this.getList()
    },
    // 获取课程学期列表
    getList() {
      // 获取课程设置详情
      const csId = this.$route.params.csId
      // 根据课程设置ID获取课程学期列表
      courseTermApi.getTermPageByCId(csId, 1, 10).then(resp => {
        this.courseTerms = resp.data.list
      })
    },
    close() {
      this.$refs['courseScheme'].clearValidate()
      this.dialog.show = false
    },
    // 点击确定
    submit(courseScheme) {
      this.hold = true
      this.$refs[courseScheme].validate(valid => {
        if (valid) {
          this.courseScheme.teacherIds = '[]'
          this.courseScheme.isDefaultScheme = false
          this.courseScheme.schemeStatus = '0'
          courseSchemeApi.copyBySchemeId(this.courseScheme)
            .then(result => {
              if (result.code === 0) {
                this.$message({
                  type: 'success',
                  message: '复制计划成功'
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '复制失败'
                })
              }
              this.hold = false
              this.close()
              this.$emit('getList')
            })
            .catch(err => {
              this.hold = false
              console.log(err)
            })
        } else {
          this.hold = false
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
.input {
  width: 80%;
}
.el-dialog__body {
  padding-right: 81px;
}
</style>
