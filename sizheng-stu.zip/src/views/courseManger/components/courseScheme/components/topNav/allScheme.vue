<!--
@description 课程全部计划
@author cgy
-->
<template>
  <div class="course_content">
    <div role="courseset-manage-courses" style="margin:0 32px">
      <div class="cd-mb24 clearfix">
        <div v-show="state === ''" class="pull-right">
          <div class="js-sort-group hidden-xs">
            <a class="cd-btn cd-btn-primary js-create-plan" @click="schemeManger(null)">创建计划</a>
            <!-- <button class="cd-btn cd-btn-default cd-ml16 js-sort-btn">调整顺序</button> -->
          </div>
          <!-- <div class="js-sort-group hidden-xs hide">
              <button class="cd-btn cd-btn-primary cd-mr16 js-save-sort-btn">保存排序</button>
              <button class="cd-btn cd-btn-default js-cancel-sort-btn">取消排序</button>
          </div>-->
        </div>
        <div id="select-single" class="cd-select teaching-type-select">
          <el-dropdown trigger="click" @command="handleScheme">
            <span class="el-dropdown-link">
              {{ dropdown }}
              <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                v-for="item in schemeStatusOptions"
                :key="item.dictValue"
                :label="item.dictValue"
                :command="item"
              >{{ item.dictLabel }}</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    </div>
    <section v-loading="loading">
      <ol class="db">
        <li v-for="(scheme,index) of courseSchemeData" :key="index" class="mod-qa-list">
          <div class="course-left">
            <!-- 课程封面 -->
            <div class="course-cover">
              <span
                v-if="scheme.schemeStatus === '0'"
                class="course-publish-status course-publish-status--unpublished"
              >未发布</span>
              <span
                v-if="scheme.schemeStatus === '1'"
                class="course-publish-status course-publish-status--published"
              >已发布</span>
              <span
                v-if="scheme.schemeStatus === '2'"
                class="course-publish-status course-publish-status--unpublished"
              >已关闭</span>
            </div>
            <div class="course-info">
              <!-- 课程标题展示 -->
              <el-row style="display: flex">
                <el-col :span="12" style="padding-left: 5rem; margin-bottom: -10px;">
                  <div class="qt-tit ml124 click course-title">
                    <ul>
                      <li>{{ scheme.courseTitle }}</li>
                      <li>{{ scheme.courseTerm }}</li>
                      <li>{{ scheme.schemeTitle }}</li>
                    </ul>

                    <!-- 开课计划描述 -->
                    <!-- <span
                    class="course-price"
                    style="display: block;width:50rem"
                    >{{ scheme.schemeSubtitle }}</span>-->
                  </div>
                </el-col>
                <el-col :span="12" style="align-self: center">
                  <div v-if="scheme.isDefaultScheme" class="defualt-plan">默认计划</div>
                </el-col>
              </el-row>
            </div>
          </div>
          <!-- 按钮组 -->
          <div class="course-button">
            <el-tooltip
              v-if="scheme.schemeStatus !== '2'"
              content="计划管理"
              placement="bottom"
              effect="light"
            >
              <svg class="icon" aria-hidden="true" @click="schemeManger(scheme)">
                <use xlink:href="#icon-chilunshezhi" />
              </svg>
            </el-tooltip>

            <el-dropdown>
              <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-shenglvehao" />
              </svg>
              <!-- 已发布 -->
              <el-dropdown-menu v-if="scheme.schemeStatus === '1'" slot="dropdown">
                <el-dropdown-item>
                  <a @click="forwardScheme(scheme)">查看计划</a>
                </el-dropdown-item>
                <el-dropdown-item v-if="!isCopyScheme(scheme)">
                  <a @click="copyScheme(scheme)">允许复制</a>
                </el-dropdown-item>
                <el-dropdown-item v-if="isCopyScheme(scheme)">
                  <a @click="copyScheme(scheme)">复制</a>
                </el-dropdown-item>
                <el-dropdown-item v-if="isLeading(scheme)">
                  <a @click="publishCourse(scheme, '2')">关闭</a>
                </el-dropdown-item>
              </el-dropdown-menu>
              <!-- 未发布 -->
              <el-dropdown-menu v-if="scheme.schemeStatus === '0'" slot="dropdown">
                <el-dropdown-item>
                  <a @click="forwardScheme(scheme)">查看计划</a>
                </el-dropdown-item>
                <el-dropdown-item>
                  <a @click="publishCourse(scheme, '1')">发布计划</a>
                </el-dropdown-item>
                <el-dropdown-item v-if="!isCopyScheme(scheme)">
                  <a @click="copyScheme(scheme)">允许复制</a>
                </el-dropdown-item>
                <el-dropdown-item v-if="!scheme.isDefaultScheme && isLeading(scheme)">
                  <a @click="fakeDelete(scheme.schemeId, scheme.createOrgId)">删除</a>
                </el-dropdown-item>
              </el-dropdown-menu>
              <!-- 已关闭 -->
              <el-dropdown-menu v-if="scheme.schemeStatus === '2'" slot="dropdown">
                <el-dropdown-item v-if="!scheme.isDefaultScheme && isLeading(scheme)">
                  <a @click="fakeDelete(scheme.schemeId, scheme.createOrgId)">删除</a>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </li>
      </ol>
      <component
        :is="state"
        :course-scheme="courseScheme"
        :course-term="courseTerm"
        @getList="getList"
      ></component>
      <div v-if="courseSchemeData.length < 1" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>您还没有计划可管理，请先创建计划</p>
      </div>
    </section>
    <!--分页-->
    <div v-if="courseSchemeData.length > 1" class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="courseSchemeData.length"
        prev-text="上一页"
        next-text="下一页"
        @current-change="getList"
      ></el-pagination>
    </div>
    <!--分页-->

    <!--新增课程计划的对话框-->
    <add-scheme-dialog
      :dialog="dialog"
      :course-scheme="courseScheme"
      :coursedetail="coursedetail"
      @getList="getList"
    />
    <!--复制课程计划的对话框-->
    <copy-scheme-dialog
      :dialog="copyDialog"
      :course-scheme="courseScheme"
      :coursedetail="coursedetail"
      @getList="getList"
    />
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import SchemeSetting from './SchemeSetting'
import CopySchemeDialog from './CopySchemeDialog'
import AddSchemeDialog from './AddSchemeDialog'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import courseTermApi from '@/api/course/courseManage/courseTerm'
// import courseSetApi from '@/api/course/courseManage/courseSet'
export default {
  name: 'AllScheme',
  components: {
    SchemeSetting,
    AddSchemeDialog,
    CopySchemeDialog
  },
  props: {
    coursedetail: {
      type: Object,
      required: true
    },
    courseTerm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      isCreate: true,
      pageSize: 10,
      pageIndex: 1,
      total: 1,
      loading: false,
      schemeStatusOptions: [{ 'dictValue': null, 'dictLabel': '全部计划' }],
      dropdown: '全部计划',
      courseSchemeData: [],
      courseSchemes: [],
      courseScheme: {},
      state: '',
      dialog: {
        title: '',
        show: false
      },
      copyDialog: {
        title: '',
        show: false
      }
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  created() {
    // 教学计划状态字典获取
    this.getDataByType('course_scheme_status').then(response => {
      const all = { 'dictValue': null, 'dictLabel': '全部计划' }
      this.schemeStatusOptions = [all, ...response.data]
    })
    this.getList(1)
  },
  methods: {
    // 查看学期
    forwardScheme(courseScheme) {
      // 路由跳转
      // this.$router.push({  // 核心语句
      //   path: `/courseSet/${courseScheme.csId}/term/${courseScheme.ctId}/scheme/${courseScheme.schemeId}`
      // })
    },
    // 只有负责人能关闭
    isLeading(scheme) {
      console.log('isLeading = ')
      // 根据schemeId,查询出其上面的计划
      let courseTerm = {}
      courseTermApi.getCourseTermById(scheme.ctId).then(resp => {
        courseTerm = resp.data
      })
      if (courseTerm.teachingMode === '1') {
        // 判断是否为负责人(负责人默认为一个)
        const courseLeaders = JSON.parse(this.coursedetail.courseLeaders)
        // 且判断该学期下是否有默认计划
        if (this.user.userId !== courseLeaders[0]) {
          return false
        } else {
          return true
        }
      } else {
        return true
      }
    },
    // 判断是否可以复制计划
    isCopyScheme(courseScheme) {
      // 1，自己创建的计划可以复制
      const user = this.user
      // console.log('user.orgId = ', user.orgId)
      // console.log('courseScheme = ', courseScheme.createOrgId)
      const createOrgId = courseScheme.createOrgId
      const orgId = user.orgId
      if (orgId === createOrgId) {
        return true
      } else if (courseScheme.isDefaultScheme && courseScheme.isCopyScheme) {
        // 2，默认计划+允许复制字段
        return true
      } else {
        return false
      }
    },
    // 复制计划
    copyScheme(courseScheme) {
      this.courseScheme = { ...courseScheme }
      // this.courseScheme.schemeId = null
      this.copyDialog.title = '复制计划'
      this.copyDialog.show = true
    },
    // 没有课程学期展示
    isShow(courseSchemeData) {
      if (this.state !== '') {
        return false
      }
      return courseSchemeData == null || !courseSchemeData.length
    },
    // 获取教学计划
    getList(val) {
      if (val === undefined || val == null) {
        val = 1
      }
      this.loading = true
      this.state = ''
      const ctId = this.courseTerm.ctId
      // console.log('ctId = ', ctId)
      if (ctId === undefined || ctId == null) {
        this.getschemeByCsId(val)
      } else {
        courseSchemeApi.getCourseSchemePageByCtId(ctId, val, this.pageSize).then(resp => {
          this.courseSchemes = resp.data.list
          this.courseSchemeData = resp.data.list
          this.loading = false
        })
      }
    },
    // 发布课程
    publishCourse(scheme, schemeStatus) {
      this.$confirm('是否确定发布该课程?', '发布课程', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info'
      }).then(() => {
        // 数据库修改课程发布状态
        scheme.schemeStatus = schemeStatus
        courseSchemeApi.update(scheme).then(result => {
          if (result.code === 0) {
            this.$message({
              type: 'success',
              message: '课程发布成功'
            })
          } else {
            this.$message({
              type: 'error',
              message: '课程发布失败'
            })
          }
          this.getList(1)
        })
      }).catch(() => {
        this.$message({
          type: 'error',
          message: '课程发布失败'
        })
      })
    },
    // 计划管理
    schemeManger(courseScheme) {
      // 创建计划
      if (courseScheme == null || courseScheme === '' || courseScheme === undefined) {
        // console.log('courseScheme = ', courseScheme)
        this.initCourseScheme()
        this.courseScheme.csId = this.coursedetail.csId
        // this.courseScheme.ctId = this.courseTerm.ctId
        this.dialog.title = '创建计划'
        this.dialog.show = true
        return
      }
      if (this.state !== '') {
        this.state = ''
        this.courseSchemeData = this.courseSchemes
        return
      } else {
        // this.courseSchemeData = this.courseSchemeData.filter(item => item.schemeId === courseScheme.schemeId)
        this.courseSchemeData = []
        this.courseSchemeData.push(courseScheme)
        // console.log('courseScheme = ', courseScheme)
        this.courseScheme = { ...courseScheme }
        // this.courseScheme.teacherIds = JSON.stringify(this.courseScheme.teacherIds)
        this.courseScheme.orgId = this.user.orgId
        this.state = 'SchemeSetting'
      }
    },
    // 查看计划
    allScheme() {
      const csId = this.$route.params.csId
      // 路由跳转
      this.$router.push({  // 核心语句
        path: `/courseManger/${csId}/AllScheme`
      })
    },
    // 根据csId查询授课计划
    getschemeByCsId(val) {
      // 获取课程设置详情
      const csId = this.coursedetail.csId
      if (csId === undefined || csId == null) {
        this.loading = false
        return
      }
      // 根据课程设置ID获取授课计划列表
      courseSchemeApi.getCourseSchemeByCsId(csId, val, this.pageSize).then(resp => {
        this.courseSchemes = resp.data.list
        this.courseSchemeData = resp.data.list
        this.loading = false
        return
      })
    },
    // 计划类型下拉菜单触发
    handleScheme(command) {
      if (command.dictValue === null) {
        // const csId = this.$route.params.csId
        // this.state = ''
        // if (csId !== undefined && csId !== null) {
        //   this.getschemeByCsId(1)
        // } else {
        //   this.courseSchemeData = this.courseSchemes
        // }
        this.getschemeByCsId(1)
        // this.courseSchemeData = this.courseSchemes
        this.dropdown = command.dictLabel
        this.state = ''
        return
      }
      this.dropdown = command.dictLabel
      // 根据计划类型，课程设置ID，查询出计划列表
      // 从前端全部列表中查询
      const dictValue = command.dictValue
      this.courseSchemeData = this.courseSchemes.filter(item => item.schemeStatus === dictValue)
      this.state = ''
    },
    // 假删除
    fakeDelete(schemeId, createOrgId) {
      // 不是创建者或者负责人不能去删除
      const courseLeaders = JSON.parse(this.coursedetail.courseLeaders)
      if (this.user.orgId === createOrgId || this.user.orgId === courseLeaders[0]) {
        this.fakeDelete2(schemeId)
      }
    },
    // 假删除
    fakeDelete2(schemeId) {
      this.$confirm('是否确定删除该授课计划?', '删除', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          const ids = []
          ids.push(schemeId)
          // console.log('ids = ', ids)
          return courseSchemeApi.batchDelete(ids.toString())
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功'
          })
          this.getList(1)
        })
        .catch(err => {
          console.log(err)
        })
    },
    /** 初始化 */
    initCourseScheme() {
      this.courseScheme = {
        schemeId: null,
        csId: null,
        ctId: null,
        cateId: null,
        seq: '1',
        courseTitle: '',
        schemeTitle: '',
        schemeSubtitle: '',
        briefIntroduction: '',
        goals: '',
        audiences: '',
        recomIntro: '',
        giveCredit: '1',
        lessonCount: '',
        originPrice: '0',
        teacherIds: '',
        serviceInfo: '',
        publishMode: '1',
        learnMode: '1',
        courseStartTime: '',
        courseEndTime: '',
        maxMembers: '',
        schemeStatus: '0',
        publishedLessionCount: '0',
        taskCount: '1',
        compulsoryTaskCount: '1',
        memberCount: '0',
        schemeRating: '0',
        schemeCommentCount: '0',
        noteCount: '0',
        hitCount: '0',
        questionCount: '0',
        discussionCount: '0',
        materialCount: '0',
        buyCount: '0',
        isDefaultScheme: false,
        isFree: true,
        isBuyable: true,
        isShowMemberCount: true,
        isOpenExpiryNotify: true,
        isAllowedJoin: true,
        isLocked: false,
        isShowPromise: false,
        isRecommended: false,
        isHideUnpublishedLession: true,
        isAllowedSingleBuy: false,
        watchLimit: '1',
        openPeriod: null,
        daysNotifyBeforeBegin: '1',
        joinPassword: '',
        recommendedSeq: '0',
        recommendedTime: null,
        delFlag: false,
        createOrgId: this.user.orgId,
        orgId: null,
        remark: ''
      }
    }
  }
}
</script>
<style lang='scss' scoped>
.defualt-plan {
  width: 7rem;
  background-color: #177ed7;
  color: #fff;
  border-radius: 4px;
  font-size: 12px;
  line-height: 1;
  padding: 4px 6px;
}
.course-manage-header-info__type .default-single-span {
  top: 34px;
}

.cd-tag.cd-tag-blue {
  color: #fff;
  background-color: #177ed7;
}
.course-manage-header-info__type span {
  position: absolute;
  top: 46px;
}
.icon {
  // TODO： 触摸小手
  cursor: pointer;
}
.course-price {
  color: #ed3e3e;
  font-size: 14px;
  width: 1rem;
  height: 1rem;
}
.course-info {
  width: 100%;
  margin-left: 5rem;
  // height: 26px;
}
.course-title {
  width: 100%;
  // height: 26px;
}
.course-cover {
  width: 50px;
  margin-left: 1rem;
}
.course-cover img {
  margin-left: 0;
  width: 100%;
  height: 6rem;
  border-radius: 10%;
}
.course-left {
  width: 80%;
  // display: inline-block;;
}
.course-button {
  // margin-right: -18rem;
  // width: 20rem;
  display: inline-block;
  position: absolute;
  right: 50px;
  top: 30px;
}
// .el-main {
//   width: 80%;
//   // height: 500px;
//   margin: 0 auto;
// }
.all {
  font-size: 16px;
  padding: 0 25px;
  height: 35px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  color: #fff;
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  padding: 12px;
  background: #fff;
  margin: 0 32px;
  margin-bottom: 18px;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 14px;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
.course-publish-status--unpublished {
  background-color: #707070;
}
.course-publish-status {
  position: absolute;
  left: -6px;
  top: 28px;
  padding: 9px 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
}
.icon {
  width: 2.5em;
  height: 2.55em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-left: 4rem;
}
a {
  text-decoration: none;
}
.course-manage-header-info__title {
  margin-top: 4px;
  margin-bottom: 0;
  min-height: 5px;
  font-size: 16px;
  line-height: 1;
  font-weight: 500;
  width: 250px;
}
.ellipsis,
.text-overflow {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}
.course-manage-header-info {
  float: left;
  margin-left: 71px;
}
.course-publish-status--published {
  background-color: #18ad3b;
}

.course-publish-status {
  position: absolute;
  left: -6px;
  top: 28px;
  padding: 9px 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
}
.courses-manage-item .course-manage-header {
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 2px 2px 0 rgba(0, 0, 0, 0.06);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
}

.course-manage-header {
  position: relative;
  margin-bottom: 0;
  padding: 20px 32px 20px 24px;
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 0 2px 0 rgba(0, 0, 0, 0.06),
    0 0 2px 0 rgba(0, 0, 0, 0.1);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 0 2px 0 rgba(0, 0, 0, 0.06), 0 0 2px 0 rgba(0, 0, 0, 0.1);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 0 2px 0 rgba(0, 0, 0, 0.06), 0 0 2px 0 rgba(0, 0, 0, 0.1);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  background-color: #fff;
}
.cd-mb24 {
  margin-bottom: 24px !important;
}
.courses-manage-list {
  padding-left: 6px;
  list-style: none;
}

ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.cd-select .select-options > li:first-child {
  border-radius: 4px 4px 0 0;
}

.cd-select .select-options > li.checked,
.cd-select .select-options > li.checked:hover {
  background: #fafafa;
}
.cd-select .select-options > li {
  position: relative;
  padding: 16px;
  line-height: 1;
  color: rgba(0, 0, 0, 0.88);
  background: none;
  white-space: nowrap;
  display: block;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-select .select-options {
  top: 100%;
  left: 0;
  right: 0;
  z-index: 1000;
  display: none;
  border: none;
  text-align: left;
  padding: 0;
  margin: 0;
  max-height: 220px;
  overflow-x: hidden;
  overflow-y: auto;
  -webkit-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01),
    0 8px 8px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01),
    0 8px 8px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01), 0 8px 8px 0 rgba(0, 0, 0, 0.04);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  font-size: 12px;
  background-color: #fff;
  opacity: 0;
}

.cd-select .select-options,
.cd-select .select-value:after {
  position: absolute;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-select .select-value {
  padding: 5px 0 4px;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.88);
  border-bottom: 1px solid rgba(0, 0, 0, 0.16);
  padding-bottom: -1px;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.teaching-type-select {
  width: 276px;
  height: 34px;
}

.cd-select {
  position: relative;
  height: 30px;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.hide {
  display: none !important;
}
.cd-btn.cd-btn-default {
  color: rgba(0, 0, 0, 0.88);
  background: #ececec;
  border-color: #ececec;
}

.cd-btn.cd-btn-default,
.cd-btn.cd-btn-warning:active {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.cd-ml16 {
  margin-left: 16px !important;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

.cd-btn.cd-btn-primary {
  color: #fff;
  background: #e50112;
  border-color: #e50112;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
a {
  text-decoration: none;
}
a {
  color: #e50112;
}
.pull-right {
  float: right !important;
}
.cd-mb24 {
  margin-bottom: 24px !important;
}
.courseset-manage-padding {
  padding: 32px 0;
}

.courseset-manage-body {
  margin-top: 1px !important;
  min-height: 550px;
  background-color: #fff;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-content {
  position: relative;
  border-radius: 4px;
  margin-top: 24px;
  margin-bottom: 24px;
}
.course_content {
  padding-left: 0;
  padding-right: 0;
  // padding-right: 12px;
  margin: 0 auto;
  position: relative;
  border-radius: 4px;
  margin-top: 10px;
  margin-bottom: 24px;
  min-height: 500px;
}
</style>
