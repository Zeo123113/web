<!--
@description 课程全部学期
@author cgy
-->
<template>
  <div class="course_content">
    <div role="courseset-manage-courses" style="margin:0 32px">
      <div class="cd-mb24 clearfix">
        <div v-show="state === ''" class="pull-right">
          <div class="js-sort-group hidden-xs">
            <a class="cd-btn cd-btn-primary js-create-plan" @click="termManger(null)">创建学期</a>
            <!-- <button class="cd-btn cd-btn-default cd-ml16 js-sort-btn">调整顺序</button> -->
          </div>
        </div>
        <div id="select-single" class="cd-select teaching-type-select">
          <el-dropdown trigger="click" @command="handleScheme">
            <span class="el-dropdown-link">
              {{ dropdown }}
              <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                v-for="item in termTypeOptions"
                :key="item.dictValue"
                :label="item.dictValue"
                :command="item"
              >{{ item.dictLabel }}</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    </div>
    <section v-loading="loading">
      <ol class="db">
        <li v-for="(term,index) of courseTermData" :key="index" class="mod-qa-list">
          <div class="course-left">
            <ul style="display: flex;">
              <li>
                <!-- 课程封面 -->
                <div class="course-cover">
                  <img
                    :src="'http://fileserver:8888/' + term.courseCover"
                    class="img2 ml55"
                    onerror="this.src='http://fileserver:8888/group1/M00/00/00/J2Ouul7sNO6AGINfAAAKhBa2VH8659.png';this.onerror = null"
                  />
                </div>
              </li>
              <li>
                <div class="course-info">
                  <!-- 课程标题展示 -->
                  <div class="qt-tit click course-title">
                    <ul>
                      <li>{{ term.courseTitle }}</li>
                      <!-- 开课学期描述 -->
                      <li>{{ term.courseTerm }}</li>
                    </ul>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <!-- 按钮组 -->
          <div class="course-button">
            <el-tooltip content="学期管理" placement="bottom" effect="light">
              <svg class="icon" aria-hidden="true" @click="termManger(term)">
                <use xlink:href="#icon-chilunshezhi" />
              </svg>
            </el-tooltip>

            <el-dropdown>
              <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-shenglvehao" />
              </svg>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>
                  <a @click="forwardTerm(term)">查询计划</a>
                </el-dropdown-item>
                <el-dropdown-item>
                  <a @click="copyTerm(term)">复制</a>
                </el-dropdown-item>
                <el-dropdown-item>
                  <a @click="fakeDelete(term.ctId)">删除</a>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </li>
      </ol>
      <component
        :is="state"
        v-if="update"
        :course-term="courseTerm"
        :coursedetail="coursedetail"
        @getList="getList"
      ></component>
      <div v-if="state === '' && courseTermData.length < 1" class="nodata">
        <p>
          <svg class="icon icon-tishi" aria-hidden="true">
            <use xlink:href="#icon-tishi" />
          </svg>
        </p>
        <p>您还没有学期可管理，请先创建学期</p>
      </div>
    </section>
    <!-- <term-setting v-show="termShow" :course-term="courseTerm" @getList="getList" /> -->
    <!--分页-->
    <div v-if="courseTermData.length > 1" class="page_box mt30 pt10 mb10 tac">
      <el-pagination
        :current-page="pageIndex"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="courseTermData.length"
        prev-text="上一页"
        next-text="下一页"
        @current-change="getList"
      ></el-pagination>
    </div>
    <!--分页-->
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import defaultTerm from './defaultTerm'
import TermSetting from '../leftNav/TermSetting'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import courseTermApi from '@/api/course/courseManage/courseTerm'
export default {
  name: 'AllTerm',
  components: {
    defaultTerm,
    TermSetting
  },
  props: {
    coursedetail: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      update: true,
      pageSize: 10,
      pageIndex: 1,
      total: 1,
      termShow: false,
      loading: false,
      termTypeOptions: [{ 'dictValue': null, 'dictLabel': '全部学期' }],
      dropdown: '全部学期',
      courseTermData: [],
      courseTerms: [],
      state: '',
      courseTerm: {},
      isCreate: true
    }
  },
  computed: {
    ...mapGetters({
      user: 'user'
    })
  },
  watch: {
    '$route'(to, from) {
      this.$router.go(0)
    }
  },
  created() {
    // 课程计划类型字典获取
    this.getDataByType('course_term_termtype').then(response => {
      const all = { 'dictValue': null, 'dictLabel': '全部学期' }
      this.termTypeOptions = [all, ...response.data]
    })
    this.getList()
  },
  methods: {
    // 复制学期
    copyTerm(term) {
      this.courseTerm.csId = this.$route.params.csId
      this.courseTerm = { ...term }
      this.courseTerm.ctId = -1
      this.state = 'defaultTerm'
    },
    // 获取课程学期列表
    getList() {
      this.loading = true
      // this.termShow = false
      this.state = ''
      // 获取课程设置详情
      const csId = this.$route.params.csId
      // 根据课程设置ID获取课程学期列表
      courseTermApi.getTermPageByCId(csId, 1, 10).then(resp => {
        this.courseTerms = resp.data.list
        this.courseTermData = this.courseTerms
        this.loading = false
      })
    },
    // 没有课程学期展示
    isShow(courseTermData) {
      if (this.state !== '') {
        return false
      }
      return courseTermData == null || !courseTermData.length
    },
    getCourseSchemeByCtId(ctId) {
      // 根据ctId，获取授课方案
      courseSchemeApi.getCourseSchemeByCourseTermId(ctId).then(resp => {
        if (resp.data === [] || resp.data.length === 0) {
          return true
        }
        return false
      })
    },
    // 假删除
    fakeDelete(ctId) {
      // 先判断要删除的学期下有无计划，否则不能删除
      // 根据ctId，获取授课方案
      courseSchemeApi.getCourseSchemeByCourseTermId(ctId).then(resp => {
        if (resp.data.length > 0) {
          this.$message({
            type: 'info',
            message: '课程学期下面有授课计划，不能删除'
          })
          return false
        } else {
          this.$confirm('是否确定删除该课程学期?', '删除', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          })
            .then(() => {
              const ids = []
              ids.push(ctId)
              // console.log('ids = ', ids)
              return courseTermApi.batchDelete(ids.toString())
            })
            .then(() => {
              this.$message({
                type: 'success',
                message: '课程学期删除成功'
              })
              this.getList()
            })
            .catch(err => {
              console.log(err)
            })
        }
      })
    },
    setRouteCourse() {
      this.$emit('setRouteCourse')
    },
    // 查看计划
    forwardTerm(term) {
      // console.log('term.csId = ', term.csId)
      // console.log('term.ctId = ', term.ctId)
      // // 路由跳转
      // this.$router.push({  // 核心语句
      //   path: `/courseManger/${term.csId}/AllScheme/${term.ctId}`
      // })
      this.$emit('getSchemeByTerm', term)
    },
    // 学期管理
    termManger(courseTerm) {
      this.update = false
      if (courseTerm == null || courseTerm === '' || courseTerm === undefined) {
        this.initCourseTerm()
        // this.courseTerm.courseTitle = this.coursedetail.courseTitle
        // this.courseTerm.courseSubtitle = this.coursedetail.courseSubtitle
        this.courseTerm.courseTitle = this.coursedetail.courseTitle
        this.courseTerm.courseSubtitle = this.coursedetail.courseSubtitle
        this.courseTerm.briefIntroduction = this.coursedetail.briefIntroduction
        this.courseTerm.audiences = this.coursedetail.audiences
        this.courseTerm.goals = this.coursedetail.goals
        this.courseTerm.csId = this.coursedetail.csId
        this.courseTerm.courseCover = this.coursedetail.courseCover
        this.courseTermData = []
        this.state = 'defaultTerm'
        this.update = true
        return
      }
      if (this.state === 'defaultTerm') {
        this.state = ''
        this.courseTermData = this.courseTerms
        this.update = true
        return
      } else {
        // this.courseTermData = this.courseTermData.filter(item => item.ctId === courseTerm.ctId)
        this.courseTermData = []
        this.courseTermData.push(courseTerm)
        // console.log('courseTermData = ', this.courseTermData)
        this.courseTerm = courseTerm
        this.courseTerm.orgId = this.user.orgId
        this.state = 'defaultTerm'
        this.update = true
      }
    },
    // 学期类型下拉菜单触发
    handleScheme(command) {
      console.log('command = ', command)
      if (command.dictValue === null) {
        this.courseTermData = this.courseTerms
        this.dropdown = command.dictLabel
        this.state = ''
        return
      }
      this.dropdown = command.dictLabel
      // 根据学期类型，课程设置ID，查询出学期列表
      // 从前端全部列表中查询termType
      const dictValue = command.dictValue
      this.courseTermData = this.courseTerms.filter(item => item.termType === dictValue)
    },
    /** 初始化课程学期对象 */
    initCourseTerm() {
      this.courseTerm = {
        ctId: -1,
        csId: null,
        courseTitle: this.coursedetail.courseTitle,
        courseSubtitle: this.coursedetail.courseSubtitle,
        termType: '0',
        courseTerm: '',
        courseStartTime: null,
        courseEndTime: null,
        teachingMode: '0',
        schemeType: '0',
        examMode: '0',
        markingMode: '0',
        briefIntroduction: this.coursedetail.briefIntroduction,
        courseCover: '',
        goals: '',
        audiences: '',
        recomIntro: '',
        propaedeutics: '',
        courseRefMaterials: '',
        requirements: '',
        hoursPerWeek: '',
        commonQuestions: '',
        delFlag: false,
        createOrgId: null,
        orgId: null,
        createBy: '',
        createTime: null,
        updateBy: '',
        updateTime: '',
        remark: '',
        termTitle: ''
      }
    }
  }
}
</script>
<style lang='scss' scoped>
a {
  // TODO： 触摸小手
  cursor: pointer;
}
.icon {
  // TODO： 触摸小手
  cursor: pointer;
}
.course-price {
  color: #ed3e3e;
  font-size: 14px;
  width: 1rem;
  height: 1rem;
}
.course-price {
  color: #ed3e3e;
  font-size: 14px;
  width: 1rem;
  height: 1rem;
}
.course-info {
  width: 100%;
  margin-left: 5rem;
  // height: 26px;
}
.course-title {
  width: 100%;
  // height: 26px;
}
.course-cover {
  margin-left: 1rem;
}
.course-cover img {
  margin-left: 0;
  width: 10rem;
  height: 6rem;
  border-radius: 10%;
}
.course-left {
  width: 80%;
}
.course-button {
  display: inline-block;
  position: absolute;
  right: 50px;
  top: 30px;
}
// .el-main {
//   width: 80%;
//   // height: 500px;
//   margin: 0 auto;
// }
.all {
  font-size: 16px;
  padding: 0 25px;
  height: 35px;
  line-height: 30px;
}
.comp-filter-bar {
  position: relative;
  display: block;
  text-align: left;
  margin-bottom: 20px;
}
.all-background {
  color: #fff;
  background: #e50012;
}
.mod-qa-list {
  position: relative;
  padding: 12px;
  background: #fff;
  margin: 0 32px;
  margin-bottom: 18px;
  box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1);
  border-radius: 5px;
}
.nodata {
  padding: 150px 0;
  text-align: center;
}
.nodata {
  p {
    font-size: 16px;
    color: #9199a1;
    text-align: center;
    line-height: 24px;
    margin-bottom: 4px;
  }
}
.icon-tishi {
  font-size: 48px;
  color: #b2b8bd;
  line-height: 48px;
}
.qt-tit {
  font-size: 14px;
  word-break: break-all;
  word-wrap: break-word;
  color: #07111b;
  line-height: 24px;
}
.content {
  color: #4d555d;
  font-size: 16px;
  line-height: 22px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
.xcontent {
  padding-left: 20px;
  border-left: 2px solid #d9dde1;
  color: #545c63;
  font-size: 12px;
  line-height: 20px;
  word-wrap: break-word;
  word-break: break-all;
  overflow: hidden;
}
// .ml124 {
//   margin-left: 124px;
// }
.r {
  float: right;
}
.static-color {
  color: #93999f;
}
.mr {
  margin-right: 30px;
}
.click {
  cursor: pointer;
}
.icon {
  width: 2.5em;
  height: 2.55em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  margin-left: 4rem;
}
a {
  text-decoration: none;
}
.course-manage-header-info__title {
  margin-top: 4px;
  margin-bottom: 0;
  min-height: 5px;
  font-size: 16px;
  line-height: 1;
  font-weight: 500;
  width: 250px;
}
.ellipsis,
.text-overflow {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}
.course-manage-header-info {
  float: left;
  margin-left: 71px;
}
.course-publish-status--published {
  background-color: #e50112;
}

.course-publish-status {
  position: absolute;
  left: -6px;
  top: 28px;
  padding: 9px 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
}
.courses-manage-item .course-manage-header {
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 2px 2px 0 rgba(0, 0, 0, 0.06);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
}

.course-manage-header {
  position: relative;
  margin-bottom: 0;
  padding: 20px 32px 20px 24px;
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 0 2px 0 rgba(0, 0, 0, 0.06),
    0 0 2px 0 rgba(0, 0, 0, 0.1);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 0 2px 0 rgba(0, 0, 0, 0.06), 0 0 2px 0 rgba(0, 0, 0, 0.1);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 0 2px 0 rgba(0, 0, 0, 0.06), 0 0 2px 0 rgba(0, 0, 0, 0.1);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  background-color: #fff;
}
.cd-mb24 {
  margin-bottom: 24px !important;
}
.courses-manage-list {
  padding-left: 6px;
  list-style: none;
}

ol,
ul {
  margin-top: 0;
  margin-bottom: 10px;
}
.cd-select .select-options > li:first-child {
  border-radius: 4px 4px 0 0;
}

.cd-select .select-options > li.checked,
.cd-select .select-options > li.checked:hover {
  background: #fafafa;
}
.cd-select .select-options > li {
  position: relative;
  padding: 16px;
  line-height: 1;
  color: rgba(0, 0, 0, 0.88);
  background: none;
  white-space: nowrap;
  display: block;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-select .select-options {
  top: 100%;
  left: 0;
  right: 0;
  z-index: 1000;
  display: none;
  border: none;
  text-align: left;
  padding: 0;
  margin: 0;
  max-height: 220px;
  overflow-x: hidden;
  overflow-y: auto;
  -webkit-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01),
    0 8px 8px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01),
    0 8px 8px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.01), 0 8px 8px 0 rgba(0, 0, 0, 0.04);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  font-size: 12px;
  background-color: #fff;
  opacity: 0;
}

.cd-select .select-options,
.cd-select .select-value:after {
  position: absolute;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-select .select-value {
  padding: 5px 0 4px;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.88);
  border-bottom: 1px solid rgba(0, 0, 0, 0.16);
  padding-bottom: -1px;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.teaching-type-select {
  width: 276px;
  height: 34px;
}

.cd-select {
  position: relative;
  height: 30px;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.hide {
  display: none !important;
}
.cd-btn.cd-btn-default {
  color: rgba(0, 0, 0, 0.88);
  background: #ececec;
  border-color: #ececec;
}

.cd-btn.cd-btn-default,
.cd-btn.cd-btn-warning:active {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
.cd-ml16 {
  margin-left: 16px !important;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

.cd-btn.cd-btn-primary {
  color: #fff;
  background: #e50112;
  border-color: #e50112;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
a {
  text-decoration: none;
}
a {
  color: #e50112;
}
.pull-right {
  float: right !important;
}
.cd-mb24 {
  margin-bottom: 24px !important;
}
.courseset-manage-padding {
  padding: 32px 0;
}

.courseset-manage-body {
  margin-top: 1px !important;
  min-height: 550px;
  background-color: #fff;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-content {
  position: relative;
  border-radius: 4px;
  margin-top: 24px;
  margin-bottom: 24px;
}
.course_content {
  padding-left: 0;
  padding-right: 0;
  // padding-right: 12px;
  margin: 0 auto;
  position: relative;
  border-radius: 4px;
  margin-top: 10px;
  margin-bottom: 24px;
  min-height: 500px;
}
</style>
