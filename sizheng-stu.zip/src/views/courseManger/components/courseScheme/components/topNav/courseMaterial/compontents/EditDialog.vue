<!--
@description 课程资源文件管理--添加修改弹出框组件
@author zhouhuan
-->
<template>
  <el-dialog
    :title="dialog.title"
    :visible.sync="dialog.show"
    :before-close="closeDialog"
    width="50%"
    @open="open"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="80px">
      <el-row>
        <el-col v-if="dialog.tag" :span="12">
          <el-form-item label="课程学期" prop="ctId">
            <el-select
              v-model="form.ctId"
              placeholder="请选择课程学期"
              clearable
              @change="courseTermChange"
            >
              <el-option
                v-for="courseTerm in courseTermOptions"
                :key="courseTerm.ctId"
                :label="courseTerm.courseTerm"
                :value="courseTerm.ctId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.tag" :span="12">
          <el-form-item label="教学方案" prop="schemeId">
            <el-select
              v-model="form.schemeId"
              placeholder="请选择教学方案"
              clearable
              @change="courseSchemeChange"
            >
              <el-option
                v-for="courseScheme in courseSchemeOptions"
                :key="courseScheme.schemeId"
                :label="courseScheme.schemeTitle"
                :value="courseScheme.schemeId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.tag" :span="12">
          <el-form-item label="授课单元" prop="unitId">
            <el-select v-model="form.unitId" placeholder="请选择授课单元" clearable>
              <el-option
                v-for="courseUnit in courseUnitOptions"
                :key="courseUnit.unitId"
                :label="courseUnit.unitTitle"
                :value="courseUnit.unitId"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="资料标题" prop="materialTitle">
            <el-input v-model="form.materialTitle" style="width:217px;" placeholder="请输入资料标题"></el-input>
          </el-form-item>
        </el-col>
        <el-col v-if="dialog.tag" :span="24">
          <el-form-item label="文件类型" prop="fileType">
            <el-radio-group v-model="fileType" size="small">
              <el-radio label="1" border>视频文件</el-radio>
              <el-radio label="2" border>学生文件</el-radio>
              <el-radio label="3" border>系统文件</el-radio>
              <el-radio label="4" border>音频文件</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
        <el-col v-if="!dialog.tag" :span="12">
          <el-form-item label="文件URL" prop="fileUrl">
            <el-input v-model="form.fileUrl" placeholder="正在等待视频转码、加密" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col v-if="!dialog.tag" :span="12">
          <el-form-item label="文件名称" prop="fileName">
            <el-input v-model="form.fileName" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col v-if="!dialog.tag" :span="12">
          <el-form-item label="文件MIME" prop="fileMime">
            <el-input v-model="form.fileMime" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col v-if="!dialog.tag" :span="12">
          <el-form-item label="文件大小" prop="fileSize">
            <el-input v-model="form.fileSize" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否公开" prop="isPublic">
            <el-radio-group v-model="form.isPublic" style="padding-top: 10px;padding-bottom: 10px;">
              <el-radio :label="true">是</el-radio>
              <el-radio :label="false">否</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否下载" prop="isCanDownload">
            <el-radio-group
              v-model="form.isCanDownload"
              style="padding-top: 10px;padding-bottom: 10px;"
            >
              <el-radio :label="true">是</el-radio>
              <el-radio :label="false">否</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="备注" prop="remark">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" size="mini" @click="submitForm">确 定</el-button>
      <el-button size="mini" @click="closeDialog">取 消</el-button>
    </div>
    <!-- 上传文件弹出框 -->
    <file-upload-dialog
      ref="FileUploadDialog"
      :system-file-uploade="systemFileUploade"
      :student-file-uploade="studentFileUploade"
      :video-file-uploade="videoFileUploade"
      :audio-file-uploade="audioFileUploade"
      :file-info="fileInfo"
      @fileInfo="fileUploadInfo"
    />
  </el-dialog>
</template>

<script>
import FileUploadDialog from './FileUploadDialog'
// import courseSetApi from '@/api/course/courseManage/courseSet'
// import courseTermApi from '@/api/course/courseManage/courseTerm'
import courseSchemeApi from '@/api/course/courseManage/courseScheme'
import courseUnitApi from '@/api/course/courseManage/courseUnit'
import courseMaterialApi from '@/api/course/courseManage/courseMaterial'

export default {
  name: 'EditDialog',
  components: { FileUploadDialog },
  props: {
    dialog: {
      type: Object,
      required: true
    },
    form: {
      type: Object,
      required: true
    },
    courseTermOptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      courseSchemeOptions: [],
      courseUnitOptions: [],
      fileType: '',
      studentFileUploade: {
        show: false
      },
      systemFileUploade: {
        show: false
      },
      videoFileUploade: {
        show: false
      },
      audioFileUploade: {
        show: false
      },
      fileInfo: {
        fileId: {},
        fileTag: '',
        md5: '',
        fileName: '',
        fileOriginalName: '',
        filePath: '',
        fileUrl: '',
        fileType: '',
        fileSize: 0,
        createBy: '',
        createTime: '',
        updateBy: '',
        updateTime: ''
      },
      // 表单校验
      rules: {
        csId: [{ required: true, message: '课程设置不能为空', trigger: 'blur' }],
        ctId: [{ required: true, message: '课程学期不能为空', trigger: 'blur' }],
        schemeId: [{ required: true, message: '教学方案不能为空', trigger: 'blur' }],
        unitId: [{ required: true, message: '授课单元不能为空', trigger: 'blur' }],
        materialTitle: [{ required: true, message: '资料名称不能为空', trigger: 'blur' }]
      }
    }
  },
  watch: {
    fileType: function(newVal) {
      if (newVal === '1') {
        this.videoFileUploade.show = true
      }
      if (newVal === '2') {
        this.studentFileUploade.show = true
      }
      if (newVal === '3') {
        this.systemFileUploade.show = true
      }
      if (newVal === '4') {
        this.audioFileUploade.show = true
      }
    }
  },
  methods: {
    open() {
    },
    // 得到上传后的文件信息
    fileUploadInfo(val) {
      console.log(val)
      this.form.fileId = val.fileIdHexString
      this.form.fileName = val.fileName
      this.form.fileMime = val.md5
      this.form.fileUrl = val.fileUrl
      this.form.fileSize = val.fileSize
      console.log(this.form)
    },
    /** 清除表单验证信息 */
    resetForm(refName) {
      if (this.$refs[refName] !== undefined) {
        this.fileType = ''
        this.$refs[refName].resetFields()
      }
    },
    /** 关闭弹框 */
    closeDialog() {
      this.dialog.show = false
      this.courseSchemeOptions = []
      this.courseUnitOptions = []
    },
    /** 课程学期选择发生变化时触发 */
    courseTermChange(value) {
      this.form.schemeId = undefined
      this.form.unitId = undefined
      if (value != null && value !== '') {
        courseSchemeApi.getCourseSchemeByCourseTermId(value).then(response => {
          this.courseSchemeOptions = response.data
        })
      }
    },
    /** 教学方案选择发生变化时触发 */
    courseSchemeChange(value) {
      this.form.unitId = undefined
      if (value != null && value !== '') {
        courseUnitApi.getRefUnitBySchemeId(value).then(response => {
          this.courseUnitOptions = response.data
        })
      }
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          if (this.form.materialId !== undefined) {
            courseMaterialApi.updateCourseMaterial(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                this.dialog.show = false
                this.$emit('reset')
              } else {
                this.$message.error('修改失败')
              }
            })
          } else {
            courseMaterialApi.addCourseMaterial(this.form).then(response => {
              if (response.code === 0) {
                this.$message({
                  message: '添加成功',
                  type: 'success'
                })
                this.dialog.show = false
                this.$emit('reset')
              } else {
                this.$message.error('添加失败')
              }
            })
          }
        }
      })
    }
  }
}
</script>
