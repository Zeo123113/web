<!--
@description 课程资源文件管理
@author cgy
-->
<template>
  <div class="course_content">
    <div class="courseset-manage-body__title">文件管理</div>
    <div class="courseset-manage-body__content cd-mt32">
      <!--搜索框-->
      <header-search
        :course-term-options="courseTermOptions"
        :query-params="queryParams"
        :date-range="dateRange"
      ></header-search>
      <!-- 结束搜索框 -->
      <!--表格外按钮组-->
      <div class="btn-group">
        <el-button size="small" type="primary" icon="el-icon-search" @click="handleQuery">搜索</el-button>
        <el-button size="small" icon="el-icon-refresh" @click="resetQuery">重置</el-button>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-plus"
          :disabled="!button.includes('course/courseMaterial/add')"
          @click="handleAdd"
        >新增</el-button>
        <el-button
          size="small"
          type="danger"
          icon="el-icon-delete"
          :disabled="deldisabled || !button.includes('course/courseMaterial/delete')"
          @click="handleBatchDelete"
        >删除</el-button>
      </div>
      <!--结束表格外按钮组-->
      <!-- 表格展示 -->
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        style="width: 100%"
        @selection-change="handleSelectionChange"
        @select-all="selectAll"
      >
        <el-table-column type="selection" width="50" />
        <el-table-column
          label="资料标题"
          prop="materialTitle"
          align="center"
          min-width="150"
          show-overflow-tooltip
        />
        <el-table-column
          label="文件存储URL"
          prop="fileUrl"
          align="center"
          min-width="200"
          show-overflow-tooltip
        />
        <el-table-column
          label="文件名称"
          prop="fileName"
          align="center"
          min-width="200"
          show-overflow-tooltip
        />
        <el-table-column
          label="文件MIME"
          prop="fileMime"
          align="center"
          min-width="150"
          show-overflow-tooltip
        />
        <el-table-column label="文件大小" prop="fileSize" align="center" min-width="120" sortable />
        <el-table-column
          label="是否公开"
          prop="isPublic"
          align="center"
          min-width="80"
          :formatter="isPublicTypeFormat"
        />
        <el-table-column
          label="是否可下载"
          prop="isCanDownload"
          align="center"
          min-width="100"
          :formatter="isCanDownloadTypeFormat"
        />
        <el-table-column label="创建者" prop="createBy" align="center" min-width="100" />
        <el-table-column label="创建时间" prop="createTime" align="center" sortable min-width="160" />
        <el-table-column label="更新者" prop="updateBy" align="center" min-width="100" />
        <el-table-column label="更新时间" prop="updateTime" align="center" sortable min-width="160" />
        <el-table-column
          label="备注"
          align="center"
          prop="remark"
          min-width="200"
          :show-overflow-tooltip="true"
        />
        <el-table-column label="操作" fixed="right" align="center" min-width="200">
          <template slot-scope="scope">
            <el-button
              type="success"
              size="mini"
              :disabled="!button.includes('course/courseMaterial/update')"
              @click="handleUpdate(scope.row)"
            >编辑</el-button>
            <el-button
              type="danger"
              size="mini"
              :disabled="!button.includes('course/courseMaterial/delete')"
              @click="handleDelete(scope.row)"
            >删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 表格结束 -->
      <!-- 分页控件-->
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      ></pagination>
      <!-- 分页控件结束-->
      <!-- 添加或修改菜单弹出框 -->
      <edit-dialog
        ref="dialog"
        :course-term-options="courseTermOptions"
        :form="form"
        :dialog="dialog"
        @reset="handleQuery"
      />
      <!-- 添加或修改菜单弹出框结束 -->
    </div>
  </div>
</template>
<script>
import courseTermApi from '@/api/course/courseManage/courseTerm'
import courseMaterialApi from '@/api/course/courseManage/courseMaterial'
import pagination from '@/components/Pagination/index'
import USER_CONST from '@/constant/user-const'
import HeaderSearch from './compontents/HeaderSearch'
import EditDialog from './compontents/EditDialog'
import { mapGetters } from 'vuex'
export default {
  components: { pagination, HeaderSearch, EditDialog },
  props: {
    coursedetail: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      courseTermOptions: [],
      // 分页记录总条数默认是1
      total: 1,
      // 默认从第一页开始
      pageNum: 1,
      // 默认每页显示的记录条数
      pageSize: USER_CONST.PAGESIZE,
      // 查询条件
      queryParams: {
        orgId: this.coursedetail.orgId,
        csId: this.coursedetail.csId,
        ctId: undefined,
        schemeId: undefined,
        unitId: undefined,
        materialTitle: undefined,
        createBy: undefined,
        beginTime: undefined,
        endTime: undefined
      },
      // 查询时间范围
      dateRange: {
        time: ''
      },
      // 数据表格展示数据
      tableData: [],
      // 新增修改的弹框表单
      form: {},
      // 批量删除按钮在未选择时禁用状态
      deldisabled: true,
      // 选中删除的列表
      ids: [],
      // 是否点击全部删除
      isSelectAll: false,
      // 弹出框
      dialog: {
        title: '',
        show: false,
        tag: true
      }
    }
  },
  computed: {
    ...mapGetters({
      button: 'button'
    })
  },
  // 钩子函数页面加载时调用数据
  created() {
    this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    courseTermApi.getTermPageByCId(this.coursedetail.csId, this.pageNum, this.pageSize).then(response => {
      this.courseTermOptions = response.data.list
    })
  },
  methods: {
    // 是否公开数据字典翻译
    isPublicTypeFormat(row) {
      return row.isPublic === true ? '是' : '否'
    },
    // 是否可下载数据字典翻译
    isCanDownloadTypeFormat(row) {
      return row.isCanDownload === true ? '是' : '否'
    },
    // 获得tableData,带有分页
    fetchData(queryParams, pageNum, pageSize) {
      courseMaterialApi.listCourseMaterial(queryParams, pageNum, pageSize).then(response => {
        this.tableData = response.data.list
        this.total = response.data.total
      })
    },
    // 根据查询条件查询按钮
    handleQuery() {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    // 处理分页组件上面的操作
    pageQuery() {
      this.fetchData(this.queryParams, this.pageNum, this.pageSize)
    },
    // 重置搜索表单
    resetQuery() {
      this.queryParams = {
        orgId: this.coursedetail.orgId,
        csId: this.coursedetail.csId,
        ctId: undefined,
        schemeId: undefined,
        unitId: undefined,
        materialTitle: undefined,
        createBy: undefined,
        beginTime: undefined,
        endTime: undefined
      }
      this.dateRange.time = ''
      this.tableData = null
    },
    // 新增编辑表单重置
    reset() {
      this.form = {
        materialId: undefined,
        orgId: this.coursedetail.orgId,
        ctId: undefined,
        csId: this.coursedetail.csId,
        schemeId: undefined,
        unitId: undefined,
        materialTitle: undefined,
        fileUrl: undefined,
        fileId: undefined,
        fileName: undefined,
        fileMime: undefined,
        fileSize: undefined,
        mediaLength: undefined,
        isPublic: true,
        isCanDownload: true,
        remark: undefined
      }
    },
    // 点击新增按钮
    handleAdd() {
      this.reset()
      this.dialog.title = '新增课程资料文件'
      this.dialog.tag = true
      this.dialog.show = true
      this.$refs.dialog.resetForm('form')
    },
    // 点击编辑按钮
    handleUpdate(row) {
      this.form = row
      this.dialog.title = '修改课程资料文件'
      this.dialog.tag = false
      this.dialog.show = true
      this.$refs.dialog.resetForm('form')
    },
    // 单条删除按钮
    handleDelete(row) {
      this.$confirm('是否确认删除课程资料名为 "' + row.materialTitle + '" 的数据项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(function() {
          return courseMaterialApi.delCourseMaterial(row.materialId)
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '课程资料删除成功'
          })
          this.fetchData(this.queryParams, this.pageNum, this.pageSize)
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 批量删除
    handleBatchDelete() {
      this.$confirm('您确定要批量删除已选定的数据项?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          if (this.isSelectAll) {
            return courseMaterialApi.batchDeleteByCriteria(this.queryParams)
          } else {
            return courseMaterialApi.batchDelete(this.ids)
          }
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '批量删除课程资料成功'
          })
          this.fetchData(this.queryParams, this.pageNum, this.pageSize)
          this.deldisabled = true // 删除按钮处于禁用状态
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 点击取消保存按钮
    cancel() {
      this.open = false
    },
    // 选中多个id
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.materialId)
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        // 删除按钮可用状态
        this.deldisabled = false
      }
    },
    // 当点击全选时则通过条件全部删除
    selectAll(selection) {
      this.ids = selection.map(item => item.materialId)
      if (selection.length === 0) {
        this.deldisabled = true
      } else {
        // 删除按钮可用状态
        this.deldisabled = false
        this.isSelectAll = true
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.course_content {
  padding-left: 0;
  padding-right: 0;
  margin: 0 auto;
  position: relative;
  border-radius: 4px;
  margin-top: 10px;
  margin-bottom: 24px;
  padding: 32px;
  background-color: #fff;
  min-height: 500px;
  .courseset-manage-body__title {
    padding-bottom: 24px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.06);
    font-size: 16px;
    line-height: 1;
    color: rgba(0, 0, 0, 0.56);
    font-weight: 500;
  }
  .courseset-manage-body__content {
    margin-top: 32px;
  }
}
.width-full {
  width: 100%;
}
.select2-container {
  margin-left: 0;
  margin-right: 0;
  border: 0;
  padding: 0;
  float: none;
}
.select2-container {
  margin: 0;
  padding: 0;
  border: none;
  position: relative;
  display: inline-block;
  zoom: 1;
  *display: inline;
  vertical-align: middle;
}
.cd-btn.cd-btn-primary,
.cd-btn.cd-btn-primary:focus,
.cd-btn.cd-btn-primary:hover {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-btn.cd-btn-primary {
  color: #fff;
  background: #e50112;
  border-color: #e50112;
}
.cd-btn {
  display: inline-block;
  text-align: center;
  vertical-align: middle;
  touch-action: manipulation;
  cursor: pointer;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  font-size: 14px;
  font-weight: 500;
  padding: 9px 12px;
  line-height: 1;
  border: 1px solid transparent;
  background: none;
  border-radius: 4px;
  outline: none;
}
img {
  vertical-align: top;
  border: none;
}
@media (min-width: 992px) {
  .col-md-8 {
    width: 66.66666667%;
  }

  .col-md-1,
  .col-md-10,
  .col-md-11,
  .col-md-12,
  .col-md-2,
  .col-md-3,
  .col-md-4,
  .col-md-5,
  .col-md-6,
  .col-md-7,
  .col-md-8,
  .col-md-9 {
    float: left;
  }
}
label + .cd-radio-group .cd-radio {
  margin-top: 12px;
  margin-bottom: 4px;
}

.course-manage-info .cd-radio {
  min-width: 76px;
  color: rgba(0, 0, 0, 0.88);
  font-weight: 400;
}
.cd-radio {
  position: relative;
  padding-left: 20px;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  display: inline-block;
  margin-bottom: 0;
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cd-radio-group {
  margin-bottom: 16px;
}
@media (min-width: 992px) {
  .col-md-8 {
    float: left;
    width: 66.66666667%;
  }
}
.width-full {
  width: 100%;
}
.select2-container {
  margin-left: 0;
  margin-right: 0;
  border: 0;
  padding: 0;
  float: none;
}
.select2-container,
.select2-drop,
.select2-search,
.select2-search input {
  -webkit-box-sizing: border-box;
  -khtml-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -ms-box-sizing: border-box;
  box-sizing: border-box;
}
.select2-container {
  margin: 0;
  padding: 0;
  border: none;
  position: relative;
  display: inline-block;
  zoom: 1;
  *display: inline;
  vertical-align: middle;
}
.course-manage-info .form-group {
  margin-bottom: 24px;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.cd-mt40 {
  margin-top: 40px !important;
}
.form-group {
  margin-bottom: 15px;
}
.course-manage-info .form-group {
  margin-bottom: 24px;
}

.form-horizontal .form-group {
  margin-bottom: 30px;
}
.form-horizontal .form-group {
  margin-left: -10px;
  margin-right: -10px;
}
.form-group {
  margin-bottom: 15px;
}
@media screen and (min-width: 1200px) {
  .cd-container {
    width: 1200px;
  }
  .cd-container {
    padding-left: 12px;
    padding-right: 12px;
    margin: 0 auto;
  }
  .container {
    width: 1160px;
  }
}
.course-manage-info {
  position: relative;
}

.courseset-manage-padding {
  padding: 32px;
}
.courseset-manage-body {
  margin-top: 1px !important;
  min-height: 550px;
  background-color: #fff;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}
.cd-content {
  position: relative;
  border-radius: 4px;
  margin-top: 24px;
  margin-bottom: 24px;
}

.courseset-manage-body__title {
  padding-bottom: 24px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.06);
  font-size: 16px;
  line-height: 1;
  color: rgba(0, 0, 0, 0.56);
  font-weight: 500;
}
.cd-mt32 {
  margin-top: 32px !important;
}
@media screen and (max-width: 992px) {
  .control-label-required {
    float: left;
  }
}
.w50 {
  width: 227px;
}
</style>
