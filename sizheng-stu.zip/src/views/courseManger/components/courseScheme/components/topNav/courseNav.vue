<!--
@description 课程设置
@author cgy
-->
<template>
  <div class="course_content" style="padding: 0">
    <div class="cd-content courseset-manage-body">
      <!-- 左边导航栏 -->
      <div
        class="cd-sidebar locked js-sidenav"
        :class="open? '':'cd_sidebar_notopen'"
        data-course-length="1"
      >
        <ul class="cd-sidebar__list">
          <div class="js-sidenav-course-menu">
            <li
              class="cd-sidebar__item active"
              :class="{'content_active': contentActive == 'CourseSetting'}"
            >
              <a @click="clickLeftNav('CourseSetting')">基础设置</a>
            </li>
            <li
              class="cd-sidebar__item active"
              :class="{'content_active': contentActive == 'CourseChapter'}"
            >
              <a @click="clickLeftNav('CourseChapter')">大纲目录</a>
            </li>
            <li
              class="cd-sidebar__item active"
              :class="{'content_active': contentActive == 'CourseNotie'}"
            >
              <a @click="clickLeftNav('CourseNotie')">课程公告</a>
            </li>
            <li
              class="cd-sidebar__item active"
              :class="{'content_active': contentActive == 'Knowledge'}"
            >
              <a @click="clickLeftNav('Knowledge')">课程知识点</a>
            </li>
          </div>
        </ul>
      </div>
      <!-- main内容 -->
      <div class="folding" :class="open? '':'folding_notopen'">
        <div class="ui-layout-toggler" @click="open = !open">
          <i v-if="open" class="el-icon-caret-left"></i>
          <!--收起-->
          <i v-else class="el-icon-caret-right"></i>
          <!--展开-->
        </div>
      </div>
      <!-- <BaseSetting /> -->
      <component :is="state" :class="open ? '':'cl_main_notopen'" :coursedetail="coursedetail" />
    </div>
  </div>
</template>
<script>
import CourseNotie from '../leftNav/courseNotice/index'
import CourseSetting from './courseSetting'
import CourseChapter from '../leftNav/chapter/index'
import Knowledge from '../leftNav/knowledge/index'
export default {
  name: 'CourseNav',
  components: {
    CourseSetting,
    CourseNotie,
    CourseChapter,
    Knowledge
  },
  props: {
    coursedetail: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 绿色下划线
      contentActive: 'CourseSetting',
      state: 'CourseSetting',
      // 展开/收起表示（默认false为收起，true为展开）
      open: true
    }
  },
  methods: {
    getList() {
      this.$emit('getList')
    },
    // 点击左边导航栏--基础设置
    clickLeftNav(state) {
      this.contentActive = state
      this.state = state
    }
  }
}
</script>
<style lang="scss" scoped>
// TODO：内容
.content_active {
  border-left: 5px solid #e50112;
}
.cl_main_notopen {
  margin-left: 8px;
}
.cd_sidebar_notopen {
  display: none;
}
.folding_notopen {
  left: 0px !important;
}
.folding {
  position: absolute;
  left: 192px;
  width: 8px;
  height: 100%;
  background: #fafafa;
  border: 1px solid #eee;
  border-width: 0;
  display: flex;
}
.ui-layout-toggler {
  border: 1px solid #eee;
  background-color: #eee;
  border-width: 1px 0;
  height: 100%;
  width: 8px;
  align-self: center;
  i {
    display: block;
    margin-top: 450px;
  }
}
li {
  cursor: pointer;
  display: list-item;
  text-align: -webkit-match-parent;
}
.cd-sidebar__list .cd-sidebar__item > a {
  padding: 5px 24px 5px 50px;
  border-left: 4px solid transparent;
  display: block;
  color: rgba(0, 0, 0, 0.56);
  font-weight: 500;
  font-size: 14px;
}

a {
  text-decoration: none;
}
.task-list-header {
  position: relative;
  margin-bottom: 24px;
  padding: 0 6px 0 24px;
  height: 56px;
  line-height: 56px;
  -webkit-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02),
    0 0 2px 0 rgba(0, 0, 0, 0.04), 0 2px 2px 0 rgba(0, 0, 0, 0.06);
  -moz-box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.02), 0 0 2px 0 rgba(0, 0, 0, 0.04),
    0 2px 2px 0 rgba(0, 0, 0, 0.06);
  color: rgba(0, 0, 0, 0.56);
  font-size: 14px;
}

.task-list-header {
  padding-top: 7px;
  padding-bottom: 10px;
  font-size: 16px;
  line-height: 42px;
  background-color: #fff;
  margin-bottom: 18px;
}
.cd-sidebar__list .cd-sidebar__heading {
  list-style-type: none;
  color: rgba(0, 0, 0, 0.32);
  font-size: 12px;
  // padding: 18px 24px;
}

.cd-sidebar__list li {
  list-style: none;
  line-height: 1;
}
.cd-sidebar__list .cd-sidebar__item {
  padding: 12px 0;
}

.cd-sidebar__list li {
  list-style: none;
  line-height: 1;
}
.cd-sidebar__list {
  padding-left: 0;
  margin-top: 0;
  margin-bottom: 0;
}
.cd-sidebar {
  width: 200px;
  background: #fff;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
  padding: 16px 0;
  position: absolute;
  border-radius: 4px 0 0 4px;
}
.courseset-manage-body {
  margin-top: 1px !important;
  min-height: 550px;
  background-color: #fff;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  -moz-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01),
    0 4px 4px 0 rgba(0, 0, 0, 0.04);
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.01), 0 4px 4px 0 rgba(0, 0, 0, 0.04);
}

.cd-content {
  position: relative;
  border-radius: 4px;
  margin-top: 30px;
  margin-bottom: 24px;
}
.cd-container {
  padding-left: 12px;
  padding-right: 12px;
  margin: 0 auto;
}
.course_content {
  padding-left: 0;
  padding-right: 0;
  // padding-right: 12px;
  margin: 0 auto;
  position: relative;
  border-radius: 4px;
  margin-top: 10px;
  margin-bottom: 24px;
}
</style>
