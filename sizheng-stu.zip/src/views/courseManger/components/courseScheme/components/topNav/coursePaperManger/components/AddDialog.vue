<!--
@description 试卷修改/添加 包含试题列表的编辑
@author CPY
-->
<template>
  <div>
    <!--试卷基本信息-->
    <el-dialog
      v-loading="loading"
      :title="questionManger ? '试题管理' : paper.paperId ? '修改试卷':'添加试卷'"
      :visible.sync="dialogBaseVisible"
      width="60%"
      @open="getQuestionList"
      @close="resetForm('paper')"
    >
      <el-form ref="paper" :model="paper" :rules="rules" label-width="100px">
        <div v-if="!questionManger">
          <el-form-item label="试卷名称" prop="paperTitle">
            <el-input v-model="paper.paperTitle" placeholder="请输入试卷名称" autocomplete="off"></el-input>
          </el-form-item>
          <el-row>
            <el-col :span="6">
              <el-form-item label="是否共享" prop="isShare">
                <el-switch v-model="paper.isShare" active-color="#13ce66" inactive-color="#ff4949"></el-switch>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="详细描述">
            <el-input
              v-model="paper.description"
              type="textarea"
              :autosize="{ minRows: 2, maxRows: 4}"
              placeholder="请输入内容"
            ></el-input>
          </el-form-item>
          <el-form-item label="备注">
            <el-input
              v-model="paper.remark"
              type="textarea"
              :autosize="{ minRows: 2, maxRows: 4}"
              placeholder="请输入内容"
            ></el-input>
          </el-form-item>
        </div>
        <div v-if="paper.paperId && questionManger">
          <el-button size="small" icon="el-icon-plus" type="text" @click="handleAddList()">手动选题</el-button>
          <el-button size="small" icon="el-icon-check" type="text" @click="automaticQuestion()">自动抽题</el-button>
          <QuestionList
            ref="questionList"
            :question-type-options="questionTypeOptions"
            :questionlist="questionlist"
          ></QuestionList>
          <br />
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="savePaper('paper')">保存</el-button>
        <el-button size="mini" @click="resetForm('paper')">取消</el-button>
      </div>
    </el-dialog>
    <!--结束试卷基本信息-->
    <!--选择随机生成弹窗-->
    <el-dialog
      title="随机抽题"
      width="70%"
      :visible.sync="questionListDialog"
      top
      class="random-dialog"
      @open="openRandom"
      @close="closeQuestionList()"
    >
      <!--查询form-->
      <el-form
        ref="numberValidateForm"
        class="form-inline"
        :inline="true"
        :model="extractingSelect"
        label-width="100px"
      >
        <el-form-item label="课程章节">
          <treeselect
            v-model="extractingSelect.chapterId"
            :options="chapterTreeOptions"
            style="display: inline-block;width:220px;"
            placeholder="请选择章节"
          />
        </el-form-item>
        <el-form-item label="试题类型" prop="tqTypeId">
          <el-select v-model="extractingSelect.tqTypeId" clearable placeholder="请选择题目类型">
            <el-option
              v-for="dict in questionTypeOptions"
              :key="dict.dictValue"
              :label="dict.dictLabel"
              :value="dict.dictValue"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="试题难度" prop="diffLevel">
          <el-select v-model="extractingSelect.diffLevel" clearable placeholder="请选择试题难度">
            <el-option
              v-for="dict in diffLevelOptions"
              :key="dict.dictValue"
              :label="dict.dictLabel"
              :value="dict.dictValue"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="知识点" prop="knowledgeId">
          <el-select v-model="extractingSelect.knowledgeId" class="knowledge_select" clearable placeholder="请选择知识点">
            <el-option
              v-for="item in knowledgeOptions"
              :key="item.knowledgeId"
              :label="item.knowledgeName"
              :value="item.knowledgeId"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">查询</el-button>
        </el-form-item>
        <el-form-item label="试题数量" prop="num">
          {{ total }} 道
          抽取<el-input v-model="extractingSelect.randomNum" type="number" :min="0" :max="total" class="el-input-num"></el-input>道
          <!--非材料题设置分数-->
          <span>每题<el-input v-model="globalValueForm.value" type="number" :min="0" :step="0.5" :max="10" class="el-input-num"></el-input>分</span>
          <el-button type="primary" style="margin-left:10px;" @click="submitRandom()">抽取</el-button>
        </el-form-item>
      </el-form>
      <!-- 分页控件-->
      <!--查询form结束-->
      <!--查询结果-->
      <el-table
        v-loading="randomloading"
        :data="bankList"
        tooltip-effect="light"
        row-key="tqId"
      >
        <!-- @select-all="checkboxSelect"
        @select="checkboxSelect" -->
        <el-table-column type="selection" align="center" min-width="50" />
        <el-table-column label="编号" type="index" align="center" min-width="120" />
        <el-table-column
          label="试题类型"
          prop="tqTypeId"
          :formatter="tqTypeFormat"
          sortable
          align="center"
          min-width="100"
        />
        <el-table-column
          label="题目简述"
          prop="title"
          align="center"
          min-width="200"
          show-overflow-tooltip
        />
        <el-table-column
          v-if="isExtracting"
          label="操作"
          align="center"
          min-width="150"
          fixed="right"
          style="height:90px"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              size="mini"
              @click="handleRemove(scope.row)"
            >移除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0 && !isExtracting"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="pageQuery"
      />
      <!--结束查询结果-->
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeQuestionList()">取消</el-button>
        <el-button size="small" type="primary" @click="addRandQuestion()">确 定</el-button>
      </span>
    </el-dialog>
    <!--结束选择随机生成弹窗-->
    <!--题库选题-->
    <QuestionBank
      ref="questionBank"
      :course-id="Number(this.$route.params.csId)"
      :question-ids="questionIds"
      :dialog-base-visible.sync="SelectdialogBaseVisible"
      @saveQuestion="saveQuestion"
      @saveMATERIALQuestion="saveMATERIALQuestion"
    ></QuestionBank>
  </div>
</template>
<script>
import paperApi from '@/api/exambank/paper'
import bankApi from '@/api/exambank/bank'
import QUESTIONTYPE from '@/constant/question-type-const'
import QuestionList from './components/AddQuestionList'
import QuestionBank from './components/question-bank/index.vue'
import Treeselect from '@riophae/vue-treeselect'
import chapterApi from '@/api/exambank/chapter'
import knowledgeApi from '@/api/exambank/knowledge'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import EXAMBANKCONST from '@/constant/exambank-const'
import pagination from '@/components/Pagination/index'
export default {
  components: {
    QuestionBank,
    QuestionList,
    Treeselect,
    pagination
  },
  props: {
    // 打开弹窗标志
    dialogBaseVisible: {
      type: Boolean,
      default: false
    },
    // 是编辑还是试题管理
    questionManger: {
      type: Boolean,
      default: false
    },
    // 试卷对象
    paper: {
      type: Object,
      required: true
    },
    coursedetail: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 选择添加试题类型弹窗
      isQuestionTypeDialogVisible: false,
      // 试题类型列表
      questionTypeOptions: [],
      // 生成方式弹窗
      addQuestionType: false,
      // 试题生成方式
      generation: '',
      // 选择随机生成弹窗
      questionListDialog: false,
      // 选择的试题类型(单选题)
      selectedRadio: QUESTIONTYPE.SELECT,
      // 材料题
      MATERIAL: QUESTIONTYPE.MATERIAL,
      // 试题列表
      questionlist: [],
      // 试题列表存在试题类型
      questionOptions: [],
      // 加载
      loading: false,
      // 默认分页参数
      pageNum: 1,
      // 条数限制
      pageSize: EXAMBANKCONST.PAGESIZE,
      // 抽取总数
      total: 0,
      // 验证规则，
      rules: {
        // 试卷名称
        paperTitle: [
          { required: true, message: '请输入试卷名称', trigger: 'blur' },
          { min: 3, max: 100, message: '请输入大于3个字符小于100个字符', trigger: 'blur' }
        ]
      },
      SelectdialogBaseVisible: false,
      // 已有试题列表
      questionIds: null,
      // 抽取试题选择实体
      extractingSelect: {
        tqTypeId: QUESTIONTYPE.SELECT,
        chapterId: null,
        knowledgeId: null,
        diffLevel: EXAMBANKCONST.EASY,
        orgId: null,
        isExamAllowed: true,
        isShare: true,
        // 随机数量
        randomNum: null
      },
      // 知识点数组
      knowledgeOptions: [],
      // 章节数组
      chapterTreeOptions: [],
      // 试题难度
      diffLevelOptions: [],
      // 自动抽取查询出的试题列表
      bankList: [],
      // 自动抽取抽取出的试题列表
      bankRandomList: [],
      // 随机抽题弹窗加载
      randomloading: false,
      // 抽取试题的全局分数
      globalValueForm: {
        value: null,
        material: null
      },
      // 抽取试题的提交数组
      randomList: [],
      // 是否抽取操作
      isExtracting: false
    }
  },
  created() {
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.questionTypeOptions = response.data
    })
    // 试题类型字典获取
    this.getDataByType('exambank_question_type').then(response => {
      this.questionTypeOptions = response.data
      this.questionTypeOptions.forEach(item => {
        if (item.dictValue === this.MATERIAL) {
          const index = this.bankList.indexOf(item)
          this.questionTypeOptions.splice(index, 1)
        }
      })
    })
    // 树形章节
    chapterApi.getChapterTreeByCourseId(this.$route.params.csId).then(response => {
      this.chapterTreeOptions = response.data
    })
    knowledgeApi.getKnownledgeListByCourseId(this.$route.params.csId).then(response => {
      this.knowledgeOptions = response.data
    })
    // 试题难度字典获取
    this.getDataByType('exambank_diff_level').then(response => {
      this.diffLevelOptions = response.data
    })
  },
  methods: {
    /** 试题类型字典翻译 */
    tqTypeFormat(row) {
      return this.selectDictLabel(this.questionTypeOptions, row.tqTypeId.toString())
    },
    saveMATERIALQuestion(checkedQuestions) {
      checkedQuestions.forEach(item => {
        item.paperId = this.paper.paperId
      })
      paperApi.addMaterial(checkedQuestions).then(resp => {
        this.checkedQuestions = []
        this.checkList = []
        if (resp.code === 0) {
          this.getQuestionList()
          this.$message({
            message: '保存成功',
            type: 'success'
          })
        } else {
          this.$message({
            message: '保存失败',
            type: 'error'
          })
        }
      })
    },
    // 添加试题
    handleAddList() {
      this.SelectdialogBaseVisible = true
      this.selectedRadio = '0'
      this.generation = 2
    },
    // 分页查询
    pageQuery(pagePara) {
      this.pageNum = pagePara.page
      this.pageSize = pagePara.limit
      this.submitForm()
    },
    // 打开抽取弹窗
    openRandom() {
      this.extractingSelect = {
        tqTypeId: QUESTIONTYPE.SELECT,
        chapterId: null,
        knowledgeId: null,
        diffLevel: EXAMBANKCONST.EASY
      }
    },
    // 随机抽取
    submitRandom() {
      this.randomloading = true
      this.isExtracting = true
      this.extractingSelect.orgId = this.$store.getters.user.orgId
      bankApi.randomlist(this.extractingSelect).then(resp => {
        if (resp.code === 0) {
          this.bankRandomList = resp.data
          this.total = resp.data.length
          this.randomloading = false
        }
      })
    },
    // 随机查询结果
    submitForm() {
      this.randomloading = true
      this.extractingSelect.orgId = this.$store.getters.user.orgId
      this.isExtracting = false
      bankApi.listQuestions(this.extractingSelect, this.pageNum, this.pageSize).then(resp => {
        if (resp.code === 0) {
          this.bankList = resp.data.list
          this.total = resp.data.total
          this.randomloading = false
        }
      })
    },
    // 自动抽题列表的移除
    handleRemove(row) {
      const index = this.bankList.indexOf(row)
      this.bankList.splice(index, 1)
    },
    // 保存表单
    savePaper(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.questionManger) {
            this.questionlist.forEach(item => {
              item.paperId = this.paper.paperId
            })
            paperApi.update(this.questionlist).then(resp => {
              if (resp.code === 0) {
                this.$message({
                  type: 'success',
                  message: '修改成功'
                })
              }
            })
            this.resetForm('paper')
          } else {
          // 如果paperId存在，即是修改弹窗
            if (this.paper.paperId) {
              this.paper.updateBy = this.$store.getters.user.loginName
              paperApi.editPaper(this.paper).then(resp => {
                this.resetForm('paper')
                if (resp.code === 0) {
                  this.$message({
                    type: 'success',
                    message: '修改成功'
                  })
                } else {
                  this.$message({
                    message: resp.msg,
                    type: 'error'
                  })
                }
              })
            } else {
              this.paper.createBy = this.$store.getters.user.loginName
              this.paper.orgId = this.$store.getters.user.org.orgId
              paperApi.addPaper(this.paper).then(resp => {
                this.resetForm('paper')
                console.log(resp)
                if (resp.code === 0) {
                  this.$message({
                    type: 'success',
                    message: '添加成功'
                  })
                } else {
                  this.$message({
                    message: resp.msg,
                    type: 'error'
                  })
                }
              })
            }
          }
        }
      })
    },
    // 重置表单
    resetForm(formName) {
      this.$emit('update:dialogBaseVisible', false)
      this.$emit('reGetList')
      if (this.paper.paperId !== 0) {
        this.$nextTick(() => {
          this.questionlist = []
          this.questionOptions = []
        })
      }
    },
    // 清空试题列表的amount和value值
    clearBQuestionBlank() {
      this.questionlist = []
      this.bQuestionListBlank = []
    },
    // 关闭试题列表
    closeQuestionList() {
      this.questionListDialog = false
    },
    // 添加试题类型
    addRandQuestion() {
      if (this.isExtracting) {
        // 给提交试题列表赋值
        this.bankRandomList.forEach(item => {
          this.randomList.push({
            paperId: this.paper.paperId,
            tqId: item.tqId,
            tqTypeId: item.tqTypeId,
            diffLevel: item.diffLevel,
            value: this.globalValueForm.value,
            // 试题数量
            amount: 1
          })
        })
        paperApi.addQuestionList(this.randomList, this.generation).then(resp => {
          if (resp.code === 0) {
            this.questionListDialog = false
            this.$message({
              message: '添加成功',
              type: 'success'
            })
            this.getQuestionList()
          } else {
            this.$message({
              message: '添加失败',
              type: 'error'
            })
          }
        })
      } else {
        this.closeQuestionList()
      }
    },
    // 获取试卷试题列表
    getQuestionList() {
      if (this.paper.paperId) {
        paperApi.getQuestionByPaperId(this.paper.paperId).then(resp => {
          if (resp.code === 0) {
            this.loading = false
            this.questionlist = resp.data
          }
        })
      } else {
        this.paper.paperTitle = null
        this.paper.description = null
        this.paper.keepsecret = null
        this.paper.isShare = null
      }
    },
    // 保存试题列表
    saveQuestion(list) {
      let groupSeq = 1
      if (this.questionlist.length > 0) {
        groupSeq = Number(this.questionlist[this.questionlist.length - 1].groupSeq) + 1
      }
      list.forEach(item => {
        item.groupSeq = groupSeq
        groupSeq++
      })
      this.questionlist = this.questionlist.concat(list)
      // 按照试题类型排序
      for (let i = 0; i < this.questionlist.length - 1; i++) {
        for (let j = 0; j < this.questionlist.length - i - 1; j++) {
          if (this.questionlist[j].tqTypeId > this.questionlist[j + 1].tqTypeId) {
            const temp = this.questionlist[j]
            this.questionlist[j] = this.questionlist[j + 1]
            this.questionlist[j + 1] = temp
          }
        }
      }
      list.forEach(item => {
        this.questionIds = this.questionIds + ',' + item.tqId
      })
    },
    automaticQuestion() {
      this.generation = 1
      this.questionListDialog = true
    }
  }
}
</script>
<style scoped>
/* .el-dialog__wrapper >>> .el-dialog {
    width: 55%;
} */
.condition {
  font-size: 16px;
  margin-bottom: 15px;
  display: inline-block;
}
.Item {
  margin-top: 15px;
  margin-bottom: 15px;
}
.knowledge_select {
  width: 100%;
}
.el-input-num {
  width: 100px;
  margin: 0 8px;
}
</style>
<style scoped>
.knowledge_select >>> .el-select__tags {
  overflow-x: hidden;
}
.random-dialog /deep/ .el-dialog /deep/ .el-dialog__body {
  height: 81vh;
  overflow-y: auto;
}
.random-dialog >>> .el-dialog {
  margin-bottom: 0px;
}
</style>
