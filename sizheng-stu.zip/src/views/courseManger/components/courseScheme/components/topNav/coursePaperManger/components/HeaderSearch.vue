<!--
@description 试卷管理头部搜索
@author CPY
-->
<template>
  <div class="sort">
    <el-form ref="paperSelect" :inline="true" :model="paperSelect" class="demo-form-inline">

      <el-form-item label="课程学期" prop="termId">
        <el-select v-model="paperSelect.termId" placeholder="请选择课程学期" clearable>
          <el-option
            v-for="item in courseTermOptions"
            :key="item.ctId"
            :label="item.courseTerm"
            :value="item.ctId"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="试卷名称" prop="paperTitle">
        <el-input v-model="paperSelect.paperTitle" placeholder="请输入试卷名称关键字" clearable></el-input>
      </el-form-item>
      <!-- <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          unlink-panels
          :picker-options="pickerOptions"
          style="width:217px;"
        ></el-date-picker>
      </el-form-item> -->
      <!-- <el-form-item label="试卷共享" prop="isShare">
        <el-switch
          v-model="paperSelect.isShare"
          active-color="#13ce66"
          inactive-color="#ff4949"
        >
        </el-switch>
      </el-form-item> -->
      <el-form-item>
        <el-button
          type="primary"
          icon="el-icon-search"
          :disabled="!button.includes('bank/paper/list')"
          size="small"
          @click="onSubmit"
        >搜索</el-button>
        <el-button
          icon="el-icon-refresh"
          :disabled="!button.includes('bank/paper/recycle')"
          size="small"
          @click="handleRecycleBin()"
        >{{ paperSelect.delFlag?'关闭回收站':'打开回收站' }}</el-button>
        <el-button
          type="primary"
          icon="el-icon-plus"
          :disabled="!button.includes('bank/paper/add')"
          size="small"
          @click="addPaper()"
        >添加</el-button>
        <el-button
          type="danger"
          icon="el-icon-delete"
          :disabled="multselect || !button.includes('bank/paper/deletebatch')"
          size="small"
          @click="deleteBatch()"
        >{{ paperSelect.delFlag?'恢复': '删除' }}</el-button>
        <el-button
          type="danger"
          :disabled="!paperSelect.delFlag|| !button.includes('bank/paper/delempty') || paperIds.length<=0"
          size="small"
          @click="handleEmpty()"
        >
          <svg class="icon" aria-hidden="true">
            <use xlink:href="#icon-qingkonghuancun" />
          </svg>
          &nbsp;清空
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  name: 'HeaderSearch',
  components: {
  },
  props: {
    // 封装对象
    paperSelect: {
      type: Object,
      default: null
    },
    // 按钮权限
    button: {
      type: Array,
      required: true
    },
    // 学期列表
    courseTermOptions: {
      type: Array,
      required: true
    },
    multselect: {
      type: Boolean,
      required: true
    },
    paperIds: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      // 初始化日期快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      // 日期
      dateRange: '',
      orgOptions: [],
      courseOptions: []
    }
  },
  /** 监听日期变化 */
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.paperSelect.beginTime = val[0]
        this.paperSelect.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  mounted() {
    // 获取当前用户的组织机构树

  },
  methods: {
    /** 点击搜索 */
    onSubmit() {
      this.$emit('handleQuery', this.paperSelect)
    },
    handleRecycleBin() {
      this.paperSelect.delFlag = !this.paperSelect.delFlag
      this.$emit('handleQuery', this.paperSelect)
    },
    /** 重置按钮操作 */
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.dateRange = ''
      this.paperSelect.beginTime = null
      this.paperSelect.endTime = null
      this.$emit('handleQuery', this.paperSelect)
    },
    addPaper() {
      this.$emit('addPaper')
    },
    deleteBatch() {
      this.$emit('deleteBatch')
    },
    handleEmpty() {
      this.$emit('handleEmpty')
    }
  }
}
</script>
<style scoped>
</style>
