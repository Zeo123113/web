<!--
@description 试卷管理--题库选题--头部搜索组件
@author cpy
-->
<template>
  <el-form ref="searchForm" :model="queryParams" :inline="true" class="form-inline">
    <el-form-item label="课程章节">
      <treeselect
        v-model="queryParams.chapterId"
        :options="chapterOptions"
        style="display: inline-block;width:220px;"
        placeholder="请选择章节"
      />
    </el-form-item>
    <el-form-item label="知识点">
      <el-select v-model="queryParams.kidList" filterable clearable multiple>
        <el-option
          v-for="item in knowledgeOptions"
          :key="item.knowledgeId"
          :label="item.knowledgeName"
          :value="item.knowledgeId"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="试题难度">
      <el-select v-model="queryParams.diffLevel" clearable>
        <el-option
          v-for="item in diffLevelOptions"
          :key="item.dictValue"
          :label="item.dictLabel"
          :value="item.dictValue"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="题目简述" prop="title">
      <el-input
        v-model="queryParams.title"
        placeholder="请输入题目简述"
        size="small"
        clearable
      />
    </el-form-item>
    <el-form-item label="试题共享" prop="isShare">
      <el-switch
        v-model="queryParams.isShare"
        active-color="#13ce66"
        inactive-color="#ff4949"
      >
      </el-switch>
    </el-form-item>
    <el-form-item label="创建时间">
      <el-date-picker
        v-model="dateRange"
        value-format="yyyy-MM-dd"
        type="daterange"
        range-separator="-"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        unlink-panels
        :picker-options="pickerOptions"
        size="small"
        style="width:217px;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        icon="el-icon-search"
        size="mini"
        @click="handleQuery"
      >搜索</el-button>
      <el-button
        icon="el-icon-refresh"
        size="mini"
        @click="handleRecycleBin('searchForm')"
      >重置</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
import Treeselect from '@riophae/vue-treeselect'
import chapterApi from '@/api/exambank/chapter'
import knowledgeApi from '@/api/exambank/knowledge'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  name: 'HeaderSearch',
  components: {
    Treeselect
  },
  props: {
    queryParams: {
      type: Object,
      required: true
    },
    courseOptions: {
      type: Array,
      required: true
    },
    coursedetail: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      // 日期时间左边快捷键
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      dateRange: '',
      chapterOptions: [],
      diffLevelOptions: [],
      knowledgeOptions: []
    }
  },
  watch: {
    dateRange: function(val) {
      if (val != null) {
        this.queryParams.beginTime = val[0]
        this.queryParams.endTime = val[1]
      } else {
        this.dateRange = ''
      }
    }
  },
  created() {
    chapterApi.getChapterTreeByCourseId(this.coursedetail.csId).then(response => {
      this.chapterOptions = response.data
      this.knowledgeOptions = []
      this.queryParams.chapterId = null
      this.queryParams.kidList = null
    })
    knowledgeApi.getKnownledgeListByCourseId(this.coursedetail.csId).then(response => {
      this.knowledgeOptions = response.data
      this.queryParams.kidList = null
    })
    // 试题难度数据字典获取
    this.getDataByType('exambank_diff_level').then(response => {
      this.diffLevelOptions = response.data
    })
  },
  methods: {
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.kidList = JSON.stringify(this.queryParams.kidList)
      this.$emit('handleQuery', this.queryParams)
    },
    /** 点击了回收站 */
    handleRecycleBin(formName) {
      this.$refs[formName].resetFields()
      this.dateRange = ''
      this.queryParams.beginTime = null
      this.queryParams.endTime = null
      this.$emit('handleQuery', this.queryParams)
    }
  }
}
</script>
<style scoped>
.el-select >>> .el-select__tags{
  overflow-x: hidden;
}
</style>
